								
	#define MaxCnt 256 //8bit							
								
	RsltAllDUTCtnr							
		TPG::T_ADC()						
	{							
		TestConditions.apply();//Timing set						
		RsltAllDUTCtnr result;						
								
		int	test_id=1201;					
								
		CW_Close("SW1;SW13;SW14"); 						
		timer.wait(1e-3);						
		MMXH_PMU_Set("VDDH_mmxh_pmu",VSIM_,"3.3V",R7V,M240mA,"240.0mA","-200.0mA",CLOSE_,ON_);						
		DPIN_PMU_Set("EN_mdm", VSIM_,"0.0V",R6V,M2mA,"2.0mA","-2.0mA",CLOSE_,ON_);						
		DPIN_Levelset("I2CPins","1.8V","0.4V","0.8V","0.8V",CLOSE_,ON_);						
		timer.wait(1e-3); //1ms						
								
		//#########################################						
		OFCArray<ValDUT> ADC_READ(1024,"0;0");						
		int     StepCnt = MaxCnt;						
		double  Set_voltage1 = 0; 						
		double  Set_voltage2 = 2.5;						
		double  Arr_Voltage1[MaxCnt];						
		memset(Arr_Voltage1,0,sizeof(Arr_Voltage1));  
		//memset(_Out_opt_bytecapcount_(_Size) void * _Dst, _In_ int _Val, _In_ size_t _Size); 몇 개 캡처할지?, 입력값, 사이즈  		
								
		double  step_voltage = (double)(Set_voltage2 - Set_voltage1) / (double)MaxCnt;	//Aalog Step					
								
		for(StepCnt = 0; StepCnt < MaxCnt; StepCnt++)						
		{						
			double Input_voltage = Set_voltage1 + ((double)StepCnt * step_voltage);	//초기값 + Step 전압				
								
			DPIN_PMU_Set("EN_mdm", VSIM_,Input_voltage,R6V,M2mA,"2.0mA","-2.0mA");					
			timer.wait(1e-3); //1ms					
								
			ADC_READ[StepCnt] =I2C_Read(0x3D);					
		}						
								
		double INL[MaxCnt];						
		double DNL[MaxCnt];						
								
		int    mMinus = 2;						
		int    ArrCnt = MaxCnt - (mMinus *2);		//왜 2의 n승 -1 이 아닌가..				
		int    sadd = mMinus - 1;					//start address? 0은 0이고 1부터 의미가 있으니까.
		int    eadd = MaxCnt  - (mMinus +1) ;		//end address?		256 - (2+1)..? 왜 3이나 빼지.
								
		ValDUT		data_inl_out;				
		ValDUT		data_dnl_out;				
								
		for(ItrDUTs itrDut(DUT_ACTIVE); !itrDut.isDone(); itrDut++)						
		{						
			ValDUT BValue = ADC_READ[sadd][*itrDut].getAsDouble();	//최소값.
			ValDUT mValue = ADC_READ[eadd][*itrDut].getAsDouble();  //최대값.	
								
			int mMin = BValue[*itrDut];					
			int mMax = mValue[*itrDut];					
								
			double DATA_VLSB = ((double)mMax- (double)mMin) / ArrCnt;//아날로그 값의 최대-최소 / 최대 개수
			if (DATA_VLSB == 0) DATA_VLSB = 1;					
								
			double MAXINL = 9999;					
			double MAXDNL = 9999;					
								
			//#####################################					
			//####### INL/ DNL ####################					
			//#####################################					
			memset(INL,9999,sizeof(INL));					
			memset(DNL,9999,sizeof(DNL));					
								
			int k = 0;					
			for(int cnt = sadd;cnt <= eadd;cnt++) 		//cnt = sadd(= mMinus - 1 = 2-1)			
			{					
				BValue = ADC_READ[cnt-1][*itrDut].getAsDouble(); 	// 그 전 Step 값		
				mValue = ADC_READ[cnt][*itrDut].getAsDouble();	// 	현재 Step 값.		
								
				int orgval = BValue[*itrDut];	//			
				int val = mValue[*itrDut];		//		
								
				INL[k] = ((k * DATA_VLSB )+ (double)mMin - (double)val) / DATA_VLSB;	//Step 별 차이	(수식대로는 아니지만)	
				DNL[k] = (((double)val - (double)orgval) / DATA_VLSB);					//Step 별 차이	 이게 INL 아닌가?			
				k++;				
			}					
			
			MAXINL = 0;					
			MAXDNL = 0;					
			for(int i = 1; i < ArrCnt-1; i++)					
			{					
				if(MAXINL < fabs(INL[i])) MAXINL = fabs(INL[i]);				
				if(MAXDNL < fabs(DNL[i])) MAXDNL = fabs(DNL[i]);				
			}					
			data_inl_out[*itrDut] = MAXINL;					
			data_dnl_out[*itrDut] = MAXDNL;					
		}						
		
		// clean up						
		DPIN_Levelset("I2CPins","1.6V","0.0V","0.8V","0.8V",OPEN_,OFF_);						
		DPIN_PMU_Set("PULLUP_mdm",VSIM_,"0.0V",R6V,M2mA,"2.0mA","-2.0mA",OPEN_,OFF_);						
		DPIN_PMU_Set("EN_mdm", VSIM_,"0.0V",R6V,M2mA,"2.0mA","-2.0mA",OPEN_,OFF_);						
		MMXH_PMU_Set("VDDH_mmxh_pmu",VSIM_,"0.0V",R7V,M240mA,"240.0mA","-200.0mA",OPEN_,OFF_);						
		timer.wait(1e-3); //1ms						
								
		CW_Open("SW1;SW13;SW14");						
								
		result |= Judge(test_id,"ADC_INL",      "ADC_LS.INL",  data_inl_out,"SoftBins.BIN12"); if(RscDUTs(DUT_ACTIVE).isEmpty())return result;test_id++;						
		result |= Judge(test_id,"ADC_DNL",      "ADC_LS.DNL",  data_dnl_out,"SoftBins.BIN12"); if(RscDUTs(DUT_ACTIVE).isEmpty())return result;test_id++;						
								
		return result;						
	} // T_ADC							
