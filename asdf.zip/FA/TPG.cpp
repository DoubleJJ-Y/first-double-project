﻿
#include "AT/RDK/TestFunction.h"
#include "AT/RDK/RDK_Automotive.h"

#include "TPG_ph.h"
#include "AT/IPSModule/IATIPS_TimerTriggerAWGResource.h"
#include "AT/IPSModule/IATIPS_PBTriggerResource.h"
#include "AT/AnalogRFCmn/IATGeneratorResource.h"
#include "AT/AnalogRFCmn/IATReceiverResource.h"

using namespace OASIS;
using namespace AT;
using namespace AT::ATF;
using namespace rdk;
using namespace rdkenum;

// Global Object and Variable Definition
OFCStringArray_t	MaskAlarms;
OFCStringArray_t	UnmaskAlarms;

double  V = 1e-0;
double mV = 1e-3;
double  A = 1e-0;
double mA = 1e-3;
double uA = 1e-6;
double  S = 1e-0;
double mS = 1e-3;
double uS = 1e-6;
double  Hz = 1e-0;
double KHz = 1e+3;
double MHz = 1e+6;
double pct = 1e-2;

int test_id = 0;

int dut_int;
int NUMSITE;
ValDUT dut_int_VD;
OFCString dut_string;

///////////////////////////// FT & QA Select ///////////////////////////
#if 1
    #define FT_TEST
#endif
#if 0
    #define QA_TEST
#endif
///////////////////////////// FT & QA Select ///////////////////////////

int en_search = 0;
int en_trim = 1;

/////////////////  Enable flag  ///////////////////
//	RscUserVar aaa("en_disable","search_Flag");
//   if( aaa.getValueAsInt() == 1) en_search = 1;
//	else en_search = 0;
//
//	RscUserVar bbb("en_disable","trim_Flag");
//  if( bbb.getValueAsInt() == 1) en_trim = 1;
//	else en_trim = 0;
////////////////////////////////////////////////////



OFCString act_site;
//---------------------------------------------------
// Global Object and Variable Definition
double VBG_target = 1.2015; //KTB8316 V
double VREF_EAOUT_target = 0.6; //KTB8316 V
double IBIAS_target = 0.5*1e-6; //KTB8316 A
double RSNS_target = 30*1e-6; //KTB8316 A
double FOSC_target = 1000000; //KTB8316 Hz
double HSCL_target = 0.750; //KTB8316 A
double VCL_target = 0.600; //KTB8316 A
double ZCS_target = 0.050; //KTB8316 A
double TON_target = 3000000; //KTB8316 Hz
//---------------------------------------------------

int Timming_Speed = 50000 * 3; // It means T_H_LB in Test Plan 30KHz. //15M Maximum - If 18M -> ZCS Delta Fail

// Leakage Pre
OFCArray<ValDUT> ILK_VIN_PRE(1,100); 
OFCArray<ValDUT> ILK_MODE_PRE_H(1,100); 
OFCArray<ValDUT> ILK_MODE_PRE_L(1,100); 
OFCArray<ValDUT> ILK_EN_PRE_H(1,100); 
OFCArray<ValDUT> ILK_EN_PRE_L(1,100); 
OFCArray<ValDUT> ILK_LX_PRE_H(1,100); 
OFCArray<ValDUT> ILK_LX_PRE_L(1,100);
OFCArray<ValDUT> ILK_VOUT_PRE_H(1,100); 
OFCArray<ValDUT> ILK_VOUT_PRE_L(1,100); 

ValDUT vbg_code = 0;
ValDUT vref_eaout_code = 0;
ValDUT ibias_code = 0;
ValDUT rsns_code = 0;
ValDUT fosc_code = 0;
ValDUT hscl_code = 0;
ValDUT vcl_code = 0;
ValDUT zcs_code = 0;
ValDUT ton_code = 0;

ValDUT VHEN1 = 0;
ValDUT VHEN2 = 0;
ValDUT VHEN3 = 0;
ValDUT VHEN4 = 0;
ValDUT VHEN5 = 0;

//VIN BURN 
ValDUT VIEN = 0;
ValDUT VOEN = 0;


//ReadBack Part - global
ValDUT RD_OTP40_47;
ValDUT RD_OTP41_03;
ValDUT RD_OTP41_47;
ValDUT RD_OTP42_02;
ValDUT RD_OTP42_47;
ValDUT RD_OTP43_03;
ValDUT RD_OTP43_47;
ValDUT RD_OTP47_05;
ValDUT RD_OTP48_04;

//Trim Flag // 1 = //fresh, 0 = burned
ValDUT EN_OTP40_47;
ValDUT EN_OTP41_03;
ValDUT EN_OTP41_47;
ValDUT EN_OTP42_02;
ValDUT EN_OTP42_47;
ValDUT EN_OTP43_03;
ValDUT EN_OTP43_47;
ValDUT EN_OTP47_05;
ValDUT EN_OTP48_04;

//Do not Trim if it's tested before for Correlation chip
ValDUT	vbg_exc_flag	=1 ;
ValDUT	vref_exc_flag	=1 ;
ValDUT	ibias_exc_flag	=1 ;
ValDUT	rsns_exc_flag	=1 ;
ValDUT	fosc_exc_flag	=1 ;
ValDUT	hscl_exc_flag	=1 ;
ValDUT	vcl_exc_flag	=1 ;
ValDUT	zcs_exc_flag	=1 ;
ValDUT	ton_exc_flag	=1 ;


// This member function is used to execute the test measurement section.
// If this function returns true, next routine is called.
// If this function returns false, R.T.E occurs.
// Test result is set by ATCP_Base::setTestResult() function. Branch status is set to following value
// if default branch status value is not changed.
// ------------------------------
// |Test Result | Branch status |
// |----------------------------|
// |    PASS    |       0       |
// |    FAIL    |       1       |
// | NOT_TESTED |      255      |
// ------------------------------
bool
TPG::execute()
{
	alarm_set();

	//UtlAlarm::setAlarmBehavior(ABT_FAIL,"All",MT_ALL); // Display Alarm Bin

	RsltAllDUTCtnr result;
	ATCP_Base::setDlogPrecision(3); 
	if(TestDescription == "T_KELVIN_CHECK")				 {result |=T_KELVIN_CHECK();}
	if(TestDescription == "T_CONTINUITY")				 {result |=T_CONTINUITY();}
	if(TestDescription == "T_LEAKAGE_PRE")				 {result |=T_LEAKAGE_PRE();}
	ATCP_Base::setDlogPrecision(1); 
	if(TestDescription == "T_REG_READ_PRE")				 {result |=T_REG_READ_PRE();}
	ATCP_Base::setDlogPrecision(3); 	
	if(TestDescription == "T_VBG_TRIM")					 {result |=T_VBG_TRIM();}
	if(TestDescription == "T_VBG_BURN")					 {result |=T_VBG_BURN();}
	if(TestDescription == "T_VBG_POST")					 {result |=T_VBG_POST();}
	if(TestDescription == "T_VREF_EAOUT_TRIM")			 {result |=T_VREF_EAOUT_TRIM();}
	if(TestDescription == "T_VREF_EAOUT_BURN")			 {result |=T_VREF_EAOUT_BURN();}
	if(TestDescription == "T_VREF_EAOUT_POST")			 {result |=T_VREF_EAOUT_POST();}
	if(TestDescription == "T_IBIAS_TRIM")				 {result |=T_IBIAS_TRIM();}
	if(TestDescription == "T_IBIAS_BURN")				 {result |=T_IBIAS_BURN();}
	if(TestDescription == "T_IBIAS_POST")				 {result |=T_IBIAS_POST();}
	if(TestDescription == "T_RSNS_TRIM")				 {result |=T_RSNS_TRIM();}
	if(TestDescription == "T_RSNS_BURN")				 {result |=T_RSNS_BURN();}
	if(TestDescription == "T_RSNS_POST")				 {result |=T_RSNS_POST();}
	if(TestDescription == "T_FOSC_TRIM")				 {result |=T_FOSC_TRIM();}
	if(TestDescription == "T_FOSC_BURN")				 {result |=T_FOSC_BURN();}
	if(TestDescription == "T_FOSC_POST")				 {result |=T_FOSC_POST();}
	if(TestDescription == "T_HSCL_TRIM")				 {result |=T_HSCL_TRIM();}
	if(TestDescription == "T_HSCL_BURN")				 {result |=T_HSCL_BURN();}
	if(TestDescription == "T_HSCL_POST")				 {result |=T_HSCL_POST();}
	if(TestDescription == "T_VCL_TRIM")					 {result |=T_VCL_TRIM();}
	if(TestDescription == "T_VCL_BURN")					 {result |=T_VCL_BURN();}
	if(TestDescription == "T_VCL_POST")					 {result |=T_VCL_POST();}
	if(TestDescription == "T_ZCS_TRIM")					 {result |=T_ZCS_TRIM();}
	if(TestDescription == "T_ZCS_BURN")					 {result |=T_ZCS_BURN();}
	if(TestDescription == "T_ZCS_POST")					 {result |=T_ZCS_POST();}
	if(TestDescription == "T_RDSON")					 {result |=T_RDSON();}
	if(TestDescription == "T_EA_OFFSET")				 {result |=T_EA_OFFSET();}
	if(TestDescription == "T_COMPARATOR")				 {result |=T_COMPARATOR();}
	if(TestDescription == "T_NEG_CL")					 {result |=T_NEG_CL();}
	if(TestDescription == "T_IIN")						 {result |=T_IIN();}
	if(TestDescription == "T_UVLO_SEARCH")				 {result |=T_UVLO_SEARCH();}
	if(TestDescription == "T_UVLO_GNG")					 {result |=T_UVLO_GNG();} //GNG
	if(TestDescription == "T_OVP_SEARCH")				 {result |=T_OVP_SEARCH();}
	if(TestDescription == "T_OVP_GNG")					 {result |=T_OVP_GNG();} //GNG
	if(TestDescription == "T_UV_THR_SEARCH")			 {result |=T_UV_THR_SEARCH();}
	if(TestDescription == "T_UV_THR_GNG")				 {result |=T_UV_THR_GNG();} //GNG
	if(TestDescription == "T_EN_VTH_SEARCH")			 {result |=T_EN_VTH_SEARCH();}
	if(TestDescription == "T_EN_VTH_GNG")				 {result |=T_EN_VTH_GNG();} //GNG
	if(TestDescription == "T_TON_TRIM")					 {result |=T_TON_TRIM();}
	if(TestDescription == "T_TON_BURN")					 {result |=T_TON_BURN();}
	if(TestDescription == "T_TON_POST")					 {result |=T_TON_POST();}
	if(TestDescription == "T_PULLDOWN_RES")				 {result |=T_PULLDOWN_RES();}
	if(TestDescription == "T_INTER_POR_SEARCH")			 {result |=T_INTER_POR_SEARCH();}
	ATCP_Base::setDlogPrecision(1);
	if(TestDescription == "T_INTER_POR_GNG")			 {result |=T_INTER_POR_GNG();} //GNG
	ATCP_Base::setDlogPrecision(1); 
	if(TestDescription == "T_REG_READ_POST")			 {result |=T_REG_READ_POST();}
	ATCP_Base::setDlogPrecision(3);
	if(TestDescription == "T_LEAKAGE_POST")				 {result |=T_LEAKAGE_POST();}
	if(TestDescription == "T_CONTINUITY_POST")			 {result |=T_CONTINUITY_POST();}
	ATCP_Base::setDlogPrecision(2);
	if(TestDescription == "T_PC_CHECK")					{result |=T_PC_CHECK();}
	if(TestDescription == "T_CONTACT_CHECK")			{result |=T_CONTACT_CHECK();}

	RscDUTs(DUT_ON_HOLD).unmask();
	ATCP_Base::setTestResult(result);

	return true;
}

// This member function can be used to check Test Instance Parameters for errors.
// It can also be used to set member variables which depend on Instance Parameter.
// This member function is called after setValues().
void
TPG::postProcessParams(bool /* isClientTool */)
{
}

// This member function can be used to add PatternLists and TestConditions if
// user describes Pattern/-List and TestCondition directly in execute() function.
// This can be done by using function addPatternList() and addTestCondition().
void
TPG::registerObjects()
{
#pragma todo("Modify this function when you use PatternList or TestCondition directly described in execute() function.")
	/* If PatternList is directly described in execute() function,                                        */
	/* specify PatternList name as the argument of addPatternList() function like the following examples. */
	//addPatternList("SmplPList");

	//addPatternList("I2C_READ");
	//addPatternList("I2C_WRITE");

	//addPatternList("Initial_register_set");
	//

	//addPatternList("I2C_RD_OSC_0x10_0x11");
	//addPatternList("SCL_1ms_low_pulse");

	//addPatternList("PULSE_200HZ");

	///* If TestCondition is directly described in execute() function,                                          */
	/* specify TestCondition name as the argument of addTestCondition() function like the following examples. */
	//addTestCondition("SmplTestCondition");
}

// This is the Constructor.
// This function initialize member variables.
// This function is called when a test instance which uses this Test Class is generated. 
TPG::TPG()
{
}

// This is the Destructor.
// This function is called when a test instance which uses this Test Class is unloaded. 
TPG::~TPG()
{
}

void TPG::ktb8316_discharge()
{
	//rdk::Timer::START(); 
//Discharge For preventing from affection of previous item-----------------------------------------------------------------------
	rdk::CW("K1;K2;K3;K12;K13;K15;K16").on().APPLY(); 
	rdk::MMXH::PMU("Allpins_mmxh_pmu").isvm("-1.0mA",rdkenum::R30mA,rdkenum::R7V,"7.0V","-7.0V").connect().power(ON).APPLY();	
	DPIN_PMU_Set("Allpins_mdm",ISVM_,"-1.0mA",R25mA,M6V,"2.0V","-1.0V",CLOSE_,ON_);
    rdk::MFHP::PMU("LX_mfhp_pmu").isvm("-1.0mA",rdkenum::R3A,rdkenum::R7V,"7.0V","-7.0V").connect(rdkenum::PORTA,rdkenum::PORTA).power(ON).APPLY();
	rdk::Timer::WAIT(5e-3);

	//MMXH_PMU_Slewrate("Allpins_mmxh_pmu" ,"Fast");   //for spike
	rdk::MMXH::PMU("Allpins_mmxh_pmu").isvm("0.0mA",rdkenum::R30mA,rdkenum::R7V,"7.0V","-7.0V").connect().power(ON).APPLY();	
	DPIN_PMU_Set("Allpins_mdm",ISVM_,"0.0mA",R25mA,M6V,"2.0V","-1.0V",CLOSE_,ON_);
    rdk::MFHP::PMU("LX_mfhp_pmu").isvm("0.0mA",rdkenum::R3A,rdkenum::R7V,"7.0V","-7.0V").APPLY();
	rdk::Timer::WAIT(3e-3);
	DPIN_PMU_Set("Allpins_mdm",OPEN_,OFF_);
	rdk::MMXH::PMU("Allpins_mmxh_pmu").disconnect().power(OFF).APPLY();
    rdk::MFHP::PMU("LX_mfhp_pmu").disconnect().power(OFF).APPLY();
	rdk::Timer::WAIT(1e-3);
	rdk::CW("K_ALL").off().APPLY(); 
	rdk::Timer::WAIT(1e-3);
	//MMXH_PMU_Slewrate("Allpins_mmxh_pmu" ,"VeryFast");   //for spike
	//Time Timer::STOP(const OFCString& msg);      // Syntax 2 

	//OASIS::Time time = rdk::Timer::STOP(); 
	//dlgout.precision(3);
	//dlgout<<time<<endl;

//--------------------------------------------------------------------------------------------------------------------------------
}


void TPG::I2C_Write(ValDUT addr, ValDUT data)
{
   #if 1 // for pattern editor view
       RscPList Rscplist("I2C_WRITE");
       m_PList.clear();
       m_PList.push_back(Rscplist);
       OASIS::OFCArray<OASIS::OFCString> defaultValues;
       ATCP_Base::setValues(defaultValues,false);
   #endif

	ValDUT Addr_data = 0;
	ValDUT Data_data = 0;

	for(ItrDUTs itrDut(DUT_ACTIVE);!itrDut.isDone();itrDut++)
	{
		int ADDR = addr[*itrDut].getAsInt();
		int DATA = data[*itrDut].getAsInt();

		if(ADDR & 0x40)	{ Addr_data[*itrDut]+=0x3 << 18;} else{ Addr_data[*itrDut]+=0x1 << 18;}
		if(ADDR & 0x20)	{ Addr_data[*itrDut]+=0x3 << 15;} else{ Addr_data[*itrDut]+=0x1 << 15;}
		if(ADDR & 0x10)	{ Addr_data[*itrDut]+=0x3 << 12;} else{ Addr_data[*itrDut]+=0x1 << 12;}
		if(ADDR & 0x08)	{ Addr_data[*itrDut]+=0x3 <<  9;} else{ Addr_data[*itrDut]+=0x1 <<  9;}
		if(ADDR & 0x04)	{ Addr_data[*itrDut]+=0x3 <<  6;} else{ Addr_data[*itrDut]+=0x1 <<  6;}
		if(ADDR & 0x02)	{ Addr_data[*itrDut]+=0x3 <<  3;} else{ Addr_data[*itrDut]+=0x1 <<  3;}
		if(ADDR & 0x01)	{ Addr_data[*itrDut]+=0x3;      } else{ Addr_data[*itrDut]+=0x1;      }

		if(DATA & 0x80)	{ Data_data[*itrDut]+=0x3 << 21;} else{ Data_data[*itrDut]+=0x1 << 21;}
		if(DATA & 0x40)	{ Data_data[*itrDut]+=0x3 << 18;} else{ Data_data[*itrDut]+=0x1 << 18;}
		if(DATA & 0x20)	{ Data_data[*itrDut]+=0x3 << 15;} else{ Data_data[*itrDut]+=0x1 << 15;}
		if(DATA & 0x10)	{ Data_data[*itrDut]+=0x3 << 12;} else{ Data_data[*itrDut]+=0x1 << 12;}
		if(DATA & 0x08)	{ Data_data[*itrDut]+=0x3 <<  9;} else{ Data_data[*itrDut]+=0x1 <<  9;}
		if(DATA & 0x04)	{ Data_data[*itrDut]+=0x3 <<  6;} else{ Data_data[*itrDut]+=0x1 <<  6;}
		if(DATA & 0x02)	{ Data_data[*itrDut]+=0x3 <<  3;} else{ Data_data[*itrDut]+=0x1 <<  3;}
		if(DATA & 0x01)	{ Data_data[*itrDut]+=0x3;      } else{ Data_data[*itrDut]+=0x1;      }

	}

	rdk::Digital::Pattern("I2C_WRITE").MODIFY_SERIAL(Addr_data, "MODE_mdm", "ADDRESS", 21, MSB_FIRST, DR,  DUT_ACTIVE);
	rdk::Digital::Pattern("I2C_WRITE").MODIFY_SERIAL(Data_data, "MODE_mdm", "DATA",    24, MSB_FIRST, DR,  DUT_ACTIVE);

	Run_pat("I2C_WRITE",Wait_);


}

void TPG::I2C_Write2(ValDUT addr, ValDUT data)
{

   #if 1 // for pattern editor view
       RscPList Rscplist("I2C_WRITE2");
       m_PList.clear();
       m_PList.push_back(Rscplist);
       OASIS::OFCArray<OASIS::OFCString> defaultValues;
       ATCP_Base::setValues(defaultValues,false);
   #endif

	ValDUT Addr_data = 0;
	ValDUT Data_data = 0;

	for(ItrDUTs itrDut(DUT_ACTIVE);!itrDut.isDone();itrDut++)
	{
		int ADDR = addr[*itrDut].getAsInt();
		int DATA = data[*itrDut].getAsInt();

		if(ADDR & 0x40)	{ Addr_data[*itrDut]+=0x3 << 18;} else{ Addr_data[*itrDut]+=0x1 << 18;}
		if(ADDR & 0x20)	{ Addr_data[*itrDut]+=0x3 << 15;} else{ Addr_data[*itrDut]+=0x1 << 15;}
		if(ADDR & 0x10)	{ Addr_data[*itrDut]+=0x3 << 12;} else{ Addr_data[*itrDut]+=0x1 << 12;}
		if(ADDR & 0x08)	{ Addr_data[*itrDut]+=0x3 <<  9;} else{ Addr_data[*itrDut]+=0x1 <<  9;}
		if(ADDR & 0x04)	{ Addr_data[*itrDut]+=0x3 <<  6;} else{ Addr_data[*itrDut]+=0x1 <<  6;}
		if(ADDR & 0x02)	{ Addr_data[*itrDut]+=0x3 <<  3;} else{ Addr_data[*itrDut]+=0x1 <<  3;}
		if(ADDR & 0x01)	{ Addr_data[*itrDut]+=0x3;      } else{ Addr_data[*itrDut]+=0x1;      }

		if(DATA & 0x80)	{ Data_data[*itrDut]+=0x3 << 21;} else{ Data_data[*itrDut]+=0x1 << 21;}
		if(DATA & 0x40)	{ Data_data[*itrDut]+=0x3 << 18;} else{ Data_data[*itrDut]+=0x1 << 18;}
		if(DATA & 0x20)	{ Data_data[*itrDut]+=0x3 << 15;} else{ Data_data[*itrDut]+=0x1 << 15;}
		if(DATA & 0x10)	{ Data_data[*itrDut]+=0x3 << 12;} else{ Data_data[*itrDut]+=0x1 << 12;}
		if(DATA & 0x08)	{ Data_data[*itrDut]+=0x3 <<  9;} else{ Data_data[*itrDut]+=0x1 <<  9;}
		if(DATA & 0x04)	{ Data_data[*itrDut]+=0x3 <<  6;} else{ Data_data[*itrDut]+=0x1 <<  6;}
		if(DATA & 0x02)	{ Data_data[*itrDut]+=0x3 <<  3;} else{ Data_data[*itrDut]+=0x1 <<  3;}
		if(DATA & 0x01)	{ Data_data[*itrDut]+=0x3;      } else{ Data_data[*itrDut]+=0x1;      }

	}
	rdk::Digital::Pattern("I2C_WRITE2").MODIFY_SERIAL(Addr_data, "MODE_mdm", "ADDRESS", 21, MSB_FIRST, DR,  DUT_ACTIVE);
	rdk::Digital::Pattern("I2C_WRITE2").MODIFY_SERIAL(Data_data, "MODE_mdm", "DATA",    24, MSB_FIRST, DR,  DUT_ACTIVE);
	
	Run_pat("I2C_WRITE2",Wait_);
}



ValDUT TPG::I2C_Read(ValDUT addr)
{
   #if 1 // for pattern editor view
       RscPList Rscplist("I2C_READ");
       m_PList.clear();
       m_PList.push_back(Rscplist);
       OASIS::OFCArray<OASIS::OFCString> defaultValues;
       ATCP_Base::setValues(defaultValues,false);
   #endif

	ValDUT Addr_data = 0;

	for(ItrDUTs itrDut(DUT_ACTIVE);!itrDut.isDone();itrDut++)
	{
		int ADDR = addr[*itrDut].getAsInt();

		if(ADDR & 0x40)	{ Addr_data[*itrDut]+=0x3 << 18;} else{ Addr_data[*itrDut]+=0x1 << 18;}
		if(ADDR & 0x20)	{ Addr_data[*itrDut]+=0x3 << 15;} else{ Addr_data[*itrDut]+=0x1 << 15;}
		if(ADDR & 0x10)	{ Addr_data[*itrDut]+=0x3 << 12;} else{ Addr_data[*itrDut]+=0x1 << 12;}
		if(ADDR & 0x08)	{ Addr_data[*itrDut]+=0x3 <<  9;} else{ Addr_data[*itrDut]+=0x1 <<  9;}
		if(ADDR & 0x04)	{ Addr_data[*itrDut]+=0x3 <<  6;} else{ Addr_data[*itrDut]+=0x1 <<  6;}
		if(ADDR & 0x02)	{ Addr_data[*itrDut]+=0x3 <<  3;} else{ Addr_data[*itrDut]+=0x1 <<  3;}
		if(ADDR & 0x01)	{ Addr_data[*itrDut]+=0x3;      } else{ Addr_data[*itrDut]+=0x1;      }

	}

	rdk::Digital::Pattern("I2C_READ").MODIFY_SERIAL(Addr_data, "MODE_mdm", "ADDRESS", 21, MSB_FIRST, DR,  DUT_ACTIVE);

	rdk::Digital::Pattern("I2C_READ").START_DMEM_SERIAL("EN_mdm", 1, 8, MSB_FIRST);

	int bit_cnt;
	ValDUT acqData_VD = 0;
	for (ItrDUTs itrDut(DUT_ACTIVE); !itrDut.isDone(); itrDut++)
	{
		OFCNRArray<unsigned int> dmem_data;
		rdk::Digital::Pattern("I2C_READ").GET_DMEM_DATA(dmem_data, *itrDut, "EN_mdm");
		for (bit_cnt = 0; bit_cnt<8; bit_cnt++)
			acqData_VD[*itrDut] += dmem_data[bit_cnt] * (int)pow(2.0, (double)(dmem_data.size() - 1 - bit_cnt));
	}
	return acqData_VD;
}





void TPG::mask_if_active(OFCString dut_name)
{
	OFCStringArray_t mask_dut;
	OFCStringUtils::StringTokenizer(dut_name,',',mask_dut);

	for(size_t index=0;index<mask_dut.size();index++)
	{
		DUTID_t dutid = OFCStringUtils::toInt(mask_dut[index]);
		RscDUT mask_DUT(dutid);
		if(mask_DUT.isActive())
			mask_DUT.mask();
	}
}
void TPG::unmask_if_masked(OFCString dut_name)
{
	OFCStringArray_t unmask_dut;
	OFCStringUtils::StringTokenizer(dut_name,',',unmask_dut);

	for(size_t index=0;index<unmask_dut.size();index++)
	{
		DUTID_t dutid = OFCStringUtils::toInt(unmask_dut[index]);
		RscDUT unmask_DUT(dutid);
		if(unmask_DUT.isMasked())
			unmask_DUT.unmask();
	}
}


void TPG::CW_close_active_site(OFCString CWPins)
{
	int dut_int;
	ValDUT dut_int_VD;
	OFCString  dut_string;

	for(ItrDUTs itrDut(DUT_ACTIVE); !itrDut.isDone(); itrDut++) {
		dut_int = itrDut.getDUTID();
		dut_int_VD.set(dut_int);
        dut_string = dut_int_VD.getAsString();
	    RscDUTs  dut(dut_string);
		CW_Close(CWPins, dut); //
	}
}
void TPG::CW_open_active_site(OFCString CWPins)
{
	int dut_int;
	ValDUT dut_int_VD;
	OFCString  dut_string;

	for(ItrDUTs itrDut(DUT_ACTIVE); !itrDut.isDone(); itrDut++) {
		dut_int = itrDut.getDUTID();
		dut_int_VD.set(dut_int);
        dut_string = dut_int_VD.getAsString();
	    RscDUTs  dut(dut_string);
		CW_Open(CWPins, dut); //
	}
}


OASIS::OFCString
TPG::GET_active_site()
{
	OFCString duts_name;

	OFCString active_site_str;
	OFCStringArray_t duts_name_ary;

	RscDUTs active_duts(DUT_ACTIVE);
	duts_name = active_duts.getName();
	OFCStringUtils::StringTokenizer(duts_name, ';' ,duts_name_ary);
	OFCStringUtils::StringDetokenizer(duts_name_ary, ',' ,active_site_str);

	return active_site_str;
}

void TPG::timing_set(double frequency,RscTestCondition timing_condition)
{
	double ts;
	ts=1/frequency;

	RscUserVar ts_var("Period_VAR.TS_SPEED");
	ts_var.setValue(ts);
	timing_condition.buildTCM();
	timing_condition.apply();
}


int TPG::partition(double *a, int m, int n) 
 { 
     int i,pindex;
	 double pivot;

     pindex = m; 
     pivot = a[n]; 
     for(i=m;i<n;i++) 
     { 
         if(a[i] <= pivot) 
         { 
             swap(a[pindex], a[i]); 
             pindex++; 
         } 
     } 
     swap(a[pindex], a[n]); 
     return pindex; 
 } 
 

int TPG::quicksort(double *a, int m, int n) 
 { 
     int index; 
     if(m>=n) 
         return 0; 
     { 
         index = partition(a,m,n); 
         quicksort(a, m, index-1); 
         quicksort(a, index+1, n); 
     } 

	 return 1;
 } 


//------------------------------------------------------------------------------
//------------------------------------------------------------------------------
void TPG::alarm_set()
{
	MaskAlarms.clear();
	UnmaskAlarms.clear();
	
	RscPin all_mdm_dcl("Allpins_mdm");
	MaskAlarms.push_back(ATF_ALARM_LIMITER_FAIL);
	all_mdm_dcl.maskAlarm(MaskAlarms);

	MaskAlarms.clear();
	UnmaskAlarms.clear();
	
	RscPin all_mfhp("Allpins_mfhp_pmu");
	MaskAlarms.push_back(ATF_ALARM_KELVIN);
	MaskAlarms.push_back(ATF_ALARM_CLAMP);
	MaskAlarms.push_back(ATF_ALARM_OVER_RANGE);
	MaskAlarms.push_back(ATF_ALARM_SOURCE_NOT_SETTLED);
	all_mfhp.maskAlarm(MaskAlarms);

	MaskAlarms.clear();
	UnmaskAlarms.clear();
	
	RscPin all_mmxh_pmu("Allpins_mmxh_pmu");
	MaskAlarms.push_back(ATF_ALARM_KELVIN);
	MaskAlarms.push_back(ATF_ALARM_CLAMP);
	MaskAlarms.push_back(ATF_ALARM_OVER_RANGE);
	MaskAlarms.push_back(ATF_ALARM_SOURCE_NOT_SETTLED);
	MaskAlarms.push_back(ATF_ALARM_OVER_RANGE);
	MaskAlarms.push_back(ATF_ALARM_SPIKE);
	
	all_mmxh_pmu.maskAlarm(MaskAlarms);
}



RsltAllDUTCtnr
TPG::T_KELVIN_CHECK()
{
// Kelvin connection check
	TestConditions.apply();
	RsltAllDUTCtnr result;
 
	test_id = 1;

	OFCArray<ValDUT> VIN_KEL_CK(1,100); 
	OFCArray<ValDUT> LX_KEL_CK(1,100); 
	OFCArray<ValDUT> GND_KEL_CK(1,100); 	



	// kelvin connection check - IN
	rdk::CW("K_ALL").off().APPLY(); 	
	rdk::Timer::WAIT(1.0e-3);

	rdk::MMXH::PMU("VIN_mmxh_pmu").isvm_kelvin(rdkenum::MMXH::PMU::KELVIN_STATE::HI).connect().power(ON).APPLY();
	rdk::Timer::WAIT(5.0e-3);

	VIN_KEL_CK[0] = rdk::MMXH::PMU("VIN_mmxh_pmu").MEAS_R(10);

	result |= Judge(test_id,"VIN_KEL_CK",VIN_KEL_CK[0], 10, 200,"SoftBins.BIN11","SoftBins.BIN11","Ohms"); if(RscDUTs(DUT_ACTIVE).isEmpty())return result;

	rdk::MMXH::PMU("VIN_mmxh_pmu").isvm("0.0uA", rdkenum::R3uA,rdkenum::R2V,"2.0V","-2.0V").disconnect().power(OFF).APPLY();

	// kelvin connection check - LX
	rdk::MMXH::PMU("LX_mmxh_pmu").isvm_kelvin(rdkenum::MMXH::PMU::KELVIN_STATE::HI).connect().power(ON).APPLY();
	rdk::Timer::WAIT(5.0e-3);

	LX_KEL_CK[0] = rdk::MMXH::PMU("LX_mmxh_pmu").MEAS_R(10);

	result |= Judge(test_id,"LX_KEL_CK",LX_KEL_CK[0], 10, 200,"SoftBins.BIN11","SoftBins.BIN11","Ohms"); if(RscDUTs(DUT_ACTIVE).isEmpty())return result;

	rdk::MMXH::PMU("LX_mmxh_pmu").isvm("0.0uA", rdkenum::R3uA,rdkenum::R2V,"2.0V","-2.0V").disconnect().power(OFF).APPLY();
	
	// kelvin connection check - GND	
	rdk::CW("K14;K15").on().APPLY();
	rdk::Timer::WAIT(1.0e-3);

	rdk::MMXH::PMU("GND_mmxh_pmu").isvm_kelvin(rdkenum::MMXH::PMU::KELVIN_STATE::HI).connect().power(ON).APPLY();
	rdk::Timer::WAIT(5.0e-3);

	GND_KEL_CK[0] = rdk::MMXH::PMU("GND_mmxh_pmu").MEAS_R(10);

	result |= Judge(test_id,"GND_KEL_CK",GND_KEL_CK[0], 10, 200,"SoftBins.BIN11","SoftBins.BIN11","Ohms"); if(RscDUTs(DUT_ACTIVE).isEmpty())return result;

	rdk::MMXH::PMU("GND_mmxh_pmu").isvm("0.0uA", rdkenum::R3uA,rdkenum::R2V,"2.0V","-2.0V").disconnect().power(OFF).APPLY();	
	
	//All CW off
	rdk::CW("K14;K15").off().APPLY();
	rdk::Timer::WAIT(1.0e-3);

	return result;	
} //T_KELVIN_CHECK



RsltAllDUTCtnr
TPG::T_CONTINUITY()
{
	RsltAllDUTCtnr result;

	test_id = 10;

	OFCArray<ValDUT> os1_data(3,100); 
    OFCArray<ValDUT> meas_data(2,100);

	//KTB8316_flag();

	rdk::CW("K1;K16").on().APPLY(); 	
	rdk::Timer::WAIT(1.0e-3);
// T_CONTINUITY_Test

	rdk::MMXH::PMU("OS_mmxh_pmu").vsim("0.0V",rdkenum::R2V,rdkenum::R3mA,"3.0mA","-3.0mA").connect().power(ON).APPLY();	
	rdk::Timer::WAIT(1.0e-3);

	rdk::MMXH::PMU("VIN_mmxh_pmu").isvm("-0.1mA",rdkenum::R3mA,rdkenum::R2V,"2V","-2V").connect().power(ON).APPLY();
	rdk::Timer::WAIT(1.0e-3);
	meas_data[0] = rdk::MMXH::PMU("VIN_mmxh_pmu").MEAS_V(100);
	rdk::MMXH::PMU("VIN_mmxh_pmu").iforce("0.0uA").APPLY(); 
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("0.0V",rdkenum::R2V,rdkenum::R3mA,"3.0mA","-3.0mA").APPLY();
	result |= Judge(test_id,"OS1_VIN","T_CONT_LS.OS_N",meas_data[0],"SoftBins.BIN5"); if(RscDUTs(DUT_ACTIVE).isEmpty())return result;test_id++;


	rdk::MMXH::PMU("LX_mmxh_pmu").isvm("-0.1mA",rdkenum::R3mA,rdkenum::R2V,"2V","-2V").connect().power(ON).APPLY();
	rdk::Timer::WAIT(1.0e-3);
	meas_data[0] = rdk::MMXH::PMU("LX_mmxh_pmu").MEAS_V(100);
	rdk::MMXH::PMU("LX_mmxh_pmu").iforce("0.0uA").APPLY(); 
	rdk::MMXH::PMU("LX_mmxh_pmu").vsim("0.0V",rdkenum::R2V,rdkenum::R3mA,"3.0mA","-3.0mA").APPLY();
	result |= Judge(test_id,"OS1_LX","T_CONT_LS.OS_N",meas_data[0],"SoftBins.BIN5"); if(RscDUTs(DUT_ACTIVE).isEmpty())return result;test_id++;


	rdk::MMXH::PMU("VOUT_mmxh_pmu").isvm("-0.1mA",rdkenum::R3mA,rdkenum::R2V,"2V","-2V").connect().power(ON).APPLY();
	rdk::Timer::WAIT(1.0e-3);
	meas_data[0] = rdk::MMXH::PMU("VOUT_mmxh_pmu").MEAS_V(100);
	rdk::MMXH::PMU("VOUT_mmxh_pmu").iforce("0.0uA").APPLY(); 
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("0.0V",rdkenum::R2V,rdkenum::R3mA,"3.0mA","-3.0mA").APPLY();
	result |= Judge(test_id,"OS1_VOUT","T_CONT_LS.OS_N",meas_data[0],"SoftBins.BIN5"); if(RscDUTs(DUT_ACTIVE).isEmpty())return result;test_id++;

	rdk::MMXH::PMU("EN_mmxh_pmu").isvm("-0.1mA",rdkenum::R3mA,rdkenum::R2V,"2V","-2V").connect().power(ON).APPLY();
	rdk::Timer::WAIT(1.0e-3);
	meas_data[0] = rdk::MMXH::PMU("EN_mmxh_pmu").MEAS_V(100);
	rdk::MMXH::PMU("EN_mmxh_pmu").iforce("0.0uA").APPLY(); 
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("0.0V",rdkenum::R2V,rdkenum::R3mA,"3.0mA","-3.0mA").APPLY();
	result |= Judge(test_id,"OS1_EN","T_CONT_LS.OS_N",meas_data[0],"SoftBins.BIN5"); if(RscDUTs(DUT_ACTIVE).isEmpty())return result;test_id++;


	rdk::MMXH::PMU("MODE_mmxh_pmu").isvm("-0.1mA",rdkenum::R3mA,rdkenum::R2V,"2V","-2V").connect().power(ON).APPLY();
	rdk::Timer::WAIT(1.0e-3);
	meas_data[0] = rdk::MMXH::PMU("MODE_mmxh_pmu").MEAS_V(100);
	rdk::MMXH::PMU("MODE_mmxh_pmu").iforce("0.0uA").APPLY(); 
	rdk::MMXH::PMU("MODE_mmxh_pmu").vsim("0.0V",rdkenum::R2V,rdkenum::R3mA,"3.0mA","-3.0mA").APPLY();
	result |= Judge(test_id,"OS1_MODE","T_CONT_LS.OS_N",meas_data[0],"SoftBins.BIN5"); if(RscDUTs(DUT_ACTIVE).isEmpty())return result;test_id++;


// clean up
	rdk::MMXH::PMU("Allpins_mmxh_pmu").vsim("0.0V",rdkenum::R2V,rdkenum::R3mA,"3.0mA","-3.0mA").connect().power(ON).APPLY();	
	rdk::Timer::WAIT(1.0e-3);
	rdk::MMXH::PMU("Allpins_mmxh_pmu").disconnect().power(OFF).APPLY();
	rdk::CW("K1;K16").off().APPLY(); 
	rdk::Timer::WAIT(1e-3); 

	return result;
	
} // T_CONTINUITY


RsltAllDUTCtnr
TPG::T_LEAKAGE_PRE()
{
	RsltAllDUTCtnr result;

	RscTestCondition MODE_Timing("(Timing_MODE)");
	timing_set(Timming_Speed,MODE_Timing);

	test_id = 100;

	rdk::CW("K1;K16").on().APPLY();  //MODE_MMXH EN_MMXH // In ACCO, Using LX MFHP(FPVI), But Using MMXH in this.
	rdk::Timer::WAIT(3e-3);

	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").connect().power(ON).APPLY();
	rdk::MMXH::PMU("MODE_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").connect().power(ON).APPLY();
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").connect().power(ON).APPLY();
	rdk::Timer::WAIT(3e-3);

//IC Turn on
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("1.5V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY(); //For spike
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("3.5V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY(); //For spike

	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("5.5V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();
	rdk::Timer::WAIT(3e-3);

//VIN_Leak_Pre
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("5.5V",rdkenum::R7V,rdkenum::R30mA,"30.0mA","-30.0mA").APPLY();
	rdk::Timer::WAIT(3e-3);
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("5.5V",rdkenum::R7V,rdkenum::R30uA,"30.0uA","-30.0uA").APPLY();
	rdk::Timer::WAIT(3e-3);
	DGT_Lvlset("VIN_mmxh_dgt",IM_,"100KHz",16000); //Max 1MHz, 0~16000
	DGT_Start("VIN_mmxh_dgt");

	rdk::Timer::WAIT(3e-3);
	DGT_Stop("VIN_mmxh_dgt",CLOSE_);


	ILK_VIN_PRE[0] = rdk::MMXH::PMU("VIN_mmxh_pmu").MEAS_I(100);

	MMXH_PMU_Slewrate("VIN_mmxh_pmu","Slow");   //for spike
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R30uA,"30.0uA","-30.0uA").APPLY();
	rdk::Timer::WAIT(3e-3);
	MMXH_PMU_Slewrate("VIN_mmxh_pmu","VeryFast");   //for spike

//Iik_modeh_pre
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("1.5V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY(); //For spike
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("3.5V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY(); //For spike

	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("5.5V",rdkenum::R7V,rdkenum::R240mA,"240.0mA","-240.0mA").APPLY();
	rdk::Timer::WAIT(3e-3);

	rdk::MMXH::PMU("MODE_mmxh_pmu").vsim("1.5V",rdkenum::R7V,rdkenum::R300uA,"300.0uA","-300.0uA").connect().power(ON).APPLY();	 //For spike
	rdk::MMXH::PMU("MODE_mmxh_pmu").vsim("3.5V",rdkenum::R7V,rdkenum::R300uA,"300.0uA","-300.0uA").APPLY();	 //For spike


	rdk::MMXH::PMU("MODE_mmxh_pmu").vsim("5.5V",rdkenum::R7V,rdkenum::R300uA,"300.0uA","-300.0uA").APPLY();
	rdk::Timer::WAIT(3e-3);

	ILK_MODE_PRE_H[0] = rdk::MMXH::PMU("MODE_mmxh_pmu").MEAS_I(100);

//Iik_model_pre
	MMXH_PMU_Slewrate("MODE_mmxh_pmu","Slow");  //for spike
	rdk::MMXH::PMU("MODE_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R300uA,"300.0uA","-300.0uA").APPLY(); 
	rdk::Timer::WAIT(3e-3);
	MMXH_PMU_Slewrate("MODE_mmxh_pmu","VeryFast");  //for spike

	ILK_MODE_PRE_L[0] = rdk::MMXH::PMU("MODE_mmxh_pmu").MEAS_I(100);	

	rdk::MMXH::PMU("MODE_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R30mA,"30.0mA","-30.0mA").APPLY(); 
	rdk::Timer::WAIT(3e-3);

//Ilk_vouth_pre
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("1.5V",rdkenum::R7V,rdkenum::R30mA,"30.0mA","-30.0mA").connect().power(ON).APPLY(); //For spike
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("3.5V",rdkenum::R7V,rdkenum::R30mA,"30.0mA","-30.0mA").APPLY(); //For spike

	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("5.5V",rdkenum::R7V,rdkenum::R30mA,"30.0mA","-30.0mA").APPLY();
	rdk::Timer::WAIT(3e-3);
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("5.5V",rdkenum::R7V,rdkenum::R300uA,"300.0uA","-300.0uA").APPLY();
	rdk::Timer::WAIT(3e-3);

	ILK_VOUT_PRE_H[0] = rdk::MMXH::PMU("VOUT_mmxh_pmu").MEAS_I(100);

//Ilk_voutl_pre
	MMXH_PMU_Slewrate("VOUT_mmxh_pmu","Slow");  //for spike
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R300uA,"300.0uA","-300.0uA").APPLY();
	rdk::Timer::WAIT(3e-3);
	MMXH_PMU_Slewrate("VOUT_mmxh_pmu","VeryFast");  //for spike

	ILK_VOUT_PRE_L[0] = rdk::MMXH::PMU("VOUT_mmxh_pmu").MEAS_I(100);

//Clean up
	MMXH_PMU_Slewrate("VIN_mmxh_pmu","Slow");   //for spike
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R30mA,"30.0mA","-30.0mA").APPLY();
	rdk::Timer::WAIT(3e-3);
	rdk::MMXH::PMU("MODE_mmxh_pmu").disconnect().power(OFF).APPLY();
	rdk::MMXH::PMU("EN_mmxh_pmu").disconnect().power(OFF).APPLY();
	rdk::MMXH::PMU("VOUT_mmxh_pmu").disconnect().power(OFF).APPLY();
	rdk::MMXH::PMU("VIN_mmxh_pmu").disconnect().power(OFF).APPLY();

	rdk::CW("K_ALL").off().APPLY(); 
	rdk::Timer::WAIT(3e-3);
	MMXH_PMU_Slewrate("VIN_mmxh_pmu","VeryFast");   //for spike

	result |= Judge(test_id,"Ilk_vin_pre",  "T_LEAK_LS.Leak_Pre",ILK_VIN_PRE[0],"SoftBins.BIN7"); if(RscDUTs(DUT_ACTIVE).isEmpty())return result; test_id++;

	result |= Judge(test_id,"Ilk_modeh_pre",  "T_LEAK_LS.Leak_Pre",ILK_MODE_PRE_H[0],"SoftBins.BIN7"); if(RscDUTs(DUT_ACTIVE).isEmpty())return result; test_id++;
	result |= Judge(test_id,"Ilk_model_pre",  "T_LEAK_LS.Leak_Pre",ILK_MODE_PRE_L[0],"SoftBins.BIN7"); if(RscDUTs(DUT_ACTIVE).isEmpty())return result; test_id++;

	result |= Judge(test_id,"Ilk_vouth_pre",  "T_LEAK_LS.Leak_VOUT_H",ILK_VOUT_PRE_H[0],"SoftBins.BIN7"); if(RscDUTs(DUT_ACTIVE).isEmpty())return result; test_id++;
	result |= Judge(test_id,"Ilk_voutl_pre",  "T_LEAK_LS.Leak_VOUT_L",ILK_VOUT_PRE_L[0],"SoftBins.BIN7"); if(RscDUTs(DUT_ACTIVE).isEmpty())return result; test_id++;

//Ilk_enh_pre
	rdk::CW("K1;K12;K13;K16").on().APPLY();  
	rdk::Timer::WAIT(3e-3);

	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").connect().power(ON).APPLY();
	rdk::MMXH::PMU("MODE_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").connect().power(ON).APPLY();
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").connect().power(ON).APPLY();
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").connect().power(ON).APPLY();
	rdk::Timer::WAIT(3e-3);
	
	//IC Turn on - VOUT 1.0V -> 5.5V - 240827
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("2.5V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();	//For spike
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("2.5V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();	//For spike

	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("4.5V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();	//For spike
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("4.5V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();	//For spike

	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("5.5V",rdkenum::R7V,rdkenum::R240mA,"100mA","-100mA").APPLY();//3mA best
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("5.5V",rdkenum::R7V,rdkenum::R240mA,"100mA","-100mA").APPLY();//3mA best
	rdk::Timer::WAIT(5e-3);

	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("5.5V",rdkenum::R7V,rdkenum::R3mA,"3mA","-3mA").APPLY();
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("5.5V",rdkenum::R7V,rdkenum::R3mA,"3mA","-3mA").APPLY();//3mA best
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("5.5V",rdkenum::R7V,rdkenum::R3mA,"3mA","-3mA").APPLY();
	rdk::Timer::WAIT(5e-3);
	
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("5.5V",rdkenum::R7V,rdkenum::R30uA,"30uA","-30uA").APPLY();
	rdk::Timer::WAIT(15e-3);

	ILK_EN_PRE_H[0] = rdk::MMXH::PMU("EN_mmxh_pmu").MEAS_I(100);

//Ilk_enl_pre
	MMXH_PMU_Slewrate("EN_mmxh_pmu","Slow");   //for spike	
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R3mA,"3mA","-3mA").APPLY();
	rdk::Timer::WAIT(5e-3);
	MMXH_PMU_Slewrate("EN_mmxh_pmu","VeryFast");   //for spike	

	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R30uA,"30uA","-30uA").APPLY();
	rdk::Timer::WAIT(5e-3);

	ILK_EN_PRE_L[0] = rdk::MMXH::PMU("EN_mmxh_pmu").MEAS_I(100);
	
//Clean up
	MMXH_PMU_Slewrate("VIN_mmxh_pmu" ,"Slow");   //for spike
	MMXH_PMU_Slewrate("VOUT_mmxh_pmu","Slow");  //for spike

	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R30uA,"30.0uA","-30.0uA").APPLY();
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R3mA,"3mA","-3mA").APPLY();
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R3mA,"3mA","-3mA").APPLY();
	rdk::Timer::WAIT(3e-3);
	rdk::MMXH::PMU("VOUT_mmxh_pmu").disconnect().power(OFF).APPLY();
	rdk::MMXH::PMU("EN_mmxh_pmu").disconnect().power(OFF).APPLY();
	rdk::MMXH::PMU("VIN_mmxh_pmu").disconnect().power(OFF).APPLY();
	rdk::MMXH::PMU("MODE_mmxh_pmu").disconnect().power(OFF).APPLY();
	rdk::CW("K_ALL").off().APPLY(); 
	rdk::Timer::WAIT(3e-3);

	MMXH_PMU_Slewrate("VIN_mmxh_pmu" ,"VeryFast");   //for spike
	MMXH_PMU_Slewrate("VOUT_mmxh_pmu","VeryFast");  //for spike


	result |= Judge(test_id,"Ilk_enh_pre",  "T_LEAK_LS.Leak_Pre",ILK_EN_PRE_H[0],"SoftBins.BIN7"); if(RscDUTs(DUT_ACTIVE).isEmpty())return result; test_id++;
	result |= Judge(test_id,"Ilk_enl_pre",  "T_LEAK_LS.Leak_Pre",ILK_EN_PRE_L[0],"SoftBins.BIN7"); if(RscDUTs(DUT_ACTIVE).isEmpty())return result; test_id++;

// Setup - LX Lkg
    rdk::CW("K2;K13;K16").on().APPLY(); // MODE_MDM, EN_MMXH, VIN_CAP
	rdk::Timer::WAIT(1e-3);

	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").connect().power(ON).APPLY();
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").connect().power(ON).APPLY();
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").connect().power(ON).APPLY();
	rdk::MMXH::PMU("LX_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").connect().power(ON).APPLY();
	rdk::Timer::WAIT(3e-3);

//IC Turn on
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("1.8V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY(); //For spike
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("1.8V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY(); //For spike
	rdk::Timer::WAIT(5e-3);

	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();
	rdk::Timer::WAIT(5e-3);

	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R3mA,"3mA","-3mA").APPLY();
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R3mA,"3mA","-3mA").APPLY();
	rdk::Timer::WAIT(3e-3); 
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("1.8V",rdkenum::R7V,rdkenum::R3mA,"3mA","-3mA").APPLY(); //For spike
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R3mA,"3mA","-3mA").APPLY();
	DPIN_Levelset("MODE_mdm","3.6V", "0.0V", "1.8V", "1.8V",CLOSE_,ON_);
	rdk::Timer::WAIT(5e-3); 

// Test Mode In	
	I2C_Write(0x6A,0x5A); // enter test mode 
	rdk::Timer::WAIT(1e-3); 
	I2C_Write(0x6A,0xA5); // enter test mode   
	rdk::Timer::WAIT(3e-3); 

	I2C_Write(0x25,0x01); // (T_DISABLE_DRVR=1);
	rdk::Timer::WAIT(1e-3); 

	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("5.5V",rdkenum::R7V,rdkenum::R3mA,"3mA","-3mA").APPLY(); //Setting VIN, LX 3.6V -> 5.5V
	rdk::Timer::WAIT(6e-3); 
//Ilk_lxh_pre
	rdk::MMXH::PMU("LX_mmxh_pmu").vsim("2.5V",rdkenum::R7V,rdkenum::R3mA,"3mA","-3mA").connect().power(ON).APPLY();
	rdk::MMXH::PMU("LX_mmxh_pmu").vsim("5.5V",rdkenum::R7V,rdkenum::R3mA,"3mA","-3mA").APPLY();
	rdk::Timer::WAIT(5e-3);
	rdk::MMXH::PMU("LX_mmxh_pmu").vsim("5.5V",rdkenum::R7V,rdkenum::R30uA,"30.0uA","-30.0uA").APPLY();
	rdk::Timer::WAIT(5e-3);

	ILK_LX_PRE_H[0] = rdk::MMXH::PMU("LX_mmxh_pmu").MEAS_I(100);


//Ilk_lxl_pre
	MMXH_PMU_Slewrate("LX_mmxh_pmu","Slow");   //for spike
	rdk::MMXH::PMU("LX_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R30uA,"30.0uA","-30.0uA").APPLY();
	rdk::Timer::WAIT(5e-3);
	MMXH_PMU_Slewrate("LX_mmxh_pmu","VeryFast");   //for spike

	ILK_LX_PRE_L[0] = rdk::MMXH::PMU("LX_mmxh_pmu").MEAS_I(100);

	I2C_Write(0x6A,0x00); //Exit Test mode
	rdk::Timer::WAIT(1e-3); 

// clean up
	MMXH_PMU_Slewrate("VIN_mmxh_pmu" ,"Slow");  //for spike
	MMXH_PMU_Slewrate("VOUT_mmxh_pmu","Slow");  //for spike
	MMXH_PMU_Slewrate("EN_mmxh_pmu"  ,"Slow");  //for spike	

	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R3mA,"3mA","-3mA").APPLY();
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R3mA,"3mA","-3mA").APPLY();
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R3mA,"3mA","-3mA").APPLY();
	rdk::Timer::WAIT(3e-3); 
	DPIN_Levelset("MODE_mdm",OPEN_,OFF_);
	rdk::MMXH::PMU("VOUT_mmxh_pmu").disconnect().power(OFF).APPLY();	
	rdk::MMXH::PMU("EN_mmxh_pmu").disconnect().power(OFF).APPLY();	
	rdk::MMXH::PMU("VIN_mmxh_pmu").disconnect().power(OFF).APPLY();	
	rdk::MMXH::PMU("LX_mmxh_pmu").disconnect().power(OFF).APPLY();	
	rdk::CW("K_ALL").off().APPLY();
	rdk::Timer::WAIT(3e-3); 
	MMXH_PMU_Slewrate("VIN_mmxh_pmu" ,"VeryFast");  //for spike
	MMXH_PMU_Slewrate("VOUT_mmxh_pmu","VeryFast");  //for spike
	MMXH_PMU_Slewrate("EN_mmxh_pmu"  ,"VeryFast");  //for spike	

	result |= Judge(test_id,"Ilk_lxh_pre",  "T_LEAK_LS.Leak_Pre",ILK_LX_PRE_H[0],"SoftBins.BIN7"); if(RscDUTs(DUT_ACTIVE).isEmpty())return result; test_id++;
	result |= Judge(test_id,"Ilk_lxl_pre",  "T_LEAK_LS.Leak_Pre",ILK_LX_PRE_L[0],"SoftBins.BIN7"); if(RscDUTs(DUT_ACTIVE).isEmpty())return result; test_id++;

	return result;
} // T_LEAKAGE_PRE


RsltAllDUTCtnr 
TPG::T_REG_READ_PRE()
{	
	RsltAllDUTCtnr result;
	ValDUT Read;

	test_id = 200;

	//ReadBack Part - local
	ValDUT RD_OTP40;
	ValDUT RD_OTP41;
	ValDUT RD_OTP42;
	ValDUT RD_OTP43;
	ValDUT RD_OTP44;
	ValDUT RD_OTP45;
	ValDUT RD_OTP46;
	ValDUT RD_OTP47;
	ValDUT RD_OTP48;

	RscTestCondition MODE_Timing("(Timing_MODE)");
	timing_set(Timming_Speed,MODE_Timing);

// Setup
    rdk::CW("K2;K3;K13;K16").on().APPLY(); 
	rdk::Timer::WAIT(1e-3);
	
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").connect().power(ON).APPLY(); 
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").connect().power(ON).APPLY(); 
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").connect().power(ON).APPLY(); 
	rdk::Timer::WAIT(1e-3);

//IC Turn on
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("1.8V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY(); //For spike
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("1.8V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();  //For spike
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("1.8V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").APPLY();			//For spike

	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").APPLY();
	DPIN_Levelset("MODE_mdm","3.6V", "0.0V", "2.0V", "1.0V",CLOSE_,ON_);
	rdk::Timer::WAIT(3e-3); 

// Test Mode In	
	I2C_Write(0x6A,0x5A); // enter test mode 
	rdk::Timer::WAIT(1e-3); 
	I2C_Write(0x6A,0xA5); // enter test mode   
	rdk::Timer::WAIT(3e-3); 

	MMXH_PMU_Slewrate("EN_mmxh_pmu"  ,"Slow");  //for spike	
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").APPLY(); 
	rdk::Timer::WAIT(3e-3);
	rdk::MMXH::PMU("EN_mmxh_pmu").isvm("0.0mA",rdkenum::R300uA,rdkenum::R7V,"7.0V","-7.0V").APPLY();
	rdk::Timer::WAIT(3e-3);
	//rdk::MMXH::PMU("EN_mmxh_pmu").disconnect().power(OFF).APPLY(); //Keep connected for Read 0x27 - 241112
	DPIN_Levelset("MODE_mdm","3.6V", "0.0V", "2.0V", "1.0V",OPEN_,OFF_);	
	rdk::Timer::WAIT(3e-3);
    //rdk::CW("K16").off().APPLY();	//Keep connected for Read 0x27 - 241112
	MMXH_PMU_Slewrate("EN_mmxh_pmu"  ,"VeryFast");  //for spike	

	//Read Register of TEST Part
	RscTestCondition I2C_Timing("(Timing_I2C)");
	timing_set(Timming_Speed,I2C_Timing);

	DPIN_Levelset("I2CPins","3.6V", "0.0V", "2.0V", "1.0V",CLOSE_,ON_);
	rdk::Timer::WAIT(3e-3);

//Read 0x6A
	I2C_Write2(0x23,0x90); // set the readback path   
	rdk::Timer::WAIT(1e-3); 

	Read = I2C_Read(0x6A);
	result |= Judge(test_id,"R1_REG_0x6A",	Read,   -0.5, 0.5,"SoftBins.BIN12","SoftBins.BIN12","Dec"); if(RscDUTs(DUT_ACTIVE).isEmpty())return result; test_id++; //Rev0p9
	
//Read 0x20
	I2C_Write2(0x23,0x90); // set the readback path 
	rdk::Timer::WAIT(1e-3);   

	Read = I2C_Read(0x20);
	result |= Judge(test_id,"R1_REG_0x20",	Read,   -0.5, 0.5,"SoftBins.BIN12","SoftBins.BIN12","Dec"); if(RscDUTs(DUT_ACTIVE).isEmpty())return result; test_id++; //Rev0p9

//Read 0x21
	I2C_Write2(0x23,0x90); // set the readback path
	rdk::Timer::WAIT(1e-3);  

	Read = I2C_Read(0x21);
	result |= Judge(test_id,"R1_REG_0x21",	Read,   -0.5, 255.5,"SoftBins.BIN12","SoftBins.BIN12","Dec"); if(RscDUTs(DUT_ACTIVE).isEmpty())return result; test_id++;

//Read 0x22
	I2C_Write2(0x23,0x90); // set the readback path   
	rdk::Timer::WAIT(1e-3); 

	Read = I2C_Read(0x22);
	result |= Judge(test_id,"R1_REG_0x22",	Read,   -0.5, 255.5,"SoftBins.BIN12","SoftBins.BIN12","Dec"); if(RscDUTs(DUT_ACTIVE).isEmpty())return result; test_id++;

//Read 0x23
	I2C_Write2(0x23,0x90); // set the readback path
	rdk::Timer::WAIT(1e-3);    

	Read = I2C_Read(0x23);
	result |= Judge(test_id,"R1_REG_0x23",	Read,   -0.5, 255.5,"SoftBins.BIN12","SoftBins.BIN12","Dec"); if(RscDUTs(DUT_ACTIVE).isEmpty())return result; test_id++;

//Read 0x24
	I2C_Write2(0x23,0x90); // set the readback path   
	rdk::Timer::WAIT(1e-3); 

	Read = I2C_Read(0x24);
	result |= Judge(test_id,"R1_REG_0x24",	Read,   -0.5, 255.5,"SoftBins.BIN12","SoftBins.BIN12","Dec"); if(RscDUTs(DUT_ACTIVE).isEmpty())return result; test_id++;

//Read 0x25
	I2C_Write2(0x23,0x90); // set the readback path
	rdk::Timer::WAIT(1e-3);    

	Read = I2C_Read(0x25);
	result |= Judge(test_id,"R1_REG_0x25",	Read,   -0.5, 255.5,"SoftBins.BIN12","SoftBins.BIN12","Dec"); if(RscDUTs(DUT_ACTIVE).isEmpty())return result; test_id++;

//Read 0x26
	I2C_Write2(0x23,0x90); // set the readback path   
	rdk::Timer::WAIT(1e-3); 

	Read = I2C_Read(0x26);
	result |= Judge(test_id,"R1_REG_0x26",	Read,   -0.5, 255.5,"SoftBins.BIN12","SoftBins.BIN12","Dec"); if(RscDUTs(DUT_ACTIVE).isEmpty())return result; test_id++;

//Read 0x27
	I2C_Write2(0x23,0x90); // set the readback path 
	rdk::Timer::WAIT(1e-3);   

	Read = I2C_Read(0x27);
	result |= Judge(test_id,"R1_REG_0x27",	Read,   1, 255.5,"SoftBins.BIN12","SoftBins.BIN12","Dec"); if(RscDUTs(DUT_ACTIVE).isEmpty())return result; test_id++; //Rev0p9

//Read 0x28
	I2C_Write2(0x23,0x90); // set the readback path 
	rdk::Timer::WAIT(1e-3);   

	Read = I2C_Read(0x28);
	result |= Judge(test_id,"R1_REG_0x28",	Read,   -0.5, 255.5,"SoftBins.BIN12","SoftBins.BIN12","Dec"); if(RscDUTs(DUT_ACTIVE).isEmpty())return result; test_id++;

//Read 0x29
	I2C_Write2(0x23,0x90); // set the readback path 
	rdk::Timer::WAIT(1e-3);   

	Read = I2C_Read(0x29);
	result |= Judge(test_id,"R1_REG_0x29",	Read,   -0.5, 255.5,"SoftBins.BIN12","SoftBins.BIN12","Dec"); if(RscDUTs(DUT_ACTIVE).isEmpty())return result; test_id++;


//Read Register of OTP Part

//Read 0x40
	I2C_Write2(0x23,0x90); 
	rdk::Timer::WAIT(1e-3);
	
	RD_OTP40  = I2C_Read(0x40);  // Read OTP

	for(ItrDUTs itrDut(DUT_ACTIVE);!itrDut.isDone();itrDut++) 
	{
		RD_OTP40_47[*itrDut] = RD_OTP40[*itrDut] & 0xF0; //	Rdata1 & 1111 0000->???? 0000 for simulation

		if((RD_OTP40[*itrDut] & 0xF0) == 0x00) EN_OTP40_47[*itrDut] = 1; else EN_OTP40_47[*itrDut] = 0; // 1 = //fresh, 0 = burned
	}
	result |= Judge(test_id,"R1_REG_0x40",     RD_OTP40,  -0.5, 255.5,"SoftBins.BIN12","SoftBins.BIN12","Dec"); if(RscDUTs(DUT_ACTIVE).isEmpty())return result; test_id++;

//Read 0x41
	I2C_Write2(0x23,0x90); 
	rdk::Timer::WAIT(1e-3);

	RD_OTP41  = I2C_Read(0x41);  // Read OTP

	for(ItrDUTs itrDut(DUT_ACTIVE);!itrDut.isDone();itrDut++) 
	{
		RD_OTP41_03[*itrDut] = RD_OTP41[*itrDut] & 0x0F; //	Rdata1 & 0000 1111
		RD_OTP41_47[*itrDut] = RD_OTP41[*itrDut] & 0xF0; //	Rdata1 & 1111 0000->???? 0000 for simulation

		if((RD_OTP41[*itrDut] & 0x0F) == 0x00) EN_OTP41_03[*itrDut] = 1; else EN_OTP41_03[*itrDut] = 0; // 1 = //fresh, 0 = burned
		if((RD_OTP41[*itrDut] & 0xF0) == 0x00) EN_OTP41_47[*itrDut] = 1; else EN_OTP41_47[*itrDut] = 0; // 1 = //fresh, 0 = burned
	}
	result |= Judge(test_id,"R1_REG_0x41",      RD_OTP41,  -0.5, 255.5,"SoftBins.BIN12","SoftBins.BIN12","Dec"); if(RscDUTs(DUT_ACTIVE).isEmpty())return result; test_id++;


//Read 0x42
	I2C_Write2(0x23,0x90); rdk::Timer::WAIT(1e-3);
	RD_OTP42  = I2C_Read(0x42);  // Read OTP

	for(ItrDUTs itrDut(DUT_ACTIVE);!itrDut.isDone();itrDut++) 
	{
		RD_OTP42_02[*itrDut] = RD_OTP42[*itrDut] & 0x07; //	Rdata1 & 0000 0111
		RD_OTP42_47[*itrDut] = RD_OTP42[*itrDut] & 0xF0; //	Rdata1 & 1111 0000 

		if((RD_OTP42[*itrDut] & 0x07) == 0x00) EN_OTP42_02[*itrDut] = 1; else EN_OTP42_02[*itrDut] = 0; // 1 = //fresh, 0 = burned
		if((RD_OTP42[*itrDut] & 0xF0) == 0x00) EN_OTP42_47[*itrDut] = 1; else EN_OTP42_47[*itrDut] = 0; // 1 = //fresh, 0 = burned 
	}

	result |= Judge(test_id,"R1_REG_0x42",      RD_OTP42,  -0.5, 255.5,"SoftBins.BIN12","SoftBins.BIN12","Dec"); if(RscDUTs(DUT_ACTIVE).isEmpty())return result; test_id++;


//Read 0x43
	I2C_Write(0x23,0x90); 
	rdk::Timer::WAIT(1e-3);

	RD_OTP43  = I2C_Read(0x43);  // Read OTP

	for(ItrDUTs itrDut(DUT_ACTIVE);!itrDut.isDone();itrDut++) 
	{
		RD_OTP43_03[*itrDut] = RD_OTP43[*itrDut] & 0x0F; //	Rdata1 & 0000 1111
		RD_OTP43_47[*itrDut] = RD_OTP43[*itrDut] & 0xF0; //	Rdata1 & 0001 0000

		if((RD_OTP43[*itrDut] & 0x0F) == 0x00) EN_OTP43_03[*itrDut] = 1; else EN_OTP43_03[*itrDut] = 0; // 1 = //fresh, 0 = burned
		if((RD_OTP43[*itrDut] & 0xF0) == 0x00) EN_OTP43_47[*itrDut] = 1; else EN_OTP43_47[*itrDut] = 0; // 1 = //fresh, 0 = burned
	}

	result |= Judge(test_id,"R1_REG_0x43",         RD_OTP43,  -0.5, 255.5,"SoftBins.BIN12","SoftBins.BIN12","Dec"); if(RscDUTs(DUT_ACTIVE).isEmpty())return result; test_id++;
	

//Read 0x47 - 0x47 First, 0x44 is better for stable OTP READ. But display later. 240827
	I2C_Write(0x23,0x90); 
	rdk::Timer::WAIT(1e-3);

	RD_OTP47  = I2C_Read(0x47);  // Read OTP
	for(ItrDUTs itrDut(DUT_ACTIVE);!itrDut.isDone();itrDut++) 
	{
		RD_OTP47_05[*itrDut] = RD_OTP47[*itrDut] & 0x3F; //	Rdata1 & 0011 1111 

		if((RD_OTP47[*itrDut] & 0x3F) == 0x00) EN_OTP47_05[*itrDut] = 1; else EN_OTP47_05[*itrDut] = 0; // 1 = //fresh, 0 = burned
	}

//Read 0x44
	I2C_Write(0x23,0x90); 
	rdk::Timer::WAIT(1e-3);

	RD_OTP44  = I2C_Read(0x44);  // Read OTP
	result |= Judge(test_id,"R1_REG_0x44",RD_OTP44,  -0.5, 255.5,"SoftBins.BIN12","SoftBins.BIN12","Dec"); if(RscDUTs(DUT_ACTIVE).isEmpty())return result; test_id++;

//Read 0x45
	I2C_Write(0x23,0x90); 
	rdk::Timer::WAIT(1e-3);

	RD_OTP45  = I2C_Read(0x45);  // Read OTP
	result |= Judge(test_id,"R1_REG_0x45",RD_OTP45,  -0.5, 255.5,"SoftBins.BIN12","SoftBins.BIN12","Dec"); if(RscDUTs(DUT_ACTIVE).isEmpty())return result; test_id++;

//Read 0x46
	I2C_Write(0x23,0x90); 
	rdk::Timer::WAIT(1e-3);

	RD_OTP46  = I2C_Read(0x46);  // Read OTP
	result |= Judge(test_id,"R1_REG_0x46",RD_OTP46,  -0.5, 255.5,"SoftBins.BIN12","SoftBins.BIN12","Dec"); if(RscDUTs(DUT_ACTIVE).isEmpty())return result; test_id++;


//Read 0x47 - Display Result
	result |= Judge(test_id,"R1_REG_0x47",RD_OTP47,  -0.5, 255.5,"SoftBins.BIN12","SoftBins.BIN12","Dec"); if(RscDUTs(DUT_ACTIVE).isEmpty())return result; test_id++;


//Read 0x48
	I2C_Write(0x23,0x90); 
	rdk::Timer::WAIT(1e-3);

	RD_OTP48  = I2C_Read(0x48);  // Read OTP

	for(ItrDUTs itrDut(DUT_ACTIVE);!itrDut.isDone();itrDut++) 
	{
		RD_OTP48_04[*itrDut] = RD_OTP48[*itrDut] & 0x1F; //	Rdata1 & 0001 1111

		if((RD_OTP48[*itrDut] & 0x1F) == 0x00) EN_OTP48_04[*itrDut] = 1;
		else EN_OTP48_04[*itrDut] = 0; // 1 = //fresh, 0 = burned
	}
	result |= Judge(test_id,"R1_REG_0x48",RD_OTP48,  -0.5, 255.5,"SoftBins.BIN12","SoftBins.BIN12","Dec"); if(RscDUTs(DUT_ACTIVE).isEmpty())return result; test_id++;

// clean up
	I2C_Write(0x6A,0x00); //Exit Test Mode
	rdk::Timer::WAIT(1e-3); 

	MMXH_PMU_Slewrate("VIN_mmxh_pmu" ,"Slow");  //for spike
	MMXH_PMU_Slewrate("VOUT_mmxh_pmu","Slow");  //for spike

	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();
	rdk::Timer::WAIT(3e-3);
	rdk::MMXH::PMU("VOUT_mmxh_pmu").disconnect().power(OFF).APPLY();	
	rdk::MMXH::PMU("VIN_mmxh_pmu").disconnect().power(OFF).APPLY();	
	rdk::MMXH::PMU("EN_mmxh_pmu").disconnect().power(OFF).APPLY();	
	DPIN_Levelset("I2CPins",OPEN_,OFF_);
	rdk::CW("K_ALL").off().APPLY();
	rdk::Timer::WAIT(3e-3);

	MMXH_PMU_Slewrate("VIN_mmxh_pmu" ,"VeryFast");   //for spike
	MMXH_PMU_Slewrate("VOUT_mmxh_pmu","VeryFast");   //for spike

//Do not Trim if it's tested before for Correlation chip
//1 => fresh, 0=>burend
for(ItrDUTs itrDut(DUT_ACTIVE);!itrDut.isDone();itrDut++) 
{
	if(EN_OTP43_47[*itrDut]==0) //9.TON
	{
		vbg_exc_flag[*itrDut]	=0;
		vref_exc_flag[*itrDut]	=0;
		ibias_exc_flag[*itrDut]	=0;
		rsns_exc_flag[*itrDut]	=0;
		fosc_exc_flag[*itrDut]	=0;
		hscl_exc_flag[*itrDut]	=0;
		vcl_exc_flag[*itrDut]	=0;
		zcs_exc_flag[*itrDut]	=0;
		ton_exc_flag[*itrDut]	=0;	
	}
	
	else if(EN_OTP43_03[*itrDut]==0) //8.ZCS
	{
		vbg_exc_flag[*itrDut]	=0;
		vref_exc_flag[*itrDut]	=0;
		ibias_exc_flag[*itrDut]	=0;
		rsns_exc_flag[*itrDut]	=0;
		fosc_exc_flag[*itrDut]	=0;
		hscl_exc_flag[*itrDut]	=0;
		vcl_exc_flag[*itrDut]	=0;
		zcs_exc_flag[*itrDut]	=0;
		ton_exc_flag[*itrDut]	=1;	
	}
	
	else if(EN_OTP42_02[*itrDut]==0)//7.VCL
	{
		vbg_exc_flag[*itrDut]	=0;
		vref_exc_flag[*itrDut]	=0;
		ibias_exc_flag[*itrDut]	=0;
		rsns_exc_flag[*itrDut]	=0;
		fosc_exc_flag[*itrDut]	=0;
		hscl_exc_flag[*itrDut]	=0;
		vcl_exc_flag[*itrDut]	=0;
		zcs_exc_flag[*itrDut]	=1;
		ton_exc_flag[*itrDut]	=1;	
	}
	
	else if(EN_OTP42_47[*itrDut]==0)//6.HSCL
	{
		vbg_exc_flag[*itrDut]	=0;
		vref_exc_flag[*itrDut]	=0;
		ibias_exc_flag[*itrDut]	=0;
		rsns_exc_flag[*itrDut]	=0;
		fosc_exc_flag[*itrDut]	=0;
		hscl_exc_flag[*itrDut]	=0;
		vcl_exc_flag[*itrDut]	=1;
		zcs_exc_flag[*itrDut]	=1;
		ton_exc_flag[*itrDut]	=1;	
	}
	
	else if(EN_OTP41_47[*itrDut]==0)//5.FOSC
	{
		vbg_exc_flag[*itrDut]	=0;
		vref_exc_flag[*itrDut]	=0;
		ibias_exc_flag[*itrDut]	=0;
		rsns_exc_flag[*itrDut]	=0;
		fosc_exc_flag[*itrDut]	=0;
		hscl_exc_flag[*itrDut]	=1;
		vcl_exc_flag[*itrDut]	=1;
		zcs_exc_flag[*itrDut]	=1;
		ton_exc_flag[*itrDut]	=1;	
	}
	
	else if(EN_OTP48_04[*itrDut]==0)//4.RSNS
	{
		vbg_exc_flag[*itrDut]	=0;
		vref_exc_flag[*itrDut]	=0;
		ibias_exc_flag[*itrDut]	=0;
		rsns_exc_flag[*itrDut]	=0;
		fosc_exc_flag[*itrDut]	=1;
		hscl_exc_flag[*itrDut]	=1;
		vcl_exc_flag[*itrDut]	=1;
		zcs_exc_flag[*itrDut]	=1;
		ton_exc_flag[*itrDut]	=1;	
	}
	
	else if(EN_OTP41_03[*itrDut]==0)//3.IBIAS
	{
		vbg_exc_flag[*itrDut]	=0;
		vref_exc_flag[*itrDut]	=0;
		ibias_exc_flag[*itrDut]	=0;
		rsns_exc_flag[*itrDut]	=1;
		fosc_exc_flag[*itrDut]	=1;
		hscl_exc_flag[*itrDut]	=1;
		vcl_exc_flag[*itrDut]	=1;
		zcs_exc_flag[*itrDut]	=1;
		ton_exc_flag[*itrDut]	=1;	
	}
	
	else if(EN_OTP40_47[*itrDut]==0)//2.VREF
	{
		vbg_exc_flag[*itrDut]	=0;
		vref_exc_flag[*itrDut]	=0;
		ibias_exc_flag[*itrDut]	=1;
		rsns_exc_flag[*itrDut]	=1;
		fosc_exc_flag[*itrDut]	=1;
		hscl_exc_flag[*itrDut]	=1;
		vcl_exc_flag[*itrDut]	=1;
		zcs_exc_flag[*itrDut]	=1;
		ton_exc_flag[*itrDut]	=1;	
	}
	
	else 
	{
		vbg_exc_flag[*itrDut]	=1;
		vref_exc_flag[*itrDut]	=1;
		ibias_exc_flag[*itrDut]	=1;
		rsns_exc_flag[*itrDut]	=1;
		fosc_exc_flag[*itrDut]	=1;
		hscl_exc_flag[*itrDut]	=1;
		vcl_exc_flag[*itrDut]	=1;
		zcs_exc_flag[*itrDut]	=1;
		ton_exc_flag[*itrDut]	=1;	
	}
}

	return result;		
} //T_REG_READ_PRE


//VBG_TRIM
RsltAllDUTCtnr
TPG::T_VBG_TRIM()
{
	RsltAllDUTCtnr result;
	test_id = 300;
	
    //ValDUT read_BGR_VD;
	OFCArray<ValDUT> VBG_pre(1,100);
	OFCArray<ValDUT> VBG_sim(1,100);
	ValDUT VBG_pre_err;
	ValDUT VBG_sim_err;
	//ValDUT VBG_code;

	RscTestCondition MODE_Timing("(Timing_MODE)");
	timing_set(Timming_Speed,MODE_Timing);

//	Setup test mode entry
	rdk::CW("K2;K13;K16").on().APPLY(); // MODE_MDM, EN_MMXH, VIN_CAP
	rdk::Timer::WAIT(3e-3); 

//IC Turn on
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("1.8V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").connect().power(ON).APPLY(); //For spike
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("1.8V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").connect().power(ON).APPLY();  //For spike
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("1.8V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").connect().power(ON).APPLY();    //For spike

	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").APPLY(); 	
	DPIN_Levelset("MODE_mdm","3.6V", "0.0V", "1.8V", "1.8V",CLOSE_,ON_);
	rdk::Timer::WAIT(15e-3); 

	I2C_Write(0x6A,0x5A);  // enter test mode 
	rdk::Timer::WAIT(1e-3);
	I2C_Write(0x6A,0xA5); // enter test mode  2. Enter Test Mode.
	rdk::Timer::WAIT(3e-3); 

	MMXH_PMU_Slewrate("EN_mmxh_pmu"  ,"Slow");  //for spike	
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").APPLY(); //EN Float-1
	rdk::Timer::WAIT(3e-3); 
	rdk::MMXH::PMU("EN_mmxh_pmu").isvm("0.0mA",rdkenum::R3mA,rdkenum::R2V,"2V","-2V").APPLY(); //EN Float-2
	rdk::Timer::WAIT(3e-3); 
	rdk::MMXH::PMU("EN_mmxh_pmu").disconnect().power(OFF).APPLY();
	MMXH_PMU_Slewrate("EN_mmxh_pmu"  ,"VeryFast");  //for spike	
	rdk::CW("K16").off().APPLY(); // EN_MMXH
	rdk::Timer::WAIT(3e-3);
	rdk::CW("K5").on().APPLY(); // OP7
	rdk::Timer::WAIT(3e-3); 
	
	rdk::MMXH::PMU("EN_mmxh_pmu").isvm("0.0mA",rdkenum::R3mA,rdkenum::R2V,"2V","-2V").connect().power(ON).APPLY(); 
	rdk::Timer::WAIT(3e-3); 

	I2C_Write(0x24,0x04); // (DIS_EN=1)
	rdk::Timer::WAIT(1e-3); 
	I2C_Write(0x23,0x08); // (AD_MUXO_EN=1)   
	rdk::Timer::WAIT(3e-3); 

// Pre measure
	VBG_pre[0] = rdk::MMXH::PMU("EN_mmxh_pmu").MEAS_V(200);

    for(ItrDUTs itrDut(DUT_ACTIVE); !itrDut.isDone(); itrDut++) 
	{
		VBG_pre_err[*itrDut] = ((VBG_target - VBG_pre[0][*itrDut].getAsDouble()) / ((VBG_pre[0][*itrDut].getAsDouble())+1e-9));
    }

	I2C_Write(0x6A,0x00); // EXIT test mode
	rdk::Timer::WAIT(1.0e-3); 

// clean up
	MMXH_PMU_Slewrate("VIN_mmxh_pmu" ,"Slow");  //for spike
	MMXH_PMU_Slewrate("VOUT_mmxh_pmu","Slow");  //for spike

	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").APPLY();
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("0.0V",rdkenum::R2V,rdkenum::R3mA,"3.0mA","-3.0mA").APPLY();
	rdk::Timer::WAIT(3e-3);
	rdk::MMXH::PMU("VOUT_mmxh_pmu").disconnect().power(OFF).APPLY();	
	rdk::MMXH::PMU("EN_mmxh_pmu").disconnect().power(OFF).APPLY();	
	rdk::MMXH::PMU("VIN_mmxh_pmu").disconnect().power(OFF).APPLY();	
	DPIN_Levelset("MODE_mdm",OPEN_,OFF_);
	rdk::CW("K_ALL").off().APPLY(); 
	rdk::Timer::WAIT(3e-3);

	MMXH_PMU_Slewrate("VIN_mmxh_pmu" ,"VeryFast");  //for spike
	MMXH_PMU_Slewrate("VOUT_mmxh_pmu","VeryFast");  //for spike

	result |= Judge(test_id,"VBG_pre",    "T_VBG_TRIM_LS.VBG_pre",     VBG_pre[0],"SoftBins.BIN13"); if(RscDUTs(DUT_ACTIVE).isEmpty())return result; test_id++;
	result |= Judge(test_id,"VBG_pre_err","T_VBG_TRIM_LS.VBG_pre_err",VBG_pre_err,"SoftBins.BIN13"); if(RscDUTs(DUT_ACTIVE).isEmpty()) return result; test_id++;


// trim table
	for(ItrDUTs itrDut(DUT_ACTIVE);!itrDut.isDone();itrDut++) 
	{
		double VBG_data_err = VBG_pre_err[*itrDut].getAsDouble() * 100;

		if ( VBG_data_err >= -50 && VBG_data_err<50)
		{	
		
			if (VBG_data_err >= 0.12 && VBG_data_err < 0.31)		{ vbg_code[*itrDut] = 63; }
			if (VBG_data_err >= 0.31 && VBG_data_err < 0.49)		{ vbg_code[*itrDut] = 62; }
			if (VBG_data_err >= 0.49 && VBG_data_err < 0.66)		{ vbg_code[*itrDut] = 61; }
			if (VBG_data_err >= 0.66 && VBG_data_err < 0.82)		{ vbg_code[*itrDut] = 60; }
			if (VBG_data_err >= 0.82 && VBG_data_err < 0.99)		{ vbg_code[*itrDut] = 59; }
			if (VBG_data_err >= 0.99 && VBG_data_err < 1.15)		{ vbg_code[*itrDut] = 58; }
			if (VBG_data_err >= 1.15 && VBG_data_err < 1.32)		{ vbg_code[*itrDut] = 57; }
			if (VBG_data_err >= 1.32 && VBG_data_err < 1.50)		{ vbg_code[*itrDut] = 56; }
			if (VBG_data_err >= 1.50 && VBG_data_err < 1.67)		{ vbg_code[*itrDut] = 55; }
			if (VBG_data_err >= 1.67 && VBG_data_err < 1.83)		{ vbg_code[*itrDut] = 54; }
			if (VBG_data_err >= 1.83 && VBG_data_err < 1.99)		{ vbg_code[*itrDut] = 53; }
			if (VBG_data_err >= 1.99 && VBG_data_err < 2.16)		{ vbg_code[*itrDut] = 52; }
			if (VBG_data_err >= 2.16 && VBG_data_err < 2.33)		{ vbg_code[*itrDut] = 51; }
			if (VBG_data_err >= 2.33 && VBG_data_err < 2.49)		{ vbg_code[*itrDut] = 50; }
			if (VBG_data_err >= 2.49 && VBG_data_err < 2.65)		{ vbg_code[*itrDut] = 49; }
			if (VBG_data_err >= 2.65 && VBG_data_err < 2.83)		{ vbg_code[*itrDut] = 48; }
			if (VBG_data_err >= 2.83 && VBG_data_err < 3.01)		{ vbg_code[*itrDut] = 47; }
			if (VBG_data_err >= 3.01 && VBG_data_err < 3.17)		{ vbg_code[*itrDut] = 46; }
			if (VBG_data_err >= 3.17 && VBG_data_err < 3.33)		{ vbg_code[*itrDut] = 45; }
			if (VBG_data_err >= 3.33 && VBG_data_err < 3.49)		{ vbg_code[*itrDut] = 44; }
			if (VBG_data_err >= 3.49 && VBG_data_err < 3.65)		{ vbg_code[*itrDut] = 43; }
			if (VBG_data_err >= 3.65 && VBG_data_err < 3.80)		{ vbg_code[*itrDut] = 42; }
			if (VBG_data_err >= 3.80 && VBG_data_err < 3.96)		{ vbg_code[*itrDut] = 41; }
			if (VBG_data_err >= 3.96 && VBG_data_err < 4.13)		{ vbg_code[*itrDut] = 40; }
			if (VBG_data_err >= 4.13 && VBG_data_err < 4.30)		{ vbg_code[*itrDut] = 39; }
			if (VBG_data_err >= 4.30 && VBG_data_err < 4.45)		{ vbg_code[*itrDut] = 38; }
			if (VBG_data_err >= 4.45 && VBG_data_err < 4.60)		{ vbg_code[*itrDut] = 37; }
			if (VBG_data_err >= 4.60 && VBG_data_err < 4.76)		{ vbg_code[*itrDut] = 36; }
			if (VBG_data_err >= 4.76 && VBG_data_err < 4.92)		{ vbg_code[*itrDut] = 35; }
			if (VBG_data_err >= 4.92 && VBG_data_err < 5.07)		{ vbg_code[*itrDut] = 34; }
			if (VBG_data_err >= 5.07 && VBG_data_err < 5.20)		{ vbg_code[*itrDut] = 33; }
			if (VBG_data_err >= 5.20 && VBG_data_err < 50.0)		{ vbg_code[*itrDut] = 32; }

			if (VBG_data_err >= -50.0 && VBG_data_err < -5.59)  	{ vbg_code[*itrDut] = 31; }
			if (VBG_data_err >= -5.59 && VBG_data_err < -5.40)		{ vbg_code[*itrDut] = 30; }
			if (VBG_data_err >= -5.40 && VBG_data_err < -5.22)		{ vbg_code[*itrDut] = 29; }
			if (VBG_data_err >= -5.22 && VBG_data_err < -5.02)		{ vbg_code[*itrDut] = 28; }
			if (VBG_data_err >= -5.02 && VBG_data_err < -4.83)		{ vbg_code[*itrDut] = 27; }
			if (VBG_data_err >= -4.83 && VBG_data_err < -4.64)		{ vbg_code[*itrDut] = 26; }
			if (VBG_data_err >= -4.64 && VBG_data_err < -4.46)		{ vbg_code[*itrDut] = 25; }
			if (VBG_data_err >= -4.46 && VBG_data_err < -4.26)		{ vbg_code[*itrDut] = 24; }
			if (VBG_data_err >= -4.26 && VBG_data_err < -4.06)		{ vbg_code[*itrDut] = 23; }
			if (VBG_data_err >= -4.06 && VBG_data_err < -3.88)		{ vbg_code[*itrDut] = 22; }
			if (VBG_data_err >= -3.88 && VBG_data_err < -3.70)		{ vbg_code[*itrDut] = 21; }
			if (VBG_data_err >= -3.70 && VBG_data_err < -3.51)		{ vbg_code[*itrDut] = 20; }
			if (VBG_data_err >= -3.51 && VBG_data_err < -3.32)		{ vbg_code[*itrDut] = 19; }
			if (VBG_data_err >= -3.32 && VBG_data_err < -3.14)		{ vbg_code[*itrDut] = 18; }
			if (VBG_data_err >= -3.14 && VBG_data_err < -2.96)		{ vbg_code[*itrDut] = 17; }
			if (VBG_data_err >= -2.96 && VBG_data_err < -2.77)		{ vbg_code[*itrDut] = 16; }
			if (VBG_data_err >= -2.77 && VBG_data_err < -2.57)		{ vbg_code[*itrDut] = 15; }
			if (VBG_data_err >= -2.57 && VBG_data_err < -2.39)		{ vbg_code[*itrDut] = 14; }
			if (VBG_data_err >= -2.39 && VBG_data_err < -2.22)		{ vbg_code[*itrDut] = 13; }
			if (VBG_data_err >= -2.22 && VBG_data_err < -2.03)		{ vbg_code[*itrDut] = 12; }
			if (VBG_data_err >= -2.03 && VBG_data_err < -1.85)		{ vbg_code[*itrDut] = 11; }
			if (VBG_data_err >= -1.85 && VBG_data_err < -1.67)		{ vbg_code[*itrDut] = 10; }
			if (VBG_data_err >= -1.67 && VBG_data_err < -1.50)		{ vbg_code[*itrDut] = 9; }
			if (VBG_data_err >= -1.50 && VBG_data_err < -1.31)		{ vbg_code[*itrDut] = 8; }
			if (VBG_data_err >= -1.31 && VBG_data_err < -1.13)		{ vbg_code[*itrDut] = 7; }
			if (VBG_data_err >= -1.13 && VBG_data_err < -0.95)		{ vbg_code[*itrDut] = 6; }
			if (VBG_data_err >= -0.95 && VBG_data_err < -0.77)		{ vbg_code[*itrDut] = 5; }
			if (VBG_data_err >= -0.77 && VBG_data_err < -0.60)		{ vbg_code[*itrDut] = 4; }
			if (VBG_data_err >= -0.60 && VBG_data_err < -0.43)		{ vbg_code[*itrDut] = 3; }
			if (VBG_data_err >= -0.43 && VBG_data_err < -0.26)		{ vbg_code[*itrDut] = 2; }
			if (VBG_data_err >= -0.26 && VBG_data_err < -0.09)		{ vbg_code[*itrDut] = 1; }
			if (VBG_data_err >= -0.09 && VBG_data_err <  0.12)		{ vbg_code[*itrDut] = 0; }
		}
		else
			vbg_code[*itrDut] = 0; //

       if (EN_OTP47_05[*itrDut] == 0) { vbg_code[*itrDut] = RD_OTP47_05[*itrDut].getAsInt(); } 

	}

	result |= Judge(test_id,"VBG_code",	vbg_code,   -0.5, 255.5,"SoftBins.BIN13","SoftBins.BIN13","Dec"); if(RscDUTs(DUT_ACTIVE).isEmpty())return result; test_id++;


//	Setup test mode entry -2nd
	rdk::CW("K2;K13;K16").on().APPLY(); // MODE_MDM, EN_MMXH, VIN_CAP
	rdk::Timer::WAIT(3e-3); 
	
//IC Turn on
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("1.8V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").connect().power(ON).APPLY(); //For spike
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("1.8V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").connect().power(ON).APPLY();  //For spike
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("1.8V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").connect().power(ON).APPLY();    //For spike

	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").APPLY(); 
	DPIN_Levelset("MODE_mdm","3.6V", "0.0V", "1.8V", "1.8V",CLOSE_,ON_);
	rdk::Timer::WAIT(15e-3); 

	I2C_Write(0x6A,0x5A); // enter test mode 
	rdk::Timer::WAIT(1e-3); 
	I2C_Write(0x6A,0xA5); // enter test mode  2. Enter Test Mode.
	rdk::Timer::WAIT(5e-3); 

	MMXH_PMU_Slewrate("EN_mmxh_pmu"  ,"Slow");  //for spike	
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").APPLY(); //EN Float-1
	rdk::Timer::WAIT(3e-3); 
	rdk::MMXH::PMU("EN_mmxh_pmu").isvm("0.0mA",rdkenum::R3mA,rdkenum::R2V,"2V","-2V").APPLY(); //EN Float-2
	rdk::Timer::WAIT(3e-3); 
	rdk::MMXH::PMU("EN_mmxh_pmu").disconnect().power(OFF).APPLY();
	MMXH_PMU_Slewrate("EN_mmxh_pmu"  ,"VeryFast");  //for spike	


	rdk::CW("K16").off().APPLY(); // EN_MMXH
	rdk::Timer::WAIT(3e-3);
	rdk::CW("K5").on().APPLY(); // OP7
	rdk::Timer::WAIT(3e-3); 
	
	rdk::MMXH::PMU("EN_mmxh_pmu").isvm("0.0mA",rdkenum::R3mA,rdkenum::R2V,"2V","-2V").connect().power(ON).APPLY(); 
	rdk::Timer::WAIT(3e-3); 

	I2C_Write(0x24,0x04); // (DIS_EN=1)
	rdk::Timer::WAIT(1e-3); 
	I2C_Write(0x23,0x08); // (AD_MUXO_EN=1)   
	rdk::Timer::WAIT(3e-3); 

//Sim Measure
	I2C_Write(0x47,vbg_code); // OTP data write reg.
	rdk::Timer::WAIT(3e-3); 
 
	VBG_sim[0] = rdk::MMXH::PMU("EN_mmxh_pmu").MEAS_V(100);

    for(ItrDUTs itrDut(DUT_ACTIVE); !itrDut.isDone(); itrDut++) 
	{
		VBG_sim_err[*itrDut] = ((VBG_target - VBG_sim[0][*itrDut].getAsDouble() ) / (VBG_sim[0][*itrDut].getAsDouble()+1e-9) ); 
    }

	I2C_Write(0x6A,0x00); 
	rdk::Timer::WAIT(1e-3); // EXIT test mode

// clean up
	MMXH_PMU_Slewrate("VIN_mmxh_pmu" ,"Slow");  //for spike
	MMXH_PMU_Slewrate("VOUT_mmxh_pmu","Slow");  //for spike

	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").APPLY();
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("0.0V",rdkenum::R2V,rdkenum::R3mA,"3.0mA","-3.0mA").APPLY();
	rdk::Timer::WAIT(3e-3);
	rdk::MMXH::PMU("VOUT_mmxh_pmu").disconnect().power(OFF).APPLY();	
	rdk::MMXH::PMU("EN_mmxh_pmu").disconnect().power(OFF).APPLY();	
	rdk::MMXH::PMU("VIN_mmxh_pmu").disconnect().power(OFF).APPLY();	
	DPIN_Levelset("MODE_mdm",OPEN_,OFF_);
	rdk::CW("K_ALL").off().APPLY(); 
	rdk::Timer::WAIT(3e-3);

	MMXH_PMU_Slewrate("VIN_mmxh_pmu" ,"VeryFast");  //for spike
	MMXH_PMU_Slewrate("VOUT_mmxh_pmu","VeryFast");  //for spike

	result |= Judge(test_id,"VBG_sim",    "T_VBG_TRIM_LS.VBG_sim",     VBG_sim[0],"SoftBins.BIN13"); if(RscDUTs(DUT_ACTIVE).isEmpty())return result; test_id++;
	result |= Judge(test_id,"VBG_sim_err","T_VBG_TRIM_LS.VBG_sim_err",VBG_sim_err,"SoftBins.BIN13"); if(RscDUTs(DUT_ACTIVE).isEmpty()) return result; test_id++;

	return result;
} // T_BGR_Trim


RsltAllDUTCtnr
TPG::T_VBG_BURN()
{
	//TestConditions.apply();
	RsltAllDUTCtnr result;

	if (en_trim == 1)
	{
			rdk::CW("K2;K12;K13;K16").on().APPLY(); // MODE MDM, EN MMXH, VIN_CAP, VOUT_CAP 
			rdk::Timer::WAIT(3e-3); 

			//IC Turn on
			rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("1.8V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").connect().power(ON).APPLY(); //For spike
			rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("1.8V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").connect().power(ON).APPLY();  //For spike
			rdk::MMXH::PMU("EN_mmxh_pmu").vsim("1.8V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").connect().power(ON).APPLY();    //For spike

			rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();
			rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();
			rdk::MMXH::PMU("EN_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").APPLY();
			DPIN_Levelset("MODE_mdm","3.6V", "0.0V", "1.8V", "1.8V",CLOSE_,ON_);
			rdk::Timer::WAIT(15e-3); 

			I2C_Write(0x6A,0x5A);     rdk::Timer::WAIT(1e-3); // enter test mode 
			I2C_Write(0x6A,0xA5);     rdk::Timer::WAIT(1e-3); // enter test mode  2. Enter Test Mode.
			I2C_Write(0x47,vbg_code); rdk::Timer::WAIT(1e-3); //3. Write target OTP values into REG 0x40 to 0x48.
			I2C_Write(0x20,0x07);     rdk::Timer::WAIT(1e-3); // 4. Write REG 0x20 = 0x00 to select data in REG 0x40 to be burned.
			I2C_Write(0x21,0x09);     rdk::Timer::WAIT(1e-3); // 5. Write REG 0x21=0x09 (OTP_CLK_REQ=1, EXVPP_EN=1).


			for(ItrDUTs itrDut(DUT_ACTIVE); !itrDut.isDone(); itrDut++) 
			{
				VHEN1[*itrDut] = EN_OTP47_05[*itrDut] * 1.0 * 5;
				VHEN2[*itrDut] = EN_OTP47_05[*itrDut] * 1.1 * 5;
				VHEN3[*itrDut] = EN_OTP47_05[*itrDut] * 1.2 * 5;
				VHEN4[*itrDut] = EN_OTP47_05[*itrDut] * 1.3 * 5;
				VHEN5[*itrDut] = EN_OTP47_05[*itrDut] * 1.4 * 5;

				//For VIN : If burend chip, VIN off, VOUT off
				VIEN[*itrDut] = EN_OTP47_05[*itrDut] * 5.5; //5.5V
				VOEN[*itrDut] = EN_OTP47_05[*itrDut] * 3.6; //3.6V
			}										  
			
			//If burend chip, VIN & VOUT off slowly
			MMXH_PMU_Slewrate("VIN_mmxh_pmu","Slow");   //for spike
			MMXH_PMU_Slewrate("VOUT_mmxh_pmu","Slow");   //for spike
			rdk::MMXH::PMU("VIN_mmxh_pmu").vsim(VIEN,rdkenum::R7V,rdkenum::R240mA,"200.0mA","-200.0mA").APPLY(); // VIN 5.5 V is needed for Burn //Check 0V and 5.5V both with DGT
			rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim(VOEN,rdkenum::R7V,rdkenum::R240mA,"200.0mA","-200.0mA").APPLY();
			rdk::Timer::WAIT(3e-3);	
			MMXH_PMU_Slewrate("VOUT_mmxh_pmu","VeryFast");   //for spike
			MMXH_PMU_Slewrate("VIN_mmxh_pmu","VeryFast");   //for spike

			//Burn
			rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim(VHEN1,rdkenum::R7V,rdkenum::R240mA,"200.0mA","-200.0mA").APPLY();
			rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim(VHEN2,rdkenum::R7V,rdkenum::R240mA,"200.0mA","-200.0mA").APPLY();
			rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim(VHEN3,rdkenum::R7V,rdkenum::R240mA,"200.0mA","-200.0mA").APPLY();
			rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim(VHEN4,rdkenum::R7V,rdkenum::R240mA,"200.0mA","-200.0mA").APPLY();
			rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim(VHEN5,rdkenum::R7V,rdkenum::R240mA,"200.0mA","-200.0mA").APPLY();
			rdk::Timer::WAIT(1e-3); 

			I2C_Write(0x21,0x0B); //7. Write 0x21 = 0x0B to program the OTP(BURN_EN=1). 8. Wait 1ms.
			rdk::Timer::WAIT(1e-3); 
			I2C_Write(0x21,0x09); //9. Write 0x21 = 0x09 to stop OTP programming.
			rdk::Timer::WAIT(1e-3); 

			rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim(VHEN5,rdkenum::R7V,rdkenum::R240mA,"200.0mA","-200.0mA").APPLY();
			rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim(VHEN4,rdkenum::R7V,rdkenum::R240mA,"200.0mA","-200.0mA").APPLY();
			rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim(VHEN3,rdkenum::R7V,rdkenum::R240mA,"200.0mA","-200.0mA").APPLY();
			rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim(VHEN2,rdkenum::R7V,rdkenum::R240mA,"200.0mA","-200.0mA").APPLY();
			rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim(VHEN1,rdkenum::R7V,rdkenum::R240mA,"200.0mA","-200.0mA").APPLY();
			rdk::Timer::WAIT(1e-3); 

			I2C_Write(0x6A,0x00); // exit test mode
			rdk::Timer::WAIT(1e-3); 

			// clean up
			MMXH_PMU_Slewrate("VIN_mmxh_pmu" ,"Slow");   //for spike
			MMXH_PMU_Slewrate("VOUT_mmxh_pmu","Slow");   //for spike
			MMXH_PMU_Slewrate("EN_mmxh_pmu"  ,"Slow");   //for spike	

			rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R240mA,"200.0mA","-200.0mA").APPLY();
			rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();
			rdk::MMXH::PMU("EN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();
			rdk::Timer::WAIT(3e-3);
			DPIN_Levelset("MODE_mdm",OPEN_,OFF_);
			rdk::MMXH::PMU("VOUT_mmxh_pmu").disconnect().power(OFF).APPLY();
			rdk::MMXH::PMU("VIN_mmxh_pmu").disconnect().power(OFF).APPLY();
			rdk::MMXH::PMU("EN_mmxh_pmu").disconnect().power(OFF).APPLY();
			rdk::CW("K_ALL").off().APPLY();
			rdk::Timer::WAIT(3e-3);

			MMXH_PMU_Slewrate("VIN_mmxh_pmu" ,"VeryFast");   //for spike
			MMXH_PMU_Slewrate("VOUT_mmxh_pmu","VeryFast");   //for spike
			MMXH_PMU_Slewrate("EN_mmxh_pmu"  ,"VeryFast");   //for spike	
	}


	result |= Judge(test_id,"VBG_burn", "T_BURN.BURN", EN_OTP47_05,"SoftBins.BIN13"); if(RscDUTs(DUT_ACTIVE).isEmpty())return result; test_id++;

	return result;
} // T_VBG_Burn


RsltAllDUTCtnr
TPG::T_VBG_POST()
{
	//TestConditions.apply();
	RsltAllDUTCtnr result;

	OFCArray<ValDUT> VBG_post(1,100);
	ValDUT VBG_post_err;

	RscTestCondition MODE_Timing("(Timing_MODE)");
	timing_set(Timming_Speed,MODE_Timing);

	rdk::CW("K2;K13;K16").on().APPLY(); // MODE_MDM, EN_MMXH, VIN_CAP
	rdk::Timer::WAIT(3e-3); 

	//IC Turn on
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("1.8V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").connect().power(ON).APPLY(); //For spike
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("1.8V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").connect().power(ON).APPLY();  //For spike
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("1.8V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").connect().power(ON).APPLY();    //For spike

	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").APPLY(); 
	DPIN_Levelset("MODE_mdm","3.6V", "0.0V", "1.8V", "1.8V",CLOSE_,ON_);
	rdk::Timer::WAIT(15e-3); 


	I2C_Write(0x6A,0x5A); // enter test mode 
	rdk::Timer::WAIT(1e-3); 
	I2C_Write(0x6A,0xA5); // enter test mode  2. Enter Test Mode.
	rdk::Timer::WAIT(5e-3); 

	MMXH_PMU_Slewrate("EN_mmxh_pmu"  ,"Slow");  //for spike	
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").APPLY(); 
	rdk::Timer::WAIT(3e-3); 
	rdk::MMXH::PMU("EN_mmxh_pmu").isvm("0.0mA",rdkenum::R3mA,rdkenum::R7V,"7.0V","-7V").APPLY(); //EN Float-2
	rdk::Timer::WAIT(3e-3); 
	rdk::MMXH::PMU("EN_mmxh_pmu").disconnect().power(OFF).APPLY();
	MMXH_PMU_Slewrate("EN_mmxh_pmu"  ,"VeryFast");  //for spike	

	rdk::CW("K16").off().APPLY(); // EN_MMXH
	rdk::Timer::WAIT(3e-3);
	rdk::CW("K5").on().APPLY(); // OP7
	rdk::Timer::WAIT(3e-3); 
	
	rdk::MMXH::PMU("EN_mmxh_pmu").isvm("0.0mA",rdkenum::R3mA,rdkenum::R2V,"2V","-2V").connect().power(ON).APPLY();
	rdk::Timer::WAIT(3e-3); 

	I2C_Write(0x24,0x04); // (DIS_EN=1)
	rdk::Timer::WAIT(1e-3); 
	I2C_Write(0x23,0x08); // (AD_MUXO_EN=1)   
	rdk::Timer::WAIT(3e-3); 

// Post measure
	VBG_post[0] = rdk::MMXH::PMU("EN_mmxh_pmu").MEAS_V(100);

    for(ItrDUTs itrDut(DUT_ACTIVE); !itrDut.isDone(); itrDut++) 
	{
		VBG_post_err[*itrDut] = ((VBG_target - VBG_post[0][*itrDut].getAsDouble() ) / (VBG_post[0][*itrDut].getAsDouble()+1e-9) ); 
    }

	I2C_Write(0x6A,0x00); // exit test mode
	rdk::Timer::WAIT(1e-3); 

// clean up
	MMXH_PMU_Slewrate("VIN_mmxh_pmu" ,"Slow");  //for spike
	MMXH_PMU_Slewrate("VOUT_mmxh_pmu","Slow");  //for spike

	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").APPLY();
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("0.0V",rdkenum::R2V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();
	rdk::Timer::WAIT(3e-3);
	DPIN_Levelset("MODE_mdm",OPEN_,OFF_);
	rdk::MMXH::PMU("VOUT_mmxh_pmu").disconnect().power(OFF).APPLY();	
	rdk::MMXH::PMU("EN_mmxh_pmu").disconnect().power(OFF).APPLY();	
	rdk::MMXH::PMU("VIN_mmxh_pmu").disconnect().power(OFF).APPLY();	
	rdk::CW("K_ALL").off().APPLY(); 
	rdk::Timer::WAIT(3e-3);

	MMXH_PMU_Slewrate("VIN_mmxh_pmu" ,"VeryFast");  //for spike
	MMXH_PMU_Slewrate("VOUT_mmxh_pmu","VeryFast");  //for spike


	result |= Judge(test_id,"VBG_post",     "T_VBG_TRIM_LS.VBG_post",     VBG_post[0],"SoftBins.BIN13"); if(RscDUTs(DUT_ACTIVE).isEmpty())return result; test_id++;
	result |= Judge(test_id,"VBG_post_err", "T_VBG_TRIM_LS.VBG_post_err",VBG_post_err,"SoftBins.BIN13"); if(RscDUTs(DUT_ACTIVE).isEmpty()) return result; test_id++;

	return result;
} // T_VBG_POST



RsltAllDUTCtnr
TPG::T_VREF_EAOUT_TRIM()
{
	//TestConditions.apply();
	RsltAllDUTCtnr result;
	test_id = 400;
	OFCArray<ValDUT> VREF_EAOUT_pre(1,100);
	OFCArray<ValDUT> VREF_EAOUT_sim(1,100);
	ValDUT VREF_EAOUT_pre_err;
	ValDUT VREF_EAOUT_sim_err;

    rdk::CW("K2;K12;K13;K16").on().APPLY(); // MODE_MDM, EN_MMXH, VIN_CAP, VOUT_CAP 
	rdk::Timer::WAIT(3e-3);

	//IC Turn on
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("1.8V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").connect().power(ON).APPLY(); //For spike
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("1.8V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").connect().power(ON).APPLY();	//For spike
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("1.8V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").connect().power(ON).APPLY();			//For spike

	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").APPLY();
	DPIN_Levelset("MODE_mdm","3.6V", "0.0V", "1.8V", "1.8V",CLOSE_,ON_);
	rdk::Timer::WAIT(15e-3); 
	
	I2C_Write(0x6A,0x5A); // enter test mode 
	rdk::Timer::WAIT(1e-3); 
	I2C_Write(0x6A,0xA5); // enter test mode   
	rdk::Timer::WAIT(3e-3); 

	MMXH_PMU_Slewrate("EN_mmxh_pmu"  ,"Slow");  //for spike	
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").APPLY();
	rdk::Timer::WAIT(3e-3);
	rdk::MMXH::PMU("EN_mmxh_pmu").isvm("0.0mA",rdkenum::R3mA,rdkenum::R7V,"7.0V","-7V").APPLY(); //EN Float-2
	rdk::Timer::WAIT(3e-3); 
	rdk::MMXH::PMU("EN_mmxh_pmu").disconnect().power(OFF).APPLY();
	MMXH_PMU_Slewrate("EN_mmxh_pmu"  ,"VeryFast");  //for spike	

	rdk::CW("K16").off().APPLY(); //EN_MMXH
	rdk::Timer::WAIT(1e-3); 
	rdk::CW("K5").on().APPLY(); //OP7
	rdk::Timer::WAIT(3e-3); 

	rdk::MMXH::PMU("EN_mmxh_pmu").isvm("0.0mA",rdkenum::R300uA,rdkenum::R2V,"2.0V","-2V").connect().power(ON).APPLY();	
	rdk::Timer::WAIT(3e-3); 

	I2C_Write(0x25,0x0D); // (T_DIS_LPWR=1, T_EA_OFFS=1, T_DISABLE_DRVR=1) 
	rdk::Timer::WAIT(1e-3); 
	I2C_Write(0x23,0xC9); // (MUXSEL=2'b11,AD_MUXO_EN=1,ENMUX=3'b001)
	rdk::Timer::WAIT(3e-3); 
 
// Pre measure
	VREF_EAOUT_pre[0] = rdk::MMXH::PMU("EN_mmxh_pmu").MEAS_V(100);	

	I2C_Write(0x6A,0x00); // exit test mode
	rdk::Timer::WAIT(1e-3); 

// clean up
	MMXH_PMU_Slewrate("VIN_mmxh_pmu" ,"Slow");   //for spike
	MMXH_PMU_Slewrate("VOUT_mmxh_pmu","Slow");   //for spike

	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();
	rdk::Timer::WAIT(3e-3); 
	//rdk::MMXH::PMU("VOUT_mmxh_pmu").disconnect().power(OFF).APPLY();
	//rdk::MMXH::PMU("VIN_mmxh_pmu").disconnect().power(OFF).APPLY();
	//rdk::MMXH::PMU("EN_mmxh_pmu").disconnect().power(OFF).APPLY();
	DPIN_Levelset("MODE_mdm",OPEN_,OFF_);
	rdk::CW("K_ALL").off().APPLY();
	rdk::Timer::WAIT(3e-3); 

	MMXH_PMU_Slewrate("VIN_mmxh_pmu" ,"VeryFast");   //for spike
	MMXH_PMU_Slewrate("VOUT_mmxh_pmu","VeryFast");   //for spike

    for(ItrDUTs itrDut(DUT_ACTIVE); !itrDut.isDone(); itrDut++) 
	{
    	VREF_EAOUT_pre_err[*itrDut] = (VREF_EAOUT_target - VREF_EAOUT_pre[0][*itrDut].getAsDouble()) / (VREF_EAOUT_pre[0][*itrDut].getAsDouble()+1e-9) ;
    }

	result |= Judge(test_id,"VREF_EAOUT_pre",    "T_VREF_EAOUT_TRIM_LS.VREF_EAOUT_pre",     VREF_EAOUT_pre[0],"SoftBins.BIN14"); if(RscDUTs(DUT_ACTIVE).isEmpty())return result; test_id++;
	result |= Judge(test_id,"VREF_EAOUT_pre_err","T_VREF_EAOUT_TRIM_LS.VREF_EAOUT_pre_err",VREF_EAOUT_pre_err,"SoftBins.BIN14"); if(RscDUTs(DUT_ACTIVE).isEmpty()) return result; test_id++;


// trim table
    for(ItrDUTs itrDut(DUT_ACTIVE); !itrDut.isDone(); itrDut++) 
	{
		double VREF_EAOUT_err = VREF_EAOUT_pre_err[*itrDut].getAsDouble() * 100;

        if(VREF_EAOUT_err>=-50.0 && VREF_EAOUT_err<=50.0) 
		{
			if (VREF_EAOUT_err >= -1.03 && VREF_EAOUT_err < 0.34)		{ vref_eaout_code[*itrDut] = 240; }//
			if (VREF_EAOUT_err >= -1.72 && VREF_EAOUT_err < -1.0)		{ vref_eaout_code[*itrDut] = 224; }//
			if (VREF_EAOUT_err >= -2.40 && VREF_EAOUT_err < -1.72)		{ vref_eaout_code[*itrDut] = 208; }//
			if (VREF_EAOUT_err >= -3.07 && VREF_EAOUT_err < -2.40)		{ vref_eaout_code[*itrDut] = 192; }//
			if (VREF_EAOUT_err >= -3.72 && VREF_EAOUT_err < -3.07)		{ vref_eaout_code[*itrDut] = 176; }//
			if (VREF_EAOUT_err >= -4.36 && VREF_EAOUT_err < -3.72)		{ vref_eaout_code[*itrDut] = 160; }//
			if (VREF_EAOUT_err >= -4.99 && VREF_EAOUT_err < -4.36)		{ vref_eaout_code[*itrDut] = 144; }//
			if (VREF_EAOUT_err >= -50.0 && VREF_EAOUT_err < -4.99)		{ vref_eaout_code[*itrDut] = 128; }//
			if (VREF_EAOUT_err >= 4.74  && VREF_EAOUT_err < 50.0)		{ vref_eaout_code[*itrDut] = 112; }//
			if (VREF_EAOUT_err >= 3.98  && VREF_EAOUT_err < 4.74)		{ vref_eaout_code[*itrDut] = 96; }//
			if (VREF_EAOUT_err >= 3.23  && VREF_EAOUT_err < 3.98)		{ vref_eaout_code[*itrDut] = 80; }//
			if (VREF_EAOUT_err >= 2.49  && VREF_EAOUT_err < 3.23)		{ vref_eaout_code[*itrDut] = 64; }//
			if (VREF_EAOUT_err >= 1.77  && VREF_EAOUT_err < 2.49)		{ vref_eaout_code[*itrDut] = 48; }//
			if (VREF_EAOUT_err >= 1.06  && VREF_EAOUT_err < 1.77)		{ vref_eaout_code[*itrDut] = 32; }//
			if (VREF_EAOUT_err >= 0.35  && VREF_EAOUT_err < 1.06)		{ vref_eaout_code[*itrDut] = 16; }//
			if (VREF_EAOUT_err >= 0.34  && VREF_EAOUT_err < 0.35)		{ vref_eaout_code[*itrDut] = 0; }//
		}
         else 
			vref_eaout_code[*itrDut] = 0;

       if (EN_OTP40_47[*itrDut]==0) { vref_eaout_code[*itrDut] = RD_OTP40_47[*itrDut].getAsInt(); } 

	} // for ItrDUTs

	result |= Judge(test_id,"VREF_EAOUT_code",	vref_eaout_code,   -0.5, 255.5,"SoftBins.BIN14","SoftBins.BIN14","Dec"); if(RscDUTs(DUT_ACTIVE).isEmpty())return result; test_id++;


//----------------------------------------------------------------------------------------------------------------
    rdk::CW("K2;K12;K13;K16").on().APPLY(); // MODE_MDM, EN_MMXH, VIN_CAP, VOUT_CAP 
	rdk::Timer::WAIT(3e-3);

	//IC Turn on
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("1.8V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").connect().power(ON).APPLY(); //For spike
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("1.8V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").connect().power(ON).APPLY();	//For spike
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("1.8V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").connect().power(ON).APPLY();			//For spike

	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").APPLY();
	DPIN_Levelset("MODE_mdm","3.6V", "0.0V", "1.8V", "1.8V",CLOSE_,ON_);
	rdk::Timer::WAIT(15e-3); 
	
	I2C_Write(0x6A,0x5A); // enter test mode 
	rdk::Timer::WAIT(1e-3); 
	I2C_Write(0x6A,0xA5); // enter test mode   
	rdk::Timer::WAIT(3e-3);

	MMXH_PMU_Slewrate("EN_mmxh_pmu"  ,"Slow");  //for spike	
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").APPLY();
	rdk::Timer::WAIT(3e-3);
	rdk::MMXH::PMU("EN_mmxh_pmu").isvm("0.0mA",rdkenum::R3mA,rdkenum::R7V,"7.0V","-7V").APPLY(); //EN Float-2
	rdk::Timer::WAIT(3e-3); 
	rdk::MMXH::PMU("EN_mmxh_pmu").disconnect().power(OFF).APPLY();
	MMXH_PMU_Slewrate("EN_mmxh_pmu"  ,"VeryFast");  //for spike	

	rdk::CW("K16").off().APPLY(); // EN_MMXH
	rdk::Timer::WAIT(3e-3);
	rdk::CW("K5").on().APPLY(); // OP7
	rdk::Timer::WAIT(3e-3);
	
	rdk::MMXH::PMU("EN_mmxh_pmu").isvm("0.0mA",rdkenum::R300uA,rdkenum::R2V,"2.0V","-2V").connect().power(ON).APPLY();	

	I2C_Write(0x25,0x0D); // (T_DIS_LPWR=1, T_EA_OFFS=1, T_DISABLE_DRVR=1)
	rdk::Timer::WAIT(1e-3); 
	I2C_Write(0x23,0xC9); // (MUXSEL=2'b11,AD_MUXO_EN=1,ENMUX=3'b001)
	rdk::Timer::WAIT(1e-3); 
	
	I2C_Write(0x40,vref_eaout_code); // OTP data write reg.
	rdk::Timer::WAIT(1e-3); 

// Sim Measure
	VREF_EAOUT_sim[0] = rdk::MMXH::PMU("EN_mmxh_pmu").MEAS_V(100);	

    for(ItrDUTs itrDut(DUT_ACTIVE); !itrDut.isDone(); itrDut++) 
	{
		VREF_EAOUT_sim_err[*itrDut] = ((VREF_EAOUT_target - VREF_EAOUT_sim[0][*itrDut].getAsDouble() ) / (VREF_EAOUT_sim[0][*itrDut].getAsDouble()+1e-9) ); 	
    }

	I2C_Write(0x6A,0x00); // EXIT test mode
	rdk::Timer::WAIT(1e-3); 

// clean up
	MMXH_PMU_Slewrate("VIN_mmxh_pmu" ,"Slow");   //for spike
	MMXH_PMU_Slewrate("VOUT_mmxh_pmu","Slow");   //for spike

	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").APPLY();
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").APPLY();
	rdk::Timer::WAIT(3e-3);
	DPIN_Levelset("MODE_mdm",OPEN_,OFF_);
	rdk::MMXH::PMU("VOUT_mmxh_pmu").disconnect().power(OFF).APPLY();	
	rdk::MMXH::PMU("EN_mmxh_pmu").disconnect().power(OFF).APPLY();
	rdk::MMXH::PMU("VIN_mmxh_pmu").disconnect().power(OFF).APPLY();
	rdk::CW("K_ALL").off().APPLY();
	rdk::Timer::WAIT(3e-3);

	MMXH_PMU_Slewrate("VIN_mmxh_pmu" ,"VeryFast");   //for spike
	MMXH_PMU_Slewrate("VOUT_mmxh_pmu","VeryFast");   //for spike

	result |= Judge(test_id,"VREF_EAOUT_sim",    "T_VREF_EAOUT_TRIM_LS.VREF_EAOUT_sim",     VREF_EAOUT_sim[0],"SoftBins.BIN14"); if(RscDUTs(DUT_ACTIVE).isEmpty())return result; test_id++;
	result |= Judge(test_id,"VREF_EAOUT_sim_err","T_VREF_EAOUT_TRIM_LS.VREF_EAOUT_sim_err",VREF_EAOUT_sim_err,"SoftBins.BIN14"); if(RscDUTs(DUT_ACTIVE).isEmpty()) return result; test_id++;

	return result;
} // T_VREF_EAOUT_Trim


RsltAllDUTCtnr
TPG::T_VREF_EAOUT_BURN()
{
	RsltAllDUTCtnr result;

	RscTestCondition MODE_Timing("(Timing_MODE)");
	timing_set(Timming_Speed,MODE_Timing);

if (en_trim == 1)
{
	rdk::CW("K2;K12;K13;K16").on().APPLY(); // MODE_MDM, EN_MMXH, VIN_CAP, VOUT_CAP 
	rdk::Timer::WAIT(3e-3); 

	//IC Turn on
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("1.8V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").connect().power(ON).APPLY(); //For spike
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("1.8V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").connect().power(ON).APPLY();	//For spike
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("1.8V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").connect().power(ON).APPLY();			//For spike

	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").APPLY();
	DPIN_Levelset("MODE_mdm","3.6V", "0.0V", "1.8V", "1.8V",CLOSE_,ON_);
	rdk::Timer::WAIT(15e-3); 


	I2C_Write(0x6A,0x5A);			  rdk::Timer::WAIT(1e-3); // enter test mode 
	I2C_Write(0x6A,0xA5);			  rdk::Timer::WAIT(1e-3); // enter test mode  2. Enter Test Mode.
	I2C_Write(0x40,vref_eaout_code);  rdk::Timer::WAIT(1e-3); //3. Write target OTP values into REG 0x40 to 0x48.
	I2C_Write(0x20,0x00);		  	  rdk::Timer::WAIT(1e-3); // 4. Write REG 0x20 = 0x00 to select data in REG 0x40 to be burned.
	I2C_Write(0x21,0x09);		      rdk::Timer::WAIT(1e-3); // 5. Write REG 0x21=0x09 (OTP_CLK_REQ=1, EXVPP_EN=1).

	for(ItrDUTs itrDut(DUT_ACTIVE); !itrDut.isDone(); itrDut++) 
	{
		VHEN1[*itrDut] = EN_OTP40_47[*itrDut] * 1.0 * 5;
		VHEN2[*itrDut] = EN_OTP40_47[*itrDut] * 1.1 * 5;
		VHEN3[*itrDut] = EN_OTP40_47[*itrDut] * 1.2 * 5;
		VHEN4[*itrDut] = EN_OTP40_47[*itrDut] * 1.3 * 5;
		VHEN5[*itrDut] = EN_OTP40_47[*itrDut] * 1.4 * 5;

		//For VIN : If burend chip, VIN off, VOUT off
		VIEN[*itrDut] = EN_OTP40_47[*itrDut] * 5.5; //5.5V
		VOEN[*itrDut] = EN_OTP40_47[*itrDut] * 3.6; //3.6V
	}										  
		
	//If burend chip, VIN & VOUT off slowly
	MMXH_PMU_Slewrate("VIN_mmxh_pmu","Slow");   //for spike
	MMXH_PMU_Slewrate("VOUT_mmxh_pmu","Slow");   //for spike
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim(VIEN,rdkenum::R7V,rdkenum::R240mA,"200.0mA","-200.0mA").APPLY(); // VIN 5.5 V is needed for Burn //Check 0V and 5.5V both with DGT
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim(VOEN,rdkenum::R7V,rdkenum::R240mA,"200.0mA","-200.0mA").APPLY();
	rdk::Timer::WAIT(3e-3);	
	MMXH_PMU_Slewrate("VOUT_mmxh_pmu","VeryFast");   //for spike
	MMXH_PMU_Slewrate("VIN_mmxh_pmu","VeryFast");   //for spike

	//Burn
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim(VHEN1,rdkenum::R7V,rdkenum::R240mA,"200.0mA","-200.0mA").APPLY();
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim(VHEN2,rdkenum::R7V,rdkenum::R240mA,"200.0mA","-200.0mA").APPLY();
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim(VHEN3,rdkenum::R7V,rdkenum::R240mA,"200.0mA","-200.0mA").APPLY();
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim(VHEN4,rdkenum::R7V,rdkenum::R240mA,"200.0mA","-200.0mA").APPLY();
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim(VHEN5,rdkenum::R7V,rdkenum::R240mA,"200.0mA","-200.0mA").APPLY();
	rdk::Timer::WAIT(1e-3); 

	I2C_Write(0x21,0x0B); //7. Write 0x21 = 0x0B to program the OTP(BURN_EN=1). 8. Wait 1ms.
	rdk::Timer::WAIT(1e-3); 
	I2C_Write(0x21,0x09); //9. Write 0x21 = 0x09 to stop OTP programming.
	rdk::Timer::WAIT(1e-3); 

	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim(VHEN5,rdkenum::R7V,rdkenum::R240mA,"200.0mA","-200.0mA").APPLY();
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim(VHEN4,rdkenum::R7V,rdkenum::R240mA,"200.0mA","-200.0mA").APPLY();
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim(VHEN3,rdkenum::R7V,rdkenum::R240mA,"200.0mA","-200.0mA").APPLY();
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim(VHEN2,rdkenum::R7V,rdkenum::R240mA,"200.0mA","-200.0mA").APPLY();
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim(VHEN1,rdkenum::R7V,rdkenum::R240mA,"200.0mA","-200.0mA").APPLY();
	rdk::Timer::WAIT(1e-3); 

	I2C_Write(0x6A,0x00); // exit test mode
	rdk::Timer::WAIT(1e-3); 


	// clean up
	MMXH_PMU_Slewrate("VIN_mmxh_pmu" ,"Slow");   //for spike
	MMXH_PMU_Slewrate("VOUT_mmxh_pmu","Slow");   //for spike
	MMXH_PMU_Slewrate("EN_mmxh_pmu"  ,"Slow");   //for spike	

	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R240mA,"200.0mA","-200.0mA").APPLY();
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();
	rdk::Timer::WAIT(3e-3);
	DPIN_Levelset("MODE_mdm",OPEN_,OFF_);
	rdk::MMXH::PMU("VOUT_mmxh_pmu").disconnect().power(OFF).APPLY();
	rdk::MMXH::PMU("VIN_mmxh_pmu").disconnect().power(OFF).APPLY();
	rdk::MMXH::PMU("EN_mmxh_pmu").disconnect().power(OFF).APPLY();
	rdk::CW("K_ALL").off().APPLY();
	rdk::Timer::WAIT(3e-3);	

	MMXH_PMU_Slewrate("VIN_mmxh_pmu" ,"VeryFast");   //for spike
	MMXH_PMU_Slewrate("VOUT_mmxh_pmu","VeryFast");   //for spike
	MMXH_PMU_Slewrate("EN_mmxh_pmu"  ,"VeryFast");   //for spike	

}
	result |= Judge(test_id,"VREF_EAOUT_burn", "T_BURN.BURN", EN_OTP40_47,"SoftBins.BIN14"); if(RscDUTs(DUT_ACTIVE).isEmpty())return result; test_id++;

	return result;
} // T_VREF_EAOUT_BURN


RsltAllDUTCtnr
TPG::T_VREF_EAOUT_POST()
{
	RsltAllDUTCtnr result;

	OFCArray<ValDUT> VREF_EAOUT_post(1,100);
	ValDUT VREF_EAOUT_post_err;

// Setup
    rdk::CW("K2;K12;K13;K16").on().APPLY(); // MODE_MDM, EN_MMXH, VIN_CAP, VOUT_CAP 
	rdk::Timer::WAIT(3e-3);

	//IC Turn on
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("1.8V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").connect().power(ON).APPLY(); //For spike
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("1.8V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").connect().power(ON).APPLY();	//For spike
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("1.8V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").connect().power(ON).APPLY();			//For spike

	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").APPLY();
	DPIN_Levelset("MODE_mdm","3.6V", "0.0V", "1.8V", "1.8V",CLOSE_,ON_);
	rdk::Timer::WAIT(15e-3); 
	
	I2C_Write(0x6A,0x5A); // enter test mode 
	rdk::Timer::WAIT(1e-3); 
	I2C_Write(0x6A,0xA5); // enter test mode   
	rdk::Timer::WAIT(3e-3); 

	MMXH_PMU_Slewrate("EN_mmxh_pmu"  ,"Slow");  //for spike	
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").APPLY();
	rdk::Timer::WAIT(3e-3);
	rdk::MMXH::PMU("EN_mmxh_pmu").isvm("0.0mA",rdkenum::R3mA,rdkenum::R7V,"7.0V","-7V").APPLY(); //EN Float-2
	rdk::Timer::WAIT(3e-3); 
	rdk::MMXH::PMU("EN_mmxh_pmu").disconnect().power(OFF).APPLY();
	MMXH_PMU_Slewrate("EN_mmxh_pmu"  ,"VeryFast");  //for spike	

	rdk::CW("K16").off().APPLY(); // EN_MMXH
	rdk::Timer::WAIT(3e-3);
	rdk::CW("K5").on().APPLY(); // OP7
	rdk::Timer::WAIT(3e-3);

	rdk::MMXH::PMU("EN_mmxh_pmu").isvm("0.0mA",rdkenum::R300uA,rdkenum::R2V,"2.0V","-2V").connect().power(ON).APPLY();	

	I2C_Write(0x25,0x0D); // (T_DIS_LPWR=1, T_EA_OFFS=1, T_DISABLE_DRVR=1)
	rdk::Timer::WAIT(1e-3);
	I2C_Write(0x23,0xC9); // (MUXSEL=2'b11,AD_MUXO_EN=1,ENMUX=3'b001)
	rdk::Timer::WAIT(1e-3); 

// Post measure
	VREF_EAOUT_post[0] = rdk::MMXH::PMU("EN_mmxh_pmu").MEAS_V(100);	

	I2C_Write(0x6A,0x00); // EXIT test mode
	rdk::Timer::WAIT(1e-3); 

    for(ItrDUTs itrDut(DUT_ACTIVE); !itrDut.isDone(); itrDut++) 
	{
		VREF_EAOUT_post_err[*itrDut] = ((VREF_EAOUT_target - VREF_EAOUT_post[0][*itrDut].getAsDouble() ) / (VREF_EAOUT_post[0][*itrDut].getAsDouble()+1e-9) ); 
    }

// clean up
	MMXH_PMU_Slewrate("VIN_mmxh_pmu" ,"Slow");   //for spike
	MMXH_PMU_Slewrate("VOUT_mmxh_pmu","Slow");   //for spike

	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").APPLY();
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").APPLY();
	rdk::Timer::WAIT(3e-3);
	DPIN_Levelset("MODE_mdm",OPEN_,OFF_);
	rdk::MMXH::PMU("EN_mmxh_pmu").disconnect().power(OFF).APPLY();
	rdk::MMXH::PMU("VIN_mmxh_pmu").disconnect().power(OFF).APPLY();
	rdk::MMXH::PMU("VOUT_mmxh_pmu").disconnect().power(OFF).APPLY();	
	rdk::CW("K_ALL").off().APPLY();
	rdk::Timer::WAIT(3e-3);

	MMXH_PMU_Slewrate("VIN_mmxh_pmu" ,"VeryFast");   //for spike
	MMXH_PMU_Slewrate("VOUT_mmxh_pmu","VeryFast");   //for spike

	result |= Judge(test_id,"VREF_EAOUT_post",    "T_VREF_EAOUT_TRIM_LS.VREF_EAOUT_post",     VREF_EAOUT_post[0],"SoftBins.BIN14"); if(RscDUTs(DUT_ACTIVE).isEmpty())return result; test_id++;
	result |= Judge(test_id,"VREF_EAOUT_post_err","T_VREF_EAOUT_TRIM_LS.VREF_EAOUT_post_err",VREF_EAOUT_post_err,"SoftBins.BIN14"); if(RscDUTs(DUT_ACTIVE).isEmpty()) return result; test_id++;

	return result;
} // T_VREF_EAOUT_POST


//IBIAS_Trim
RsltAllDUTCtnr
TPG::T_IBIAS_TRIM()
{
	RsltAllDUTCtnr result;
	test_id = 500;	

	OFCArray<ValDUT> IBIAS_pre(1,100);
	OFCArray<ValDUT> IBIAS_sim(1,100);
	ValDUT IBIAS_pre_err;
	ValDUT IBIAS_sim_err;
	//ValDUT IBIAS_code;

	//ktb8316_discharge(); // Discharge For preventing from affection of previous item

// Setup
    rdk::CW("K2;K13;K16").on().APPLY(); // MODE_MDM, EN_MMXH, VIN_CAP  
	rdk::Timer::WAIT(3e-3);

	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").connect().power(ON).APPLY(); 
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").connect().power(ON).APPLY();	
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").connect().power(ON).APPLY();		
	rdk::Timer::WAIT(3e-3);

	//IC Turn on
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("1.8V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY(); //For spike
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("1.8V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();	//For spike
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("1.8V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").APPLY();			//For spike

	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();
	rdk::Timer::WAIT(5e-3);

	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R30mA,"30.0mA","-30.0mA").APPLY();
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R30mA,"30.0mA","-30.0mA").APPLY();
	rdk::Timer::WAIT(5e-3); 
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").APPLY();
	DPIN_Levelset("MODE_mdm","3.6V", "0.0V", "1.8V", "1.8V",CLOSE_,ON_);
	rdk::Timer::WAIT(15e-3); 

	I2C_Write(0x6A,0x5A); 
	rdk::Timer::WAIT(1e-3); // enter test mode 
	I2C_Write(0x6A,0xA5); 
	rdk::Timer::WAIT(3e-3); // enter test mode   

	MMXH_PMU_Slewrate("EN_mmxh_pmu"  ,"Slow");  //for spike	
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").APPLY();
	rdk::Timer::WAIT(5e-3);
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R3uA,"3.0uA","-3.0uA").APPLY(); //EN Float-1
	rdk::Timer::WAIT(5e-3);
	MMXH_PMU_Slewrate("EN_mmxh_pmu"  ,"VeryFast");  //for spike	

	I2C_Write(0x24,0x04); // disable BUCK block(DIS_EN=1)
	rdk::Timer::WAIT(1e-3); 
	I2C_Write(0x23,0x88); // mux out IBIAS_0.5uA(MUXSEL=2'b10,AD_MUXO_EN=1)
	rdk::Timer::WAIT(3e-3); 

// Pre measure	
	IBIAS_pre[0] = rdk::MMXH::PMU("EN_mmxh_pmu").MEAS_I(100);	//Expected IBIAS_0.5uA

// Test Mode Out	
	I2C_Write(0x6A,0x00); // EXIT test mode
	rdk::Timer::WAIT(1e-3); 

// clean up
	MMXH_PMU_Slewrate("VIN_mmxh_pmu" ,"Slow");   //for spike
	MMXH_PMU_Slewrate("VOUT_mmxh_pmu","Slow");   //for spike

	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R30mA,"30.0mA","-30.0mA").APPLY();
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R30mA,"30.0mA","-30.0mA").APPLY();
	rdk::Timer::WAIT(3e-3);
	DPIN_Levelset("MODE_mdm",OPEN_,OFF_);
	rdk::MMXH::PMU("VOUT_mmxh_pmu").disconnect().power(OFF).APPLY();
	rdk::MMXH::PMU("VIN_mmxh_pmu").disconnect().power(ON).APPLY();
	rdk::CW("K_ALL").off().APPLY();
	rdk::Timer::WAIT(3e-3);	

	MMXH_PMU_Slewrate("VIN_mmxh_pmu" ,"VeryFast");   //for spike
	MMXH_PMU_Slewrate("VOUT_mmxh_pmu","VeryFast");   //for spike
//-------------------------

    for(ItrDUTs itrDut(DUT_ACTIVE); !itrDut.isDone(); itrDut++) 
	{
		IBIAS_pre[0][*itrDut] = IBIAS_pre[0][*itrDut].getAsDouble() * -1;
		IBIAS_pre_err[*itrDut] = ((IBIAS_target - IBIAS_pre[0][*itrDut].getAsDouble()) / (IBIAS_pre[0][*itrDut].getAsDouble()+1e-9) );
    }

	result |= Judge(test_id,"IBIAS_pre",    "T_IBIAS_TRIM_LS.IBIAS_pre",     IBIAS_pre[0],"SoftBins.BIN15"); if(RscDUTs(DUT_ACTIVE).isEmpty())return result; test_id++;
	result |= Judge(test_id,"IBIAS_pre_err","T_IBIAS_TRIM_LS.IBIAS_pre_err",IBIAS_pre_err,"SoftBins.BIN15"); if(RscDUTs(DUT_ACTIVE).isEmpty()) return result; test_id++;



// trim table  -------------------------------------------------------------------------------------------------
    for(ItrDUTs itrDut(DUT_ACTIVE); !itrDut.isDone(); itrDut++) 
	{
		double IBIAS_data_err = IBIAS_pre_err[*itrDut].getAsDouble() * 100;

		if (IBIAS_data_err >= -50 && IBIAS_data_err<50)
		{
			if (IBIAS_data_err >=  -3.56 && IBIAS_data_err <  -0.92)	{ ibias_code[*itrDut] = 15; }//
			if (IBIAS_data_err >=  -6.64 && IBIAS_data_err <  -3.56)	{ ibias_code[*itrDut] = 14; }//
			if (IBIAS_data_err >=  -9.15 && IBIAS_data_err <  -6.64)	{ ibias_code[*itrDut] = 13; }//
			if (IBIAS_data_err >= -10.99 && IBIAS_data_err <  -9.15)	{ ibias_code[*itrDut] = 12; }//
			if (IBIAS_data_err >= -12.68 && IBIAS_data_err < -10.99)	{ ibias_code[*itrDut] = 11; }//
			if (IBIAS_data_err >= -14.72 && IBIAS_data_err < -12.68)	{ ibias_code[*itrDut] = 10; }//
			if (IBIAS_data_err >= -17.18 && IBIAS_data_err < -14.72)	{ ibias_code[*itrDut] = 9; }//
			if (IBIAS_data_err >= -50.0  && IBIAS_data_err < -17.18)	{ ibias_code[*itrDut] = 8; }//

			if (IBIAS_data_err >= 23.27 && IBIAS_data_err < 50.0)		{ ibias_code[*itrDut] = 7; }//
			if (IBIAS_data_err >= 19.45 && IBIAS_data_err < 23.27)		{ ibias_code[*itrDut] = 6; }//
			if (IBIAS_data_err >= 16.07 && IBIAS_data_err < 19.45)		{ ibias_code[*itrDut] = 5; }//
			if (IBIAS_data_err >= 12.52 && IBIAS_data_err < 16.07)		{ ibias_code[*itrDut] = 4; }//
			if (IBIAS_data_err >=  8.67 && IBIAS_data_err < 12.52)		{ ibias_code[*itrDut] = 3; }//
			if (IBIAS_data_err >=  4.84 && IBIAS_data_err <  8.67)		{ ibias_code[*itrDut] = 2; }//
			if (IBIAS_data_err >=  1.54 && IBIAS_data_err <  4.84)		{ ibias_code[*itrDut] = 1; }//
			if (IBIAS_data_err >= -0.92 && IBIAS_data_err <  1.54)		{ ibias_code[*itrDut] = 0; }//
		}
		else
			ibias_code[*itrDut] = 0; //

       if (EN_OTP41_03[*itrDut] == 0) { ibias_code[*itrDut] = RD_OTP41_03[*itrDut].getAsInt(); } 

	} // for ItrDUTs

	result |= Judge(test_id,"IBIAS_code",	ibias_code,   -0.5, 255.5,"SoftBins.BIN15","SoftBins.BIN15","Dec"); if(RscDUTs(DUT_ACTIVE).isEmpty())return result; test_id++;

	//ktb8316_discharge(); // Discharge For preventing from affection of previous item

// Sim Setup
    rdk::CW("K2;K13;K16").on().APPLY(); // MODE_MDM, EN_MMXH, VIN_CAP  
	rdk::Timer::WAIT(3e-3);

	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").connect().power(ON).APPLY(); 
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").connect().power(ON).APPLY();	
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").connect().power(ON).APPLY();	
	rdk::Timer::WAIT(3e-3);

	//IC Turn on
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("1.8V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY(); //For spike
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("1.8V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();	//For spike
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("1.8V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").APPLY();			//For spike

	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();
	rdk::Timer::WAIT(5e-3);

	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R30mA,"30.0mA","-30.0mA").APPLY();
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R30mA,"30.0mA","-30.0mA").APPLY();
	rdk::Timer::WAIT(5e-3); 
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").APPLY();
	DPIN_Levelset("MODE_mdm","3.6V", "0.0V", "1.8V", "1.8V",CLOSE_,ON_);
	rdk::Timer::WAIT(15e-3); 
	
	I2C_Write(0x6A,0x5A); 
	rdk::Timer::WAIT(1e-3); // enter test mode 
	I2C_Write(0x6A,0xA5); 
	rdk::Timer::WAIT(3e-3); // enter test mode   

	MMXH_PMU_Slewrate("EN_mmxh_pmu"  ,"Slow");  //for spike	
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").APPLY();
	rdk::Timer::WAIT(5e-3);
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R3uA,"3.0uA","-3.0uA").APPLY();
	rdk::Timer::WAIT(5e-3);
	MMXH_PMU_Slewrate("EN_mmxh_pmu"  ,"VeryFast");  //for spike	

	I2C_Write(0x24,0x04); // disable BUCK block(DIS_EN=1)
	rdk::Timer::WAIT(1e-3); 
	I2C_Write(0x23,0x88); // mux out IBIAS_0.5uA(MUXSEL=2'b10,AD_MUXO_EN=1)
	rdk::Timer::WAIT(3e-3); 

	I2C_Write(0x41,ibias_code);	
	rdk::Timer::WAIT(3e-3);  // OTP data write reg.	

// Sim measure
	IBIAS_sim[0] = rdk::MMXH::PMU("EN_mmxh_pmu").MEAS_I(100);	

	I2C_Write(0x6A,0x00); 
	rdk::Timer::WAIT(1.0e-3); // EXIT test mode

// clean up
	MMXH_PMU_Slewrate("VIN_mmxh_pmu" ,"Slow");   //for spike
	MMXH_PMU_Slewrate("VOUT_mmxh_pmu","Slow");   //for spike

	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R30mA,"30.0mA","-30.0mA").APPLY();
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R30mA,"30.0mA","-30.0mA").APPLY();
	rdk::Timer::WAIT(3e-3);
	DPIN_Levelset("MODE_mdm",OPEN_,OFF_);
	rdk::MMXH::PMU("GND_mmxh_pmu").disconnect().power(OFF).APPLY();
	rdk::MMXH::PMU("VOUT_mmxh_pmu").disconnect().power(OFF).APPLY();
	rdk::MMXH::PMU("EN_mmxh_pmu").disconnect().power(OFF).APPLY();	
	rdk::MMXH::PMU("VIN_mmxh_pmu").disconnect().power(OFF).APPLY();	
    rdk::CW("K_ALL").off().APPLY();
	rdk::Timer::WAIT(3e-3);

	MMXH_PMU_Slewrate("VIN_mmxh_pmu" ,"VeryFast");   //for spike
	MMXH_PMU_Slewrate("VOUT_mmxh_pmu","VeryFast");   //for spike

    for(ItrDUTs itrDut(DUT_ACTIVE); !itrDut.isDone(); itrDut++) 
	{
		IBIAS_sim[0][*itrDut] = IBIAS_sim[0][*itrDut].getAsDouble() * -1;
		IBIAS_sim_err[*itrDut] = ((IBIAS_target - IBIAS_sim[0][*itrDut].getAsDouble() ) / (IBIAS_sim[0][*itrDut].getAsDouble()+1e-9) ); 
    }

	result |= Judge(test_id,"IBIAS_sim",    "T_IBIAS_TRIM_LS.IBIAS_sim",     IBIAS_sim[0],"SoftBins.BIN15"); if(RscDUTs(DUT_ACTIVE).isEmpty())return result; test_id++;
	result |= Judge(test_id,"IBIAS_sim_err","T_IBIAS_TRIM_LS.IBIAS_sim_err",IBIAS_sim_err,"SoftBins.BIN15"); if(RscDUTs(DUT_ACTIVE).isEmpty()) return result; test_id++;

	return result;
} // T_IBIAS_Trim


RsltAllDUTCtnr
TPG::T_IBIAS_BURN()
{
	RsltAllDUTCtnr result;
if (en_trim == 1)
	{
		rdk::CW("K2;K12;K13;K16").on().APPLY(); // MODE MDM, EN MMXH, VIN_CAP, VOUT_CAP 
		rdk::Timer::WAIT(3e-3); 

		//IC Turn on
		rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("1.8V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").connect().power(ON).APPLY(); //For spike
		rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("1.8V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").connect().power(ON).APPLY();	//For spike
		rdk::MMXH::PMU("EN_mmxh_pmu").vsim("1.8V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").connect().power(ON).APPLY();			//For spike

		rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();
		rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();
		rdk::MMXH::PMU("EN_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").APPLY();
		DPIN_Levelset("MODE_mdm","3.6V", "0.0V", "1.8V", "1.8V",CLOSE_,ON_);
		rdk::Timer::WAIT(15e-3); 

		I2C_Write(0x6A,0x5A);			rdk::Timer::WAIT(1e-3); // enter test mode 
		I2C_Write(0x6A,0xA5);			rdk::Timer::WAIT(1e-3); // enter test mode  2. Enter Test Mode.
		I2C_Write(0x41,ibias_code);		rdk::Timer::WAIT(1e-3); //3. Write target OTP values into REG 0x40 to 0x48.
		I2C_Write(0x20,0x01);			rdk::Timer::WAIT(1e-3); // 4. Write REG 0x20 = 0x00 to select data in REG 0x40 to be burned.
		I2C_Write(0x21,0x09);			rdk::Timer::WAIT(1e-3); // 5. Write REG 0x21=0x09 (OTP_CLK_REQ=1, EXVPP_EN=1).
	
		for(ItrDUTs itrDut(DUT_ACTIVE); !itrDut.isDone(); itrDut++) 
		{
			VHEN1[*itrDut] = EN_OTP41_03[*itrDut] * 1.0 * 5;
			VHEN2[*itrDut] = EN_OTP41_03[*itrDut] * 1.1 * 5;
			VHEN3[*itrDut] = EN_OTP41_03[*itrDut] * 1.2 * 5;
			VHEN4[*itrDut] = EN_OTP41_03[*itrDut] * 1.3 * 5;
			VHEN5[*itrDut] = EN_OTP41_03[*itrDut] * 1.4 * 5;

			//For VIN : If burend chip, VIN off, VOUT off
			VIEN[*itrDut] = EN_OTP41_03[*itrDut] * 5.5; //5.5V
			VOEN[*itrDut] = EN_OTP41_03[*itrDut] * 3.6; //3.6V
		}										  
		
		//If burend chip, VIN & VOUT off slowly
		MMXH_PMU_Slewrate("VIN_mmxh_pmu","Slow");   //for spike
		MMXH_PMU_Slewrate("VOUT_mmxh_pmu","Slow");   //for spike
		rdk::MMXH::PMU("VIN_mmxh_pmu").vsim(VIEN,rdkenum::R7V,rdkenum::R240mA,"200.0mA","-200.0mA").APPLY(); // VIN 5.5 V is needed for Burn //Check 0V and 5.5V both with DGT
		rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim(VOEN,rdkenum::R7V,rdkenum::R240mA,"200.0mA","-200.0mA").APPLY();
		rdk::Timer::WAIT(3e-3);	
		MMXH_PMU_Slewrate("VOUT_mmxh_pmu","VeryFast");   //for spike
		MMXH_PMU_Slewrate("VIN_mmxh_pmu","VeryFast");   //for spike

		//Burn
		rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim(VHEN1,rdkenum::R7V,rdkenum::R240mA,"200.0mA","-200.0mA").APPLY();
		rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim(VHEN2,rdkenum::R7V,rdkenum::R240mA,"200.0mA","-200.0mA").APPLY();
		rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim(VHEN3,rdkenum::R7V,rdkenum::R240mA,"200.0mA","-200.0mA").APPLY();
		rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim(VHEN4,rdkenum::R7V,rdkenum::R240mA,"200.0mA","-200.0mA").APPLY();
		rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim(VHEN5,rdkenum::R7V,rdkenum::R240mA,"200.0mA","-200.0mA").APPLY();
		rdk::Timer::WAIT(1e-3); 

		I2C_Write(0x21,0x0B); //7. Write 0x21 = 0x0B to program the OTP(BURN_EN=1). 8. Wait 1ms.
		rdk::Timer::WAIT(1e-3); 
		I2C_Write(0x21,0x09); //9. Write 0x21 = 0x09 to stop OTP programming.
		rdk::Timer::WAIT(1e-3); 

		rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim(VHEN5,rdkenum::R7V,rdkenum::R240mA,"200.0mA","-200.0mA").APPLY();
		rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim(VHEN4,rdkenum::R7V,rdkenum::R240mA,"200.0mA","-200.0mA").APPLY();
		rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim(VHEN3,rdkenum::R7V,rdkenum::R240mA,"200.0mA","-200.0mA").APPLY();
		rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim(VHEN2,rdkenum::R7V,rdkenum::R240mA,"200.0mA","-200.0mA").APPLY();
		rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim(VHEN1,rdkenum::R7V,rdkenum::R240mA,"200.0mA","-200.0mA").APPLY();
		rdk::Timer::WAIT(1e-3); 

		I2C_Write(0x6A,0x00); // exit test mode
		rdk::Timer::WAIT(1e-3); 


		// clean up
		MMXH_PMU_Slewrate("VIN_mmxh_pmu" ,"Slow");   //for spike
		MMXH_PMU_Slewrate("VOUT_mmxh_pmu","Slow");   //for spike
		MMXH_PMU_Slewrate("EN_mmxh_pmu"  ,"Slow");   //for spike	

		rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R240mA,"200.0mA","-200.0mA").APPLY();
		rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();
		rdk::MMXH::PMU("EN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();
		rdk::Timer::WAIT(3e-3);
		DPIN_Levelset("MODE_mdm",OPEN_,OFF_);
		rdk::MMXH::PMU("VOUT_mmxh_pmu").disconnect().power(OFF).APPLY();
		rdk::MMXH::PMU("VIN_mmxh_pmu").disconnect().power(OFF).APPLY();
		rdk::MMXH::PMU("EN_mmxh_pmu").disconnect().power(OFF).APPLY();
		rdk::CW("K_ALL").off().APPLY();
		rdk::Timer::WAIT(3e-3);	

		MMXH_PMU_Slewrate("VIN_mmxh_pmu" ,"VeryFast");   //for spike
		MMXH_PMU_Slewrate("VOUT_mmxh_pmu","VeryFast");   //for spike
		MMXH_PMU_Slewrate("EN_mmxh_pmu"  ,"VeryFast");   //for spike	
	}
	result |= Judge(test_id,"IBIAS_burn", "T_BURN.BURN", EN_OTP41_03,"SoftBins.BIN15"); if(RscDUTs(DUT_ACTIVE).isEmpty())return result; test_id++;

	return result;
} // T_IBIAS_Burn


RsltAllDUTCtnr
TPG::T_IBIAS_POST()
{
	RsltAllDUTCtnr result;

    ValDUT read_IBIAS_VD;
	OFCArray<ValDUT> IBIAS_post(1,100);
	ValDUT IBIAS_post_err;

	//ktb8316_discharge(); // Discharge For preventing from affection of previous item

// Setup
    rdk::CW("K2;K13;K16").on().APPLY(); // MODE_MDM, EN_MMXH, VIN_CAP  
	rdk::Timer::WAIT(3e-3);

	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").connect().power(ON).APPLY(); 
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").connect().power(ON).APPLY();	
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").connect().power(ON).APPLY();	
	rdk::Timer::WAIT(3e-3);

	//IC Turn on
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("1.8V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY(); //For spike
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("1.8V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();	//For spike
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("1.8V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").APPLY();			//For spike

	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();
	rdk::Timer::WAIT(5e-3);

	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R30mA,"30.0mA","-30.0mA").APPLY();
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R30mA,"30.0mA","-30.0mA").APPLY();
	rdk::Timer::WAIT(5e-3); 
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").APPLY();
	DPIN_Levelset("MODE_mdm","3.6V", "0.0V", "1.8V", "1.8V",CLOSE_,ON_);
	rdk::Timer::WAIT(15e-3); 
	
	I2C_Write(0x6A,0x5A); 
	rdk::Timer::WAIT(1e-3); // enter test mode 
	I2C_Write(0x6A,0xA5); 
	rdk::Timer::WAIT(3e-3); // enter test mode   

	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").APPLY();
	rdk::Timer::WAIT(5e-3);
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R3uA,"3.0uA","-3.0uA").APPLY(); 
	rdk::Timer::WAIT(5e-3);

	I2C_Write(0x24,0x04); // disable BUCK block(DIS_EN=1)
	rdk::Timer::WAIT(1e-3); 
	I2C_Write(0x23,0x88); // mux out IBIAS_0.5uA(MUXSEL=2'b10,AD_MUXO_EN=1)
	rdk::Timer::WAIT(3e-3); 
	
// Pre measure	
	IBIAS_post[0] = rdk::MMXH::PMU("EN_mmxh_pmu").MEAS_I(100);	//Expected IBIAS_0.5uA
	
// Test Mode Out	
	I2C_Write(0x6A,0x00); 
	rdk::Timer::WAIT(1e-3); // EXIT test mode
	

    for(ItrDUTs itrDut(DUT_ACTIVE); !itrDut.isDone(); itrDut++) 
	{
		IBIAS_post[0][*itrDut] = IBIAS_post[0][*itrDut].getAsDouble() * -1;
		IBIAS_post_err[*itrDut] = ((IBIAS_target - IBIAS_post[0][*itrDut].getAsDouble() ) / (IBIAS_post[0][*itrDut].getAsDouble()+1e-9) ); 
    }

// clean up
	MMXH_PMU_Slewrate("VIN_mmxh_pmu" ,"Slow");   //for spike
	MMXH_PMU_Slewrate("VOUT_mmxh_pmu","Slow");   //for spike

	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R30mA,"30.0mA","-30.0mA").APPLY();
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R30mA,"30.0mA","-30.0mA").APPLY();
	rdk::Timer::WAIT(3e-3);
	DPIN_Levelset("MODE_mdm",OPEN_,OFF_);
	rdk::MMXH::PMU("VOUT_mmxh_pmu").disconnect().power(OFF).APPLY();	
	rdk::MMXH::PMU("EN_mmxh_pmu").disconnect().power(OFF).APPLY();	
	rdk::MMXH::PMU("VIN_mmxh_pmu").disconnect().power(OFF).APPLY();	
	rdk::CW("K_ALL").off().APPLY();
	rdk::Timer::WAIT(3e-3);

	MMXH_PMU_Slewrate("VIN_mmxh_pmu" ,"VeryFast");   //for spike
	MMXH_PMU_Slewrate("VOUT_mmxh_pmu","VeryFast");   //for spike

	result |= Judge(test_id,"IBIAS_post",    "T_IBIAS_TRIM_LS.IBIAS_post",     IBIAS_post[0],"SoftBins.BIN15"); if(RscDUTs(DUT_ACTIVE).isEmpty())return result; test_id++;
	result |= Judge(test_id,"IBIAS_post_err","T_IBIAS_TRIM_LS.IBIAS_post_err",IBIAS_post_err,"SoftBins.BIN15"); if(RscDUTs(DUT_ACTIVE).isEmpty()) return result; test_id++;

	return result;
} // T_IBIAS_POST


RsltAllDUTCtnr
TPG::T_RSNS_TRIM()
{
	RsltAllDUTCtnr result;
	test_id = 600;	

	OFCArray<ValDUT> RSNS_pre(1,100);
	OFCArray<ValDUT> RSNS_sim(1,100);
	ValDUT RSNS_pre_err;
	ValDUT RSNS_sim_err;
	//ValDUT RSNS_code;
	
	//ktb8316_discharge(); // Discharge For preventing from affection of previous item

	RscTestCondition MODE_Timing("(Timing_MODE)");
	timing_set(Timming_Speed,MODE_Timing);

// Setup 
    rdk::CW("K1;K2;K13;K16").on().APPLY(); // MODE_MMXH, MODE_MDM, VIN_CAP, EN_MMXH  
	rdk::Timer::WAIT(3e-3);

	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").connect().power(ON).APPLY(); 
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").connect().power(ON).APPLY();	
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").connect().power(ON).APPLY();	
	rdk::Timer::WAIT(3e-3);

	////IC Turn on
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("1.8V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY(); //For spike
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("1.8V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();	//For spike
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("1.8V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();	//For spike
	
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();
	rdk::Timer::WAIT(5e-3);

	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R30mA,"30.0mA","-30.0mA").APPLY();
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R30mA,"30.0mA","-30.0mA").APPLY();
	rdk::Timer::WAIT(5e-3);
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").APPLY();
	DPIN_Levelset("MODE_mdm","3.6V", "0.0V", "1.8V", "1.8V",CLOSE_,ON_);
	rdk::Timer::WAIT(15e-3); 

	I2C_Write(0x6A,0x5A); 
	rdk::Timer::WAIT(1e-3); // enter test mode 
	I2C_Write(0x6A,0xA5); 
	rdk::Timer::WAIT(3e-3); // enter test mode   

	MMXH_PMU_Slewrate("EN_mmxh_pmu"  ,"Slow");  //for spike	
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").APPLY();
	rdk::Timer::WAIT(3e-3); 
	rdk::MMXH::PMU("EN_mmxh_pmu").isvm("0.0uA",rdkenum::R3mA,rdkenum::R7V,"7V","-7V").APPLY();
	rdk::Timer::WAIT(3e-3); 
	rdk::MMXH::PMU("EN_mmxh_pmu").disconnect().power(OFF).APPLY();
	MMXH_PMU_Slewrate("EN_mmxh_pmu"  ,"VeryFast");  //for spike	

	I2C_Write(0x21,0x40); 
	rdk::Timer::WAIT(3e-3);

	DPIN_Levelset("MODE_mdm",OPEN_,OFF_); 
	rdk::Timer::WAIT(3e-3);
    rdk::CW("K2").off().APPLY();
	rdk::Timer::WAIT(3e-3);

	rdk::MMXH::PMU("MODE_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R300uA,"300uA","-300uA").connect().power(ON).APPLY();	
	rdk::Timer::WAIT(5e-3);

// Pre measure
	RSNS_pre[0] = rdk::MMXH::PMU("MODE_mmxh_pmu").MEAS_I(100);

// clean up
	MMXH_PMU_Slewrate("VIN_mmxh_pmu" ,"Slow");  //for spike
	MMXH_PMU_Slewrate("VOUT_mmxh_pmu","Slow");  //for spike

	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R30mA,"30.0mA","-30.0mA").APPLY();
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R30mA,"30.0mA","-30.0mA").APPLY();
	rdk::Timer::WAIT(3e-3);
	rdk::MMXH::PMU("VOUT_mmxh_pmu").disconnect().power(OFF).APPLY();	
	rdk::MMXH::PMU("EN_mmxh_pmu").disconnect().power(OFF).APPLY();	
	rdk::MMXH::PMU("VIN_mmxh_pmu").disconnect().power(OFF).APPLY();	
	rdk::MMXH::PMU("MODE_mmxh_pmu").disconnect().power(OFF).APPLY();	
	rdk::CW("K_ALL").off().APPLY();
	rdk::Timer::WAIT(3e-3);

	MMXH_PMU_Slewrate("VIN_mmxh_pmu" ,"VeryFast");  //for spike
	MMXH_PMU_Slewrate("VOUT_mmxh_pmu","VeryFast");  //for spike

    for(ItrDUTs itrDut(DUT_ACTIVE); !itrDut.isDone(); itrDut++) 
	{//target = 30uA
		RSNS_pre[0][*itrDut] = RSNS_pre[0][*itrDut].getAsDouble() * -1;
		RSNS_pre_err[*itrDut] = ((RSNS_target - RSNS_pre[0][*itrDut].getAsDouble()) / (RSNS_pre[0][*itrDut].getAsDouble()+1e-9) ) ;
    }
	result |= Judge(test_id,"RSNS_pre",    "T_RSNS_TRIM_LS.RSNS_pre",     RSNS_pre[0],"SoftBins.BIN16"); if(RscDUTs(DUT_ACTIVE).isEmpty())return result; test_id++;
	result |= Judge(test_id,"RSNS_pre_err","T_RSNS_TRIM_LS.RSNS_pre_err",RSNS_pre_err,"SoftBins.BIN16"); if(RscDUTs(DUT_ACTIVE).isEmpty()) return result; test_id++;

// trim table
    for(ItrDUTs itrDut(DUT_ACTIVE); !itrDut.isDone(); itrDut++) 
	{
		double RSNS_data_err = RSNS_pre_err[*itrDut].getAsDouble() * 100;

		if (RSNS_data_err >= -50 && RSNS_data_err<50)
		{
			if (RSNS_data_err >=  -1.27 && RSNS_data_err <  -0.45)		{ rsns_code[*itrDut] = 31; }//
			if (RSNS_data_err >=  -2.07 && RSNS_data_err <  -1.27)		{ rsns_code[*itrDut] = 30; }//
			if (RSNS_data_err >=  -2.93 && RSNS_data_err <  -2.07)		{ rsns_code[*itrDut] = 29; }//
			if (RSNS_data_err >=  -3.71 && RSNS_data_err <  -2.93)		{ rsns_code[*itrDut] = 28; }//
			if (RSNS_data_err >=  -4.52 && RSNS_data_err <  -3.71)		{ rsns_code[*itrDut] = 27; }//
			if (RSNS_data_err >=  -5.30 && RSNS_data_err <  -4.52)		{ rsns_code[*itrDut] = 26; }//
			if (RSNS_data_err >=  -6.09 && RSNS_data_err <  -5.30)		{ rsns_code[*itrDut] = 25; }//
			if (RSNS_data_err >=  -6.95 && RSNS_data_err <  -6.09)		{ rsns_code[*itrDut] = 24; }//
			if (RSNS_data_err >=  -7.76 && RSNS_data_err <  -6.95)		{ rsns_code[*itrDut] = 23; }//
			if (RSNS_data_err >=  -8.56 && RSNS_data_err <  -7.76)		{ rsns_code[*itrDut] = 22; }//
			if (RSNS_data_err >=  -9.41 && RSNS_data_err <  -8.56)		{ rsns_code[*itrDut] = 21; }//
			if (RSNS_data_err >= -10.21 && RSNS_data_err <  -9.41)		{ rsns_code[*itrDut] = 20; }//
			if (RSNS_data_err >= -11.03 && RSNS_data_err < -10.21)		{ rsns_code[*itrDut] = 19; }//
			if (RSNS_data_err >= -11.84 && RSNS_data_err < -11.03)		{ rsns_code[*itrDut] = 18; }//
			if (RSNS_data_err >= -12.67 && RSNS_data_err < -11.84)		{ rsns_code[*itrDut] = 17; }//
			if (RSNS_data_err >= -50.0  && RSNS_data_err < -12.67)		{ rsns_code[*itrDut] = 16; }//

			if (RSNS_data_err >=  11.88 && RSNS_data_err <  50.0)		{ rsns_code[*itrDut] = 15; }//
			if (RSNS_data_err >=  11.07 && RSNS_data_err <  11.88)		{ rsns_code[*itrDut] = 14; }//
			if (RSNS_data_err >=  10.21 && RSNS_data_err <  11.07)		{ rsns_code[*itrDut] = 13; }//
			if (RSNS_data_err >=   9.43 && RSNS_data_err <  10.21)		{ rsns_code[*itrDut] = 12; }//
			if (RSNS_data_err >=   8.60 && RSNS_data_err <   9.43)		{ rsns_code[*itrDut] = 11; }//
			if (RSNS_data_err >=   7.80 && RSNS_data_err <   8.60)		{ rsns_code[*itrDut] = 10; }//
			if (RSNS_data_err >=   6.99 && RSNS_data_err <   7.80)		{ rsns_code[*itrDut] =  9; }//
			if (RSNS_data_err >=   6.15 && RSNS_data_err <   6.99)		{ rsns_code[*itrDut] =  8; }//
			if (RSNS_data_err >=   5.34 && RSNS_data_err <   6.15)		{ rsns_code[*itrDut] =  7; }//
			if (RSNS_data_err >=   4.50 && RSNS_data_err <   5.34)		{ rsns_code[*itrDut] =  6; }//
			if (RSNS_data_err >=   3.68 && RSNS_data_err <   4.50)		{ rsns_code[*itrDut] =  5; }//
			if (RSNS_data_err >=   2.92 && RSNS_data_err <   3.68)		{ rsns_code[*itrDut] =  4; }//
			if (RSNS_data_err >=   2.11 && RSNS_data_err <   2.92)		{ rsns_code[*itrDut] =  3; }//
			if (RSNS_data_err >=   1.27 && RSNS_data_err <   2.11)		{ rsns_code[*itrDut] =  2; }//
			if (RSNS_data_err >=   0.45 && RSNS_data_err <   1.27)		{ rsns_code[*itrDut] =  1; }//
			if (RSNS_data_err >=  -0.45 && RSNS_data_err <   0.45)		{ rsns_code[*itrDut] =  0; }//
		}
		else
			rsns_code[*itrDut] = 0; //

       if (EN_OTP48_04[*itrDut]==0) { rsns_code[*itrDut] = RD_OTP48_04[*itrDut].getAsInt(); } 
	} // for ItrDUTs


	result |= Judge(test_id,"RSNS_code",	rsns_code,   -0.5, 255.5,"SoftBins.BIN16","SoftBins.BIN16","Dec"); if(RscDUTs(DUT_ACTIVE).isEmpty())return result; test_id++;

	//ktb8316_discharge(); // Discharge For preventing from affection of previous item

// Sim Setup 
    rdk::CW("K1;K2;K13;K16").on().APPLY(); // MODE_MMXH, MODE_MDM, VIN_CAP, EN_MMXH  
	rdk::Timer::WAIT(3e-3);

	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").connect().power(ON).APPLY(); 
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").connect().power(ON).APPLY();	
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").connect().power(ON).APPLY();	
	rdk::Timer::WAIT(3e-3);

	//IC Turn on
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("1.8V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY(); //For spike
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("1.8V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();	//For spike
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("1.8V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").APPLY();			//For spike

	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();
	rdk::Timer::WAIT(5e-3);

	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R30mA,"30.0mA","-30.0mA").APPLY();
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R30mA,"30.0mA","-30.0mA").APPLY();
	rdk::Timer::WAIT(5e-3); 
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").APPLY();
	DPIN_Levelset("MODE_mdm","3.6V", "0.0V", "1.8V", "1.8V",CLOSE_,ON_);
	rdk::Timer::WAIT(15e-3); 
	
	I2C_Write(0x6A,0x5A); 
	rdk::Timer::WAIT(1e-3); // enter test mode 
	I2C_Write(0x6A,0xA5); 
	rdk::Timer::WAIT(3e-3); // enter test mode   

	MMXH_PMU_Slewrate("EN_mmxh_pmu"  ,"Slow");  //for spike	
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").APPLY();
	rdk::Timer::WAIT(3e-3); 
	rdk::MMXH::PMU("EN_mmxh_pmu").isvm("0.0uA",rdkenum::R3mA,rdkenum::R7V,"7V","-7V").APPLY();
	rdk::Timer::WAIT(3e-3); 
	rdk::MMXH::PMU("EN_mmxh_pmu").disconnect().power(OFF).APPLY();
	MMXH_PMU_Slewrate("EN_mmxh_pmu"  ,"VeryFast");  //for spike	

	I2C_Write(0x21,0x40); 
	rdk::Timer::WAIT(3e-3); // (XTM=1)

	I2C_Write(0x48,rsns_code); 
	rdk::Timer::WAIT(5e-3); // OTP data write reg.	

	DPIN_Levelset("MODE_mdm",OPEN_,OFF_); 
	rdk::Timer::WAIT(3e-3);
    rdk::CW("K2").off().APPLY();
	rdk::Timer::WAIT(3e-3);

	rdk::MMXH::PMU("MODE_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R300uA,"300uA","-300uA").connect().power(ON).APPLY();
	rdk::Timer::WAIT(5e-3);

// Sim measure
	RSNS_sim[0] = rdk::MMXH::PMU("MODE_mmxh_pmu").MEAS_I(100);

 
// clean up
	MMXH_PMU_Slewrate("VIN_mmxh_pmu" ,"Slow");  //for spike
	MMXH_PMU_Slewrate("VOUT_mmxh_pmu","Slow");  //for spike

	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R30mA,"30.0mA","-30.0mA").APPLY();
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R30mA,"30.0mA","-30.0mA").APPLY();
	rdk::Timer::WAIT(3e-3);
	rdk::MMXH::PMU("VOUT_mmxh_pmu").disconnect().power(OFF).APPLY();	
	rdk::MMXH::PMU("EN_mmxh_pmu").disconnect().power(OFF).APPLY();	
	rdk::MMXH::PMU("VIN_mmxh_pmu").disconnect().power(OFF).APPLY();	
	rdk::MMXH::PMU("MODE_mmxh_pmu").disconnect().power(OFF).APPLY();	
	rdk::CW("K_ALL").off().APPLY();
	rdk::Timer::WAIT(3e-3);

	MMXH_PMU_Slewrate("VIN_mmxh_pmu" ,"VeryFast");  //for spike
	MMXH_PMU_Slewrate("VOUT_mmxh_pmu","VeryFast");  //for spike

 for(ItrDUTs itrDut(DUT_ACTIVE); !itrDut.isDone(); itrDut++) 
	{
		RSNS_sim[0][*itrDut] = RSNS_sim[0][*itrDut].getAsDouble() * -1 ;
		RSNS_sim_err[*itrDut] = ((RSNS_target - RSNS_sim[0][*itrDut].getAsDouble() ) / (RSNS_sim[0][*itrDut].getAsDouble()+1e-9) ); 
    }

	result |= Judge(test_id,"RSNS_sim",    "T_RSNS_TRIM_LS.RSNS_sim",     RSNS_sim[0],"SoftBins.BIN16"); if(RscDUTs(DUT_ACTIVE).isEmpty())return result; test_id++;
	result |= Judge(test_id,"RSNS_sim_err","T_RSNS_TRIM_LS.RSNS_sim_err",RSNS_sim_err,"SoftBins.BIN16"); if(RscDUTs(DUT_ACTIVE).isEmpty()) return result; test_id++;


	return result;
} // T_RNSN_Trim




RsltAllDUTCtnr
TPG::T_RSNS_BURN()
{
	RsltAllDUTCtnr result;
if (en_trim == 1)
{
	rdk::CW("K2;K12;K13;K16").on().APPLY(); // MODE MDM, EN MMXH, VIN_CAP, VOUT_CAP 
	rdk::Timer::WAIT(3e-3); 

	//IC Turn on
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("1.8V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").connect().power(ON).APPLY(); //For spike
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("1.8V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").connect().power(ON).APPLY();	//For spike
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("1.8V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").connect().power(ON).APPLY();			//For spike

	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").APPLY();
	DPIN_Levelset("MODE_mdm","3.6V", "0.0V", "1.8V", "1.8V",CLOSE_,ON_);
	rdk::Timer::WAIT(15e-3); 

	I2C_Write(0x6A,0x5A);			rdk::Timer::WAIT(1e-3); // enter test mode 
	I2C_Write(0x6A,0xA5);			rdk::Timer::WAIT(1e-3); // enter test mode  2. Enter Test Mode.
	I2C_Write(0x48,rsns_code);  rdk::Timer::WAIT(1e-3); //3. Write target OTP values into REG 0x40 to 0x48.
	I2C_Write(0x20,0x08);			rdk::Timer::WAIT(1e-3); // 4. Write REG 0x20 = 0x00 to select data in REG 0x40 to be burned.
	I2C_Write(0x21,0x09);			rdk::Timer::WAIT(1e-3); // 5. Write REG 0x21=0x09 (OTP_CLK_REQ=1, EXVPP_EN=1).


	for(ItrDUTs itrDut(DUT_ACTIVE); !itrDut.isDone(); itrDut++) 
	{
		VHEN1[*itrDut] = EN_OTP48_04[*itrDut] * 1.0 * 5;
		VHEN2[*itrDut] = EN_OTP48_04[*itrDut] * 1.1 * 5;
		VHEN3[*itrDut] = EN_OTP48_04[*itrDut] * 1.2 * 5;
		VHEN4[*itrDut] = EN_OTP48_04[*itrDut] * 1.3 * 5;
		VHEN5[*itrDut] = EN_OTP48_04[*itrDut] * 1.4 * 5;

		//For VIN : If burend chip, VIN off, VOUT off
		VIEN[*itrDut] = EN_OTP48_04[*itrDut] * 5.5; //5.5V
		VOEN[*itrDut] = EN_OTP48_04[*itrDut] * 3.6; //3.6V
	}										  
		
	//If burend chip, VIN & VOUT off slowly
	MMXH_PMU_Slewrate("VIN_mmxh_pmu","Slow");   //for spike
	MMXH_PMU_Slewrate("VOUT_mmxh_pmu","Slow");   //for spike
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim(VIEN,rdkenum::R7V,rdkenum::R240mA,"200.0mA","-200.0mA").APPLY(); // VIN 5.5 V is needed for Burn //Check 0V and 5.5V both with DGT
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim(VOEN,rdkenum::R7V,rdkenum::R240mA,"200.0mA","-200.0mA").APPLY();
	rdk::Timer::WAIT(3e-3);	
	MMXH_PMU_Slewrate("VOUT_mmxh_pmu","VeryFast");   //for spike
	MMXH_PMU_Slewrate("VIN_mmxh_pmu","VeryFast");   //for spike

	//Burn
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim(VHEN1,rdkenum::R7V,rdkenum::R240mA,"200.0mA","-200.0mA").APPLY();
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim(VHEN2,rdkenum::R7V,rdkenum::R240mA,"200.0mA","-200.0mA").APPLY();
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim(VHEN3,rdkenum::R7V,rdkenum::R240mA,"200.0mA","-200.0mA").APPLY();
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim(VHEN4,rdkenum::R7V,rdkenum::R240mA,"200.0mA","-200.0mA").APPLY();
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim(VHEN5,rdkenum::R7V,rdkenum::R240mA,"200.0mA","-200.0mA").APPLY();
	rdk::Timer::WAIT(1e-3); 

	I2C_Write(0x21,0x0B); //7. Write 0x21 = 0x0B to program the OTP(BURN_EN=1). 8. Wait 1ms.
	rdk::Timer::WAIT(1e-3); 
	I2C_Write(0x21,0x09); //9. Write 0x21 = 0x09 to stop OTP programming.
	rdk::Timer::WAIT(1e-3); 

	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim(VHEN5,rdkenum::R7V,rdkenum::R240mA,"200.0mA","-200.0mA").APPLY();
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim(VHEN4,rdkenum::R7V,rdkenum::R240mA,"200.0mA","-200.0mA").APPLY();
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim(VHEN3,rdkenum::R7V,rdkenum::R240mA,"200.0mA","-200.0mA").APPLY();
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim(VHEN2,rdkenum::R7V,rdkenum::R240mA,"200.0mA","-200.0mA").APPLY();
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim(VHEN1,rdkenum::R7V,rdkenum::R240mA,"200.0mA","-200.0mA").APPLY();
	rdk::Timer::WAIT(1e-3); 

	I2C_Write(0x6A,0x00); // exit test mode
	rdk::Timer::WAIT(1e-3); 


	// clean up
	MMXH_PMU_Slewrate("VIN_mmxh_pmu" ,"Slow");  //for spike
	MMXH_PMU_Slewrate("VOUT_mmxh_pmu","Slow");  //for spike
	MMXH_PMU_Slewrate("EN_mmxh_pmu"  ,"Slow");  //for spike	

	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R240mA,"200.0mA","-200.0mA").APPLY();
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();
	rdk::Timer::WAIT(3e-3);
	DPIN_Levelset("MODE_mdm",OPEN_,OFF_);
	rdk::MMXH::PMU("VOUT_mmxh_pmu").disconnect().power(OFF).APPLY();
	rdk::MMXH::PMU("VIN_mmxh_pmu").disconnect().power(OFF).APPLY();
	rdk::MMXH::PMU("EN_mmxh_pmu").disconnect().power(OFF).APPLY();
	rdk::CW("K_ALL").off().APPLY();
	rdk::Timer::WAIT(3e-3);	

	MMXH_PMU_Slewrate("VIN_mmxh_pmu" ,"VeryFast");  //for spike
	MMXH_PMU_Slewrate("VOUT_mmxh_pmu","VeryFast");  //for spike
	MMXH_PMU_Slewrate("EN_mmxh_pmu"  ,"VeryFast");  //for spike	
}
	result |= Judge(test_id,"RSNS_burn", "T_BURN.BURN", EN_OTP48_04,"SoftBins.BIN16"); if(RscDUTs(DUT_ACTIVE).isEmpty())return result; test_id++;
	
	return result;
} // T_RSNS_Burn


RsltAllDUTCtnr
TPG::T_RSNS_POST()
{
	RsltAllDUTCtnr result;

	OFCArray<ValDUT> RSNS_post(1,100);
	ValDUT RSNS_post_err;

	//ktb8316_discharge(); // Discharge For preventing from affection of previous item

// Setup 
    rdk::CW("K1;K2;K13;K16").on().APPLY(); // MODE_MMXH, MODE_MDM, EN_MMXH, VIN_CAP  
	rdk::Timer::WAIT(3e-3);

	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").connect().power(ON).APPLY(); 
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").connect().power(ON).APPLY();	
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").connect().power(ON).APPLY();	
	rdk::Timer::WAIT(3e-3);

	//IC Turn on
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("1.8V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY(); //For spike
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("1.8V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();	//For spike
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("1.8V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").APPLY();			//For spike

	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();
	rdk::Timer::WAIT(5e-3);

	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R30mA,"30.0mA","-30.0mA").APPLY();
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R30mA,"30.0mA","-30.0mA").APPLY();
	rdk::Timer::WAIT(5e-3); 
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").APPLY();
	DPIN_Levelset("MODE_mdm","3.6V", "0.0V", "1.8V", "1.8V",CLOSE_,ON_);
	rdk::Timer::WAIT(15e-3); 
	
	I2C_Write(0x6A,0x5A); 
	rdk::Timer::WAIT(1e-3); // enter test mode 
	I2C_Write(0x6A,0xA5); 
	rdk::Timer::WAIT(3e-3); // enter test mode   

	MMXH_PMU_Slewrate("EN_mmxh_pmu"  ,"Slow");  //for spike	
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").APPLY();
	rdk::Timer::WAIT(3e-3); 
	rdk::MMXH::PMU("EN_mmxh_pmu").isvm("0.0uA",rdkenum::R3mA,rdkenum::R7V,"7V","-7V").APPLY();
	rdk::Timer::WAIT(3e-3); 
	rdk::MMXH::PMU("EN_mmxh_pmu").disconnect().power(OFF).APPLY();
	MMXH_PMU_Slewrate("EN_mmxh_pmu"  ,"VeryFast");  //for spike	

	I2C_Write(0x21,0x40); 
	rdk::Timer::WAIT(5e-3); // (XTM=1)

	DPIN_Levelset("MODE_mdm",OPEN_,OFF_); 
	rdk::Timer::WAIT(1e-3);
    rdk::CW("K2").off().APPLY();
	rdk::Timer::WAIT(5e-3);	

	rdk::MMXH::PMU("MODE_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R300uA,"300uA","-300uA").connect().power(ON).APPLY();
	rdk::Timer::WAIT(5e-3);	

// Post measure
	RSNS_post[0] = rdk::MMXH::PMU("MODE_mmxh_pmu").MEAS_I(100);

// clean up
	MMXH_PMU_Slewrate("VIN_mmxh_pmu" ,"Slow");  //for spike
	MMXH_PMU_Slewrate("VOUT_mmxh_pmu","Slow");  //for spike

	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R30mA,"30.0mA","-30.0mA").APPLY();
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R30mA,"30.0mA","-30.0mA").APPLY();
	rdk::Timer::WAIT(3e-3);
	rdk::MMXH::PMU("VOUT_mmxh_pmu").disconnect().power(OFF).APPLY();	
	rdk::MMXH::PMU("MODE_mmxh_pmu").disconnect().power(OFF).APPLY();	
	rdk::MMXH::PMU("EN_mmxh_pmu").disconnect().power(OFF).APPLY();	
	rdk::MMXH::PMU("VIN_mmxh_pmu").disconnect().power(OFF).APPLY();	
	rdk::CW("K_ALL").off().APPLY();
	rdk::Timer::WAIT(3e-3);

	MMXH_PMU_Slewrate("VIN_mmxh_pmu" ,"VeryFast");  //for spike
	MMXH_PMU_Slewrate("VOUT_mmxh_pmu","VeryFast");  //for spike

    for(ItrDUTs itrDut(DUT_ACTIVE); !itrDut.isDone(); itrDut++) 
	{
		RSNS_post[0][*itrDut] = RSNS_post[0][*itrDut].getAsDouble() * -1;
		RSNS_post_err[*itrDut] = ((RSNS_target - RSNS_post[0][*itrDut].getAsDouble() ) / (RSNS_post[0][*itrDut].getAsDouble()+1e-9) ) ; 
    }

	result |= Judge(test_id,"RSNS_post",    "T_RSNS_TRIM_LS.RSNS_post",     RSNS_post[0],"SoftBins.BIN16"); if(RscDUTs(DUT_ACTIVE).isEmpty())return result; test_id++;
	result |= Judge(test_id,"RSNS_post_err","T_RSNS_TRIM_LS.RSNS_post_err",RSNS_post_err,"SoftBins.BIN16"); if(RscDUTs(DUT_ACTIVE).isEmpty()) return result; test_id++;


	return result;
} // T_RSNS_post



//FOSC_Trim
RsltAllDUTCtnr
TPG::T_FOSC_TRIM()
{

	RsltAllDUTCtnr result;
	test_id = 700;	

	ValDUT FOSC_pre;
	ValDUT FOSC_sim;
	ValDUT FOSC_pre_err;
	ValDUT FOSC_sim_err;
	//ValDUT FOSC_code;
	
	RscTestCondition MODE_Timing("(Timing_MODE)");
	timing_set(Timming_Speed,MODE_Timing);

// Setup
    rdk::CW("K2;K6;K13;K16").on().APPLY(); // MODE_MDM, EN_BUFF, VIN_CAP, EN_MMXH
	rdk::Timer::WAIT(3e-3); 

	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").connect().power(ON).APPLY();
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").connect().power(ON).APPLY();
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").connect().power(ON).APPLY();
	rdk::Timer::WAIT(3e-3);

	//IC Turn on
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("1.8V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY(); //For spike
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("1.8V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();	//For spike
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("1.8V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();	//For spike

	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();
	rdk::Timer::WAIT(5e-3);

	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").APPLY();
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").APPLY();
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").APPLY();
	DPIN_Levelset("MODE_mdm","3.6V", "0.0V", "1.8V", "1.8V",CLOSE_,ON_);
	rdk::Timer::WAIT(15e-3); 

	I2C_Write(0x6A,0x5A); 
	rdk::Timer::WAIT(1e-3); // enter test mode 
	I2C_Write(0x6A,0xA5); 
	rdk::Timer::WAIT(3e-3); // enter test mode   

	MMXH_PMU_Slewrate("EN_mmxh_pmu"  ,"Slow");  //for spike	
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").APPLY();
	rdk::Timer::WAIT(3e-3);
	rdk::MMXH::PMU("EN_mmxh_pmu").isvm("0.0mA",rdkenum::R3mA,rdkenum::R7V,"7.0V","-7V").APPLY(); //EN Float-2
	rdk::Timer::WAIT(3e-3);
	rdk::MMXH::PMU("EN_mmxh_pmu").disconnect().power(OFF).APPLY(); // EN float-3
	rdk::Timer::WAIT(3e-3);
	MMXH_PMU_Slewrate("EN_mmxh_pmu"  ,"VeryFast");  //for spike	

	rdk::CW("K16").off().APPLY(); // EN_MMXH
	rdk::Timer::WAIT(3e-3);

	I2C_Write(0x44,0x40); 
	rdk::Timer::WAIT(1e-3); //  set 2MHz Fsw Option
	I2C_Write(0x24,0x04); 
	rdk::Timer::WAIT(1e-3); //  disable BUCK block(DIS_EN=1)
	I2C_Write(0x23,0xEB); 
	rdk::Timer::WAIT(5e-3); //  I2C_Write(0x24,0x04); rdk::Timer::WAIT(3e-3); //  disable BUCK block(DIS_EN=1)
	
// Pre measure
	rdk::Digital::Pin("BUF_mmxh_dcl").vohl("2.0V","1.0V").connect().power(ON).APPLY(); // ACCO PGM VOHL 2,1
	rdk::Timer::WAIT(1e-3); 

	rdk::MMXH::TMU("BUF_mmxh_tmu").event(rdkenum::COMPVOL_HYS_RISE).count(30).trigger(rdkenum::START,rdkenum::SOFT,"NONE",rdkenum::RISING).APPLY();

	RscTMUPin tmu_a("BUF_mmxh_tmu"); tmu_a.setCondition("TimeOut","10.0mS"); // setting time-out
	
	rdk::MMXH::TMU("BUF_mmxh_tmu").START().WAIT_ACQ("3mS");
	rdk::MMXH::TMU("BUF_mmxh_tmu").STOP();
	rdk::MMXH::TMU("BUF_mmxh_tmu").GET_RESULT_FREQ(FOSC_pre,rdkenum::COMPVOL_RISE);

	I2C_Write(0x21,0x00); 
	rdk::Timer::WAIT(1e-3); 

// clean up
	MMXH_PMU_Slewrate("VIN_mmxh_pmu" ,"Slow");  //for spike
	MMXH_PMU_Slewrate("VOUT_mmxh_pmu","Slow");  //for spike

	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").APPLY();
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").APPLY();
	rdk::Timer::WAIT(3e-3);
	DPIN_Levelset("MODE_mdm",OPEN_,OFF_);	
	rdk::Digital::Pin("BUF_mmxh_dcl").disconnect().power(OFF).APPLY();
	rdk::MMXH::PMU("VOUT_mmxh_pmu").disconnect().power(OFF).APPLY();
	rdk::MMXH::PMU("EN_mmxh_pmu").disconnect().power(OFF).APPLY();
	rdk::MMXH::PMU("VIN_mmxh_pmu").disconnect().power(OFF).APPLY();
	rdk::CW("K_ALL").off().APPLY();
	rdk::Timer::WAIT(3e-3);

	MMXH_PMU_Slewrate("VIN_mmxh_pmu" ,"VeryFast");  //for spike
	MMXH_PMU_Slewrate("VOUT_mmxh_pmu","VeryFast");  //for spike

    for(ItrDUTs itrDut(DUT_ACTIVE); !itrDut.isDone(); itrDut++) 
	{
    	FOSC_pre_err[*itrDut] = (FOSC_target - FOSC_pre[*itrDut].getAsDouble()) / (FOSC_pre[*itrDut].getAsDouble()+1e-9) ; 
    }

	result |= Judge(test_id,"FOSC_pre",    "T_FOSC_TRIM_LS.FOSC_pre",        FOSC_pre,"SoftBins.BIN17"); if(RscDUTs(DUT_ACTIVE).isEmpty()) return result; test_id++;
	result |= Judge(test_id,"FOSC_pre_err","T_FOSC_TRIM_LS.FOSC_pre_err",FOSC_pre_err,"SoftBins.BIN17"); if(RscDUTs(DUT_ACTIVE).isEmpty()) return result; test_id++;


// FOSC trim table ------------------------------------------------------------------------------------------
    for(ItrDUTs itrDut(DUT_ACTIVE); !itrDut.isDone(); itrDut++) 
	{
		double temp_data_err = FOSC_pre_err[*itrDut].getAsDouble() * 100;

	    if(temp_data_err >= -70.0 && temp_data_err<100.0)
		{
			if (temp_data_err >= -6.77 && temp_data_err< -2.34)		{ fosc_code[*itrDut] = 240; }//
			if (temp_data_err >= -10.76 && temp_data_err< -6.77)	{ fosc_code[*itrDut] = 224; }//
			if (temp_data_err >= -14.47 && temp_data_err< -10.76)	{ fosc_code[*itrDut] = 208; }//
			if (temp_data_err >= -17.85 && temp_data_err< -14.47)	{ fosc_code[*itrDut] = 192; }//
			if (temp_data_err >= -20.93 && temp_data_err< -17.85)	{ fosc_code[*itrDut] = 176; }//
			if (temp_data_err >= -23.83 && temp_data_err< -20.93)	{ fosc_code[*itrDut] = 160; }//
			if (temp_data_err >= -26.55 && temp_data_err< -23.83)	{ fosc_code[*itrDut] = 144; }//
			if (temp_data_err >= -70.0 && temp_data_err< -26.55)	{ fosc_code[*itrDut] = 128; }//

			if (temp_data_err >= 45.94 && temp_data_err< 100)		{ fosc_code[*itrDut] = 112; }//
			if (temp_data_err >= 36.23 && temp_data_err< 45.94)		{ fosc_code[*itrDut] = 96; }//
			if (temp_data_err >= 27.76 && temp_data_err< 36.23)		{ fosc_code[*itrDut] = 80; }//
			if (temp_data_err >= 20.37 && temp_data_err< 27.76)		{ fosc_code[*itrDut] = 64; }//
			if (temp_data_err >= 13.76 && temp_data_err< 20.37)		{ fosc_code[*itrDut] = 48; }//
			if (temp_data_err >= 7.80 && temp_data_err< 13.76)		{ fosc_code[*itrDut] = 32; }//
			if (temp_data_err >= 2.49 && temp_data_err< 7.80)		{ fosc_code[*itrDut] = 16; }//
			if (temp_data_err >= -2.34 && temp_data_err< 2.49)		{ fosc_code[*itrDut] = 0; }//
	    }
		else fosc_code[*itrDut]= 0; // 

       if(EN_OTP41_47[*itrDut]==0) { fosc_code[*itrDut] = RD_OTP41_47[*itrDut].getAsInt(); } 

	} // for ItrDUTs

	result |= Judge(test_id,"FOSC_code",	fosc_code,   -0.5, 255.5,"SoftBins.BIN17","SoftBins.BIN17","Dec"); if(RscDUTs(DUT_ACTIVE).isEmpty())return result; test_id++;

// Sim Setup
    rdk::CW("K2;K6;K13;K16").on().APPLY(); // MODE_MDM, EN_BUFF, VIN_CAP, EN_MMXH
	rdk::Timer::WAIT(3e-3); 

	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").connect().power(ON).APPLY();
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").connect().power(ON).APPLY();
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").connect().power(ON).APPLY();
	rdk::Timer::WAIT(3e-3);

	//IC Turn on
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("1.8V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY(); //For spike
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("1.8V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();	//For spike
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("1.8V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();	//For spike

	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();
	rdk::Timer::WAIT(5e-3);

	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").APPLY();
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").APPLY();
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").APPLY();
	DPIN_Levelset("MODE_mdm","3.6V", "0.0V", "1.8V", "1.8V",CLOSE_,ON_);
	rdk::Timer::WAIT(15e-3); 

	I2C_Write(0x6A,0x5A); 
	rdk::Timer::WAIT(1e-3); // enter test mode 
	I2C_Write(0x6A,0xA5); 
	rdk::Timer::WAIT(3e-3); // enter test mode   

	MMXH_PMU_Slewrate("EN_mmxh_pmu"  ,"Slow");  //for spike	
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").APPLY();
	rdk::Timer::WAIT(3e-3);
	rdk::MMXH::PMU("EN_mmxh_pmu").isvm("0.0mA",rdkenum::R3mA,rdkenum::R7V,"7.0V","-7V").APPLY(); 
	rdk::Timer::WAIT(3e-3);
	rdk::MMXH::PMU("EN_mmxh_pmu").disconnect().power(OFF).APPLY(); // EN float-3
	rdk::Timer::WAIT(3e-3);
	MMXH_PMU_Slewrate("EN_mmxh_pmu"  ,"VeryFast");  //for spike	

	rdk::CW("K16").off().APPLY(); // EN_MMXH
	rdk::Timer::WAIT(3e-3);

	I2C_Write(0x44,0x40); 
	rdk::Timer::WAIT(1e-3); //  set 2MHz Fsw Option
	I2C_Write(0x24,0x04); 
	rdk::Timer::WAIT(1e-3); //  disable BUCK block(DIS_EN=1)
	I2C_Write(0x23,0xEB); 
	rdk::Timer::WAIT(5e-3);
	
// Sim measure
	I2C_Write(0x41,fosc_code); 
	rdk::Timer::WAIT(5e-3); // OTP data write reg.

// Sim measure
	rdk::Digital::Pin("BUF_mmxh_dcl").vohl("2.0V","1.0V").connect().power(ON).APPLY(); // ACCO PGM VOHL 2,1
	rdk::Timer::WAIT(1e-3); 

	rdk::MMXH::TMU("BUF_mmxh_tmu").event(rdkenum::COMPVOL_HYS_RISE).count(30).trigger(rdkenum::START,rdkenum::SOFT,"NONE",rdkenum::RISING).APPLY();

	RscTMUPin tmu_b("BUF_mmxh_tmu"); tmu_b.setCondition("TimeOut","10.0mS"); // setting time-out

	rdk::MMXH::TMU("BUF_mmxh_tmu").START().WAIT_ACQ("3mS");
	rdk::MMXH::TMU("BUF_mmxh_tmu").STOP();
	rdk::MMXH::TMU("BUF_mmxh_tmu").GET_RESULT_FREQ(FOSC_sim,rdkenum::COMPVOL_RISE);

	I2C_Write(0x21,0x00); 
	rdk::Timer::WAIT(1e-3); 

// clean up
	MMXH_PMU_Slewrate("VIN_mmxh_pmu" ,"Slow");  //for spike
	MMXH_PMU_Slewrate("VOUT_mmxh_pmu","Slow");  //for spike

	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").APPLY();
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").APPLY();
	rdk::Timer::WAIT(3e-3);
	DPIN_Levelset("MODE_mdm",OPEN_,OFF_);	
	rdk::Digital::Pin("BUF_mmxh_dcl").disconnect().power(OFF).APPLY();
	rdk::MMXH::PMU("VOUT_mmxh_pmu").disconnect().power(OFF).APPLY();
	rdk::MMXH::PMU("EN_mmxh_pmu").disconnect().power(OFF).APPLY();
	rdk::MMXH::PMU("VIN_mmxh_pmu").disconnect().power(OFF).APPLY();
	rdk::CW("K_ALL").off().APPLY();
	rdk::Timer::WAIT(3e-3);

	MMXH_PMU_Slewrate("VIN_mmxh_pmu" ,"VeryFast");  //for spike
	MMXH_PMU_Slewrate("VOUT_mmxh_pmu","VeryFast");  //for spike

    for(ItrDUTs itrDut(DUT_ACTIVE); !itrDut.isDone(); itrDut++) 
	{
    	FOSC_sim_err[*itrDut] = (FOSC_target - FOSC_sim[*itrDut].getAsDouble()) / (FOSC_sim[*itrDut].getAsDouble()+1e-9) ; 
    }

	result |= Judge(test_id,"FOSC_sim",    "T_FOSC_TRIM_LS.FOSC_sim",        FOSC_sim,"SoftBins.BIN17"); if(RscDUTs(DUT_ACTIVE).isEmpty()) return result; test_id++;
	result |= Judge(test_id,"FOSC_sim_err","T_FOSC_TRIM_LS.FOSC_sim_err",FOSC_sim_err,"SoftBins.BIN17"); if(RscDUTs(DUT_ACTIVE).isEmpty()) return result; test_id++;

	return result;
} // T_FOSC_Trim


RsltAllDUTCtnr
TPG::T_FOSC_BURN()
{
	RsltAllDUTCtnr result;
if (en_trim == 1)
{
	rdk::CW("K2;K12;K13;K16").on().APPLY(); // MODE MDM, EN MMXH, VIN_CAP, VOUT_CAP 
	rdk::Timer::WAIT(3e-3); 

	//IC Turn on
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("1.8V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").connect().power(ON).APPLY(); //For spike
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("1.8V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").connect().power(ON).APPLY();	//For spike
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("1.8V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").connect().power(ON).APPLY();	//For spike

	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").APPLY();
	DPIN_Levelset("MODE_mdm","3.6V", "0.0V", "1.8V", "1.8V",CLOSE_,ON_);
	rdk::Timer::WAIT(15e-3); 

	I2C_Write(0x6A,0x5A);			rdk::Timer::WAIT(1e-3); // enter test mode 
	I2C_Write(0x6A,0xA5);			rdk::Timer::WAIT(1e-3); // enter test mode  2. Enter Test Mode.
	I2C_Write(0x41,fosc_code);	    rdk::Timer::WAIT(1e-3); //3. Write target OTP values into REG 0x40 to 0x48.
	I2C_Write(0x20,0x01);			rdk::Timer::WAIT(1e-3); // 4. Write REG 0x20 = 0x00 to select data in REG 0x40 to be burned.
	I2C_Write(0x21,0x09);			rdk::Timer::WAIT(1e-3); // 5. Write REG 0x21=0x09 (OTP_CLK_REQ=1, EXVPP_EN=1).


	for(ItrDUTs itrDut(DUT_ACTIVE); !itrDut.isDone(); itrDut++) 
	{
		VHEN1[*itrDut] = EN_OTP41_47[*itrDut] * 1.0 * 5;
		VHEN2[*itrDut] = EN_OTP41_47[*itrDut] * 1.1 * 5;
		VHEN3[*itrDut] = EN_OTP41_47[*itrDut] * 1.2 * 5;
		VHEN4[*itrDut] = EN_OTP41_47[*itrDut] * 1.3 * 5;
		VHEN5[*itrDut] = EN_OTP41_47[*itrDut] * 1.4 * 5;

		//For VIN : If burend chip, VIN off, VOUT off
		VIEN[*itrDut] = EN_OTP41_47[*itrDut] * 5.5; //5.5V
		VOEN[*itrDut] = EN_OTP41_47[*itrDut] * 3.6; //3.6V
	}										  
		
	//If burend chip, VIN & VOUT off slowly
	MMXH_PMU_Slewrate("VIN_mmxh_pmu","Slow");   //for spike
	MMXH_PMU_Slewrate("VOUT_mmxh_pmu","Slow");   //for spike
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim(VIEN,rdkenum::R7V,rdkenum::R240mA,"200.0mA","-200.0mA").APPLY(); // VIN 5.5 V is needed for Burn //Check 0V and 5.5V both with DGT
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim(VOEN,rdkenum::R7V,rdkenum::R240mA,"200.0mA","-200.0mA").APPLY();
	rdk::Timer::WAIT(3e-3);	
	MMXH_PMU_Slewrate("VOUT_mmxh_pmu","VeryFast");   //for spike
	MMXH_PMU_Slewrate("VIN_mmxh_pmu","VeryFast");   //for spike

	//Burn
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim(VHEN1,rdkenum::R7V,rdkenum::R240mA,"200.0mA","-200.0mA").APPLY(); 
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim(VHEN2,rdkenum::R7V,rdkenum::R240mA,"200.0mA","-200.0mA").APPLY(); 
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim(VHEN3,rdkenum::R7V,rdkenum::R240mA,"200.0mA","-200.0mA").APPLY(); 
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim(VHEN4,rdkenum::R7V,rdkenum::R240mA,"200.0mA","-200.0mA").APPLY(); 
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim(VHEN5,rdkenum::R7V,rdkenum::R240mA,"200.0mA","-200.0mA").APPLY(); 
	rdk::Timer::WAIT(1e-3); 

	I2C_Write(0x21,0x0B); //7. Write 0x21 = 0x0B to program the OTP(BURN_EN=1). 8. Wait 1ms.
	rdk::Timer::WAIT(1e-3); 
	I2C_Write(0x21,0x09); //9. Write 0x21 = 0x09 to stop OTP programming.
	rdk::Timer::WAIT(1e-3); 

	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim(VHEN5,rdkenum::R7V,rdkenum::R240mA,"200.0mA","-200.0mA").APPLY();
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim(VHEN4,rdkenum::R7V,rdkenum::R240mA,"200.0mA","-200.0mA").APPLY();
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim(VHEN3,rdkenum::R7V,rdkenum::R240mA,"200.0mA","-200.0mA").APPLY();
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim(VHEN2,rdkenum::R7V,rdkenum::R240mA,"200.0mA","-200.0mA").APPLY();
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim(VHEN1,rdkenum::R7V,rdkenum::R240mA,"200.0mA","-200.0mA").APPLY();
	rdk::Timer::WAIT(1e-3); 

	I2C_Write(0x6A,0x00); // exit test mode
	rdk::Timer::WAIT(1e-3); 
	I2C_Write(0x6A,0x00); // exit test mode
	rdk::Timer::WAIT(1e-3); 


	// clean up
	MMXH_PMU_Slewrate("VIN_mmxh_pmu" ,"Slow");  //for spike
	MMXH_PMU_Slewrate("VOUT_mmxh_pmu","Slow");  //for spike
	MMXH_PMU_Slewrate("EN_mmxh_pmu"  ,"Slow");  //for spike	

	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R240mA,"200.0mA","-200.0mA").APPLY();
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();
	rdk::Timer::WAIT(3e-3);
	DPIN_Levelset("MODE_mdm",OPEN_,OFF_);
	rdk::MMXH::PMU("VOUT_mmxh_pmu").disconnect().power(OFF).APPLY();
	rdk::MMXH::PMU("VIN_mmxh_pmu").disconnect().power(OFF).APPLY();
	rdk::MMXH::PMU("EN_mmxh_pmu").disconnect().power(OFF).APPLY();
	rdk::CW("K_ALL").off().APPLY();;
	rdk::Timer::WAIT(3e-3);	

	MMXH_PMU_Slewrate("VIN_mmxh_pmu" ,"VeryFast");  //for spike
	MMXH_PMU_Slewrate("VOUT_mmxh_pmu","VeryFast");  //for spike
	MMXH_PMU_Slewrate("EN_mmxh_pmu"  ,"VeryFast");  //for spike	
}
	result |= Judge(test_id,"FOSC_burn", "T_BURN.BURN", EN_OTP41_47,"SoftBins.BIN17"); if(RscDUTs(DUT_ACTIVE).isEmpty())return result; test_id++;
	
	return result;
} // T_FOSC_Burn


RsltAllDUTCtnr
TPG::T_FOSC_POST()
{

	RsltAllDUTCtnr result;

	ValDUT FOSC_post;
	ValDUT FOSC_post_err;

// Setup
    rdk::CW("K2;K6;K13;K16").on().APPLY(); // MODE_MDM, EN_MMXH, VIN_CAP, EN_BUFF
	rdk::Timer::WAIT(3e-3); 

	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").connect().power(ON).APPLY();
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").connect().power(ON).APPLY();
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").connect().power(ON).APPLY();
	rdk::Timer::WAIT(3e-3);

	//IC Turn on
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("1.8V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY(); //For spike
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("1.8V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();	//For spike
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("1.8V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();	//For spike

	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();
	rdk::Timer::WAIT(5e-3);

	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").APPLY();
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").APPLY();
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").APPLY();
	DPIN_Levelset("MODE_mdm","3.6V", "0.0V", "1.8V", "1.8V",CLOSE_,ON_);
	rdk::Timer::WAIT(15e-3); 

	I2C_Write(0x6A,0x5A); 
	rdk::Timer::WAIT(1e-3); // enter test mode 
	I2C_Write(0x6A,0xA5); 
	rdk::Timer::WAIT(3e-3); // enter test mode   

	MMXH_PMU_Slewrate("EN_mmxh_pmu"  ,"Slow");  //for spike	
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").APPLY();
	rdk::Timer::WAIT(3e-3);
	rdk::MMXH::PMU("EN_mmxh_pmu").isvm("0.0mA",rdkenum::R3mA,rdkenum::R7V,"7.0V","-7V").APPLY(); 
	rdk::Timer::WAIT(3e-3);
	rdk::MMXH::PMU("EN_mmxh_pmu").disconnect().power(OFF).APPLY(); // EN float-3
	rdk::Timer::WAIT(3e-3);
	MMXH_PMU_Slewrate("EN_mmxh_pmu"  ,"VeryFast");  //for spike	

	rdk::CW("K16").off().APPLY(); // EN_MMXH
	rdk::Timer::WAIT(3e-3);

	I2C_Write(0x44,0x40); 
	rdk::Timer::WAIT(1e-3); //  set 2MHz Fsw Option
	I2C_Write(0x24,0x04); 
	rdk::Timer::WAIT(1e-3); //  disable BUCK block(DIS_EN=1)
	I2C_Write(0x23,0xEB); 
	rdk::Timer::WAIT(5e-3); //  I2C_Write(0x24,0x04); rdk::Timer::WAIT(3e-3); //  disable BUCK block(DIS_EN=1)
	
// Post measure
	rdk::Digital::Pin("BUF_mmxh_dcl").vohl("2.0V","1.0V").connect().power(ON).APPLY(); // ACCO PGM VOHL 2,1
	rdk::Timer::WAIT(1e-3); 

	rdk::MMXH::TMU("BUF_mmxh_tmu").event(rdkenum::COMPVOL_HYS_RISE).count(30).trigger(rdkenum::START,rdkenum::SOFT,"NONE",rdkenum::RISING).APPLY();

	RscTMUPin tmu_a("BUF_mmxh_tmu"); tmu_a.setCondition("TimeOut","10.0mS"); // setting time-out
	
	rdk::MMXH::TMU("BUF_mmxh_tmu").START().WAIT_ACQ("3mS");
	rdk::MMXH::TMU("BUF_mmxh_tmu").STOP();
	rdk::MMXH::TMU("BUF_mmxh_tmu").GET_RESULT_FREQ(FOSC_post,rdkenum::COMPVOL_RISE);

	I2C_Write(0x21,0x00); 
	rdk::Timer::WAIT(1e-3);

// clean up
	MMXH_PMU_Slewrate("VIN_mmxh_pmu" ,"Slow");  //for spike
	MMXH_PMU_Slewrate("VOUT_mmxh_pmu","Slow");  //for spike

	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").APPLY();
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").APPLY();
	rdk::Timer::WAIT(3e-3);
	DPIN_Levelset("MODE_mdm",OPEN_,OFF_);	
	rdk::Digital::Pin("BUF_mmxh_dcl").disconnect().power(OFF).APPLY();
	rdk::MMXH::PMU("VOUT_mmxh_pmu").disconnect().power(OFF).APPLY();
	rdk::MMXH::PMU("EN_mmxh_pmu").disconnect().power(OFF).APPLY();
	rdk::MMXH::PMU("VIN_mmxh_pmu").disconnect().power(OFF).APPLY();
	rdk::CW("K_ALL").off().APPLY();
	rdk::Timer::WAIT(3e-3);

	MMXH_PMU_Slewrate("VIN_mmxh_pmu" ,"VeryFast");  //for spike
	MMXH_PMU_Slewrate("VOUT_mmxh_pmu","VeryFast");  //for spike

// FOSC post-meas
	for(ItrDUTs itrDut(DUT_ACTIVE); !itrDut.isDone(); itrDut++) 
	{
    	FOSC_post_err[*itrDut] = (FOSC_target - FOSC_post[*itrDut].getAsDouble()) / (FOSC_post[*itrDut].getAsDouble()+1e-9) ; 
    }

	result |= Judge(test_id,"FOSC_post",    "T_FOSC_TRIM_LS.FOSC_post",        FOSC_post,"SoftBins.BIN17"); if(RscDUTs(DUT_ACTIVE).isEmpty()) return result; test_id++;
	result |= Judge(test_id,"FOSC_post_err","T_FOSC_TRIM_LS.FOSC_post_err",FOSC_post_err,"SoftBins.BIN17"); if(RscDUTs(DUT_ACTIVE).isEmpty()) return result; test_id++;
	
	return result;
} // T_FOSC_POST


RsltAllDUTCtnr
TPG::T_HSCL_TRIM()
{
	RsltAllDUTCtnr result;
	test_id = 800;	

	ValDUT HSCL_pre = 0;
	ValDUT HSCL_sim;
	ValDUT HSCL_pre_err;
	ValDUT HSCL_sim_err;
	//ValDUT HSCL_code;

	//ktb8316_discharge(); // Discharge For preventing from affection of previous item

	// Setup
	rdk::CW("K2;K13;K14;K16").on().APPLY(); // MODE_MDM, VIN_CAP, LX_MFHP, EN_MMXH
	rdk::Timer::WAIT(3e-3);

	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").connect().power(ON).APPLY(); 
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").connect().power(ON).APPLY();	
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").connect().power(ON).APPLY();	
	//rdk::MFHP::PMU("LX_mfhp_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R3A,"1.0A","-1.0A").connect(rdkenum::PORTA,rdkenum::PORTA).power(ON).APPLY();
	rdk::Timer::WAIT(3e-3);

	//IC Turn on
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("1.8V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY(); //For spike
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("1.8V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();	//For spike
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("1.8V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();	//For spike

	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();
	rdk::Timer::WAIT(5e-3);

	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").APPLY();
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").APPLY();
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").APPLY();
	DPIN_Levelset("MODE_mdm","3.6V", "0.0V", "1.8V", "1.8V",CLOSE_,ON_);
	rdk::Timer::WAIT(15e-3); 
 
	I2C_Write(0x6A,0x5A); 
	rdk::Timer::WAIT(1e-3); // enter test mode 
	I2C_Write(0x6A,0xA5); 
	rdk::Timer::WAIT(3e-3); // enter test mode   

	MMXH_PMU_Slewrate("EN_mmxh_pmu"  ,"Slow");  //for spike	
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").APPLY();
	rdk::Timer::WAIT(3e-3);
	rdk::MMXH::PMU("EN_mmxh_pmu").isvm("0.0mA",rdkenum::R3mA,rdkenum::R2V,"2.0V","-2.0V").APPLY();
	rdk::Timer::WAIT(3e-3);
	MMXH_PMU_Slewrate("EN_mmxh_pmu"  ,"VeryFast");  //for spike	
	
	I2C_Write(0x25,0x32); 
	rdk::Timer::WAIT(1e-3); // (T_HS_ON=1, T_PLIMOFF=1, T_ILIM=1);
	I2C_Write(0x26,0xE0); 
	rdk::Timer::WAIT(1e-3); // (1/4 of driver) 3000/4 => 750mA
	I2C_Write(0x23,0x4C); 
	rdk::Timer::WAIT(1e-3); // PLIM_CMP(MUXSEL=2'b01,AD_MUXO_EN=1, ENMUX=3'b100)

// Pre Measure Search
    rdk::MFHP::PMU("LX_mfhp_pmu").isvm("-0.0A",rdkenum::R3A,rdkenum::R7V,"7.0V","-7.0V").connect(rdkenum::PORTA,rdkenum::PORTA).power(ON).APPLY();
	rdk::Timer::WAIT(1e-3);
	rdk::MFHP::PMU("LX_mfhp_pmu").isvm("-0.2A",rdkenum::R3A,rdkenum::R7V,"7.0V","-7.0V").APPLY();
	rdk::Timer::WAIT(1e-3);
	rdk::MFHP::PMU("LX_mfhp_pmu").isvm("-0.45A",rdkenum::R3A,rdkenum::R7V,"7.0V","-7.0V").APPLY();
	rdk::Timer::WAIT(5e-3);


#if 1 //FOR Syntax intead of PMU Search
	ValDUT meas_EN_HSCL_pre = 0;
	ValDUT dut_enter1 = 0;

////////////////////////////////////////////////////////////////////////////////////////////////////////////
act_site = GET_active_site(); // get active site //
	for(double LX_level=-0.59;LX_level>=-1.20;LX_level=LX_level-0.01) //Adjusted Search Range 1.47->1.2 A for Pin Current Spec
	{
		rdk::MFHP::PMU("LX_mfhp_pmu").isvm(LX_level,rdkenum::R3A,rdkenum::R7V,"7.0V","-7.0V").APPLY();
        timer.wait(0.2e-3);

		meas_EN_HSCL_pre = rdk::MMXH::PMU("EN_mmxh_pmu").MEAS_V(200);

	    for(ItrDUTs itrDut(DUT_ACTIVE); !itrDut.isDone(); itrDut++)
		{
			dut_int = itrDut.getDUTID(); dut_int_VD.set(dut_int); dut_string = dut_int_VD.getAsString();
		    RscDUTs  dut_R(dut_string);

			//if(dut_enter1[*itrDut].getAsInt()==0)
			//{
			//    dlgout<<"DUT"<<*itrDut<<" LX_voltage : "<<LX_level *1000 <<" EN_voltage : "<<meas_EN_HSCL_pre[0][*itrDut]<<"\n";
			//}

			if(dut_enter1[*itrDut].getAsInt()==0 && (meas_EN_HSCL_pre[*itrDut].getAsDouble() > 1.0))
			{
				HSCL_pre[*itrDut]=LX_level;
				dut_enter1[*itrDut]=1;
				rdk::DUT::MASK(dut_R,rdkenum::ON_HOLD_RESUME,true); // mask //
			}
		}
		RscDUTs rscdut1(DUT_ACTIVE);
		NUMSITE = rscdut1.getSize();
		if(NUMSITE==0)	{ goto HSCL_PRE_EXITFOR_1; }
	} // for

 HSCL_PRE_EXITFOR_1:
	rdk::DUT::UNMASK(act_site,true); // restore active site	

#endif

	rdk::MFHP::PMU("LX_mfhp_pmu").isvm("0.0A",rdkenum::R3A,rdkenum::R7V,"7.0V","-7.0V").APPLY();
	rdk::Timer::WAIT(1e-3);

	I2C_Write(0x21,0x00); 
	rdk::Timer::WAIT(1e-3); 

// clean up
	MMXH_PMU_Slewrate("VIN_mmxh_pmu" ,"Slow");  //for spike
	MMXH_PMU_Slewrate("VOUT_mmxh_pmu","Slow");  //for spike

	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").APPLY();
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").APPLY(); 
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").APPLY();
    rdk::Timer::WAIT(3e-3);
	DPIN_Levelset("MODE_mdm",OPEN_,OFF_);	
	rdk::MMXH::PMU("EN_mmxh_pmu").disconnect().power(OFF).APPLY();	
	rdk::MFHP::PMU("LX_mfhp_pmu").disconnect().power(OFF).APPLY();	
	rdk::MMXH::PMU("VIN_mmxh_pmu").disconnect().power(OFF).APPLY();	
	rdk::CW("K_ALL").off().APPLY();
	rdk::Timer::WAIT(3e-3);

	MMXH_PMU_Slewrate("VIN_mmxh_pmu" ,"VeryFast");  //for spike
	MMXH_PMU_Slewrate("VOUT_mmxh_pmu","VeryFast");  //for spike

	for(ItrDUTs itrDut(DUT_ACTIVE); !itrDut.isDone(); itrDut++) 
    {
		HSCL_pre[*itrDut] = HSCL_pre[*itrDut].getAsDouble()  * -1;
        HSCL_pre_err[*itrDut] = (HSCL_target - HSCL_pre[*itrDut].getAsDouble()) / (HSCL_pre[*itrDut].getAsDouble()+1e-9) ;
    }

	result |= Judge(test_id,"HSCL_pre",     "T_HSCL_TRIM_LS.HSCL_pre",         HSCL_pre,"SoftBins.BIN18"); if(RscDUTs(DUT_ACTIVE).isEmpty())return result;  test_id++;
	result |= Judge(test_id,"HSCL_pre_err", "T_HSCL_TRIM_LS.HSCL_pre_err", HSCL_pre_err,"SoftBins.BIN18"); if(RscDUTs(DUT_ACTIVE).isEmpty())return result;  test_id++;




// trim table--------------------------------------------------------------------------------------------------
	for(ItrDUTs itrDut(DUT_ACTIVE);!itrDut.isDone();itrDut++) 
	{
		double temp_data_err = HSCL_pre_err[*itrDut].getAsDouble() * 100;

		if ( temp_data_err >= -70 && temp_data_err<70 )
		{
			if (temp_data_err >=  -5.34 && temp_data_err<  -1.46)	{ hscl_code[*itrDut] = 240; }//
			if (temp_data_err >=  -9.22 && temp_data_err<  -5.34)	{ hscl_code[*itrDut] = 224; }//
			if (temp_data_err >= -13.11 && temp_data_err<  -9.22)	{ hscl_code[*itrDut] = 208; }//
			if (temp_data_err >= -16.99 && temp_data_err< -13.11)	{ hscl_code[*itrDut] = 192; }//
			if (temp_data_err >= -20.87 && temp_data_err< -16.99)	{ hscl_code[*itrDut] = 176; }//
			if (temp_data_err >= -25.24 && temp_data_err< -20.87)	{ hscl_code[*itrDut] = 160; }//
			if (temp_data_err >= -29.13 && temp_data_err< -25.24)	{ hscl_code[*itrDut] = 144; }//
			if (temp_data_err >= -70.0  && temp_data_err< -29.13)	{ hscl_code[*itrDut] = 128; }//
																		
			if (temp_data_err >= 25.24 && temp_data_err< 70.0 )		{ hscl_code[*itrDut] = 112; }//
			if (temp_data_err >= 21.36 && temp_data_err< 25.24)		{ hscl_code[*itrDut] =  96; }//
			if (temp_data_err >= 17.48 && temp_data_err< 21.36)		{ hscl_code[*itrDut] =  80; }//
			if (temp_data_err >= 13.59 && temp_data_err< 17.48)		{ hscl_code[*itrDut] =  64; }//
			if (temp_data_err >=  9.71 && temp_data_err< 13.59)		{ hscl_code[*itrDut] =  48; }//
			if (temp_data_err >=  5.83 && temp_data_err<  9.71)		{ hscl_code[*itrDut] =  32; }//
			if (temp_data_err >=  1.94 && temp_data_err<  5.83)		{ hscl_code[*itrDut] =  16; }//
			if (temp_data_err >= -1.46 && temp_data_err<  1.94)		{ hscl_code[*itrDut] =   0; }//
		}
		else
			hscl_code[*itrDut] = 0; //

       if (EN_OTP42_47[*itrDut]==0) { hscl_code[*itrDut] = RD_OTP42_47[*itrDut].getAsInt(); } 

	} // for ItrDUTs

	result |= Judge(test_id,"HSCL_code",hscl_code, -0.5, 255.5,"SoftBins.BIN18","SoftBins.BIN18","Dec"); if(RscDUTs(DUT_ACTIVE).isEmpty())return result; test_id++;



//Sim Setup -----------------------------------------------------------------------------------------------
	rdk::CW("K2;K13;K14;K16").on().APPLY(); // MODE_MDM, EN_MMXH, VIN_CAP 
	rdk::Timer::WAIT(3e-3);

	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").connect().power(ON).APPLY(); 
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").connect().power(ON).APPLY();	
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").connect().power(ON).APPLY();	
	//rdk::MFHP::PMU("LX_mfhp_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R3A,"1.0A","-1.0A").connect(rdkenum::PORTA,rdkenum::PORTA).power(ON).APPLY();
	rdk::Timer::WAIT(3e-3);

	//IC Turn on
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("1.8V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY(); //For spike
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("1.8V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();	//For spike
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("1.8V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();	//For spike

	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();
	rdk::Timer::WAIT(5e-3);

	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").APPLY();
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").APPLY();
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").APPLY();
	DPIN_Levelset("MODE_mdm","3.6V", "0.0V", "1.8V", "1.8V",CLOSE_,ON_);
	rdk::Timer::WAIT(15e-3); 
 
	I2C_Write(0x6A,0x5A); 
	rdk::Timer::WAIT(1e-3); // enter test mode 
	I2C_Write(0x6A,0xA5); 
	rdk::Timer::WAIT(3e-3); // enter test mode   


	MMXH_PMU_Slewrate("EN_mmxh_pmu"  ,"Slow");   //for spike
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").APPLY();
	rdk::Timer::WAIT(3e-3);
	rdk::MMXH::PMU("EN_mmxh_pmu").isvm("0.0mA",rdkenum::R3mA,rdkenum::R2V,"2.0V","-2.0V").APPLY(); //EN Float-2
	rdk::Timer::WAIT(3e-3);
	MMXH_PMU_Slewrate("EN_mmxh_pmu"  ,"VeryFast");   //for spike

	I2C_Write(0x25,0x32); 
	rdk::Timer::WAIT(1e-3); // (T_HS_ON=1, T_PLIMOFF=1, T_ILIM=1);
	I2C_Write(0x26,0xE0); 
	rdk::Timer::WAIT(1e-3); // (1/4 of driver) 3000/4 => 750mA
	I2C_Write(0x23,0x4C); 
	rdk::Timer::WAIT(1e-3); // PLIM_CMP(MUXSEL=2'b01,AD_MUXO_EN=1, ENMUX=3'b100)

	I2C_Write(0x42,hscl_code); 
	rdk::Timer::WAIT(3e-3); // OTP data write reg. 

// Sim Measure Search
    rdk::MFHP::PMU("LX_mfhp_pmu").isvm("-0.0A",rdkenum::R3A,rdkenum::R7V,"7.0V","-7.0V").connect(rdkenum::PORTA,rdkenum::PORTA).power(ON).APPLY();
	rdk::Timer::WAIT(1e-3);
	rdk::MFHP::PMU("LX_mfhp_pmu").isvm("-0.2A",rdkenum::R3A,rdkenum::R7V,"7.0V","-7.0V").APPLY();
	rdk::Timer::WAIT(1e-3);
	rdk::MFHP::PMU("LX_mfhp_pmu").isvm("-0.45A",rdkenum::R3A,rdkenum::R7V,"7.0V","-7.0V").APPLY();
	rdk::Timer::WAIT(5e-3);


#if 1 //FOR Syntax intead of PMU Search
	ValDUT meas_en_HSCL_sim = 0;
	ValDUT	dut_enter2 = 0;

////////////////////////////////////////////////////////////////////////////////////////////////////////////
act_site = GET_active_site(); // get active site //
	for(double LX_level=-0.59;LX_level>=-1.20;LX_level=LX_level-0.01)//Adjusted Search Range 1.47->1.2 A for Pin Current Spec
	{
		rdk::MFHP::PMU("LX_mfhp_pmu").isvm(LX_level,rdkenum::R3A,rdkenum::R7V,"7.0V","-7.0V").APPLY();
        timer.wait(0.2e-3);

		meas_en_HSCL_sim = rdk::MMXH::PMU("EN_mmxh_pmu").MEAS_V(200);

	    for(ItrDUTs itrDut(DUT_ACTIVE); !itrDut.isDone(); itrDut++)
		{
			dut_int = itrDut.getDUTID(); dut_int_VD.set(dut_int); dut_string = dut_int_VD.getAsString();
		    RscDUTs  dut_R(dut_string);

			//if(dut_enter2[*itrDut].getAsInt()==0)
			//{
			//    dlgout<<"DUT"<<*itrDut<<" LX_voltage : "<<LX_level *1000 <<" EN_voltage : "<<meas_EN[0][*itrDut]<<"\n";
			//}

			if(dut_enter2[*itrDut].getAsInt()==0 && (meas_en_HSCL_sim[*itrDut].getAsDouble() > 1.0))
			{
				HSCL_sim[*itrDut]=LX_level;
				dut_enter2[*itrDut]=1;
				rdk::DUT::MASK(dut_R,rdkenum::ON_HOLD_RESUME,true); // mask //
			}
		}
		RscDUTs rscdut1(DUT_ACTIVE);
		NUMSITE = rscdut1.getSize();
		if(NUMSITE==0)	{ goto HSCL_SIM_EXITFOR_1; }
	} // for

 HSCL_SIM_EXITFOR_1:
	rdk::DUT::UNMASK(act_site,true); // restore active site	

#endif

	rdk::MFHP::PMU("LX_mfhp_pmu").isvm("0.0A",rdkenum::R3A,rdkenum::R7V,"7.0V","-7.0V").APPLY();	
	rdk::Timer::WAIT(1e-3); 

	I2C_Write(0x21,0x00); 
	rdk::Timer::WAIT(1e-3); 

// clean up
	MMXH_PMU_Slewrate("VIN_mmxh_pmu" ,"Slow");  //for spike
	MMXH_PMU_Slewrate("VOUT_mmxh_pmu","Slow");  //for spike

	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").APPLY();
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").APPLY(); 
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").APPLY();
    rdk::Timer::WAIT(3e-3);	
 	DPIN_Levelset("MODE_mdm",OPEN_,OFF_);	
	rdk::MMXH::PMU("EN_mmxh_pmu").disconnect().power(OFF).APPLY();	
	rdk::MFHP::PMU("LX_mfhp_pmu").disconnect().power(OFF).APPLY();	
	rdk::MMXH::PMU("VIN_mmxh_pmu").disconnect().power(OFF).APPLY();	
	rdk::CW("K_ALL").off().APPLY();
	rdk::Timer::WAIT(3e-3);

	MMXH_PMU_Slewrate("VIN_mmxh_pmu" ,"VeryFast");  //for spike
	MMXH_PMU_Slewrate("VOUT_mmxh_pmu","VeryFast");  //for spike

    for(ItrDUTs itrDut(DUT_ACTIVE); !itrDut.isDone(); itrDut++)
    {
		HSCL_sim[*itrDut] = HSCL_sim[*itrDut].getAsDouble()  * -1;
        HSCL_sim_err[*itrDut] = ( HSCL_target - HSCL_sim[*itrDut].getAsDouble()) / (HSCL_sim[*itrDut].getAsDouble()+1e-9) ;
    }

	result |= Judge(test_id,"HSCL_sim",     "T_HSCL_TRIM_LS.HSCL_sim",         HSCL_sim,"SoftBins.BIN18"); if(RscDUTs(DUT_ACTIVE).isEmpty())return result;  test_id++;
	result |= Judge(test_id,"HSCL_sim_err", "T_HSCL_TRIM_LS.HSCL_sim_err", HSCL_sim_err,"SoftBins.BIN18"); if(RscDUTs(DUT_ACTIVE).isEmpty())return result;  test_id++;

	return result;

} // T_HS_HSCL_Trim


RsltAllDUTCtnr
TPG::T_HSCL_BURN()
{

	RsltAllDUTCtnr result;
if (en_trim == 1)
{
	rdk::CW("K2;K12;K13;K14;K16").on().APPLY(); // MODE MDM, EN MMXH, VIN_CAP, VOUT_CAP 
	rdk::Timer::WAIT(3e-3); 

	//IC Turn on
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("1.8V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").connect().power(ON).APPLY(); //For spike
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("1.8V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").connect().power(ON).APPLY();	//For spike
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("1.8V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").connect().power(ON).APPLY();	//For spike

	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").APPLY();
	DPIN_Levelset("MODE_mdm","3.6V", "0.0V", "1.8V", "1.8V",CLOSE_,ON_);
	rdk::Timer::WAIT(15e-3); 

	I2C_Write(0x6A,0x5A);		rdk::Timer::WAIT(1e-3); // enter test mode 
	I2C_Write(0x6A,0xA5);		rdk::Timer::WAIT(1e-3); // enter test mode  2. Enter Test Mode.
	I2C_Write(0x42,hscl_code);	rdk::Timer::WAIT(1e-3); //3. Write target OTP values into REG 0x40 to 0x48.
	I2C_Write(0x20,0x02);		rdk::Timer::WAIT(1e-3); // 4. Write REG 0x20 = 0x00 to select data in REG 0x40 to be burned.
	I2C_Write(0x21,0x09);		rdk::Timer::WAIT(1e-3); // 5. Write REG 0x21=0x09 (OTP_CLK_REQ=1, EXVPP_EN=1).

	for(ItrDUTs itrDut(DUT_ACTIVE); !itrDut.isDone(); itrDut++) 
	{
		VHEN1[*itrDut] = EN_OTP42_47[*itrDut] * 1.0 * 5;
		VHEN2[*itrDut] = EN_OTP42_47[*itrDut] * 1.1 * 5;
		VHEN3[*itrDut] = EN_OTP42_47[*itrDut] * 1.2 * 5;
		VHEN4[*itrDut] = EN_OTP42_47[*itrDut] * 1.3 * 5;
		VHEN5[*itrDut] = EN_OTP42_47[*itrDut] * 1.4 * 5;

		//For VIN : If burend chip, VIN off, VOUT off
		VIEN[*itrDut] = EN_OTP42_47[*itrDut] * 5.5; //5.5V
		VOEN[*itrDut] = EN_OTP42_47[*itrDut] * 3.6; //3.6V
	}										  
		
	//If burend chip, VIN & VOUT off slowly
	MMXH_PMU_Slewrate("VIN_mmxh_pmu","Slow");   //for spike
	MMXH_PMU_Slewrate("VOUT_mmxh_pmu","Slow");   //for spike
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim(VIEN,rdkenum::R7V,rdkenum::R240mA,"200.0mA","-200.0mA").APPLY(); // VIN 5.5 V is needed for Burn //Check 0V and 5.5V both with DGT
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim(VOEN,rdkenum::R7V,rdkenum::R240mA,"200.0mA","-200.0mA").APPLY();
	rdk::Timer::WAIT(3e-3);	
	MMXH_PMU_Slewrate("VOUT_mmxh_pmu","VeryFast");   //for spike
	MMXH_PMU_Slewrate("VIN_mmxh_pmu","VeryFast");   //for spike

	//Burn
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim(VHEN1,rdkenum::R7V,rdkenum::R240mA,"200.0mA","-200.0mA").APPLY();
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim(VHEN2,rdkenum::R7V,rdkenum::R240mA,"200.0mA","-200.0mA").APPLY();
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim(VHEN3,rdkenum::R7V,rdkenum::R240mA,"200.0mA","-200.0mA").APPLY();
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim(VHEN4,rdkenum::R7V,rdkenum::R240mA,"200.0mA","-200.0mA").APPLY();
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim(VHEN5,rdkenum::R7V,rdkenum::R240mA,"200.0mA","-200.0mA").APPLY();
	rdk::Timer::WAIT(1e-3); 

	I2C_Write(0x21,0x0B); //7. Write 0x21 = 0x0B to program the OTP(BURN_EN=1). 8. Wait 1ms.
	rdk::Timer::WAIT(1e-3); 
	I2C_Write(0x21,0x09); //9. Write 0x21 = 0x09 to stop OTP programming.
	rdk::Timer::WAIT(1e-3); 

	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim(VHEN5,rdkenum::R7V,rdkenum::R240mA,"200.0mA","-200.0mA").APPLY();
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim(VHEN4,rdkenum::R7V,rdkenum::R240mA,"200.0mA","-200.0mA").APPLY();
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim(VHEN3,rdkenum::R7V,rdkenum::R240mA,"200.0mA","-200.0mA").APPLY();
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim(VHEN2,rdkenum::R7V,rdkenum::R240mA,"200.0mA","-200.0mA").APPLY();
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim(VHEN1,rdkenum::R7V,rdkenum::R240mA,"200.0mA","-200.0mA").APPLY();
	rdk::Timer::WAIT(1e-3); 

	I2C_Write(0x6A,0x00); // exit test mode
	rdk::Timer::WAIT(1e-3); 



	// clean up
	MMXH_PMU_Slewrate("VIN_mmxh_pmu" ,"Slow");  //for spike
	MMXH_PMU_Slewrate("VOUT_mmxh_pmu","Slow");  //for spike
	MMXH_PMU_Slewrate("EN_mmxh_pmu"  ,"Slow");  //for spike	

	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R240mA,"200.0mA","-200.0mA").APPLY();
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();
	rdk::Timer::WAIT(3e-3);
	DPIN_Levelset("MODE_mdm",OPEN_,OFF_);
	rdk::MMXH::PMU("VOUT_mmxh_pmu").disconnect().power(OFF).APPLY();
	rdk::MMXH::PMU("VIN_mmxh_pmu").disconnect().power(OFF).APPLY();
	rdk::MMXH::PMU("EN_mmxh_pmu").disconnect().power(OFF).APPLY();
	rdk::CW("K_ALL").off().APPLY();
	rdk::Timer::WAIT(3e-3);	

	MMXH_PMU_Slewrate("VIN_mmxh_pmu" ,"VeryFast");  //for spike
	MMXH_PMU_Slewrate("VOUT_mmxh_pmu","VeryFast");  //for spike
	MMXH_PMU_Slewrate("EN_mmxh_pmu"  ,"VeryFast");  //for spike	
}
	result |= Judge(test_id,"HSCL_burn", "T_BURN.BURN", EN_OTP42_47,"SoftBins.BIN18"); if(RscDUTs(DUT_ACTIVE).isEmpty())return result; test_id++;

	return result;
} // T_HSCL_Burn


RsltAllDUTCtnr
TPG::T_HSCL_POST()
{
	RsltAllDUTCtnr result;

	ValDUT HSCL_post;
	ValDUT HSCL_post_err;

 //Post Setup

	//ktb8316_discharge(); // Discharge For preventing from affection of previous item

	// Setup
	rdk::CW("K2;K13;K14;K16").on().APPLY(); // MODE_MDM, VIN_CAP, LX_MFHP, EN_MMXH
	rdk::Timer::WAIT(3e-3);

	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").connect().power(ON).APPLY(); 
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").connect().power(ON).APPLY();	
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").connect().power(ON).APPLY();	
	//rdk::MFHP::PMU("LX_mfhp_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R3A,"1.0A","-1.0A").connect(rdkenum::PORTA,rdkenum::PORTA).power(ON).APPLY();
	rdk::Timer::WAIT(3e-3);

	//IC Turn on
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("1.8V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY(); //For spike
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("1.8V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();	//For spike
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("1.8V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();	//For spike

	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();
	rdk::Timer::WAIT(5e-3);

	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").APPLY();
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").APPLY();
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").APPLY();
	DPIN_Levelset("MODE_mdm","3.6V", "0.0V", "1.8V", "1.8V",CLOSE_,ON_);
	rdk::Timer::WAIT(15e-3); 
 
	I2C_Write(0x6A,0x5A); 
	rdk::Timer::WAIT(1e-3); // enter test mode 
	I2C_Write(0x6A,0xA5); 
	rdk::Timer::WAIT(3e-3); // enter test mode   

	MMXH_PMU_Slewrate("EN_mmxh_pmu"  ,"Slow");  //for spike	
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").APPLY();
	rdk::Timer::WAIT(3e-3);
	rdk::MMXH::PMU("EN_mmxh_pmu").isvm("0.0mA",rdkenum::R3mA,rdkenum::R2V,"2.0V","-2.0V").APPLY(); //EN Float-2
	rdk::Timer::WAIT(3e-3);
	MMXH_PMU_Slewrate("EN_mmxh_pmu"  ,"VeryFast");  //for spike	


	I2C_Write(0x25,0x32); 
	rdk::Timer::WAIT(1e-3); // (T_HS_ON=1, T_PLIMOFF=1, T_ILIM=1);
	I2C_Write(0x26,0xE0); 
	rdk::Timer::WAIT(1e-3); // (1/4 of driver) 3000/4 => 750mA
	I2C_Write(0x23,0x4C); 
	rdk::Timer::WAIT(1e-3); // PLIM_CMP(MUXSEL=2'b01,AD_MUXO_EN=1, ENMUX=3'b100)

// Post Measure Search
    rdk::MFHP::PMU("LX_mfhp_pmu").isvm("-0.0A",rdkenum::R3A,rdkenum::R7V,"7.0V","-7.0V").connect(rdkenum::PORTA,rdkenum::PORTA).power(ON).APPLY();
	rdk::Timer::WAIT(1e-3);
	rdk::MFHP::PMU("LX_mfhp_pmu").isvm("-0.2A",rdkenum::R3A,rdkenum::R7V,"7.0V","-7.0V").APPLY();
	rdk::Timer::WAIT(1e-3);
	rdk::MFHP::PMU("LX_mfhp_pmu").isvm("-0.45A",rdkenum::R3A,rdkenum::R7V,"7.0V","-7.0V").APPLY();
	rdk::Timer::WAIT(5e-3);

#if 1 //FOR Syntax intead of PMU Search
	ValDUT meas_en_HSCL_post = 0;
	ValDUT dut_enter3 = 0;

////////////////////////////////////////////////////////////////////////////////////////////////////////////
act_site = GET_active_site(); // get active site //
	for(double LX_level=-0.59;LX_level>=-1.20;LX_level=LX_level-0.01) //Adjusted Search Range 1.47->1.2 A for Pin Current Spec
	{
		rdk::MFHP::PMU("LX_mfhp_pmu").isvm(LX_level,rdkenum::R3A,rdkenum::R7V,"7.0V","-7.0V").APPLY();
        timer.wait(0.2e-3);

		meas_en_HSCL_post = rdk::MMXH::PMU("EN_mmxh_pmu").MEAS_V(200);

	    for(ItrDUTs itrDut(DUT_ACTIVE); !itrDut.isDone(); itrDut++)
		{
			dut_int = itrDut.getDUTID(); dut_int_VD.set(dut_int); dut_string = dut_int_VD.getAsString();
		    RscDUTs  dut_R(dut_string);

			//if(dut_enter3[*itrDut].getAsInt()==0)
			//{
			//    dlgout<<"DUT"<<*itrDut<<" LX_voltage : "<<LX_level *1000 <<" EN_voltage : "<<meas_en_HSCL_post[0][*itrDut]<<"\n";
			//}

			if(dut_enter3[*itrDut].getAsInt()==0 && (meas_en_HSCL_post[*itrDut].getAsDouble() > 1.0))
			{
				HSCL_post[*itrDut]=LX_level;
				dut_enter3[*itrDut]=1;
				rdk::DUT::MASK(dut_R,rdkenum::ON_HOLD_RESUME,true); // mask //
			}
		}
		RscDUTs rscdut1(DUT_ACTIVE);
		NUMSITE = rscdut1.getSize();
		if(NUMSITE==0)	{ goto HSCL_POST_EXITFOR_1; }
	} // for

 HSCL_POST_EXITFOR_1:
	rdk::DUT::UNMASK(act_site,true); // restore active site	

#endif

	rdk::MFHP::PMU("LX_mfhp_pmu").isvm("0.0A",rdkenum::R3A,rdkenum::R7V,"7.0V","-7.0V").APPLY();

	I2C_Write(0x21,0x00); 
	rdk::Timer::WAIT(1e-3); 

// clean up
	MMXH_PMU_Slewrate("VIN_mmxh_pmu" ,"Slow");  //for spike
	MMXH_PMU_Slewrate("VOUT_mmxh_pmu","Slow");  //for spike

	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").APPLY(); 
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").APPLY(); 
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").APPLY();
    rdk::Timer::WAIT(3e-3);	
	DPIN_Levelset("MODE_mdm",OPEN_,OFF_);
	rdk::MMXH::PMU("EN_mmxh_pmu").disconnect().power(OFF).APPLY();	
	rdk::MMXH::PMU("VOUT_mmxh_pmu").disconnect().power(OFF).APPLY();	
	rdk::MFHP::PMU("LX_mfhp_pmu").disconnect().power(OFF).APPLY();	
	rdk::MMXH::PMU("VIN_mmxh_pmu").disconnect().power(OFF).APPLY();	
	rdk::CW("K_ALL").off().APPLY();
	rdk::Timer::WAIT(3e-3);
	
	MMXH_PMU_Slewrate("VIN_mmxh_pmu" ,"VeryFast");  //for spike
	MMXH_PMU_Slewrate("VOUT_mmxh_pmu","VeryFast");  //for spike

	for(ItrDUTs itrDut(DUT_ACTIVE); !itrDut.isDone(); itrDut++)
    {
		HSCL_post[*itrDut]     = HSCL_post[*itrDut].getAsDouble() * -1;;
		HSCL_post_err[*itrDut] = (HSCL_target - HSCL_post[*itrDut].getAsDouble()) / (HSCL_post[*itrDut].getAsDouble()+1e-9);
    }

    result |= Judge(test_id,"HSCL_post",    "T_HSCL_TRIM_LS.HSCL_post",        HSCL_post,"SoftBins.BIN18"); if(RscDUTs(DUT_ACTIVE).isEmpty()) return result; test_id++;
	result |= Judge(test_id,"HSCL_post_err","T_HSCL_TRIM_LS.HSCL_post_err",HSCL_post_err,"SoftBins.BIN18"); if(RscDUTs(DUT_ACTIVE).isEmpty()) return result; test_id++;


	return result;
} // T_HSCL_POST


RsltAllDUTCtnr
TPG::T_VCL_TRIM()
{
	RsltAllDUTCtnr result;
	test_id = 900;	

	ValDUT VCL_pre=0;
	ValDUT VCL_sim;
	ValDUT VCL_pre_err;
	ValDUT VCL_sim_err;
	//ValDUT VCL_code;

	//ktb8316_discharge(); // Discharge For preventing from affection of previous item

	rdk::CW("K2;K13;K15;K16").on().APPLY(); // MODE_MDM, VIN_CAP, GND_MMXH(LX_MFHP_LOW SIDE), EN_MMXH
	rdk::Timer::WAIT(3e-3);

	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").connect().power(ON).APPLY(); 
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").connect().power(ON).APPLY();	
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").connect().power(ON).APPLY();	
	rdk::Timer::WAIT(3e-3);

	//IC Turn on
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("1.8V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY(); //For spike
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("1.8V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();	//For spike
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("1.8V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();	//For spike

	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();
	rdk::Timer::WAIT(5e-3);

	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").APPLY();
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").APPLY();
	rdk::Timer::WAIT(5e-3); 
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").APPLY();
	DPIN_Levelset("MODE_mdm","3.6V", "0.0V", "1.8V", "1.8V",CLOSE_,ON_);
	rdk::Timer::WAIT(15e-3); 
 
	I2C_Write(0x6A,0x5A); 
	rdk::Timer::WAIT(1e-3); // enter test mode 
	I2C_Write(0x6A,0xA5); 
	rdk::Timer::WAIT(3e-3); // enter test mode   

	MMXH_PMU_Slewrate("EN_mmxh_pmu"  ,"Slow");  //for spike	
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R3mA,"3mA","-3mA").APPLY(); //EN Float-1
	rdk::Timer::WAIT(3e-3);
	rdk::MMXH::PMU("EN_mmxh_pmu").isvm("0.0mA",rdkenum::R3mA,rdkenum::R7V,"7.0V","-7V").APPLY(); //EN Float-2
	rdk::Timer::WAIT(3e-3);
	MMXH_PMU_Slewrate("EN_mmxh_pmu"  ,"VeryFast");  //for spike	
	
	I2C_Write(0x25,0x52); 
	rdk::Timer::WAIT(1e-3); // (T_LS_ON=1, T_PLIMOFF=1, T_ILIM=1);
	I2C_Write(0x26,0xE0); 
	rdk::Timer::WAIT(1e-3); // (1/4 of driver) => (2400/4)= 600mA. 
	I2C_Write(0x23,0xCC); 
	rdk::Timer::WAIT(5e-3); // to mux out NVLY_CMP;

	rdk::MFHP::PMU("LX_mfhp_pmu").isvm("0.0A",rdkenum::R3A,rdkenum::R7V,"7.0V","-7.0V").connect(rdkenum::PORTA,rdkenum::PORTA).power(ON).APPLY();
	rdk::Timer::WAIT(1e-3);

// Pre Measure Search
	rdk::MFHP::PMU("LX_mfhp_pmu").isvm("-0.35A",rdkenum::R3A,rdkenum::R7V,"7.0V","-7.0V").APPLY();
	rdk::Timer::WAIT(1e-3);


#if 1 //FOR Syntax intead of PMU Search
	ValDUT	meas_en_VCL_pre = 0;
	ValDUT	dut_enter4 = 0;

////////////////////////////////////////////////////////////////////////////////////////////////////////////
act_site = GET_active_site(); // get active site //
	for(double LX_level=-0.39;LX_level>=-1.20;LX_level=LX_level-0.01)//Adjusted Search Range 1.27->1.2 A for Pin Current Spec
	{
		rdk::MFHP::PMU("LX_mfhp_pmu").isvm(LX_level,rdkenum::R3A,rdkenum::R7V,"7.0V","-7.0V").APPLY();
        timer.wait(0.2e-3);

		meas_en_VCL_pre = rdk::MMXH::PMU("EN_mmxh_pmu").MEAS_V(200);

	    for(ItrDUTs itrDut(DUT_ACTIVE); !itrDut.isDone(); itrDut++)
		{
			dut_int = itrDut.getDUTID(); dut_int_VD.set(dut_int); dut_string = dut_int_VD.getAsString();
		    RscDUTs  dut_R(dut_string);

			//if(dut_enter4[*itrDut].getAsInt()==0)
			//{
			//    dlgout<<"DUT"<<*itrDut<<" LX_voltage : "<<LX_level *1000 <<" EN_voltage : "<<meas_en_VCL_pre[0][*itrDut]<<"\n";
			//}

			if(dut_enter4[*itrDut].getAsInt()==0 && (meas_en_VCL_pre[*itrDut].getAsDouble() > 1.0))
			{
				VCL_pre[*itrDut]=LX_level;
				dut_enter4[*itrDut]=1;
				rdk::DUT::MASK(dut_R,rdkenum::ON_HOLD_RESUME,true); // mask //
			}
		}
		RscDUTs rscdut1(DUT_ACTIVE);
		NUMSITE = rscdut1.getSize();
		if(NUMSITE==0)	{ goto VCL_PRE_EXITFOR_1; }
	} // for

 VCL_PRE_EXITFOR_1:
	rdk::DUT::UNMASK(act_site,true); // restore active site	

#endif
	
	rdk::MFHP::PMU("LX_mfhp_pmu").isvm("0.0A",rdkenum::R3A,rdkenum::R7V,"7.0V","-7.0V").APPLY();
    rdk::Timer::WAIT(3e-3);

	I2C_Write(0x21,0x00); 
	rdk::Timer::WAIT(1e-3); // 

// clean up
	MMXH_PMU_Slewrate("VIN_mmxh_pmu" ,"Slow");  //for spike
	MMXH_PMU_Slewrate("VOUT_mmxh_pmu","Slow");  //for spike

	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R3mA,"3mA","-3mA").APPLY(); 
	rdk::MFHP::PMU("LX_mfhp_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R3mA,"3mA","-3mA").APPLY();
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R3mA,"3mA","-3mA").APPLY();
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R3mA,"3mA","-3mA").APPLY();
    rdk::Timer::WAIT(3e-3);
	DPIN_Levelset("MODE_mdm",OPEN_,OFF_);
	rdk::MMXH::PMU("EN_mmxh_pmu").disconnect().power(OFF).APPLY();	
	rdk::MFHP::PMU("LX_mfhp_pmu").disconnect().power(OFF).APPLY();	
	rdk::MMXH::PMU("VIN_mmxh_pmu").disconnect().power(OFF).APPLY();	
	rdk::MMXH::PMU("VOUT_mmxh_pmu").disconnect().power(OFF).APPLY();	
	rdk::CW("K_ALL").off().APPLY();
	rdk::Timer::WAIT(3e-3);
	
	MMXH_PMU_Slewrate("VIN_mmxh_pmu" ,"VeryFast");  //for spike
	MMXH_PMU_Slewrate("VOUT_mmxh_pmu","VeryFast");  //for spike

    for(ItrDUTs itrDut(DUT_ACTIVE); !itrDut.isDone(); itrDut++) 
    {
		VCL_pre[*itrDut] = VCL_pre[*itrDut].getAsDouble() * -1;
		VCL_pre_err[*itrDut] = (-VCL_pre[*itrDut].getAsDouble() + VCL_target) / (VCL_pre[*itrDut].getAsDouble()+1e-9) ;
    }

	result |= Judge(test_id,"VCL_pre",     "T_VCL_TRIM_LS.VCL_pre",         VCL_pre,"SoftBins.BIN19"); if(RscDUTs(DUT_ACTIVE).isEmpty())return result;  test_id++;
	result |= Judge(test_id,"VCL_pre_err", "T_VCL_TRIM_LS.VCL_pre_err", VCL_pre_err,"SoftBins.BIN19"); if(RscDUTs(DUT_ACTIVE).isEmpty())return result;  test_id++;



// trim table ------------------------------------------------------------------------------------------------
    for(ItrDUTs itrDut(DUT_ACTIVE);!itrDut.isDone();itrDut++) 
	{
        double temp_data_err = VCL_pre_err[*itrDut].getAsDouble() * 100;
		
		if (temp_data_err >= -50.0 && temp_data_err <50.0)
		{
			if (temp_data_err >=  -9.74 && temp_data_err<  -3.25)   { vcl_code[*itrDut] = 7; }//
			if (temp_data_err >= -16.23 && temp_data_err<  -9.74)	{ vcl_code[*itrDut] = 6; }//
			if (temp_data_err >= -22.73 && temp_data_err< -16.23)	{ vcl_code[*itrDut] = 5; }//
			if (temp_data_err >= -50.0  && temp_data_err< -22.73)	{ vcl_code[*itrDut] = 4; }//
			if (temp_data_err >=  16.23 && temp_data_err<  50.0 )   { vcl_code[*itrDut] = 3; }//
			if (temp_data_err >=   9.74 && temp_data_err<  16.23)   { vcl_code[*itrDut] = 2; }//
			if (temp_data_err >=   3.25 && temp_data_err<   9.74)	{ vcl_code[*itrDut] = 1; }//
			if (temp_data_err >=  -3.25 && temp_data_err<   3.25)   { vcl_code[*itrDut] = 0; }//
		}
		else
			vcl_code[*itrDut] = 0; //

       if (EN_OTP42_02[*itrDut]==0) { vcl_code[*itrDut] = RD_OTP42_02[*itrDut].getAsInt(); } 

	} // for ItrDUTs

	result |= Judge(test_id,"VCL_code",vcl_code, -0.5, 255.5,"SoftBins.BIN19","SoftBins.BIN19","Dec"); if(RscDUTs(DUT_ACTIVE).isEmpty())return result; test_id++;



//Sim Setup ----------------------------------------------------------------------------------------------
	rdk::CW("K2;K13;K15;K16").on().APPLY(); // MODE_MDM, VIN_CAP, GND_MMXH(LX_MFHP_LOW SIDE), EN_MMXH
	rdk::Timer::WAIT(3e-3);

	//IC Turn on
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("1.8V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").connect().power(ON).APPLY(); //For spike
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("1.8V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").connect().power(ON).APPLY();	//For spike
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("1.8V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").connect().power(ON).APPLY();	//For spike

	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();
	rdk::Timer::WAIT(5e-3);

	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").APPLY();
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").APPLY();
	rdk::Timer::WAIT(5e-3); 
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").APPLY();
	DPIN_Levelset("MODE_mdm","3.6V", "0.0V", "1.8V", "1.8V",CLOSE_,ON_);
	rdk::Timer::WAIT(15e-3); 
 
	I2C_Write(0x6A,0x5A); 
	rdk::Timer::WAIT(1e-3); // enter test mode 
	I2C_Write(0x6A,0xA5); 
	rdk::Timer::WAIT(3e-3); // enter test mode   

	MMXH_PMU_Slewrate("EN_mmxh_pmu"  ,"Slow");   //for spike	
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R3mA,"3mA","-3mA").APPLY(); //EN Float-1
	rdk::Timer::WAIT(3e-3);
	rdk::MMXH::PMU("EN_mmxh_pmu").isvm("0.0mA",rdkenum::R3mA,rdkenum::R7V,"7.0V","-7V").APPLY(); //EN Float-2
	rdk::Timer::WAIT(3e-3);
	MMXH_PMU_Slewrate("EN_mmxh_pmu"  ,"VeryFast");   //for spike	

	I2C_Write(0x25,0x52); 
	//I2C_Write(0x25,0x32); 
	rdk::Timer::WAIT(1e-3); // (T_LS_ON=1, T_PLIMOFF=1, T_ILIM=1);
	I2C_Write(0x26,0xE0); 
	rdk::Timer::WAIT(1e-3); // (1/4 of driver) => (2400/4)= 600mA. 
	I2C_Write(0x23,0xCC); 
	rdk::Timer::WAIT(5e-3); // to mux out NVLY_CMP;

	I2C_Write(0x42,vcl_code); 
	rdk::Timer::WAIT(5e-3);

	rdk::MFHP::PMU("LX_mfhp_pmu").isvm("0.0A",rdkenum::R3A,rdkenum::R7V,"7.0V","-7.0V").connect(rdkenum::PORTA,rdkenum::PORTA).power(ON).APPLY();
	rdk::Timer::WAIT(1e-3);

// Sim Measure Search
    rdk::MFHP::PMU("LX_mfhp_pmu").isvm("-0.35A",rdkenum::R3A,rdkenum::R7V,"7.0V","-7.0V").APPLY();
    rdk::Timer::WAIT(1e-3);


#if 1 //FOR Syntax intead of PMU Search
	ValDUT	meas_en_VCL_sim = 0;
	ValDUT	dut_enter5 = 0;

////////////////////////////////////////////////////////////////////////////////////////////////////////////
act_site = GET_active_site(); // get active site //
	for(double LX_level=-0.39;LX_level>=-1.20;LX_level=LX_level-0.01)//Adjusted Search Range 1.27->1.2 A for Pin Current Spec
	{
		rdk::MFHP::PMU("LX_mfhp_pmu").isvm(LX_level,rdkenum::R3A,rdkenum::R7V,"7.0V","-7.0V").APPLY();
        timer.wait(0.2e-3);

		meas_en_VCL_sim = rdk::MMXH::PMU("EN_mmxh_pmu").MEAS_V(200);

	    for(ItrDUTs itrDut(DUT_ACTIVE); !itrDut.isDone(); itrDut++)
		{
			dut_int = itrDut.getDUTID(); dut_int_VD.set(dut_int); dut_string = dut_int_VD.getAsString();
		    RscDUTs  dut_R(dut_string);

			//if(dut_enter5[*itrDut].getAsInt()==0)
			//{
			//    dlgout<<"DUT"<<*itrDut<<" LX_voltage : "<<LX_level *1000 <<" EN_voltage : "<<meas_en_VCL_sim[0][*itrDut]<<"\n";
			//}

			if(dut_enter5[*itrDut].getAsInt()==0 && (meas_en_VCL_sim[*itrDut].getAsDouble() > 1.0))
			{
				VCL_sim[*itrDut]=LX_level;
				dut_enter5[*itrDut]=1;
				rdk::DUT::MASK(dut_R,rdkenum::ON_HOLD_RESUME,true); // mask //
			}
		}
		RscDUTs rscdut1(DUT_ACTIVE);
		NUMSITE = rscdut1.getSize();
		if(NUMSITE==0)	{ goto VCL_SIM_EXITFOR_1; }
	} // for

 VCL_SIM_EXITFOR_1:
	rdk::DUT::UNMASK(act_site,true); // restore active site	

#endif

	rdk::MFHP::PMU("LX_mfhp_pmu").isvm("0.0A",rdkenum::R3A,rdkenum::R7V,"7.0V","-7.0V").APPLY();	
    rdk::Timer::WAIT(3e-3);

	I2C_Write(0x21,0x00); 
	rdk::Timer::WAIT(1e-3); 

// clean up
	MMXH_PMU_Slewrate("VIN_mmxh_pmu" ,"Slow");  //for spike
	MMXH_PMU_Slewrate("VOUT_mmxh_pmu","Slow");  //for spike

	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R3mA,"3mA","-3mA").APPLY(); 
	rdk::MFHP::PMU("LX_mfhp_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R3mA,"3mA","-3mA").APPLY();
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R3mA,"3mA","-3mA").APPLY();
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R3mA,"3mA","-3mA").APPLY();
    rdk::Timer::WAIT(3e-3);
	DPIN_Levelset("MODE_mdm",OPEN_,OFF_);
	rdk::MMXH::PMU("EN_mmxh_pmu").disconnect().power(OFF).APPLY();	
	rdk::MFHP::PMU("LX_mfhp_pmu").disconnect().power(OFF).APPLY();	
	rdk::MMXH::PMU("VIN_mmxh_pmu").disconnect().power(OFF).APPLY();	
	rdk::MMXH::PMU("VOUT_mmxh_pmu").disconnect().power(OFF).APPLY();	
	rdk::CW("K_ALL").off().APPLY();
	rdk::Timer::WAIT(3e-3);
	
	MMXH_PMU_Slewrate("VIN_mmxh_pmu" ,"VeryFast");  //for spike
	MMXH_PMU_Slewrate("VOUT_mmxh_pmu","VeryFast");  //for spike


    for(ItrDUTs itrDut(DUT_ACTIVE); !itrDut.isDone(); itrDut++)
    {
		VCL_sim[*itrDut] = VCL_sim[*itrDut].getAsDouble() * -1;
        VCL_sim_err[*itrDut] = ( -VCL_sim[*itrDut].getAsDouble() + VCL_target ) / (VCL_sim[*itrDut].getAsDouble()+1e-9);
    }
	
	result |= Judge(test_id,"VCL_sim", "T_VCL_TRIM_LS.VCL_sim", VCL_sim,"SoftBins.BIN19"); if(RscDUTs(DUT_ACTIVE).isEmpty())return result;  test_id++;
	result |= Judge(test_id,"VCL_sim_err", "T_VCL_TRIM_LS.VCL_sim_err", VCL_sim_err,"SoftBins.BIN19"); if(RscDUTs(DUT_ACTIVE).isEmpty())return result;  test_id++;


	return result;

} // T_VCL_Trim


RsltAllDUTCtnr
TPG::T_VCL_BURN()
{
	//TestConditions.apply();
	RsltAllDUTCtnr result;
if (en_trim == 1)
{
	rdk::CW("K2;K12;K13;K16").on().APPLY(); // MODE MDM, EN MMXH, VIN_CAP, VOUT_CAP 
	rdk::Timer::WAIT(3e-3); 

	//IC Turn on
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("1.8V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").connect().power(ON).APPLY(); //For spike
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("1.8V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").connect().power(ON).APPLY();	//For spike
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("1.8V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").connect().power(ON).APPLY();	//For spike

	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").APPLY();
	DPIN_Levelset("MODE_mdm","3.6V", "0.0V", "1.8V", "1.8V",CLOSE_,ON_);
	rdk::Timer::WAIT(15e-3); 
												   
	I2C_Write(0x6A,0x5A);		  rdk::Timer::WAIT(2e-3); // enter test mode 
	I2C_Write(0x6A,0xA5);		  rdk::Timer::WAIT(2e-3); // enter test mode  2. Enter Test Mode.
	I2C_Write(0x42,vcl_code);     rdk::Timer::WAIT(2e-3); //3. Write target OTP values into REG 0x40 to 0x48.
	I2C_Write(0x20,0x02);		  rdk::Timer::WAIT(2e-3); // 4. Write REG 0x20 = 0x00 to select data in REG 0x40 to be burned.
	I2C_Write(0x21,0x09);		  rdk::Timer::WAIT(2e-3); // 5. Write REG 0x21=0x09 (OTP_CLK_REQ=1, EXVPP_EN=1).

	for(ItrDUTs itrDut(DUT_ACTIVE); !itrDut.isDone(); itrDut++) 
	{
		VHEN1[*itrDut] = EN_OTP42_02[*itrDut] * 1.0 * 5;
		VHEN2[*itrDut] = EN_OTP42_02[*itrDut] * 1.1 * 5;
		VHEN3[*itrDut] = EN_OTP42_02[*itrDut] * 1.2 * 5;
		VHEN4[*itrDut] = EN_OTP42_02[*itrDut] * 1.3 * 5;
		VHEN5[*itrDut] = EN_OTP42_02[*itrDut] * 1.4 * 5;

		//For VIN : If burend chip, VIN off, VOUT off
		VIEN[*itrDut] = EN_OTP42_02[*itrDut] * 5.5; //5.5V
		VOEN[*itrDut] = EN_OTP42_02[*itrDut] * 3.6; //3.6V
	}										  
		
	//If burend chip, VIN & VOUT off slowly
	MMXH_PMU_Slewrate("VIN_mmxh_pmu","Slow");   //for spike
	MMXH_PMU_Slewrate("VOUT_mmxh_pmu","Slow");   //for spike
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim(VIEN,rdkenum::R7V,rdkenum::R240mA,"200.0mA","-200.0mA").APPLY(); // VIN 5.5 V is needed for Burn //Check 0V and 5.5V both with DGT
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim(VOEN,rdkenum::R7V,rdkenum::R240mA,"200.0mA","-200.0mA").APPLY();
	rdk::Timer::WAIT(3e-3);	
	MMXH_PMU_Slewrate("VOUT_mmxh_pmu","VeryFast");   //for spike
	MMXH_PMU_Slewrate("VIN_mmxh_pmu","VeryFast");   //for spike

	//Burn
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim(VHEN1,rdkenum::R7V,rdkenum::R240mA,"200.0mA","-200.0mA").APPLY();
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim(VHEN2,rdkenum::R7V,rdkenum::R240mA,"200.0mA","-200.0mA").APPLY();
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim(VHEN3,rdkenum::R7V,rdkenum::R240mA,"200.0mA","-200.0mA").APPLY();
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim(VHEN4,rdkenum::R7V,rdkenum::R240mA,"200.0mA","-200.0mA").APPLY();
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim(VHEN5,rdkenum::R7V,rdkenum::R240mA,"200.0mA","-200.0mA").APPLY();
	rdk::Timer::WAIT(1e-3); 

	I2C_Write(0x21,0x0B); //7. Write 0x21 = 0x0B to program the OTP(BURN_EN=1). 8. Wait 1ms.
	rdk::Timer::WAIT(1e-3); 
	I2C_Write(0x21,0x09); //9. Write 0x21 = 0x09 to stop OTP programming.
	rdk::Timer::WAIT(1e-3); 

	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim(VHEN5,rdkenum::R7V,rdkenum::R240mA,"200.0mA","-200.0mA").APPLY();
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim(VHEN4,rdkenum::R7V,rdkenum::R240mA,"200.0mA","-200.0mA").APPLY();
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim(VHEN3,rdkenum::R7V,rdkenum::R240mA,"200.0mA","-200.0mA").APPLY();
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim(VHEN2,rdkenum::R7V,rdkenum::R240mA,"200.0mA","-200.0mA").APPLY();
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim(VHEN1,rdkenum::R7V,rdkenum::R240mA,"200.0mA","-200.0mA").APPLY();

	I2C_Write(0x6A,0x00); // exit test mode
	rdk::Timer::WAIT(1e-3); 


	// clean up
	MMXH_PMU_Slewrate("VIN_mmxh_pmu" ,"Slow");  //for spike
	MMXH_PMU_Slewrate("VOUT_mmxh_pmu","Slow");  //for spike
	MMXH_PMU_Slewrate("EN_mmxh_pmu"  ,"Slow");  //for spike	

	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R240mA,"200.0mA","-200.0mA").APPLY();
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();
	rdk::Timer::WAIT(3e-3);
	DPIN_Levelset("MODE_mdm",OPEN_,OFF_);
	rdk::MMXH::PMU("VOUT_mmxh_pmu").disconnect().power(OFF).APPLY();
	rdk::MMXH::PMU("VIN_mmxh_pmu").disconnect().power(OFF).APPLY();
	rdk::MMXH::PMU("EN_mmxh_pmu").disconnect().power(OFF).APPLY();
	rdk::CW("K_ALL").off().APPLY();
	rdk::Timer::WAIT(3e-3);	

	MMXH_PMU_Slewrate("VIN_mmxh_pmu" ,"VeryFast");  //for spike
	MMXH_PMU_Slewrate("VOUT_mmxh_pmu","VeryFast");  //for spike
	MMXH_PMU_Slewrate("EN_mmxh_pmu"  ,"VeryFast");  //for spike	
}
	result |= Judge(test_id,"VCL_burn", "T_BURN.BURN", EN_OTP42_02,"SoftBins.BIN19"); if(RscDUTs(DUT_ACTIVE).isEmpty())return result; test_id++;
	return result;

} // T_VCL_Burn


RsltAllDUTCtnr
TPG::T_VCL_POST()
{
	RsltAllDUTCtnr result;

	//ktb8316_discharge(); // Discharge For preventing from affection of previous item

	ValDUT VCL_post;
	ValDUT VCL_post_err;

	rdk::CW("K2;K13;K15;K16").on().APPLY(); // MODE_MDM, VIN_CAP, GND_MMXH(LX_MFHP_LOW SIDE), EN_MMXH
	rdk::Timer::WAIT(3e-3);

	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").connect().power(ON).APPLY(); 
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").connect().power(ON).APPLY();	
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").connect().power(ON).APPLY();	
	rdk::Timer::WAIT(3e-3);

	//IC Turn on
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("1.8V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY(); //For spike
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("1.8V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();	//For spike
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("1.8V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();	//For spike

	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();
	rdk::Timer::WAIT(5e-3);

	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").APPLY();
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").APPLY();
	rdk::Timer::WAIT(5e-3); 
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").APPLY();
	DPIN_Levelset("MODE_mdm","3.6V", "0.0V", "1.8V", "1.8V",CLOSE_,ON_);
	rdk::Timer::WAIT(15e-3); 
 
	I2C_Write(0x6A,0x5A); 
	rdk::Timer::WAIT(1e-3); // enter test mode 
	I2C_Write(0x6A,0xA5); 
	rdk::Timer::WAIT(3e-3); // enter test mode   

	MMXH_PMU_Slewrate("EN_mmxh_pmu"  ,"Slow");  //for spike	
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R3mA,"3mA","-3mA").APPLY(); //EN Float-1
	rdk::Timer::WAIT(3e-3);
	rdk::MMXH::PMU("EN_mmxh_pmu").isvm("0.0mA",rdkenum::R3mA,rdkenum::R7V,"7.0V","-7V").APPLY(); //EN Float-2
	rdk::Timer::WAIT(3e-3);
	MMXH_PMU_Slewrate("EN_mmxh_pmu"  ,"VeryFast");  //for spike	


	I2C_Write(0x25,0x52); 
	rdk::Timer::WAIT(1e-3); // (T_LS_ON=1, T_PLIMOFF=1, T_ILIM=1);
	I2C_Write(0x26,0xE0); 
	rdk::Timer::WAIT(1e-3); // (1/4 of driver) => (2400/4)= 600mA. 
	I2C_Write(0x23,0xCC); 
	rdk::Timer::WAIT(5e-3); // to mux out NVLY_CMP;

	rdk::MFHP::PMU("LX_mfhp_pmu").isvm("0.0A",rdkenum::R3A,rdkenum::R7V,"7.0V","-7.0V").connect(rdkenum::PORTA,rdkenum::PORTA).power(ON).APPLY();
	rdk::Timer::WAIT(1e-3);

// Post Measure Search
	rdk::MFHP::PMU("LX_mfhp_pmu").isvm("-0.35A",rdkenum::R3A,rdkenum::R7V,"7.0V","-7.0V").APPLY();
	rdk::Timer::WAIT(1e-3);


#if 1 //FOR Syntax intead of PMU Search
	ValDUT	meas_en_VCL_post = 0;
	ValDUT	dut_enter6 = 0;

////////////////////////////////////////////////////////////////////////////////////////////////////////////
act_site = GET_active_site(); // get active site //
	for(double LX_level=-0.39;LX_level>=-1.20;LX_level=LX_level-0.01)//Adjusted Search Range 1.27->1.2 A for Pin Current Spec
	{
		rdk::MFHP::PMU("LX_mfhp_pmu").isvm(LX_level,rdkenum::R3A,rdkenum::R7V,"7.0V","-7.0V").APPLY();
        timer.wait(0.2e-3);

		meas_en_VCL_post = rdk::MMXH::PMU("EN_mmxh_pmu").MEAS_V(200);

	    for(ItrDUTs itrDut(DUT_ACTIVE); !itrDut.isDone(); itrDut++)
		{
			dut_int = itrDut.getDUTID(); dut_int_VD.set(dut_int); dut_string = dut_int_VD.getAsString();
		    RscDUTs  dut_R(dut_string);

			//if(dut_enter6[*itrDut].getAsInt()==0)
			//{
			//    dlgout<<"DUT"<<*itrDut<<" LX_voltage : "<<LX_level *1000 <<" EN_voltage : "<<meas_en_VCL_post[0][*itrDut]<<"\n";
			//}

			if(dut_enter6[*itrDut].getAsInt()==0 && (meas_en_VCL_post[*itrDut].getAsDouble() > 1.0))
			{
				VCL_post[*itrDut]=LX_level;
				dut_enter6[*itrDut]=1;
				rdk::DUT::MASK(dut_R,rdkenum::ON_HOLD_RESUME,true); // mask //
			}
		}
		RscDUTs rscdut1(DUT_ACTIVE);
		NUMSITE = rscdut1.getSize();
		if(NUMSITE==0)	{ goto VCL_POST_EXITFOR_1; }
	} // for

 VCL_POST_EXITFOR_1:
	rdk::DUT::UNMASK(act_site,true); // restore active site	

#endif

	rdk::MFHP::PMU("LX_mfhp_pmu").isvm("0.0A",rdkenum::R3A,rdkenum::R7V,"7.0V","-7.0V").APPLY();
    rdk::Timer::WAIT(3e-3);

	I2C_Write(0x21,0x00); 
	rdk::Timer::WAIT(1e-3); 

// clean up
	MMXH_PMU_Slewrate("VIN_mmxh_pmu" ,"Slow");   //for spike
	MMXH_PMU_Slewrate("VOUT_mmxh_pmu","Slow");   //for spike

	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R3mA,"3mA","-3mA").APPLY(); 
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R3mA,"3mA","-3mA").APPLY();
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R3mA,"3mA","-3mA").APPLY();
    rdk::Timer::WAIT(3e-3);
	DPIN_Levelset("MODE_mdm",OPEN_,OFF_);
	rdk::MMXH::PMU("EN_mmxh_pmu").disconnect().power(OFF).APPLY();	
	rdk::MFHP::PMU("LX_mfhp_pmu").disconnect().power(OFF).APPLY();	
	rdk::MMXH::PMU("VIN_mmxh_pmu").disconnect().power(OFF).APPLY();	
	rdk::MMXH::PMU("VOUT_mmxh_pmu").disconnect().power(OFF).APPLY();	
	rdk::CW("K_ALL").off().APPLY();
	rdk::Timer::WAIT(3e-3);
	
	MMXH_PMU_Slewrate("VIN_mmxh_pmu" ,"VeryFast");   //for spike
	MMXH_PMU_Slewrate("VOUT_mmxh_pmu","VeryFast");   //for spike

    for(ItrDUTs itrDut(DUT_ACTIVE); !itrDut.isDone(); itrDut++) 
    {
		VCL_post[*itrDut] = VCL_post[*itrDut].getAsDouble() * -1;
		VCL_post_err[*itrDut] = (-VCL_post[*itrDut].getAsDouble() + VCL_target) / (VCL_post[*itrDut].getAsDouble()+1e-9) ;
    }

    result |= Judge(test_id,"VCL_post",    "T_VCL_TRIM_LS.VCL_post",        VCL_post,"SoftBins.BIN19"); if(RscDUTs(DUT_ACTIVE).isEmpty())return result; test_id++;
	result |= Judge(test_id,"VCL_post_err","T_VCL_TRIM_LS.VCL_post_err",VCL_post_err,"SoftBins.BIN19"); if(RscDUTs(DUT_ACTIVE).isEmpty()) return result; test_id++;

	return result;
} // T_VCL_POST



RsltAllDUTCtnr
TPG::T_ZCS_TRIM()
{
	RsltAllDUTCtnr result;
	RscTestCondition MODE_Timing("(Timing_MODE)");
	timing_set(Timming_Speed,MODE_Timing);

	test_id = 1000;	

	ValDUT ZCS_pre;
	ValDUT ZCS_sim;
	ValDUT ZCS_pre_err;
	ValDUT ZCS_sim_err;
	
	ValDUT ZCS_OTP27_03_pre=99;
	ValDUT RD_OTP27_pre=99;	
	
	ValDUT ZCS_OTP27_03_sim=99;
	ValDUT RD_OTP27_sim=99;		

	ValDUT ZCS_OTP27_03_delta = 99;
	

// ZCS Pre Setup
	rdk::CW("K2;K3;K13;K16").on().APPLY(); // MODE_MDM, EN_MDM, VIN_CAP, EN_MMXH
	rdk::Timer::WAIT(3e-3);
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").connect().power(ON).APPLY();
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").connect().power(ON).APPLY();
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R30mA,"3.0mA","-3.0mA").connect().power(ON).APPLY(); //EN Float-1
	rdk::Timer::WAIT(1e-3);
	
	//IC Turn on
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("1.2V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY(); //For spike
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("1.2V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();	//For spike
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("1.8V",rdkenum::R7V,rdkenum::R30mA,"3.0mA","-3.0mA").APPLY(); //EN Float-1

	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("2.5V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("2.5V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R30mA,"3.0mA","-3.0mA").APPLY();
	DPIN_Levelset("MODE_mdm","3.6V", "0.0V", "1.8V", "1.8V",CLOSE_,ON_);
	rdk::Timer::WAIT(15e-3); 

	I2C_Write(0x6A,0x5A); 
	rdk::Timer::WAIT(1e-3); // enter test mode 
	I2C_Write(0x6A,0xA5); 
	rdk::Timer::WAIT(3e-3); // enter test mode   

	MMXH_PMU_Slewrate("EN_mmxh_pmu"  ,"Slow");  //for spike	
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R30mA,"3.0mA","-3.0mA").APPLY(); //EN Float-1
	rdk::Timer::WAIT(3e-3);
	rdk::MMXH::PMU("EN_mmxh_pmu").isvm("0.0uA",rdkenum::R3mA,rdkenum::R7V,"7.0V","-7V").APPLY(); //Current range 30mA->3mA for REG27_delta - 241111
	rdk::Timer::WAIT(3e-3);
	MMXH_PMU_Slewrate("EN_mmxh_pmu"  ,"VeryFast");  //for spike	


/////////////////////////////////////////Rev09_RD_OTP27_pre/////////////////////////////////////////////////////////////////
	//rdk::MMXH::PMU("EN_mmxh_pmu").disconnect().power(OFF).APPLY();//For REG27_delta
	DPIN_Levelset("MODE_mdm","3.6V", "0.0V", "2.0V", "1.0V",OPEN_,OFF_);
	rdk::Timer::WAIT(3e-3);
    //rdk::CW("K16").off().APPLY();	//For REG27_delta
	RscTestCondition I2C_Timing("(Timing_I2C)");
	timing_set(Timming_Speed,I2C_Timing);

//Read 0x27 Pre - Rev0p9
	DPIN_Levelset("I2CPins","3.6V", "0.0V", "2.0V", "1.0V",CLOSE_,ON_);
	rdk::Timer::WAIT(3e-3);

	I2C_Write2(0x23,0x90); 
	rdk::Timer::WAIT(1e-3);
	
	RD_OTP27_pre  = I2C_Read(0x27);  // Read OTP Pre

	for(ItrDUTs itrDut(DUT_ACTIVE);!itrDut.isDone();itrDut++) 
	{
		ZCS_OTP27_03_pre[*itrDut] = RD_OTP27_pre[*itrDut] & 0x0F; //	Rdata1 & 1111 0000->???? 0000 for simulation
	}

	rdk::CW("K3").off().APPLY();
	//rdk::CW("K16").on().APPLY();//For REG27_delta
	rdk::MMXH::PMU("EN_mmxh_pmu").isvm("0.0uA",rdkenum::R3mA,rdkenum::R7V,"7.0V","-7V").APPLY();//Current range 30mA->3mA for REG27_delta - 241111S
	rdk::Timer::WAIT(15e-3); 
//////////////////////////////////////////////////////////////////////////////////////////////////////////
	I2C_Write(0x25,0x50); 
	rdk::Timer::WAIT(1e-3); // (T_LS_ON=1, T_PLIMOFF=1, T_ILIMOFF=1);
	I2C_Write(0x23,0x8C); 
	rdk::Timer::WAIT(10e-3); //  mux out IZX_CMP;

// Pre Measure Search
	rdk::MFHP::PMU("LX_mfhp_pmu").isvm("-10mA",rdkenum::R300mA,rdkenum::R7V,"7.0V","-7.0V").connect(rdkenum::PORTA,rdkenum::PORTA).power(ON).APPLY();
	rdk::Timer::WAIT(10e-3);

// Target threshold current = 50mA. 
	ZCS_pre = PMU_Search("LX_mfhp_pmu","-10.0mA","-210.mA","-2.0mA","0.2e-3","EN_mmxh_pmu",Falling_,"1.0V"); 
	rdk::Timer::WAIT(1e-3);

	rdk::MFHP::PMU("LX_mfhp_pmu").isvm("-0mA",rdkenum::R300mA,rdkenum::R7V,"7.0V","-7.0V").APPLY();
 	rdk::Timer::WAIT(1e-3);

	I2C_Write(0x21,0x00); 
	rdk::Timer::WAIT(1e-3); 

// clean up
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R30mA,"3.0mA","-3.0mA").APPLY(); 
	rdk::Timer::WAIT(3e-3);	
	DPIN_Levelset("I2CPins",OPEN_,OFF_);
	rdk::MFHP::PMU("LX_mfhp_pmu").disconnect().power(OFF).APPLY();
	rdk::Timer::WAIT(1e-3);	

	for(ItrDUTs itrDut(DUT_ACTIVE); !itrDut.isDone(); itrDut++) 
    {
		ZCS_pre[*itrDut]     = ZCS_pre[*itrDut].getAsDouble() * -1;
        ZCS_pre_err[*itrDut] = (-ZCS_pre[*itrDut].getAsDouble() + ZCS_target) / (ZCS_pre[*itrDut].getAsDouble()+1e-9);
    }



// trim table ------------------------------------------------------------------------------------------------
    for(ItrDUTs itrDut(DUT_ACTIVE);!itrDut.isDone();itrDut++) 
	{
        double temp_data_err = ZCS_pre_err[*itrDut].getAsDouble() * 100;
        if (temp_data_err >= -60.0 && temp_data_err<60.0) //Limit -60~60 - Rev0p9
            {
                if (temp_data_err >=  -4.55 && temp_data_err<  -1.14)	    { zcs_code[*itrDut] = 15; }//
                if (temp_data_err >=  -7.95 && temp_data_err<  -4.55)	    { zcs_code[*itrDut] = 14; }//
                if (temp_data_err >= -11.36 && temp_data_err<  -7.95)		{ zcs_code[*itrDut] = 13; }//
                if (temp_data_err >= -15.91 && temp_data_err< -11.36)		{ zcs_code[*itrDut] = 12; }//
                if (temp_data_err >= -19.32 && temp_data_err< -15.91)		{ zcs_code[*itrDut] = 11; }//
                if (temp_data_err >= -22.73 && temp_data_err< -19.32)		{ zcs_code[*itrDut] = 10; }//
                if (temp_data_err >= -26.14 && temp_data_err< -22.73)		{ zcs_code[*itrDut] = 9; }//
                if (temp_data_err >= -70.0  && temp_data_err< -26.14)		{ zcs_code[*itrDut] = 8; }//

                if (temp_data_err >=  25.0  && temp_data_err<  70.0 )		{ zcs_code[*itrDut] = 7; }//
                if (temp_data_err >=  20.45 && temp_data_err<  25.0 )	    { zcs_code[*itrDut] = 6; }//
                if (temp_data_err >=  17.05 && temp_data_err<  20.45)	    { zcs_code[*itrDut] = 5; }//
                if (temp_data_err >=  13.64 && temp_data_err<  17.05)	    { zcs_code[*itrDut] = 4; }//
                if (temp_data_err >=   9.09 && temp_data_err<  13.64)	    { zcs_code[*itrDut] = 3; }//
                if (temp_data_err >=   5.68 && temp_data_err<   9.09)		{ zcs_code[*itrDut] = 2; }//
                if (temp_data_err >=   2.27 && temp_data_err<   5.68)		{ zcs_code[*itrDut] = 1; }//
                if (temp_data_err >=  -1.14 && temp_data_err<   2.27)	    { zcs_code[*itrDut] = 0; }//
            }
            else
                zcs_code[*itrDut] = 0; 

       if (EN_OTP43_03[*itrDut]==0) { zcs_code[*itrDut] = RD_OTP43_03[*itrDut].getAsInt(); } 

	} // for ItrDUTs

	

	

//ZCS Sim Setup -----------------------------------------------------------------------------------------------
	rdk::CW("K2;K3;K13;K16").on().APPLY(); // MODE_MDM, EN_MDM, VIN_CAP, EN_MMXH
	rdk::Timer::WAIT(3e-3);

	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("1.8V",rdkenum::R7V,rdkenum::R30mA,"3.0mA","-3.0mA").APPLY();	//For spike
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R30mA,"3.0mA","-3.0mA").APPLY();
	DPIN_Levelset("MODE_mdm","3.6V", "0.0V", "1.8V", "1.8V",CLOSE_,ON_);
	rdk::Timer::WAIT(15e-3); 
 
	I2C_Write(0x6A,0x5A); 
	rdk::Timer::WAIT(1e-3); // enter test mode 
	I2C_Write(0x6A,0xA5); 
	rdk::Timer::WAIT(3e-3); // enter test mode   

	MMXH_PMU_Slewrate("EN_mmxh_pmu"  ,"Slow");  //for spike	
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R30mA,"30.0mA","-30.0mA").APPLY(); //EN Float-1
	rdk::Timer::WAIT(3e-3);
	rdk::MMXH::PMU("EN_mmxh_pmu").isvm("0.0uA",rdkenum::R3mA,rdkenum::R7V,"7.0V","-7V").APPLY(); //Current range 30mA->3mA for REG27_delta - 241111
	rdk::Timer::WAIT(3e-3);
/////////////////////////////////////////Rev09_RD_OTP27_sim/////////////////////////////////////////////////////////////////
	//rdk::MMXH::PMU("EN_mmxh_pmu").disconnect().power(OFF).APPLY(); //Delete For REG27_delta
	DPIN_Levelset("MODE_mdm","3.6V", "0.0V", "2.0V", "1.0V",OPEN_,OFF_);
	rdk::Timer::WAIT(3e-3);
    //rdk::CW("K16").off().APPLY();	//Delete For REG27_delta
	MMXH_PMU_Slewrate("EN_mmxh_pmu"  ,"VeryFast");  //for spike	

	
//Read 0x27 Sim - Rev0p9
	DPIN_Levelset("I2CPins","3.6V", "0.0V", "2.0V", "1.0V",CLOSE_,ON_);
	rdk::Timer::WAIT(3e-3);

	I2C_Write(0x23,0x90); 
	rdk::Timer::WAIT(1e-3);
	
	RD_OTP27_sim  = I2C_Read(0x27);  // Read OTP Sim

	for(ItrDUTs itrDut(DUT_ACTIVE);!itrDut.isDone();itrDut++) 
	{
		ZCS_OTP27_03_sim[*itrDut] = RD_OTP27_sim[*itrDut] & 0x0F; //	Rdata1 & 1111 0000->???? 0000 for simulation
	}

	rdk::CW("K3").off().APPLY();
	//rdk::CW("K16").on().APPLY(); //Delete For REG27_delta
	rdk::MMXH::PMU("EN_mmxh_pmu").isvm("0.0uA",rdkenum::R3mA,rdkenum::R7V,"7.0V","-7V").APPLY(); //Current range 30mA->3mA for REG27_delta - 241111
	rdk::Timer::WAIT(15e-3); 
//////////////////////////////////////////////////////////////////////////////////////////////////////////
	I2C_Write(0x25,0x50); 
	rdk::Timer::WAIT(1e-3); // (T_LS_ON=1, T_PLIMOFF=1, T_ILIM=1);
	I2C_Write(0x23,0x8C); 
	rdk::Timer::WAIT(1e-3); //  mux out IZX_CMP;

	I2C_Write(0x43,zcs_code); 
	rdk::Timer::WAIT(3e-3); 

// sim Measure Search
	rdk::MFHP::PMU("LX_mfhp_pmu").isvm("-10mA",rdkenum::R300mA,rdkenum::R7V,"7.0V","-7.0V").connect(rdkenum::PORTA,rdkenum::PORTA).power(ON).APPLY();
    rdk::Timer::WAIT(10e-3);


// Target threshold current = 50mA. 
	ZCS_sim = PMU_Search("LX_mfhp_pmu","-10.0mA","-210.mA","-2.0mA","0.2e-3","EN_mmxh_pmu",Falling_,"1.0V"); 
	rdk::Timer::WAIT(1e-3);

	rdk::MFHP::PMU("LX_mfhp_pmu").isvm("-0mA",rdkenum::R300mA,rdkenum::R7V,"7.0V","-7.0V").APPLY();
 	rdk::Timer::WAIT(1e-3);

    I2C_Write(0x21,0x00); 
	rdk::Timer::WAIT(1e-3); 

// clean up
	MMXH_PMU_Slewrate("VIN_mmxh_pmu" ,"Slow");   //for spike
	MMXH_PMU_Slewrate("VOUT_mmxh_pmu","Slow");   //for spike

	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();
    rdk::Timer::WAIT(3e-3);	
	DPIN_Levelset("I2CPins",OPEN_,OFF_);
	rdk::MFHP::PMU("LX_mfhp_pmu").disconnect().power(OFF).APPLY();
	rdk::MMXH::PMU("VIN_mmxh_pmu").disconnect().power(OFF).APPLY();	
	rdk::MMXH::PMU("VOUT_mmxh_pmu").disconnect().power(OFF).APPLY();	
	rdk::MMXH::PMU("EN_mmxh_pmu").disconnect().power(OFF).APPLY();	
	rdk::CW("K_ALL").off().APPLY();
	rdk::Timer::WAIT(3e-3);

	MMXH_PMU_Slewrate("VIN_mmxh_pmu" ,"VeryFast");   //for spike
	MMXH_PMU_Slewrate("VOUT_mmxh_pmu","VeryFast");   //for spike
	////
    for(ItrDUTs itrDut(DUT_ACTIVE); !itrDut.isDone(); itrDut++) 
    {
		ZCS_sim[*itrDut]     = ZCS_sim[*itrDut].getAsDouble() * -1;
		ZCS_sim_err[*itrDut] = (-ZCS_sim[*itrDut].getAsDouble() + ZCS_target) / (ZCS_sim[*itrDut].getAsDouble()+1e-9);
    }

	result |= Judge(test_id,"REG27_1",     ZCS_OTP27_03_pre,  -1, 16,"SoftBins.BIN20","SoftBins.BIN20","Dec"); if(RscDUTs(DUT_ACTIVE).isEmpty())return result; test_id++;
	result |= Judge(test_id,"ZCS_pre",     "T_ZCS_TRIM_LS.ZCS_pre",         ZCS_pre,"SoftBins.BIN20"); if(RscDUTs(DUT_ACTIVE).isEmpty())return result;  test_id++;
	result |= Judge(test_id,"ZCS_pre_err", "T_ZCS_TRIM_LS.ZCS_pre_err", ZCS_pre_err,"SoftBins.BIN20"); if(RscDUTs(DUT_ACTIVE).isEmpty())return result;  test_id++;

	result |= Judge(test_id,"ZCS_code",zcs_code, -0.5, 255.5,"SoftBins.BIN20","SoftBins.BIN20","Dec"); if(RscDUTs(DUT_ACTIVE).isEmpty())return result; test_id++;

	result |= Judge(test_id,"REG27_2",     ZCS_OTP27_03_sim,  -1, 16,"SoftBins.BIN20","SoftBins.BIN20","Dec"); if(RscDUTs(DUT_ACTIVE).isEmpty())return result; test_id++;
	result |= Judge(test_id,"ZCS_sim",     "T_ZCS_TRIM_LS.ZCS_sim",         ZCS_sim,"SoftBins.BIN20"); if(RscDUTs(DUT_ACTIVE).isEmpty())return result;  test_id++;
	result |= Judge(test_id,"ZCS_sim_err", "T_ZCS_TRIM_LS.ZCS_sim_err", ZCS_sim_err,"SoftBins.BIN20"); if(RscDUTs(DUT_ACTIVE).isEmpty())return result;  test_id++;


//Read 0x27 Delta- Rev0p9
	for(ItrDUTs itrDut(DUT_ACTIVE);!itrDut.isDone();itrDut++) 
	{
		ZCS_OTP27_03_delta[*itrDut] = ZCS_OTP27_03_sim[*itrDut] - ZCS_OTP27_03_pre[*itrDut]; //	Rdata1 & 1111 0000->???? 0000 for simulation
	}
	
	result |= Judge(test_id,"REG27_delta",     ZCS_OTP27_03_delta,  -0.5, 0.5,"SoftBins.BIN20","SoftBins.BIN20","Dec"); if(RscDUTs(DUT_ACTIVE).isEmpty())return result; test_id++;

	return result;

} // T_ZCS_Trim


RsltAllDUTCtnr
TPG::T_ZCS_BURN()
{
	//TestConditions.apply();
	RsltAllDUTCtnr result;
if (en_trim == 1)
{
	rdk::CW("K2;K12;K13;K16").on().APPLY(); // MODE MDM, EN MMXH, VIN_CAP, VOUT_CAP 
	rdk::Timer::WAIT(3e-3); 

	//IC Turn on
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("1.8V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").connect().power(ON).APPLY(); //For spike
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("1.8V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").connect().power(ON).APPLY();	//For spike
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("1.8V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").connect().power(ON).APPLY();	//For spike

	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").APPLY();
	DPIN_Levelset("MODE_mdm","3.6V", "0.0V", "1.8V", "1.8V",CLOSE_,ON_);
	rdk::Timer::WAIT(15e-3); 

	I2C_Write(0x6A,0x5A);	  rdk::Timer::WAIT(1e-3); // enter test mode 
	I2C_Write(0x6A,0xA5);	  rdk::Timer::WAIT(1e-3); // enter test mode  2. Enter Test Mode.
	I2C_Write(0x43,zcs_code); rdk::Timer::WAIT(1e-3); // 3. Write target OTP values into REG 0x40 to 0x48.
	I2C_Write(0x20,0x03);	  rdk::Timer::WAIT(1e-3); // 4. Write REG 0x20 = 0x00 to select data in REG 0x40 to be burned.
	I2C_Write(0x21,0x09);	  rdk::Timer::WAIT(1e-3); // 5. Write REG 0x21=0x09 (OTP_CLK_REQ=1, EXVPP_EN=1).

	for(ItrDUTs itrDut(DUT_ACTIVE); !itrDut.isDone(); itrDut++) 
	{
		VHEN1[*itrDut] = EN_OTP43_03[*itrDut] * 1.0 * 5;
		VHEN2[*itrDut] = EN_OTP43_03[*itrDut] * 1.1 * 5;
		VHEN3[*itrDut] = EN_OTP43_03[*itrDut] * 1.2 * 5;
		VHEN4[*itrDut] = EN_OTP43_03[*itrDut] * 1.3 * 5;
		VHEN5[*itrDut] = EN_OTP43_03[*itrDut] * 1.4 * 5;

		//For VIN : If burend chip, VIN off, VOUT off
		VIEN[*itrDut] = EN_OTP43_03[*itrDut] * 5.5; //5.5V
		VOEN[*itrDut] = EN_OTP43_03[*itrDut] * 3.6; //3.6V
	}										  
		
	//If burend chip, VIN & VOUT off slowly
	MMXH_PMU_Slewrate("VIN_mmxh_pmu","Slow");   //for spike
	MMXH_PMU_Slewrate("VOUT_mmxh_pmu","Slow");   //for spike
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim(VIEN,rdkenum::R7V,rdkenum::R240mA,"200.0mA","-200.0mA").APPLY(); // VIN 5.5 V is needed for Burn //Check 0V and 5.5V both with DGT
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim(VOEN,rdkenum::R7V,rdkenum::R240mA,"200.0mA","-200.0mA").APPLY();
	rdk::Timer::WAIT(3e-3);	
	MMXH_PMU_Slewrate("VOUT_mmxh_pmu","VeryFast");   //for spike
	MMXH_PMU_Slewrate("VIN_mmxh_pmu","VeryFast");   //for spike

	//Burn
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim(VHEN1,rdkenum::R7V,rdkenum::R240mA,"200.0mA","-200.0mA").APPLY();
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim(VHEN2,rdkenum::R7V,rdkenum::R240mA,"200.0mA","-200.0mA").APPLY();
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim(VHEN3,rdkenum::R7V,rdkenum::R240mA,"200.0mA","-200.0mA").APPLY();
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim(VHEN4,rdkenum::R7V,rdkenum::R240mA,"200.0mA","-200.0mA").APPLY();
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim(VHEN5,rdkenum::R7V,rdkenum::R240mA,"200.0mA","-200.0mA").APPLY();
	rdk::Timer::WAIT(1e-3); 

	I2C_Write(0x21,0x0B); //7. Write 0x21 = 0x0B to program the OTP(BURN_EN=1). 8. Wait 1ms.
	rdk::Timer::WAIT(1e-3); 
	I2C_Write(0x21,0x09); //9. Write 0x21 = 0x09 to stop OTP programming.
	rdk::Timer::WAIT(1e-3); 

	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim(VHEN5,rdkenum::R7V,rdkenum::R240mA,"200.0mA","-200.0mA").APPLY();
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim(VHEN4,rdkenum::R7V,rdkenum::R240mA,"200.0mA","-200.0mA").APPLY();
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim(VHEN3,rdkenum::R7V,rdkenum::R240mA,"200.0mA","-200.0mA").APPLY();
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim(VHEN2,rdkenum::R7V,rdkenum::R240mA,"200.0mA","-200.0mA").APPLY();
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim(VHEN1,rdkenum::R7V,rdkenum::R240mA,"200.0mA","-200.0mA").APPLY();
	rdk::Timer::WAIT(1e-3); 

	I2C_Write(0x6A,0x00); // exit test mode
	rdk::Timer::WAIT(1e-3); 


	// clean up
	MMXH_PMU_Slewrate("VIN_mmxh_pmu" ,"Slow");  //for spike
	MMXH_PMU_Slewrate("VOUT_mmxh_pmu","Slow");  //for spike
	MMXH_PMU_Slewrate("EN_mmxh_pmu"  ,"Slow");  //for spike	

	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R240mA,"200.0mA","-200.0mA").APPLY();
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();
	rdk::Timer::WAIT(3e-3);
	DPIN_Levelset("MODE_mdm",OPEN_,OFF_);
	rdk::MMXH::PMU("VOUT_mmxh_pmu").disconnect().power(OFF).APPLY();
	rdk::MMXH::PMU("VIN_mmxh_pmu").disconnect().power(OFF).APPLY();
	rdk::MMXH::PMU("EN_mmxh_pmu").disconnect().power(OFF).APPLY();
	rdk::CW("K_ALL").off().APPLY();
	rdk::Timer::WAIT(3e-3);	

	MMXH_PMU_Slewrate("VIN_mmxh_pmu" ,"VeryFast");  //for spike
	MMXH_PMU_Slewrate("VOUT_mmxh_pmu","VeryFast");  //for spike
	MMXH_PMU_Slewrate("EN_mmxh_pmu"  ,"VeryFast");  //for spike	

}
	result |= Judge(test_id,"ZCS_burn", "T_BURN.BURN", EN_OTP43_03,"SoftBins.BIN20"); if(RscDUTs(DUT_ACTIVE).isEmpty())return result; test_id++;

	return result;
} // T_ZCS_Burn


RsltAllDUTCtnr
TPG::T_ZCS_POST()
{
	RsltAllDUTCtnr result;

	ValDUT ZCS_post;
	ValDUT ZCS_post_err;

	ValDUT ZCS_OTP27_03_post=99;
	ValDUT RD_OTP27_post=99;	

	ValDUT ZCS_OTP27_03_3p6=99;
	ValDUT RD_OTP27_3p6=99;	
	ValDUT ZCS_OTP27_03_5p5=99;
	ValDUT RD_OTP27_5p5=99;	

	ValDUT ZCS_post_vin3p6 = 99;
	ValDUT ZCS_post_vin5p5 = 99;
		

// ZCS post Setup
	rdk::CW("K2;K3;K13;K16").on().APPLY(); // MODE_MDM, EN_MDM, VIN_CAP, EN_MMXH
	rdk::Timer::WAIT(3e-3);
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").connect().power(ON).APPLY();
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").connect().power(ON).APPLY();
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R30mA,"3.0mA","-3.0mA").connect().power(ON).APPLY(); //EN Float-1
	rdk::Timer::WAIT(1e-3);

	//IC Turn on
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("1.2V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY(); //For spike
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("1.2V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();	//For spike
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("1.8V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();	//For spike

	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("2.5V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("2.5V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R30mA,"3.0mA","-3.0mA").APPLY();
	DPIN_Levelset("MODE_mdm","3.6V", "0.0V", "1.8V", "1.8V",CLOSE_,ON_);
	rdk::Timer::WAIT(15e-3); 
 
	I2C_Write(0x6A,0x5A); 
	rdk::Timer::WAIT(1e-3); // enter test mode 
	I2C_Write(0x6A,0xA5); 
	rdk::Timer::WAIT(3e-3); // enter test mode   

	MMXH_PMU_Slewrate("EN_mmxh_pmu"  ,"Slow");  //for spike	
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R30mA,"3.0mA","-3.0mA").APPLY(); //EN Float-1
	rdk::Timer::WAIT(3e-3);
	rdk::MMXH::PMU("EN_mmxh_pmu").isvm("0.0uA",rdkenum::R3mA,rdkenum::R7V,"7.0V","-7V").APPLY(); //Current range 30mA->3mA for REG27_delta - 241111
	rdk::Timer::WAIT(3e-3);
	MMXH_PMU_Slewrate("EN_mmxh_pmu"  ,"VeryFast");  //for spike	


/////////////////////////////////////////Rev09_RD_OTP27_post/////////////////////////////////////////////////////////////////
	//rdk::MMXH::PMU("EN_mmxh_pmu").disconnect().power(OFF).APPLY(); //Delete For REG27_delta
	DPIN_Levelset("MODE_mdm","3.6V", "0.0V", "2.0V", "1.0V",OPEN_,OFF_);
	rdk::Timer::WAIT(3e-3);
    //rdk::CW("K16").off().APPLY();	//Delete For REG27_delta
	RscTestCondition I2C_Timing("(Timing_I2C)");
	timing_set(Timming_Speed,I2C_Timing);

//Read 0x27 Post - Rev0p9
	DPIN_Levelset("I2CPins","3.6V", "0.0V", "2.0V", "1.0V",CLOSE_,ON_);
	rdk::Timer::WAIT(3e-3);

	I2C_Write(0x23,0x90); 
	rdk::Timer::WAIT(1e-3);
	
	RD_OTP27_post  = I2C_Read(0x27);  // Read OTP Post

	for(ItrDUTs itrDut(DUT_ACTIVE);!itrDut.isDone();itrDut++) 
	{
		ZCS_OTP27_03_post[*itrDut] = RD_OTP27_post[*itrDut] & 0x0F; //	Rdata1 & 1111 0000->???? 0000 for simulation
	}
	
	rdk::CW("K3").off().APPLY();
	//rdk::CW("K16").on().APPLY(); /Delete For REG27_delta
	rdk::MMXH::PMU("EN_mmxh_pmu").isvm("0.0uA",rdkenum::R3mA,rdkenum::R7V,"7.0V","-7V").APPLY();//Current range 30mA->3mA for REG27_delta - 241111
	rdk::Timer::WAIT(15e-3); 
//////////////////////////////////////////////////////////////////////////////////////////////////////////
	I2C_Write(0x25,0x50); 
	rdk::Timer::WAIT(1e-3); // (T_LS_ON=1, T_PLIMOFF=1, T_ILIM=1);
	I2C_Write(0x23,0x8C); 
	rdk::Timer::WAIT(1e-3); //  mux out IZX_CMP;

// post Measure Search
	rdk::MFHP::PMU("LX_mfhp_pmu").isvm("-10mA",rdkenum::R300mA,rdkenum::R7V,"7.0V","-7.0V").connect(rdkenum::PORTA,rdkenum::PORTA).power(ON).APPLY();
    rdk::Timer::WAIT(3e-3);


// Target threshold current = 50mA. 
	ZCS_post = PMU_Search("LX_mfhp_pmu","-10.0mA","-210.mA","-2.0mA","0.2e-3","EN_mmxh_pmu",Falling_,"1.0V"); 
	rdk::Timer::WAIT(1e-3);

	rdk::MFHP::PMU("LX_mfhp_pmu").isvm("-0mA",rdkenum::R300mA,rdkenum::R7V,"7.0V","-7.0V").APPLY();
 	rdk::Timer::WAIT(1e-3);

	I2C_Write2(0x21,0x00); 
	rdk::Timer::WAIT(1e-3); 

// clean up
	DPIN_Levelset("I2CPins",OPEN_,OFF_);
	rdk::MFHP::PMU("LX_mfhp_pmu").disconnect().power(OFF).APPLY();
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R30mA,"3.0mA","-3.0mA").APPLY(); //EN Float-1
	rdk::Timer::WAIT(3e-3);

    for(ItrDUTs itrDut(DUT_ACTIVE); !itrDut.isDone(); itrDut++) 
    {
		ZCS_post[*itrDut] = ZCS_post[*itrDut].getAsDouble() * -1;
		ZCS_post_err[*itrDut] = (-ZCS_post[*itrDut].getAsDouble() + ZCS_target) / (ZCS_post[*itrDut].getAsDouble()+1e-9);
    }

	result |= Judge(test_id,"REG27_3",     ZCS_OTP27_03_post,  -1, 16,"SoftBins.BIN20","SoftBins.BIN20","Dec"); if(RscDUTs(DUT_ACTIVE).isEmpty())return result; test_id++;
    result |= Judge(test_id,"ZCS_post",    "T_ZCS_TRIM_LS.ZCS_post",        ZCS_post,"SoftBins.BIN20"); if(RscDUTs(DUT_ACTIVE).isEmpty())return result; test_id++;
	result |= Judge(test_id,"ZCS_post_err","T_ZCS_TRIM_LS.ZCS_post_err",ZCS_post_err,"SoftBins.BIN20"); if(RscDUTs(DUT_ACTIVE).isEmpty()) return result; test_id++;

	
////////////////////////////////////////////////////////ZCS Post 3p6/////////////////////////////////////

// Setup 3p6
	rdk::CW("K2;K3;K13;K16").on().APPLY(); // MODE_MDM, EN_MDM, VIN_CAP, EN_MMXH
	rdk::Timer::WAIT(3e-3);

	//IC Turn on
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("1.8V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY(); //For spike
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("1.8V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();	//For spike
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("1.8V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();	//For spike

	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R30mA,"3.0mA","-3.0mA").APPLY();
	DPIN_Levelset("MODE_mdm","3.6V", "0.0V", "1.8V", "1.8V",CLOSE_,ON_);
	rdk::Timer::WAIT(15e-3); 
 
	I2C_Write(0x6A,0x5A); 
	rdk::Timer::WAIT(1e-3); // enter test mode 
	I2C_Write(0x6A,0xA5); 
	rdk::Timer::WAIT(3e-3); // enter test mode   

	MMXH_PMU_Slewrate("EN_mmxh_pmu"  ,"Slow");  //for spike	
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R30mA,"3.0mA","-3.0mA").APPLY(); //EN Float-1
	rdk::Timer::WAIT(3e-3);
	rdk::MMXH::PMU("EN_mmxh_pmu").isvm("0.0uA",rdkenum::R3mA,rdkenum::R7V,"7.0V","-7V").APPLY(); //Current range 30mA->3mA for REG27_delta - 241111
	rdk::Timer::WAIT(3e-3);
	MMXH_PMU_Slewrate("EN_mmxh_pmu"  ,"VeryFast");  //for spike	

/////////////////////////////////////////Rev09_RD_OTP27_3p6/////////////////////////////////////////////////////////////////
	//rdk::MMXH::PMU("EN_mmxh_pmu").disconnect().power(OFF).APPLY(); //Delete For REG27_delta
	DPIN_Levelset("MODE_mdm","3.6V", "0.0V", "2.0V", "1.0V",OPEN_,OFF_);
	rdk::Timer::WAIT(3e-3);
    //rdk::CW("K16").off().APPLY();	//Delete For REG27_delta
	timing_set(Timming_Speed,I2C_Timing);


//Read 0x27 post 3p6 - Rev0p9
	DPIN_Levelset("I2CPins","3.6V", "0.0V", "2.0V", "1.0V",CLOSE_,ON_);
	rdk::Timer::WAIT(3e-3);

	I2C_Write(0x23,0x90); 
	rdk::Timer::WAIT(1e-3);

	RD_OTP27_3p6  = I2C_Read(0x27);  // Read OTP 3p6v

	for(ItrDUTs itrDut(DUT_ACTIVE);!itrDut.isDone();itrDut++) 
	{
		ZCS_OTP27_03_3p6[*itrDut] = RD_OTP27_3p6[*itrDut] & 0x0F; //	Rdata1 & 1111 0000->???? 0000 for simulation
	}
	
	rdk::CW("K3").off().APPLY();
	//rdk::CW("K16").on().APPLY(); //Delete For REG27_delta
	rdk::MMXH::PMU("EN_mmxh_pmu").isvm("0.0uA",rdkenum::R3mA,rdkenum::R7V,"7.0V","-7V").APPLY();//Current range 30mA->3mA for REG27_delta - 241111
	rdk::Timer::WAIT(15e-3); 
//////////////////////////////////////////////////////////////////////////////////////////////////////////
	I2C_Write(0x25,0x50); 
	rdk::Timer::WAIT(1e-3); // (T_LS_ON=1, T_PLIMOFF=1, T_ILIM=1);
	I2C_Write(0x23,0x8C); 
	rdk::Timer::WAIT(1e-3); //  mux out IZX_CMP;

// post Measure Search
	rdk::MFHP::PMU("LX_mfhp_pmu").isvm("-10mA",rdkenum::R300mA,rdkenum::R7V,"7.0V","-7.0V").connect(rdkenum::PORTA,rdkenum::PORTA).power(ON).APPLY();
    rdk::Timer::WAIT(3e-3);


// Target threshold current = 50mA. 
	ZCS_post_vin3p6 = PMU_Search("LX_mfhp_pmu","-10.0mA","-210.mA","-2.0mA","0.2e-3","EN_mmxh_pmu",Falling_,"1.0V"); 
	rdk::Timer::WAIT(1e-3);

	rdk::MFHP::PMU("LX_mfhp_pmu").isvm("-0mA",rdkenum::R300mA,rdkenum::R7V,"7.0V","-7.0V").APPLY();
 	rdk::Timer::WAIT(1e-3);

	I2C_Write(0x21,0x00); 
	rdk::Timer::WAIT(1e-3); 

// clean up
	MMXH_PMU_Slewrate("VIN_mmxh_pmu" ,"Slow");  //for spike
	MMXH_PMU_Slewrate("VOUT_mmxh_pmu","Slow");  //for spike

	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();
    rdk::Timer::WAIT(3e-3);	
	DPIN_Levelset("I2CPins",OPEN_,OFF_);
	rdk::MFHP::PMU("LX_mfhp_pmu").disconnect().power(OFF).APPLY();
	rdk::Timer::WAIT(3e-3);
	
	MMXH_PMU_Slewrate("VIN_mmxh_pmu" ,"VeryFast");  //for spike
	MMXH_PMU_Slewrate("VOUT_mmxh_pmu","VeryFast");  //for spike

    for(ItrDUTs itrDut(DUT_ACTIVE); !itrDut.isDone(); itrDut++) 
    {
		ZCS_post_vin3p6[*itrDut] = ZCS_post_vin3p6[*itrDut].getAsDouble() * -1;
		//ZCS_post_err[*itrDut] = (-ZCS_post[*itrDut].getAsDouble() + ZCS_target) / ZCS_post[*itrDut].getAsDouble();
    }
	result |= Judge(test_id,"ZCS_Reg27_vin3p6",     ZCS_OTP27_03_3p6,  -1, 16,"SoftBins.BIN20","SoftBins.BIN20","Dec"); if(RscDUTs(DUT_ACTIVE).isEmpty())return result; test_id++;
	result |= Judge(test_id,"ZCS_post_vin3p6",    "T_ZCS_TRIM_LS.ZCS_post_temp",        ZCS_post_vin3p6,"SoftBins.BIN20"); if(RscDUTs(DUT_ACTIVE).isEmpty())return result; test_id++;
 
 
////////////////////////////////////////////////////////ZCS Post 5p5/////////////////////////////////////


// Setup 5p5
	rdk::CW("K2;K3;K13;K16").on().APPLY(); // MODE_MDM, EN_MDM, VIN_CAP, EN_MMXH
	rdk::Timer::WAIT(3e-3);
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R30mA,"3.0mA","-3.0mA").APPLY(); //EN Float-1
	rdk::Timer::WAIT(1e-3);

	//IC Turn on
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("1.8V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY(); //For spike
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("2.5V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();	//For spike
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("1.8V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();	//For spike

	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("4.5V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();	//For spike

	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("5.5V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R30mA,"3.0mA","-3.0mA").APPLY();
	DPIN_Levelset("MODE_mdm","3.6V", "0.0V", "1.8V", "1.8V",CLOSE_,ON_);
	rdk::Timer::WAIT(15e-3); 
 
	I2C_Write(0x6A,0x5A); 
	rdk::Timer::WAIT(1e-3); // enter test mode 
	I2C_Write(0x6A,0xA5); 
	rdk::Timer::WAIT(3e-3); // enter test mode   

	MMXH_PMU_Slewrate("EN_mmxh_pmu"  ,"Slow");  //for spike	
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R30mA,"3.0mA","-3.0mA").APPLY(); //EN Float-1
	rdk::Timer::WAIT(3e-3);
	rdk::MMXH::PMU("EN_mmxh_pmu").isvm("0.0uA",rdkenum::R3mA,rdkenum::R7V,"7.0V","-7V").APPLY(); //Current range 30mA->3mA for REG27_delta - 241111
	rdk::Timer::WAIT(3e-3);
	MMXH_PMU_Slewrate("EN_mmxh_pmu"  ,"VeryFast");  //for spike	
	
/////////////////////////////////////////Rev09_RD_OTP27_5p5/////////////////////////////////////////////////////////////////
	//rdk::MMXH::PMU("EN_mmxh_pmu").disconnect().power(OFF).APPLY();
	DPIN_Levelset("MODE_mdm","3.6V", "0.0V", "2.0V", "1.0V",OPEN_,OFF_);
	rdk::Timer::WAIT(3e-3);
    //rdk::CW("K16").off().APPLY();	
	timing_set(Timming_Speed,I2C_Timing);

//Read 0x27 Post 5p5 - Rev0p9
	DPIN_Levelset("I2CPins","3.6V", "0.0V", "2.0V", "1.0V",CLOSE_,ON_);
	rdk::Timer::WAIT(3e-3);

	I2C_Write(0x23,0x90); 
	rdk::Timer::WAIT(1e-3);
	
	RD_OTP27_5p5  = I2C_Read(0x27);  // Read OTP 5p5v

	for(ItrDUTs itrDut(DUT_ACTIVE);!itrDut.isDone();itrDut++) 
	{
		ZCS_OTP27_03_5p5[*itrDut] = RD_OTP27_5p5[*itrDut] & 0x0F; //	Rdata1 & 1111 0000->???? 0000 for simulation
	}
	
	rdk::CW("K3").off().APPLY();
	//rdk::CW("K16").on().APPLY();
	rdk::MMXH::PMU("EN_mmxh_pmu").isvm("0.0uA",rdkenum::R3mA,rdkenum::R7V,"7.0V","-7V").APPLY();//Current range 30mA->3mA for REG27_delta - 241111
	rdk::Timer::WAIT(15e-3); 
//////////////////////////////////////////////////////////////////////////////////////////////////////////
	I2C_Write(0x25,0x50); 
	rdk::Timer::WAIT(1e-3); // (T_LS_ON=1, T_PLIMOFF=1, T_ILIM=1);
	I2C_Write(0x23,0x8C); 
	rdk::Timer::WAIT(1e-3); //  mux out IZX_CMP;

// post Measure Search
	rdk::MFHP::PMU("LX_mfhp_pmu").isvm("-10mA",rdkenum::R300mA,rdkenum::R7V,"7.0V","-7.0V").connect(rdkenum::PORTA,rdkenum::PORTA).power(ON).APPLY();
    rdk::Timer::WAIT(3e-3);


// Target threshold current = 50mA. 
	ZCS_post_vin5p5 = PMU_Search("LX_mfhp_pmu","-10.0mA","-210.mA","-2.0mA","0.2e-3","EN_mmxh_pmu",Falling_,"1.0V"); 
	rdk::Timer::WAIT(1e-3);

	rdk::MFHP::PMU("LX_mfhp_pmu").isvm("-0mA",rdkenum::R300mA,rdkenum::R7V,"7.0V","-7.0V").APPLY();
 	rdk::Timer::WAIT(1e-3);

	I2C_Write(0x21,0x00); 
	rdk::Timer::WAIT(1e-3); 

// clean up
	MMXH_PMU_Slewrate("VIN_mmxh_pmu" ,"Slow");   //for spike
	MMXH_PMU_Slewrate("VOUT_mmxh_pmu","Slow");   //for spike
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();
    rdk::Timer::WAIT(3e-3);	
	DPIN_Levelset("I2CPins",OPEN_,OFF_);
	rdk::MFHP::PMU("LX_mfhp_pmu").disconnect().power(OFF).APPLY();
	rdk::MMXH::PMU("VIN_mmxh_pmu").disconnect().power(OFF).APPLY();	
	rdk::MMXH::PMU("VOUT_mmxh_pmu").disconnect().power(OFF).APPLY();	
	rdk::MMXH::PMU("EN_mmxh_pmu").disconnect().power(OFF).APPLY();	
	rdk::CW("K_ALL").off().APPLY();
	rdk::Timer::WAIT(3e-3);
	MMXH_PMU_Slewrate("VIN_mmxh_pmu" ,"VeryFast");   //for spike
	MMXH_PMU_Slewrate("VOUT_mmxh_pmu","VeryFast");   //for spike	

    for(ItrDUTs itrDut(DUT_ACTIVE); !itrDut.isDone(); itrDut++) 
    {
		ZCS_post_vin5p5[*itrDut] = ZCS_post_vin5p5[*itrDut].getAsDouble() * -1;
		//ZCS_post_err[*itrDut] = (-ZCS_post[*itrDut].getAsDouble() + ZCS_target) / ZCS_post[*itrDut].getAsDouble();
    }
	result |= Judge(test_id,"ZCS_Reg27_vin5p5",     ZCS_OTP27_03_5p5,  -1, 16,"SoftBins.BIN20","SoftBins.BIN20","Dec"); if(RscDUTs(DUT_ACTIVE).isEmpty())return result; test_id++;
	result |= Judge(test_id,"ZCS_post_vin5p5",    "T_ZCS_TRIM_LS.ZCS_post_temp",        ZCS_post_vin5p5,"SoftBins.BIN20"); if(RscDUTs(DUT_ACTIVE).isEmpty())return result; test_id++;

	return result;
} // T_ZCS_POST


RsltAllDUTCtnr
TPG::T_RDSON()
{
	RsltAllDUTCtnr result;
	test_id = 1100;	
	
	RscTestCondition MODE_Timing("(Timing_MODE)");
	timing_set(Timming_Speed,MODE_Timing);

	OFCArray<ValDUT> HS_RDSON(1,0);
	OFCArray<ValDUT> LS_RDSON(1,0);
	OFCArray<ValDUT> meas_HS_LX_V(1,0);
	OFCArray<ValDUT> meas_LS_LX_V(1,0);

// Setup
    rdk::CW("K2;K13;K14;K16").on().APPLY(); // MODE_MDM,VIN_CAP ,LX_MFHP ,EN_MMXH
	rdk::Timer::WAIT(3e-3);
	
//IC Turn on
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("1.8V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").connect().power(ON).APPLY(); //For spike
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("1.8V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").connect().power(ON).APPLY();	//For spike
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("1.8V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").connect().power(ON).APPLY();	//For spike

	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsvim("3.6V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").APPLY();
	DPIN_Levelset("MODE_mdm","3.6V", "0.0V", "1.8V", "1.8V",CLOSE_,ON_);
	rdk::Timer::WAIT(15e-3); 

// Test Mode In	
	I2C_Write(0x6A,0x5A); 
	rdk::Timer::WAIT(1e-3); // enter test mode 
	I2C_Write(0x6A,0xA5); 
	rdk::Timer::WAIT(3e-3); // enter test mode   

//HS_RDSON

	MMXH_PMU_Slewrate("EN_mmxh_pmu"  ,"Slow");  //for spike	
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").APPLY(); //EN Float-1
	rdk::Timer::WAIT(3e-3);
	rdk::MMXH::PMU("EN_mmxh_pmu").disconnect().power(OFF).APPLY(); // EN float-2
	rdk::Timer::WAIT(3e-3);
	MMXH_PMU_Slewrate("EN_mmxh_pmu"  ,"VeryFast");  //for spike	
	
	I2C_Write(0x25,0x20); 
	rdk::Timer::WAIT(1e-3); // (T_HS_ON=1);
	
	rdk::MFHP::PMU("LX_mfhp_pmu").isvim("-0.15A",rdkenum::R300mA,rdkenum::R300mA,rdkenum::R7V,"7.0V", "-7.0V").connect(rdkenum::PORTA,rdkenum::PORTA).power(ON).APPLY();
	rdk::Timer::WAIT(3e-3); 
	meas_HS_LX_V[0] = rdk::MFHP::PMU("LX_mfhp_pmu").MEAS_V(50); //Actual value for RDSON.
	rdk::Timer::WAIT(3e-3);

	//HS_RDSON = meas_VIN_V[0]-meas_LX_V[0] / 0.15 * 1000; // IN ACCO PGM // Expected RDSon_HighSide = 105 mΩ
    for(ItrDUTs itrDut(DUT_ACTIVE); !itrDut.isDone(); itrDut++) 
    {
		HS_RDSON[0][*itrDut] = (meas_HS_LX_V[0][*itrDut].getAsDouble() / -0.15) *1000 ; // Expected RDSon_HighSide = 105 mΩ
	}

//LS_RDSON
	rdk::MFHP::PMU("LX_mfhp_pmu").isvim("0.0A",rdkenum::R300mA,rdkenum::R300mA,rdkenum::R7V,"7.0V", "-7.0V").APPLY();
	rdk::Timer::WAIT(3e-3);
	rdk::MFHP::PMU("LX_mfhp_pmu").disconnect().power(ON).APPLY();
	rdk::CW("K15").on().APPLY(); // GND_MMXH(LX_MFHP_LOW SIDE)
	rdk::CW("K14").off().APPLY(); // LX_MFHP
	rdk::Timer::WAIT(1e-3);//VOUT_MFHP to GND
	
	I2C_Write(0x25,0x40); 
	rdk::Timer::WAIT(1e-3); //  (T_LS_ON=1);
	
	rdk::MFHP::PMU("LX_mfhp_pmu").isvim("-0.15A",rdkenum::R300mA,rdkenum::R300mA,rdkenum::R7V,"7.0V", "-7.0V").connect(rdkenum::PORTA,rdkenum::PORTA).power(ON).APPLY();
	rdk::Timer::WAIT(3e-3);
	
	meas_LS_LX_V[0] = rdk::MFHP::PMU("LX_mfhp_pmu").MEAS_V(50); //Actual value for RDSON.

	rdk::Timer::WAIT(3e-3);

	I2C_Write(0x21,0x00); 
	rdk::Timer::WAIT(1e-3); 

	//LS_RDSON = -meas_LX_V[0] / 0.15 * 1000;; // IN ACCO PGM // Expected RDSon_LowSide = 45 mΩ
    for(ItrDUTs itrDut(DUT_ACTIVE); !itrDut.isDone(); itrDut++) 
    {
		LS_RDSON[0][*itrDut]  = (meas_LS_LX_V[0][*itrDut].getAsDouble() / -0.15) *1000 ; // Expected RDSon_LowSide = 45 mΩ
	}
	rdk::MFHP::PMU("LX_mfhp_pmu").isvim("0.0A",rdkenum::R3A,rdkenum::R3A,rdkenum::R7V,"7.0V", "-7.0V").APPLY();
	rdk::Timer::WAIT(3e-3);

	I2C_Write(0x21,0x00); 
	rdk::Timer::WAIT(1e-3); 

//Clean up
	MMXH_PMU_Slewrate("VIN_mmxh_pmu" ,"Slow");  //for spike

	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();
	rdk::Timer::WAIT(3e-3);
	DPIN_Levelset("MODE_mdm",OPEN_,OFF_);
	rdk::MFHP::PMU("LX_mfhp_pmu").disconnect().power(OFF).APPLY();	
	rdk::MMXH::PMU("EN_mmxh_pmu").disconnect().power(OFF).APPLY();	
	rdk::MMXH::PMU("VIN_mmxh_pmu").disconnect().power(OFF).APPLY();	
	rdk::Timer::WAIT(3e-3);	
	rdk::CW("K_ALL").off().APPLY();
	rdk::Timer::WAIT(3e-3);

	MMXH_PMU_Slewrate("VIN_mmxh_pmu" ,"VeryFast");  //for spike


	result |= Judge(test_id,"HS_RDSON",HS_RDSON[0], 80.0, 150.0,"SoftBins.BIN21","SoftBins.BIN21","mOhms"); if(RscDUTs(DUT_ACTIVE).isEmpty())return result;
	result |= Judge(test_id,"LS_RDSON",LS_RDSON[0], 20.0, 80.0, "SoftBins.BIN21","SoftBins.BIN21","mOhms"); if(RscDUTs(DUT_ACTIVE).isEmpty())return result;

	return result;
}


RsltAllDUTCtnr
TPG::T_EA_OFFSET()
{
	RsltAllDUTCtnr result;
	test_id = 1200;	
	
	ValDUT EA_offset;
	
	// Setup
    rdk::CW("K2;K12;K13;K16").on().APPLY(); // MODE_MDM, VOUT_CAP, VIN_CAP, EN_MMXH
	rdk::Timer::WAIT(3e-3);

	//IC Turn on
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("1.8V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").connect().power(ON).APPLY(); //For spike
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("1.8V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").connect().power(ON).APPLY();	//For spike
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("1.8V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").connect().power(ON).APPLY();	//For spike

	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").APPLY();
	DPIN_Levelset("MODE_mdm","3.6V", "0.0V", "1.8V", "1.8V",CLOSE_,ON_);
	rdk::Timer::WAIT(15e-3); 
	
	// Test Mode In	
	I2C_Write(0x6A,0x5A); 
	rdk::Timer::WAIT(1e-3); // enter test mode 
	I2C_Write(0x6A,0xA5); 
	rdk::Timer::WAIT(3e-3); // enter test mode   

	MMXH_PMU_Slewrate("EN_mmxh_pmu"  ,"Slow");  //for spike	
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").APPLY(); //EN Float-1
	rdk::Timer::WAIT(3e-3);
	rdk::MMXH::PMU("EN_mmxh_pmu").isvm("0.0mA",rdkenum::R300uA,rdkenum::R7V,"7.0V","-7V").APPLY(); //EN Float-2
	rdk::Timer::WAIT(3e-3);
	MMXH_PMU_Slewrate("EN_mmxh_pmu"  ,"VeryFast");  //for spike	


	rdk::CW("K16").off().APPLY(); // EN_MMXH
	rdk::Timer::WAIT(3e-3);
	rdk::CW("K5").on().APPLY(); // OP7
	rdk::Timer::WAIT(3e-3);
	
	I2C_Write(0x25,0x0D); 
	rdk::Timer::WAIT(1e-3); // (T_DIS_LPWR=1, T_EA_OFFS=1, T_DISABLE_DRVR=1)
	I2C_Write(0x23,0xC9); 
	rdk::Timer::WAIT(1e-3); // (MUXSEL=2'b11,AD_MUXO_EN=1,ENMUX=3'b001)
	
	// measure
	rdk::MMXH::PMU("EN_mmxh_pmu").isvm("0.0mA",rdkenum::R300uA,rdkenum::R7V,"7.0V","-7.0V").connect().power(ON).APPLY(); 
	rdk::Timer::WAIT(5e-3);

	EA_offset = rdk::MMXH::PMU("EN_mmxh_pmu").MEAS_V(100);	//Expected EAOUT=0.6V
	
	// Test Mode Out	
	I2C_Write(0x6A,0x00); 
	rdk::Timer::WAIT(1e-3); // EXIT test mode	
	
	// clean up
	MMXH_PMU_Slewrate("VIN_mmxh_pmu" ,"Slow");  //for spike
	MMXH_PMU_Slewrate("VOUT_mmxh_pmu","Slow");  //for spike

	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").APPLY();
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").APPLY();
	rdk::Timer::WAIT(3e-3);
	DPIN_Levelset("MODE_mdm",OPEN_,OFF_);
	rdk::MMXH::PMU("EN_mmxh_pmu").disconnect().power(OFF).APPLY();	
	rdk::MMXH::PMU("VIN_mmxh_pmu").disconnect().power(OFF).APPLY();	
	rdk::MMXH::PMU("VOUT_mmxh_pmu").disconnect().power(OFF).APPLY();	
	rdk::CW("K_ALL").off().APPLY();
	rdk::Timer::WAIT(3e-3);
	
	MMXH_PMU_Slewrate("VIN_mmxh_pmu" ,"VeryFast");  //for spike
	MMXH_PMU_Slewrate("VOUT_mmxh_pmu","VeryFast");  //for spike

	//Judge
	result |= Judge(test_id,"EA_offset", "T_EA_OFFSET_LS.EA_offset", EA_offset,"SoftBins.BIN22"); if(RscDUTs(DUT_ACTIVE).isEmpty())return result; 

	return result;
}
	
RsltAllDUTCtnr
TPG::T_COMPARATOR()
{
	//TestConditions.apply();
	RsltAllDUTCtnr result;
	test_id = 1300;	
	
	ValDUT PWM_Comparator_L;
	ValDUT PWM_Comparator_H;
	ValDUT PFM_Comparator_L;
	ValDUT PFM_Comparator_H;

// PWM Setup
    rdk::CW("K2;K12;K13;K16").on().APPLY(); // MODE_MDM, VOUT_CAP, VIN_CAP, EN_MMXH //Without K14, Using MFHP test -> DUT16 Fail.
	rdk::Timer::WAIT(3e-3);

	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("0V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").connect().power(ON).APPLY(); 
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("0V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").connect().power(ON).APPLY();	
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("0V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").connect().power(ON).APPLY();
	rdk::Timer::WAIT(3e-3);

	//IC Turn on
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("1.8V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY(); //For spike
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("1.8V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();	//For spike
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("1.8V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();	//For spike

	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").APPLY();
	DPIN_Levelset("MODE_mdm","3.6V", "0.0V", "1.8V", "1.8V",CLOSE_,ON_);
	rdk::Timer::WAIT(15e-3); 


// Test Mode In	
	I2C_Write(0x6A,0x5A); 
	rdk::Timer::WAIT(1e-3); // enter test mode 
	I2C_Write(0x6A,0xA5);
	rdk::Timer::WAIT(1e-3); // enter test mode   
	I2C_Write(0x23,0x90);
	rdk::Timer::WAIT(3e-3); // set the readback path

	MMXH_PMU_Slewrate("EN_mmxh_pmu"  ,"Slow");  //for spike	
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").APPLY(); //EN Float-1
	rdk::Timer::WAIT(3e-3);
	rdk::MMXH::PMU("EN_mmxh_pmu").isvm("0.0mA",rdkenum::R3mA,rdkenum::R7V,"7.0V","-7V").APPLY(); //EN Float-2
	rdk::Timer::WAIT(3e-3);
	MMXH_PMU_Slewrate("EN_mmxh_pmu"  ,"VeryFast");  //for spike	
	

	I2C_Write(0x25,0x01); 
	rdk::Timer::WAIT(1e-3); //(T_DISABLE_DRVR=1);
	I2C_Write(0x26,0x04); 
	rdk::Timer::WAIT(1e-3); //(T_Force_CCM=1);
	I2C_Write(0x23,0x0C); 
	rdk::Timer::WAIT(1e-3); //mux out CMP_OUT(MUXSEL=2'b00, AD_MUXO_EN=1,ENMUX=3'b100)

// PWM_L measure
	rdk::MMXH::PMU("LX_mmxh_pmu").vsim("1.22V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").connect().power(ON).APPLY(); //This Range best	
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("1.22V",rdkenum::R2V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY(); //This Range best
	rdk::Timer::WAIT(5e-3);

	PWM_Comparator_L = rdk::MMXH::PMU("EN_mmxh_pmu").MEAS_V(100);	//expected measurement on EN = 0V (logic LOW);

// PWM_H measure
	rdk::MMXH::PMU("LX_mmxh_pmu").vsim("1.18V",rdkenum::R7V,rdkenum::R30mA,"30.0mA","-30.0mA").APPLY(); //This Range best	
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("1.18V",rdkenum::R2V,rdkenum::R30mA,"30.0mA","-30.0mA").APPLY();
	rdk::Timer::WAIT(5e-3);

	PWM_Comparator_H = rdk::MMXH::PMU("EN_mmxh_pmu").MEAS_V(100);	//expected measurement on EN = 3.6V (logic HIGH)

// Test Mode Out	
	I2C_Write(0x6A,0x00); 
	rdk::Timer::WAIT(1e-3); // EXIT test mode

// clean up
	MMXH_PMU_Slewrate("VIN_mmxh_pmu" ,"Slow");  //for spike
	MMXH_PMU_Slewrate("VOUT_mmxh_pmu","Slow");  //for spike

	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("0.0V",rdkenum::R2V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();
	rdk::MMXH::PMU("LX_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();
	rdk::Timer::WAIT(3e-3);
	DPIN_Levelset("MODE_mdm",OPEN_,OFF_);
	rdk::MMXH::PMU("EN_mmxh_pmu").disconnect().power(OFF).APPLY();	
	rdk::MMXH::PMU("VIN_mmxh_pmu").disconnect().power(OFF).APPLY();	
	rdk::MMXH::PMU("VOUT_mmxh_pmu").disconnect().power(OFF).APPLY();	
	rdk::MMXH::PMU("LX_mmxh_pmu").disconnect().power(OFF).APPLY();	
	rdk::CW("K_ALL").off().APPLY();
	rdk::Timer::WAIT(3e-3);

	MMXH_PMU_Slewrate("VIN_mmxh_pmu" ,"VeryFast");  //for spike
	MMXH_PMU_Slewrate("VOUT_mmxh_pmu","VeryFast");  //for spike

	result |= Judge(test_id,"PWM_Comparator_L", "T_COMPARATOR_LS.PWM_Comparator_L", PWM_Comparator_L,"SoftBins.BIN23"); if(RscDUTs(DUT_ACTIVE).isEmpty())return result; test_id++;
	result |= Judge(test_id,"PWM_Comparator_H", "T_COMPARATOR_LS.PWM_Comparator_H", PWM_Comparator_H,"SoftBins.BIN23"); if(RscDUTs(DUT_ACTIVE).isEmpty())return result; test_id++;


// PFM Setup
    rdk::CW("K2;K12;K13;K16").on().APPLY(); // MODE_MDM, VOUT_CAP, VIN_CAP, EN_MMXH
	rdk::Timer::WAIT(1e-3);

	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("0V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").connect().power(ON).APPLY(); 
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("0V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").connect().power(ON).APPLY();	
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("0V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").connect().power(ON).APPLY();
	rdk::Timer::WAIT(3e-3);

	//IC Turn on
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("1.8V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY(); //For spike
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("1.8V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();	//For spike
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("1.8V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();	//For spike

	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").APPLY();
	DPIN_Levelset("MODE_mdm","3.6V", "0.0V", "1.8V", "1.8V",CLOSE_,ON_);
	rdk::Timer::WAIT(15e-3);

// Test Mode In	
	I2C_Write(0x6A,0x5A); 
	rdk::Timer::WAIT(1e-3); // enter test mode 
	I2C_Write(0x6A,0xA5); 
	rdk::Timer::WAIT(1e-3); // enter test mode   
	I2C_Write(0x23,0x90); 
	rdk::Timer::WAIT(3e-3); // set the readback path

	MMXH_PMU_Slewrate("EN_mmxh_pmu"  ,"Slow");  //for spike	
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").APPLY(); //EN Float-1
	rdk::Timer::WAIT(3e-3);
	rdk::MMXH::PMU("EN_mmxh_pmu").isvm("0.0uA",rdkenum::R3mA,rdkenum::R7V,"7.0V","-7.0V").APPLY(); //EN Float-2
	rdk::Timer::WAIT(3e-3);
	MMXH_PMU_Slewrate("EN_mmxh_pmu"  ,"VeryFast");  //for spike

	I2C_Write(0x25,0x09); 
	rdk::Timer::WAIT(1e-3); //(T_DISABLE_DRVR=1);
	I2C_Write(0x23,0x0C); 
	rdk::Timer::WAIT(1e-3); //mux out CMP_OUT(MUXSEL=2'b00, AD_MUXO_EN=1,ENMUX=3'b100)


// PFM_L measure
	rdk::MMXH::PMU("LX_mmxh_pmu").vsim("1.22V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").connect().power(ON).APPLY();
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("1.22V",rdkenum::R2V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();
	rdk::Timer::WAIT(5e-3);

	PFM_Comparator_L = rdk::MMXH::PMU("EN_mmxh_pmu").MEAS_V(100);

// PFM_H measure
	rdk::MMXH::PMU("LX_mmxh_pmu").vsim("1.18V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("1.18V",rdkenum::R2V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();
	rdk::Timer::WAIT(5e-3);

	PFM_Comparator_H = rdk::MMXH::PMU("EN_mmxh_pmu").MEAS_V(100);	//expected measurement on EN = 3.6V (logic HIGH)

// Test Mode Out	
	I2C_Write(0x6A,0x00); 
	rdk::Timer::WAIT(1e-3); // EXIT test mode

// clean up
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("0.0V",rdkenum::R2V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();
	rdk::MMXH::PMU("LX_mmxh_pmu").vsim("0.0V",rdkenum::R2V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();
	rdk::Timer::WAIT(3e-3);
	DPIN_Levelset("MODE_mdm",OPEN_,OFF_);
	rdk::MMXH::PMU("EN_mmxh_pmu").disconnect().power(OFF).APPLY();	
	rdk::MMXH::PMU("VIN_mmxh_pmu").disconnect().power(OFF).APPLY();	
	rdk::MMXH::PMU("VOUT_mmxh_pmu").disconnect().power(OFF).APPLY();	
	rdk::MMXH::PMU("LX_mmxh_pmu").disconnect().power(OFF).APPLY();
	rdk::CW("K_ALL").off().APPLY();
	rdk::Timer::WAIT(3e-3);

	result |= Judge(test_id,"PFM_Comparator_L", "T_COMPARATOR_LS.PFM_Comparator_L", PFM_Comparator_L,"SoftBins.BIN23"); if(RscDUTs(DUT_ACTIVE).isEmpty())return result; test_id++;
	result |= Judge(test_id,"PFM_Comparator_H", "T_COMPARATOR_LS.PFM_Comparator_H", PFM_Comparator_H,"SoftBins.BIN23"); if(RscDUTs(DUT_ACTIVE).isEmpty())return result; test_id++;


	return result;
} // T_COMPARATOR

RsltAllDUTCtnr
TPG::T_NEG_CL()
{
	//TestConditions.apply();
	RsltAllDUTCtnr result;
	test_id = 1400;	
	
	RscTestCondition MODE_Timing("(Timing_MODE)");
	timing_set(Timming_Speed,MODE_Timing);

	ValDUT	neg_CL;

// Setup
    rdk::CW("K2;K13;K16").on().APPLY(); // MODE_MDM, VIN_CAP, EN_MMXH
	rdk::Timer::WAIT(3e-3);

	//IC Turn on
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("1.8V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").connect().power(ON).APPLY(); //For spike
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("1.8V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").connect().power(ON).APPLY();	//For spike
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("1.8V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").connect().power(ON).APPLY();	//For spike

	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").APPLY();
	DPIN_Levelset("MODE_mdm","3.6V", "0.0V", "1.8V", "1.8V",CLOSE_,ON_);
	rdk::Timer::WAIT(15e-3);

// Test Mode In	
	I2C_Write(0x6A,0x5A); 
	rdk::Timer::WAIT(1e-3); // enter test mode 
	I2C_Write(0x6A,0xA5); 
	rdk::Timer::WAIT(3e-3); // enter test mode   

	MMXH_PMU_Slewrate("EN_mmxh_pmu"  ,"Slow");  //for spike
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").APPLY(); //EN Float-1
	rdk::Timer::WAIT(3e-3);
	rdk::MMXH::PMU("EN_mmxh_pmu").isvm("0.0uA",rdkenum::R3mA,rdkenum::R7V,"7.0V","-7.0V").APPLY(); //EN Float-2
	rdk::Timer::WAIT(3e-3);
	MMXH_PMU_Slewrate("EN_mmxh_pmu"  ,"VeryFast");  //for spike

	I2C_Write(0x25,0x50); 
	rdk::Timer::WAIT(1e-3); // T_LS_ON=1, T_PLIMOFF=1);
	I2C_Write(0x26,0xE4); 
	rdk::Timer::WAIT(1e-3); // ENDRV_SGMT=4'b1110, T_Forced_CCM=1)(1/4 of driver);
	I2C_Write(0x23,0x0E); 
	rdk::Timer::WAIT(1e-3); // mux out INEG_CMP;

// LX_rising
	rdk::MFHP::PMU("LX_mfhp_pmu").isvm("0.05A",rdkenum::R3A,rdkenum::R7V,"7.0V","-7.0V").connect(rdkenum::PORTA,rdkenum::PORTA).power(ON).APPLY();
	rdk::Timer::WAIT(5e-3);

//EN Low TO High / threshold current = 175mA. 
	neg_CL = PMU_Search("LX_mfhp_pmu","30.0mA","470.0mA","5.0mA","0.2e-3","EN_mmxh_pmu",Rising_,"1.0V"); 

	rdk::MFHP::PMU("LX_mfhp_pmu").isvm("0.0A",rdkenum::R3A,rdkenum::R7V,"7.0V","-7.0V").APPLY();
	rdk::Timer::WAIT(3e-3);

// Test Mode Out	
	I2C_Write(0x21,0x00); 
	rdk::Timer::WAIT(1e-3); 
	
// clean up
	MMXH_PMU_Slewrate("VIN_mmxh_pmu" ,"Slow");  //for spike
	MMXH_PMU_Slewrate("VOUT_mmxh_pmu","Slow");  //for spike

	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").APPLY();
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").APPLY();
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsvim("0.0V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").APPLY();
	rdk::Timer::WAIT(3e-3);
	DPIN_Levelset("MODE_mdm",OPEN_,OFF_);
	rdk::MFHP::PMU("LX_mfhp_pmu").disconnect().power(OFF).APPLY();
	rdk::MMXH::PMU("EN_mmxh_pmu").disconnect().power(OFF).APPLY();	
	rdk::MMXH::PMU("VIN_mmxh_pmu").disconnect().power(OFF).APPLY();	
	rdk::MMXH::PMU("VOUT_mmxh_pmu").disconnect().power(OFF).APPLY();	
	rdk::CW("K_ALL").off().APPLY();
	rdk::Timer::WAIT(3e-3);

	MMXH_PMU_Slewrate("VIN_mmxh_pmu" ,"VeryFast");  //for spike
	MMXH_PMU_Slewrate("VOUT_mmxh_pmu","VeryFast");  //for spike

	result |= Judge(test_id,"neg_CL", "T_NEG_CL_LS.neg_CL", neg_CL,"SoftBins.BIN24"); if(RscDUTs(DUT_ACTIVE).isEmpty())return result;  test_id++;

	return result;
} // T_NEG_Current_Limit


RsltAllDUTCtnr
TPG::T_IIN()
{
	//TestConditions.apply();
	RsltAllDUTCtnr result;
	RscTestCondition MODE_Timing("(Timing_MODE)");
	timing_set(Timming_Speed,MODE_Timing);

	test_id = 1500;	

	ValDUT IQ_2p7 = 100;
	ValDUT IQ_3p6 = 100; 
	ValDUT IQ_5p5 = 100;

    rdk::CW("K1;K2;K12;K13;K16").on().APPLY(); // MODE_MMXH, MODE_MDM, EN_MMXH, VIN_CAP, VOUT_CAP - MODE MDM MMXH 중복 연결
	rdk::Timer::WAIT(3e-3); 

	//IC Turn on
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("1.8V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").connect().power(ON).APPLY(); //For spike
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("1.8V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").connect().power(ON).APPLY();	//For spike
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("1.8V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").connect().power(ON).APPLY();	//For spike

	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").APPLY();
	DPIN_Levelset("MODE_mdm","3.6V", "0.0V", "1.8V", "1.8V",CLOSE_,ON_);
	rdk::Timer::WAIT(15e-3); 
	
// Test Mode In	
	I2C_Write(0x6A,0x5A); 
	rdk::Timer::WAIT(1e-3); // enter test mode 
	I2C_Write(0x6A,0xA5); 
	rdk::Timer::WAIT(3e-3); // enter test mode   

	I2C_Write(0x25,0x08); 
	rdk::Timer::WAIT(1e-3); // (T_FORCED_LPWR=1);
	I2C_Write(0x6A,0x00); 
	rdk::Timer::WAIT(1e-3); // 

	DPIN_Levelset("MODE_mdm",OPEN_,OFF_);
	rdk::Timer::WAIT(1e-3);

	//MMXH_PMU_Slewrate("MODE_mmxh_pmu","Slow");  //for spike
	rdk::MMXH::PMU("MODE_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R30mA,"3.0mA","-3.0mA").connect().power(ON).APPLY();
	rdk::Timer::WAIT(3e-3);
	//MMXH_PMU_Slewrate("MODE_mmxh_pmu","VeryFast");  //for spike

// 3p6V Setup	
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();//For spike
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R300uA,"300.0uA","-300.0uA").APPLY();
	rdk::Timer::WAIT(60e-3);

	IQ_3p6 = rdk::MMXH::PMU("VIN_mmxh_pmu").MEAS_I(2000);

// 2p7V Setup	
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("2.7V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").APPLY();
	rdk::Timer::WAIT(3e-3);
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("2.7V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("2.7V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();
	rdk::Timer::WAIT(10e-3);

	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("2.7V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").APPLY();
	rdk::Timer::WAIT(5e-3);

	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("2.7V",rdkenum::R7V,rdkenum::R300uA,"300.0uA","-300.0uA").APPLY();
	rdk::Timer::WAIT(50e-3); 

	IQ_2p7 = rdk::MMXH::PMU("VIN_mmxh_pmu").MEAS_I(1700);

// 5p5V Setup	
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("2.7V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY(); //For spike
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("2.7V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();	//For spike
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("2.7V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").APPLY();			//For spike

	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("4.5V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY(); //For spike
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("4.5V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();	//For spike
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("4.5V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").APPLY();			//For spike

	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("5.5V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").APPLY();
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("5.5V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("5.5V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();
	rdk::Timer::WAIT(10e-3);

	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("5.5V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").APPLY();
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("5.5V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").APPLY();
	rdk::Timer::WAIT(5e-3);


	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("5.5V",rdkenum::R7V,rdkenum::R300uA,"300.0uA","-300.0uA").APPLY();
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("5.5V",rdkenum::R7V,rdkenum::R300uA,"300.0uA","-300.0uA").APPLY();
	rdk::Timer::WAIT(60e-3); 

	IQ_5p5 = rdk::MMXH::PMU("VIN_mmxh_pmu").MEAS_I(1700);


	I2C_Write(0x6A,0x00); 
	rdk::Timer::WAIT(1e-3); //Exit Test Mode

// clean up
	MMXH_PMU_Slewrate("VIN_mmxh_pmu" ,"Slow");   //for spike
	MMXH_PMU_Slewrate("VOUT_mmxh_pmu","Slow");   //for spike
	MMXH_PMU_Slewrate("EN_mmxh_pmu"  ,"Slow");   //for spike	

	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").APPLY();
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R300uA,"300.0uA","-300.0uA").APPLY();
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R300uA,"300.0uA","-300.0uA").APPLY();
	rdk::Timer::WAIT(3e-3);
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R240mA,"240.0mA","-240.0mA").APPLY(); //For Spike - Discharge. Mode Pin Spike When VIN Relay off -> on
	rdk::Timer::WAIT(3e-3);
	rdk::MMXH::PMU("MODE_mmxh_pmu").disconnect().power(OFF).APPLY();	
	rdk::MMXH::PMU("EN_mmxh_pmu").disconnect().power(OFF).APPLY();	
	rdk::MMXH::PMU("VIN_mmxh_pmu").disconnect().power(OFF).APPLY();	
	rdk::MMXH::PMU("VOUT_mmxh_pmu").disconnect().power(OFF).APPLY();	
	rdk::CW("K_ALL").off().APPLY();
	rdk::Timer::WAIT(3e-3);

	MMXH_PMU_Slewrate("VIN_mmxh_pmu" ,"VeryFast");   //for spike
	MMXH_PMU_Slewrate("VOUT_mmxh_pmu","VeryFast");   //for spike
	MMXH_PMU_Slewrate("EN_mmxh_pmu"  ,"VeryFast");   //for spike	

	result |= Judge(test_id,"IQ_2p7", "T_IIN_LS.IQ_2p7", IQ_2p7,"SoftBins.BIN25"); if(RscDUTs(DUT_ACTIVE).isEmpty())return result; test_id++; 
	result |= Judge(test_id,"IQ_3p6", "T_IIN_LS.IQ_3p6", IQ_3p6,"SoftBins.BIN25"); if(RscDUTs(DUT_ACTIVE).isEmpty())return result; test_id++; 
	result |= Judge(test_id,"IQ_5p5", "T_IIN_LS.IQ_5p5", IQ_5p5,"SoftBins.BIN25"); if(RscDUTs(DUT_ACTIVE).isEmpty())return result; test_id++;
	


/////ShutDown Current
	ValDUT Ishdn_2p7 = 100;
	ValDUT Ishdn_3p6 = 100; 
	ValDUT Ishdn_5p5 = 100;

	rdk::CW("K1;K16").on().APPLY(); // MODE_MMXH, EN_MMXH
	rdk::Timer::WAIT(3e-3); 


//Common Setup	//MODE, EN 0V
	rdk::MMXH::PMU("MODE_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R300uA,"100.0uA","-100.0uA").connect().power(ON).APPLY();
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R300uA,"100.0uA","-100.0uA").connect().power(ON).APPLY();
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").connect().power(ON).APPLY();

//IC Turn on
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();	//For spike
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("2.5V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();	//For spike
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("4.5V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();	//For spike

	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("5.5V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();
	rdk::Timer::WAIT(5e-3);

// 5p5V Shut Down 	
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("5.5V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").APPLY();
	rdk::Timer::WAIT(3e-3);
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("5.5V",rdkenum::R7V,rdkenum::R30uA,"30.0uA","-30.0uA").APPLY();
	rdk::Timer::WAIT(3e-3);

	Ishdn_5p5 = rdk::MMXH::PMU("VIN_mmxh_pmu").MEAS_I(100);	

// 3p6V Shut Down 		
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").APPLY();
	rdk::Timer::WAIT(3e-3);
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R30uA,"30.0uA","-30.0uA").APPLY();
	rdk::Timer::WAIT(3e-3);

	Ishdn_3p6 = rdk::MMXH::PMU("VIN_mmxh_pmu").MEAS_I(100);	


// 2p7V Shut Down 		
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("2.7V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").APPLY();
	rdk::Timer::WAIT(3e-3);
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("2.7V",rdkenum::R7V,rdkenum::R30uA,"30.0uA","-30.0uA").APPLY();
	rdk::Timer::WAIT(3e-3);

	Ishdn_2p7 = rdk::MMXH::PMU("VIN_mmxh_pmu").MEAS_I(100);	

// clean up
	MMXH_PMU_Slewrate("VIN_mmxh_pmu" ,"Slow");   //for spike

	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R30uA,"30.0uA","-30.0uA").APPLY();
	rdk::Timer::WAIT(3e-3);
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R240mA,"240.0mA","-240.0mA").APPLY(); //For Spike - Discharge. Mode Pin Spike When VIN Relay off -> on
	rdk::Timer::WAIT(3e-3);
	rdk::MMXH::PMU("VIN_mmxh_pmu").disconnect().power(OFF).APPLY();	
	rdk::MMXH::PMU("EN_mmxh_pmu").disconnect().power(OFF).APPLY();	
	rdk::MMXH::PMU("MODE_mmxh_pmu").disconnect().power(OFF).APPLY();	
	rdk::Timer::WAIT(3e-3);	
	rdk::CW("K_ALL").off().APPLY();
	rdk::Timer::WAIT(3e-3);
	
	MMXH_PMU_Slewrate("VIN_mmxh_pmu" ,"VeryFast");   //for spike

	result |= Judge(test_id,"Ishdn_2p7", "T_IIN_LS.Ishdn_2p7", Ishdn_2p7,"SoftBins.BIN26"); if(RscDUTs(DUT_ACTIVE).isEmpty())return result; test_id++; 
	result |= Judge(test_id,"Ishdn_3p6", "T_IIN_LS.Ishdn_3p6", Ishdn_3p6,"SoftBins.BIN26"); if(RscDUTs(DUT_ACTIVE).isEmpty())return result; test_id++; 
	result |= Judge(test_id,"Ishdn_5p5", "T_IIN_LS.Ishdn_5p5", Ishdn_5p5,"SoftBins.BIN26"); if(RscDUTs(DUT_ACTIVE).isEmpty())return result; test_id++; 

	return result;
} //T_IIN



RsltAllDUTCtnr
TPG::T_UVLO_SEARCH()
{
	RsltAllDUTCtnr result;
	test_id = 1600;	

	ValDUT	UVLO_R;
	ValDUT	UVLO_F;
	ValDUT	UVLO_hys;

// Setup
    rdk::CW("K2;K13;K16").on().APPLY(); // MODE_MDM, , VIN_CAP ,  EN_MMXH
	rdk::Timer::WAIT(3e-3);

	//IC Turn on
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").connect().power(ON).APPLY();
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").connect().power(ON).APPLY();
	rdk::Timer::WAIT(5e-3);

	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").connect().power(ON).APPLY();
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").connect().power(ON).APPLY();
	rdk::Timer::WAIT(5e-3); 
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").connect().power(ON).APPLY();
	DPIN_Levelset("MODE_mdm","3.6V", "0.0V", "1.8V", "1.8V",CLOSE_,ON_);
	rdk::Timer::WAIT(15e-3); 
	
// Test Mode In	
	I2C_Write(0x6A,0x5A); 
	rdk::Timer::WAIT(1e-3); // enter test mode 
	I2C_Write(0x6A,0xA5); 
	rdk::Timer::WAIT(3e-3); // enter test mode   

//EN FLOAT
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").connect().power(ON).APPLY(); //EN Float-1
	rdk::Timer::WAIT(3e-3);
	rdk::MMXH::PMU("EN_mmxh_pmu").isvm("0.0uA",rdkenum::R3mA,rdkenum::R7V,"7.0V","-7.0V").connect().power(ON).APPLY();//EN Float-2
	rdk::Timer::WAIT(3e-3);
	
	I2C_Write(0x24,0x04); 
	rdk::Timer::WAIT(1e-3); // disable BUCK block(DIS_EN=1)
	I2C_Write(0x23,0x4A); 
	rdk::Timer::WAIT(1e-3); // mux out UVLO_OK(MUXSEL=2'b01, AD_MUXO_EN=1, ENMUX=3'b010)

// UVLO_F		
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("2.6V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").connect().power(ON).APPLY();
	rdk::Timer::WAIT(5e-3);

	UVLO_F = PMU_Search("VIN_mmxh_pmu","2.60V","2.0V","20.0mV","0.5e-3","EN_mmxh_pmu",Falling_,"1.0V"); 
	
// UVLO_R
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("2.0V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").connect().power(ON).APPLY();
	rdk::Timer::WAIT(5e-3);
	
	UVLO_R = PMU_Search("VIN_mmxh_pmu","2.0V","3.0V","20.0mV","0.5e-3","EN_mmxh_pmu",Rising_,"1.8V"); 

	for(ItrDUTs itrDut(DUT_ACTIVE);!itrDut.isDone();itrDut++) 
	{	 
		UVLO_hys[*itrDut] = UVLO_R[*itrDut].getAsDouble() - UVLO_F[*itrDut].getAsDouble();
	}

// Test Mode Out	
	I2C_Write(0x6A,0x00); 
	rdk::Timer::WAIT(1e-3); // EXIT test mode

// clean up
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R300uA,"300.0uA","-300.0uA").connect().power(ON).APPLY();
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").connect().power(ON).APPLY();
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").connect().power(ON).APPLY();
	rdk::Timer::WAIT(3e-3);
	DPIN_Levelset("MODE_mdm",OPEN_,OFF_);
	rdk::MMXH::PMU("EN_mmxh_pmu").disconnect().power(OFF).APPLY();	
	rdk::MMXH::PMU("VIN_mmxh_pmu").disconnect().power(OFF).APPLY();	
	rdk::MMXH::PMU("VOUT_mmxh_pmu").disconnect().power(OFF).APPLY();	
	rdk::CW("K_ALL").off().APPLY();
	rdk::Timer::WAIT(3e-3);

	result |= Judge(test_id,"UVLO_R", "T_UVLO_SEARCH_LS.UVLO_R", UVLO_R,"SoftBins.BIN27"); if(RscDUTs(DUT_ACTIVE).isEmpty())return result;  test_id++;
	result |= Judge(test_id,"UVLO_F", "T_UVLO_SEARCH_LS.UVLO_F", UVLO_F,"SoftBins.BIN27"); if(RscDUTs(DUT_ACTIVE).isEmpty())return result;  test_id++;
	result |= Judge(test_id,"UVLO_hys", "T_UVLO_SEARCH_LS.UVLO_hys", UVLO_hys,"SoftBins.BIN27"); if(RscDUTs(DUT_ACTIVE).isEmpty())return result;  test_id++;

	return result;
} // T_UVLO_SEARCH




RsltAllDUTCtnr
TPG::T_UVLO_GNG()
{
	RsltAllDUTCtnr result;
	test_id = 1650;	

	ValDUT	UVLO_Set;
	ValDUT	UVLO_R1;
	ValDUT	UVLO_R2;
	ValDUT	UVLO_F1;
	ValDUT	UVLO_F2;

	RscTestCondition MODE_Timing("(Timing_MODE)");
	timing_set(Timming_Speed,MODE_Timing);

// Setup
	rdk::CW("K2;K13;K16").on().APPLY(); // MODE_MDM, VIN_CAP, EN_MMXH
	rdk::Timer::WAIT(3e-3);
	
//IC Turn on
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("1.8V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").connect().power(ON).APPLY(); //For spike
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("1.8V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").connect().power(ON).APPLY();	//For spike
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("1.8V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").connect().power(ON).APPLY();			//For spike

	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").APPLY();
	DPIN_Levelset("MODE_mdm","3.6V", "0.0V", "1.8V", "1.8V",CLOSE_,ON_);
	rdk::Timer::WAIT(15e-3); 
	
// Test Mode In	
	I2C_Write(0x6A,0x5A); 
	rdk::Timer::WAIT(1e-3); // enter test mode 
	I2C_Write(0x6A,0xA5); 
	rdk::Timer::WAIT(3e-3); // enter test mode   

//EN FLOAT
	MMXH_PMU_Slewrate("EN_mmxh_pmu"  ,"Slow");  //for spike	
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").APPLY(); //EN Float-1
	rdk::Timer::WAIT(3e-3);
	rdk::MMXH::PMU("EN_mmxh_pmu").isvm("0.0uA",rdkenum::R3mA,rdkenum::R7V,"7.0V","-7.0V").APPLY();//EN Float-2
	rdk::Timer::WAIT(3e-3);
	MMXH_PMU_Slewrate("EN_mmxh_pmu"  ,"VeryFast");  //for spike	
	
	I2C_Write(0x24,0x04); 
	rdk::Timer::WAIT(1e-3); // disable BUCK block(DIS_EN=1)
	I2C_Write(0x23,0x4A); 
	rdk::Timer::WAIT(1e-3); // mux out UVLO_OK(MUXSEL=2'b01, AD_MUXO_EN=1, ENMUX=3'b010)

//UVLO SET
	UVLO_Set = rdk::MMXH::PMU("EN_mmxh_pmu").MEAS_V(100);

//UVLO F1
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("2.29V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("2.29V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();

	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("2.29V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").APPLY();
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("2.29V",rdkenum::R7V,rdkenum::R3mA,"3mA","-3mA").APPLY();//VIN 3mA range's needed.
	rdk::Timer::WAIT(10e-3);

	UVLO_F1 = rdk::MMXH::PMU("EN_mmxh_pmu").MEAS_V(100);

//UVLO F2
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("1.91V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").APPLY();
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("1.91V",rdkenum::R7V,rdkenum::R3mA,"3mA","-3mA").APPLY();
	rdk::Timer::WAIT(10e-3);

	UVLO_F2 = rdk::MMXH::PMU("EN_mmxh_pmu").MEAS_V(100);

//UVLO R1
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("2.11V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").APPLY();
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("2.11V",rdkenum::R7V,rdkenum::R3mA,"3mA","-3mA").APPLY();
	rdk::Timer::WAIT(10e-3);

	UVLO_R1 = rdk::MMXH::PMU("EN_mmxh_pmu").MEAS_V(100);

//UVLO R2
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("2.49V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").APPLY();
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("2.49V",rdkenum::R7V,rdkenum::R3mA,"3mA","-3mA").APPLY();
	rdk::Timer::WAIT(10e-3);

	UVLO_R2 = rdk::MMXH::PMU("EN_mmxh_pmu").MEAS_V(100);


// Test Mode Out	
	I2C_Write(0x6A,0x00); 
	rdk::Timer::WAIT(1e-3); // EXIT test mode


// clean up
	MMXH_PMU_Slewrate("VIN_mmxh_pmu" ,"Slow");   //for spike
	MMXH_PMU_Slewrate("VOUT_mmxh_pmu","Slow");   //for spike

	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").APPLY();
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").APPLY();
	rdk::Timer::WAIT(3e-3);
	DPIN_Levelset("MODE_mdm",OPEN_,OFF_);
	rdk::MMXH::PMU("EN_mmxh_pmu").disconnect().power(OFF).APPLY();	
	rdk::MMXH::PMU("VIN_mmxh_pmu").disconnect().power(OFF).APPLY();	
	rdk::MMXH::PMU("VOUT_mmxh_pmu").disconnect().power(OFF).APPLY();	
	rdk::CW("K_ALL").off().APPLY();
	rdk::Timer::WAIT(3e-3);

	MMXH_PMU_Slewrate("VIN_mmxh_pmu" ,"VeryFast");   //for spike
	MMXH_PMU_Slewrate("VOUT_mmxh_pmu","VeryFast");   //for spike

	result |= Judge(test_id,"UVLO_Set", "T_UVLO_GNG_LS.UVLO_Set", UVLO_Set,"SoftBins.BIN27"); if(RscDUTs(DUT_ACTIVE).isEmpty())return result;  test_id++;
	result |= Judge(test_id,"UVLO_R1", "T_UVLO_GNG_LS.UVLO_R1",	UVLO_R1,"SoftBins.BIN27"); if(RscDUTs(DUT_ACTIVE).isEmpty())return result;  test_id++;
	result |= Judge(test_id,"UVLO_R2", "T_UVLO_GNG_LS.UVLO_R2",	UVLO_R2,"SoftBins.BIN27"); if(RscDUTs(DUT_ACTIVE).isEmpty())return result;  test_id++;
	result |= Judge(test_id,"UVLO_F1", "T_UVLO_GNG_LS.UVLO_F1",	UVLO_F1,"SoftBins.BIN27"); if(RscDUTs(DUT_ACTIVE).isEmpty())return result;  test_id++;
	result |= Judge(test_id,"UVLO_F2", "T_UVLO_GNG_LS.UVLO_F2",	UVLO_F2,"SoftBins.BIN27"); if(RscDUTs(DUT_ACTIVE).isEmpty())return result;  test_id++;



	return result;
} // T_UVLO_GNG



RsltAllDUTCtnr
TPG::T_OVP_SEARCH()
{
	RsltAllDUTCtnr result;
	test_id = 1700;	
	ValDUT	OVP_R;
	ValDUT	OVP_F;
	ValDUT	OVP_hys;

// Setup
    rdk::CW("K2;K13;K16").on().APPLY(); // MODE_MDM, VIN_CAP, EN_MMXH
	rdk::Timer::WAIT(3e-3);

//IC Turn on
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("5.3V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").connect().power(ON).APPLY();
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("5.3V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").connect().power(ON).APPLY();
	rdk::Timer::WAIT(5e-3); 

	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("5.3V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").connect().power(ON).APPLY();
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("5.3V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").connect().power(ON).APPLY();
	rdk::Timer::WAIT(5e-3); 
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").connect().power(ON).APPLY();
	DPIN_Levelset("MODE_mdm","3.6V", "0.0V", "1.8V", "1.8V",CLOSE_,ON_);
	rdk::Timer::WAIT(15e-3); 
	
// Test Mode In	
	I2C_Write(0x6A,0x5A); 
	rdk::Timer::WAIT(1e-3); // enter test mode 
	I2C_Write(0x6A,0xA5); 
	rdk::Timer::WAIT(3e-3); // enter test mode   

//EN FLOAT
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").connect().power(ON).APPLY(); //EN Float-1
	rdk::Timer::WAIT(3e-3);
	rdk::MMXH::PMU("EN_mmxh_pmu").isvm("0.0uA",rdkenum::R3mA,rdkenum::R7V,"7.0V","-7.0V").connect().power(ON).APPLY();//EN Float-2
	rdk::Timer::WAIT(3e-3);
	
	I2C_Write(0x24,0x04); 
	rdk::Timer::WAIT(1e-3); // disable BUCK block(DIS_EN=1)
	I2C_Write(0x23,0x8A); 
	rdk::Timer::WAIT(1e-3); // mux out VO_UV_FAULT(MUXSEL=2'b01, AD_MUXO_EN=1, ENMUX=3'b011)

	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("5.3V",rdkenum::R7V,rdkenum::R30mA,"30.0mA","-30.0mA").connect().power(ON).APPLY();
	rdk::Timer::WAIT(3e-3);

// OVP_R		
	OVP_R = PMU_Search("VIN_mmxh_pmu","5.30V","5.90V","20.0mV","0.2e-3","EN_mmxh_pmu",Falling_,"3.0V"); 
	rdk::Timer::WAIT(1e-3);

// OVP_F
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("5.9V",rdkenum::R7V,rdkenum::R30mA,"30.0mA","-30.0mA").connect().power(ON).APPLY();
	rdk::Timer::WAIT(3e-3);

	OVP_F = PMU_Search("VIN_mmxh_pmu","5.9V","5.3V","20.0mV","0.2e-3","EN_mmxh_pmu",Rising_,"3.0V");

	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R30mA,"30.0mA","-30.0mA").connect().power(ON).APPLY();
	rdk::Timer::WAIT(1e-3);

// Test Mode Out	
	I2C_Write(0x6A,0x00); 
	rdk::Timer::WAIT(1e-3); // EXIT test mode

// clean up
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R30uA,"30.0uA","-30.0uA").connect().power(ON).APPLY();
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").connect().power(ON).APPLY();
	rdk::Timer::WAIT(3e-3);
	DPIN_Levelset("MODE_mdm",OPEN_,OFF_);
	rdk::MMXH::PMU("EN_mmxh_pmu").disconnect().power(OFF).APPLY();	
	rdk::MMXH::PMU("VIN_mmxh_pmu").disconnect().power(OFF).APPLY();	
	rdk::MMXH::PMU("VOUT_mmxh_pmu").disconnect().power(OFF).APPLY();	
	rdk::CW("K_ALL").off().APPLY();
	rdk::Timer::WAIT(3e-3);


	for(ItrDUTs itrDut(DUT_ACTIVE);!itrDut.isDone();itrDut++) 
	{	 
		OVP_hys[*itrDut] = OVP_R[*itrDut].getAsDouble() - OVP_F[*itrDut].getAsDouble();
	}

	result |= Judge(test_id,"OVP_R",   "T_OVP_SEARCH_LS.OVP_R",     OVP_R,"SoftBins.BIN28"); if(RscDUTs(DUT_ACTIVE).isEmpty())return result;  test_id++;
	result |= Judge(test_id,"OVP_F",   "T_OVP_SEARCH_LS.OVP_F",     OVP_F,"SoftBins.BIN28"); if(RscDUTs(DUT_ACTIVE).isEmpty())return result;  test_id++;
	result |= Judge(test_id,"OVP_hys", "T_OVP_SEARCH_LS.OVP_hys", OVP_hys,"SoftBins.BIN28"); if(RscDUTs(DUT_ACTIVE).isEmpty())return result;  test_id++;

	return result;
} // T_OVP_SEARCH


RsltAllDUTCtnr
TPG::T_OVP_GNG()
{
	RsltAllDUTCtnr result;
	test_id = 1750;	
	ValDUT	OVP_Set;
	ValDUT	OVP_R1;
	ValDUT	OVP_R2;
	ValDUT	OVP_F1;

	RscTestCondition MODE_Timing("(Timing_MODE)");
	timing_set(Timming_Speed,MODE_Timing);

// Setup
    rdk::CW("K2;K13;K16").on().APPLY(); // MODE_MDM, VIN_CAP, EN_MMXH
	rdk::Timer::WAIT(3e-3);

//IC Turn on
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("2.5V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").connect().power(ON).APPLY(); //For spike
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("2.5V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").connect().power(ON).APPLY();	//For spike
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("1.8V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").connect().power(ON).APPLY();	//For spike

	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("4.5V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY(); //For spike
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("4.5V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();	//For spike
	
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("5.3V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("5.3V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").APPLY();
	DPIN_Levelset("MODE_mdm","3.6V", "0.0V", "1.8V", "1.8V",CLOSE_,ON_);
	rdk::Timer::WAIT(15e-3); 
	
// Test Mode In	
	I2C_Write(0x6A,0x5A); 
	rdk::Timer::WAIT(1e-3); // enter test mode 
	I2C_Write(0x6A,0xA5); 
	rdk::Timer::WAIT(3e-3); // enter test mode   

//EN FLOAT
	MMXH_PMU_Slewrate("EN_mmxh_pmu"  ,"Slow");  //for spike	
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").APPLY(); //EN Float-1
	rdk::Timer::WAIT(3e-3);
	rdk::MMXH::PMU("EN_mmxh_pmu").isvm("0.0uA",rdkenum::R3mA,rdkenum::R7V,"7.0V","-7.0V").APPLY();//EN Float-2
	rdk::Timer::WAIT(3e-3);
	MMXH_PMU_Slewrate("EN_mmxh_pmu"  ,"VeryFast");  //for spike	
	

	I2C_Write(0x24,0x04); 
	rdk::Timer::WAIT(1e-3); // disable BUCK block(DIS_EN=1)
	I2C_Write(0x23,0x8A); 
	rdk::Timer::WAIT(1e-3); // mux out VO_UV_FAULT(MUXSEL=2'b01, AD_MUXO_EN=1, ENMUX=3'b011)

//OVP SET
	OVP_Set = rdk::MMXH::PMU("EN_mmxh_pmu").MEAS_V(100);

//OVP R1
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("5.5V",rdkenum::R7V,rdkenum::R30mA,"30.0mA","-30.0mA").APPLY();
	rdk::Timer::WAIT(10e-3);

	OVP_R1 = rdk::MMXH::PMU("EN_mmxh_pmu").MEAS_V(100);

//OVP R2
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("5.9V",rdkenum::R7V,rdkenum::R30mA,"30.0mA","-30.0mA").APPLY();
	rdk::Timer::WAIT(10e-3);

	OVP_R2 = rdk::MMXH::PMU("EN_mmxh_pmu").MEAS_V(100);

//OVP F1
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("5.5V",rdkenum::R7V,rdkenum::R30mA,"30.0mA","-30.0mA").APPLY();
	rdk::Timer::WAIT(10e-3);

	OVP_F1 = rdk::MMXH::PMU("EN_mmxh_pmu").MEAS_V(100);

// Test Mode Out	
	I2C_Write(0x6A,0x00); 
	rdk::Timer::WAIT(1e-3); // EXIT test mode

// clean up
	MMXH_PMU_Slewrate("VIN_mmxh_pmu" ,"Slow");  //for spike
	MMXH_PMU_Slewrate("VOUT_mmxh_pmu","Slow");  //for spike

	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R30mA,"30.0mA","-30.0mA").APPLY();
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R30uA,"30.0uA","-30.0uA").APPLY();
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").APPLY();
	rdk::Timer::WAIT(3e-3);
	DPIN_Levelset("MODE_mdm",OPEN_,OFF_);
	rdk::MMXH::PMU("EN_mmxh_pmu").disconnect().power(OFF).APPLY();	
	rdk::MMXH::PMU("VIN_mmxh_pmu").disconnect().power(OFF).APPLY();	
	rdk::MMXH::PMU("VOUT_mmxh_pmu").disconnect().power(OFF).APPLY();	
	rdk::CW("K_ALL").off().APPLY();
	rdk::Timer::WAIT(3e-3);

	MMXH_PMU_Slewrate("VIN_mmxh_pmu" ,"VeryFast");  //for spike
	MMXH_PMU_Slewrate("VOUT_mmxh_pmu","VeryFast");  //for spike


	result |= Judge(test_id,"OVP_Set",  "T_OVP_GNG_LS.OVP_H",     OVP_Set,	"SoftBins.BIN28"); if(RscDUTs(DUT_ACTIVE).isEmpty())return result;  test_id++;
	result |= Judge(test_id,"OVP_R1",   "T_OVP_GNG_LS.OVP_H",     OVP_R1,	"SoftBins.BIN28"); if(RscDUTs(DUT_ACTIVE).isEmpty())return result;  test_id++;
	result |= Judge(test_id,"OVP_R2",   "T_OVP_GNG_LS.OVP_L",     OVP_R2,	"SoftBins.BIN28"); if(RscDUTs(DUT_ACTIVE).isEmpty())return result;  test_id++;
	result |= Judge(test_id,"OVP_F1",   "T_OVP_GNG_LS.OVP_H",     OVP_F1,	"SoftBins.BIN28"); if(RscDUTs(DUT_ACTIVE).isEmpty())return result;  test_id++;

	return result;
} // T_OVP_GNG




RsltAllDUTCtnr
TPG::T_UV_THR_SEARCH()
{
	RsltAllDUTCtnr result;
	test_id = 1800;	
	ValDUT	UV_THR_R;
	ValDUT	UV_THR_F;
	ValDUT	UV_THR_hys;

// Setup
    rdk::CW("K2;K13;K16").on().APPLY(); // MODE_MDM, VIN_CAP, VIN_MFHP(LX_MFHP) EN_MMXH 
	rdk::Timer::WAIT(3e-3);

	//IC Turn on
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("1.2V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").connect().power(ON).APPLY(); //Peer Review 3.6V -> 1.2V (241206)
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").connect().power(ON).APPLY();
	rdk::Timer::WAIT(5e-3);

	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("1.2V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").connect().power(ON).APPLY(); //Peer Review 3.6V -> 1.2V (241206)
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").connect().power(ON).APPLY();
	rdk::Timer::WAIT(5e-3); 
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").connect().power(ON).APPLY();
	DPIN_Levelset("MODE_mdm","3.6V", "0.0V", "1.8V", "1.8V",CLOSE_,ON_);
	rdk::Timer::WAIT(15e-3); 
	
// Test Mode In	
	I2C_Write(0x6A,0x5A); 
	rdk::Timer::WAIT(1e-3); // enter test mode 
	I2C_Write(0x6A,0xA5); 
	rdk::Timer::WAIT(3e-3); // enter test mode   

	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").connect().power(ON).APPLY(); //EN Float-1
	rdk::Timer::WAIT(3e-3);
	rdk::MMXH::PMU("EN_mmxh_pmu").isvm("0.0mA",rdkenum::R300uA,rdkenum::R7V,"7.0V","-7V").connect().power(ON).APPLY(); //EN Float-2
	rdk::Timer::WAIT(3e-3);
	
	I2C_Write(0x24,0x04); 
	rdk::Timer::WAIT(1e-3); // disable BUCK block(DIS_EN=1)
	I2C_Write(0x23,0x4B); 
	rdk::Timer::WAIT(5e-3); //mux out UV_THR_OK(MUXSEL=2'b01, AD_MUXO_EN=1, ENMUX=3'b010)

// UV_THR_R - UV_FAULT_R=threshold = 0.54*VOUT (VOUT = 1.2) => 0.54+ 0.108 = 0.648
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("0.2V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").connect().power(ON).APPLY();
	rdk::Timer::WAIT(1e-3);

	UV_THR_R = PMU_Search("VOUT_mmxh_pmu","0.2V","1.2V"," 5.0mV","0.5e-3","EN_mmxh_pmu",Rising_,"1.8V"); 


// UV_THR_F - UV_FAULT_F threshold = 0.5*VOUT; (VOUT = 1.2) => 0.6
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("0.9V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").connect().power(ON).APPLY();
	rdk::Timer::WAIT(1e-3);

	UV_THR_F = PMU_Search("VOUT_mmxh_pmu","0.9V","0.3V","10.0mV","0.5e-3","EN_mmxh_pmu",Falling_,"1.0V"); 


	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").connect().power(ON).APPLY();
	rdk::Timer::WAIT(1e-3);

// Test Mode Out	
	I2C_Write(0x6A,0x00); 
	rdk::Timer::WAIT(1e-3); // EXIT test mode

// clean up
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").connect().power(ON).APPLY();
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").connect().power(ON).APPLY();
	rdk::Timer::WAIT(3e-3);
	DPIN_Levelset("MODE_mdm",OPEN_,OFF_);
	rdk::MMXH::PMU("EN_mmxh_pmu").disconnect().power(OFF).APPLY();	
	rdk::MMXH::PMU("VIN_mmxh_pmu").disconnect().power(OFF).APPLY();	
	rdk::MMXH::PMU("VOUT_mmxh_pmu").disconnect().power(OFF).APPLY();	
	rdk::CW("K_ALL").off().APPLY();
	rdk::Timer::WAIT(3e-3);


	for(ItrDUTs itrDut(DUT_ACTIVE);!itrDut.isDone();itrDut++) 
	{	 
		UV_THR_hys[*itrDut] = UV_THR_R[*itrDut].getAsDouble() - UV_THR_F[*itrDut].getAsDouble();
	}

	result |= Judge(test_id,"UV_THR_R",   "T_UV_THR_SEARCH_LS.UV_THR_R",     UV_THR_R,"SoftBins.BIN29"); if(RscDUTs(DUT_ACTIVE).isEmpty())return result;  test_id++;
	result |= Judge(test_id,"UV_THR_F",   "T_UV_THR_SEARCH_LS.UV_THR_F",     UV_THR_F,"SoftBins.BIN29"); if(RscDUTs(DUT_ACTIVE).isEmpty())return result;  test_id++;
	result |= Judge(test_id,"UV_THR_hys", "T_UV_THR_SEARCH_LS.UV_THR_hys", UV_THR_hys,"SoftBins.BIN29"); if(RscDUTs(DUT_ACTIVE).isEmpty())return result;  test_id++;

	return result;
} // T_UV_THR_SEARCH



RsltAllDUTCtnr
TPG::T_UV_THR_GNG()
{
	RsltAllDUTCtnr result;
	test_id = 1850;	

	ValDUT	UV_THR_Set;
	ValDUT	UV_THR_R1;
	ValDUT	UV_THR_F1;
	ValDUT	UV_THR_F2;
	
// Setup
    rdk::CW("K2;K13;K16").on().APPLY(); // MODE_MDM, VIN_CAP, EN_MMXH
	rdk::Timer::WAIT(3e-3);

	//IC Turn on
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("1.8V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").connect().power(ON).APPLY();	//For spike

	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("1.2V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").connect().power(ON).APPLY();
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();
	rdk::Timer::WAIT(5e-3);

	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("1.2V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").APPLY();
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").APPLY();
	rdk::Timer::WAIT(5e-3); 
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").connect().power(ON).APPLY();
	DPIN_Levelset("MODE_mdm","3.6V", "0.0V", "1.8V", "1.8V",CLOSE_,ON_);
	rdk::Timer::WAIT(15e-3); 
	
// Test Mode In	
	I2C_Write(0x6A,0x5A); 
	rdk::Timer::WAIT(1e-3); // enter test mode 
	I2C_Write(0x6A,0xA5); 
	rdk::Timer::WAIT(3e-3); // enter test mode   

	MMXH_PMU_Slewrate("EN_mmxh_pmu"  ,"Slow");  //for spike	
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").APPLY(); //EN Float-1
	rdk::Timer::WAIT(3e-3);
	rdk::MMXH::PMU("EN_mmxh_pmu").isvm("0.0mA",rdkenum::R300uA,rdkenum::R7V,"7.0V","-7V").APPLY(); //EN Float-2
	rdk::Timer::WAIT(3e-3);
	MMXH_PMU_Slewrate("EN_mmxh_pmu"  ,"VeryFast");  //for spike	
	
	I2C_Write(0x24,0x04); 
	rdk::Timer::WAIT(1e-3); // disable BUCK block(DIS_EN=1)
	I2C_Write(0x23,0x4B); 
	rdk::Timer::WAIT(5e-3); //mux out UV_THR_OK(MUXSEL=2'b01, AD_MUXO_EN=1, ENMUX=3'b010)

//UV_THR Set
	UV_THR_Set = rdk::MMXH::PMU("EN_mmxh_pmu").MEAS_V(100);

//UV_THR F1
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("0.72V",rdkenum::R7V,rdkenum::R30mA,"30.0mA","-30.0mA").APPLY();
	rdk::Timer::WAIT(10e-3);

	UV_THR_F1 = rdk::MMXH::PMU("EN_mmxh_pmu").MEAS_V(100);

//UV_THR F2
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("0.54V",rdkenum::R7V,rdkenum::R30mA,"30.0mA","-30.0mA").APPLY();
	rdk::Timer::WAIT(10e-3);

	UV_THR_F2 = rdk::MMXH::PMU("EN_mmxh_pmu").MEAS_V(100);

//UV_THR R1
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("0.72V",rdkenum::R7V,rdkenum::R30mA,"30.0mA","-30.0mA").APPLY();
	rdk::Timer::WAIT(10e-3);

	UV_THR_R1 = rdk::MMXH::PMU("EN_mmxh_pmu").MEAS_V(100);


// Test Mode Out	
	I2C_Write(0x6A,0x00); 
	rdk::Timer::WAIT(1e-3); // EXIT test mode

// clean up
	MMXH_PMU_Slewrate("VIN_mmxh_pmu" ,"Slow");   //for spike

	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").APPLY();
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").APPLY();
	rdk::Timer::WAIT(3e-3);
	DPIN_Levelset("MODE_mdm",OPEN_,OFF_);
	rdk::MMXH::PMU("EN_mmxh_pmu").disconnect().power(OFF).APPLY();	
	rdk::MMXH::PMU("VIN_mmxh_pmu").disconnect().power(OFF).APPLY();	
	rdk::MMXH::PMU("VOUT_mmxh_pmu").disconnect().power(OFF).APPLY();	
	rdk::CW("K_ALL").off().APPLY();
	rdk::Timer::WAIT(3e-3);

	MMXH_PMU_Slewrate("VIN_mmxh_pmu" ,"VeryFast");   //for spike

	result |= Judge(test_id,"UV_THR_Set",   "T_UV_THR_GNG_LS.UV_THR_L",     UV_THR_Set,"SoftBins.BIN29"); if(RscDUTs(DUT_ACTIVE).isEmpty())return result;  test_id++;
	result |= Judge(test_id,"UV_THR_R1",   "T_UV_THR_GNG_LS.UV_THR_L",		UV_THR_R1,"SoftBins.BIN29"); if(RscDUTs(DUT_ACTIVE).isEmpty())return result;  test_id++;
	result |= Judge(test_id,"UV_THR_F1",   "T_UV_THR_GNG_LS.UV_THR_L",		UV_THR_F1,"SoftBins.BIN29"); if(RscDUTs(DUT_ACTIVE).isEmpty())return result;  test_id++;
	result |= Judge(test_id,"UV_THR_F2", "T_UV_THR_GNG_LS.UV_THR_H",		UV_THR_F2,"SoftBins.BIN29"); if(RscDUTs(DUT_ACTIVE).isEmpty())return result;  test_id++;

	return result;
} // T_UV_THR_GNG


RsltAllDUTCtnr
TPG::T_EN_VTH_SEARCH()
{
	RsltAllDUTCtnr result;
	test_id = 1900;	
	ValDUT	EN_R;
	ValDUT	EN_F;
	ValDUT	EN_hys;

// Setup
    rdk::CW("K1;K13;K16").on().APPLY(); //VIN_CAP, EN_MMXH, K13 Needed.
	rdk::Timer::WAIT(3e-3); 
	rdk::MMXH::PMU("MODE_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").connect().power(ON).APPLY();

//IC Turn on
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("1.0V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").connect().power(ON).APPLY();
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("2.7V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").connect().power(ON).APPLY();
	rdk::Timer::WAIT(5e-3);

	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("1.0V",rdkenum::R7V,rdkenum::R30mA,"3.0mA","-3.0mA").connect().power(ON).APPLY(); // VOUT2.7 not working. 1V is best.
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("2.7V",rdkenum::R7V,rdkenum::R30mA,"30.0mA","-30.0mA").connect().power(ON).APPLY();	
	rdk::Timer::WAIT(5e-3); 
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("2.7V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").connect().power(ON).APPLY();	
	rdk::Timer::WAIT(15e-3); 

	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("0.8V",rdkenum::R7V,rdkenum::R30mA,"3.0mA","-3.0mA").connect().power(ON).APPLY(); 
	rdk::Timer::WAIT(5e-3); 

 //EN_Vth_EN_F
		DGT_Lvlset("VIN_mmxh_dgt",IM_,"100KHz",16000); //Max 1MHz, 0~16000
	DGT_Start("VIN_mmxh_dgt");
		DGT_Lvlset("EN_mmxh_dgt",VM_,"100KHz",16000); //Max 1MHz, 0~16000
	DGT_Start("EN_mmxh_dgt");
	EN_F = PMU_Search("EN_mmxh_pmu","0.75V","0.45V","10.0mV","0.2e-3","VIN_mmxh_pmu",Falling_,"400uA"); 

	rdk::Timer::WAIT(3e-3);
	DGT_Stop("VIN_mmxh_dgt",CLOSE_);
	DGT_Stop("EN_mmxh_dgt",CLOSE_);
	
	rdk::Timer::WAIT(1e-3); 



	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("0.2V",rdkenum::R2V,rdkenum::R30mA,"30.0mA","-30.0mA").connect().power(ON).APPLY();
	rdk::Timer::WAIT(3e-3); 

// EN_Vth_EN_R
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("5.5V",rdkenum::R7V,rdkenum::R30mA,"30.0mA","-30.0mA").connect().power(ON).APPLY(); //VIN Range 30mA best.
	rdk::Timer::WAIT(5e-3);
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("0.2V",rdkenum::R2V,rdkenum::R30mA,"30.0mA","-30.0mA").connect().power(ON).APPLY(); //EN Range 30mA best.
	rdk::Timer::WAIT(15e-3);
	
	DGT_Lvlset("VIN_mmxh_dgt",IM_,"100KHz",16000); //Max 1MHz, 0~16000
	DGT_Start("VIN_mmxh_dgt");
	DGT_Lvlset("EN_mmxh_dgt",VM_,"100KHz",16000); //Max 1MHz, 0~16000
	DGT_Start("EN_mmxh_dgt");
	EN_R = PMU_Search("EN_mmxh_pmu","0.3V","1.3V","5.0mV","0.5e-3","VIN_mmxh_pmu",Rising_,"0.5mA"); 
	DGT_Stop("VIN_mmxh_dgt",CLOSE_);
	DGT_Stop("EN_mmxh_dgt",CLOSE_);
	rdk::Timer::WAIT(3e-3);


	

	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("0.0V",rdkenum::R2V,rdkenum::R30mA,"30.0mA","-30.0mA").connect().power(ON).APPLY(); //EN Range 30mA best.
	rdk::Timer::WAIT(3e-3);

// clean up
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").connect().power(ON).APPLY();
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").connect().power(ON).APPLY();
	rdk::Timer::WAIT(3e-3);
	rdk::MMXH::PMU("EN_mmxh_pmu").disconnect().power(OFF).APPLY();	
	rdk::MMXH::PMU("VIN_mmxh_pmu").disconnect().power(OFF).APPLY();	
	rdk::MMXH::PMU("VOUT_mmxh_pmu").disconnect().power(OFF).APPLY();	
	rdk::CW("K_ALL").off().APPLY();
	rdk::Timer::WAIT(3e-3);


	for(ItrDUTs itrDut(DUT_ACTIVE);!itrDut.isDone();itrDut++) 
	{	 
		EN_hys[*itrDut] = (EN_R[*itrDut].getAsDouble() - EN_F[*itrDut].getAsDouble());
	}

	result |= Judge(test_id,"EN_R",   "T_EN_VTH_SEARCH_LS.EN_R",     EN_R,"SoftBins.BIN30"); if(RscDUTs(DUT_ACTIVE).isEmpty())return result;  test_id++;
	result |= Judge(test_id,"EN_F",   "T_EN_VTH_SEARCH_LS.EN_F",     EN_F,"SoftBins.BIN30"); if(RscDUTs(DUT_ACTIVE).isEmpty())return result;  test_id++;
	result |= Judge(test_id,"EN_hys", "T_EN_VTH_SEARCH_LS.EN_hys", EN_hys,"SoftBins.BIN30"); if(RscDUTs(DUT_ACTIVE).isEmpty())return result;  test_id++;
	

	return result;
} // T_UV_THR_SEARCH


RsltAllDUTCtnr
TPG::T_EN_VTH_GNG()
{
	RsltAllDUTCtnr result;
	test_id = 1950;	
	ValDUT	EN_VTH_Set;
	ValDUT	EN_VTH_R1;
	ValDUT	EN_VTH_R2;
	ValDUT	EN_VTH_F1;
	ValDUT	EN_VTH_F2;

	RscTestCondition MODE_Timing("(Timing_MODE)");
	timing_set(Timming_Speed,MODE_Timing);

// Setup
    rdk::CW("K1;K16").on().APPLY(); //VIN_CAP, EN_MMXH
	rdk::Timer::WAIT(3e-3); 
	rdk::MMXH::PMU("MODE_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").connect().power(ON).APPLY();

//IC Turn on
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("2.7V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").connect().power(ON).APPLY();
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("2.7V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").connect().power(ON).APPLY();
	rdk::Timer::WAIT(5e-3);

	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("2.7V",rdkenum::R7V,rdkenum::R30mA,"3.0mA","-3.0mA").APPLY(); 
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("2.7V",rdkenum::R7V,rdkenum::R30mA,"30.0mA","-30.0mA").APPLY();	
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("2.7V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").connect().power(ON).APPLY();	
	rdk::Timer::WAIT(5e-3); 

//EN_VTH Set
	EN_VTH_Set = rdk::MMXH::PMU("VIN_mmxh_pmu").MEAS_I(100);

//EN_VTH F1
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("0.79V",rdkenum::R2V,rdkenum::R3mA,"3.0mA","-3.0mA").APPLY();
	rdk::Timer::WAIT(5e-3);
	EN_VTH_F1 = rdk::MMXH::PMU("VIN_mmxh_pmu").MEAS_I(200);

//EN_VTH F2
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("0.31V",rdkenum::R2V,rdkenum::R3mA,"3.0mA","-3.0mA").APPLY();
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("2.7V",rdkenum::R7V,rdkenum::R30uA,"30uA","-30uA").APPLY(); 
	rdk::Timer::WAIT(5e-3);

	EN_VTH_F2 = rdk::MMXH::PMU("VIN_mmxh_pmu").MEAS_I(100);

	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R30mA,"30.0mA","-30.0mA").APPLY();

	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("2.5V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();	//For spike
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("2.5V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();	//For spike

	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("4.5V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();	//For spike
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("4.5V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();	//For spike

	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("5.5V",rdkenum::R7V,rdkenum::R30mA,"30.0mA","-30.0mA").APPLY(); 
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("5.5V",rdkenum::R7V,rdkenum::R30mA,"30.0mA","-30.0mA").APPLY();
	rdk::Timer::WAIT(5e-3);	
	
//EN_VTH R1
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("0.31V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").APPLY();
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("5.5V",rdkenum::R7V,rdkenum::R30uA,"30.0uA","-30.0uA").APPLY(); 
	rdk::Timer::WAIT(5e-3);

	EN_VTH_R1 = rdk::MMXH::PMU("VIN_mmxh_pmu").MEAS_I(100);

//EN_VTH R2
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("5.5V",rdkenum::R7V,rdkenum::R30mA,"30.0mA","-30.0mA").APPLY(); 
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("5.5V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY(); 
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("0.79V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").APPLY();
	rdk::Timer::WAIT(3e-3);
	
	EN_VTH_R2 = rdk::MMXH::PMU("VIN_mmxh_pmu").MEAS_I(1000);
	
// clean up
	MMXH_PMU_Slewrate("VIN_mmxh_pmu" ,"Slow");  //for spike
	MMXH_PMU_Slewrate("VOUT_mmxh_pmu","Slow");  //for spike

	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R30mA,"30.0mA","-30.0mA").APPLY(); 
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY(); 
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").APPLY();
	rdk::Timer::WAIT(3e-3);
	rdk::MMXH::PMU("VIN_mmxh_pmu").disconnect().power(OFF).APPLY();	
	rdk::MMXH::PMU("VOUT_mmxh_pmu").disconnect().power(OFF).APPLY();	
	rdk::MMXH::PMU("EN_mmxh_pmu").disconnect().power(OFF).APPLY();	
	rdk::MMXH::PMU("MODE_mmxh_pmu").disconnect().power(OFF).APPLY();	
	rdk::CW("K_ALL").off().APPLY();
	rdk::Timer::WAIT(3e-3);

	MMXH_PMU_Slewrate("VIN_mmxh_pmu" ,"VeryFast");  //for spike
	MMXH_PMU_Slewrate("VOUT_mmxh_pmu","VeryFast");  //for spike

	result |= Judge(test_id,"EN_VTH_Set",  "T_EN_VTH_GNG_LS.EN_H",     EN_VTH_Set,"SoftBins.BIN30"); if(RscDUTs(DUT_ACTIVE).isEmpty())return result;  test_id++;
	result |= Judge(test_id,"EN_VTH_R1",   "T_EN_VTH_GNG_LS.EN_L",     EN_VTH_R1,"SoftBins.BIN30"); if(RscDUTs(DUT_ACTIVE).isEmpty())return result;  test_id++;
	result |= Judge(test_id,"EN_VTH_R2",   "T_EN_VTH_GNG_LS.EN_H_R2",     EN_VTH_R2,"SoftBins.BIN30"); if(RscDUTs(DUT_ACTIVE).isEmpty())return result;  test_id++;
	result |= Judge(test_id,"EN_VTH_F1",   "T_EN_VTH_GNG_LS.EN_H",     EN_VTH_F1,"SoftBins.BIN30"); if(RscDUTs(DUT_ACTIVE).isEmpty())return result;  test_id++;
	result |= Judge(test_id,"EN_VTH_F2",   "T_EN_VTH_GNG_LS.EN_L",     EN_VTH_F2,"SoftBins.BIN30"); if(RscDUTs(DUT_ACTIVE).isEmpty())return result;  test_id++;
	
	return result;
} // T_UV_THR_GNG




//TON_Trim
RsltAllDUTCtnr
TPG::T_TON_TRIM()
{
	//TestConditions.apply();//Timing set
	RsltAllDUTCtnr result;

	test_id = 2000;	

	ValDUT TON_pre;
	ValDUT TON_pre_err;
	ValDUT TON_sim;
	ValDUT TON_sim_err;
	//ValDUT TON_code;

	RscTestCondition MODE_Timing("(Timing_MODE)");
	timing_set(Timming_Speed,MODE_Timing);

	rdk::CW("K2;K7;K12;K13;K16").on().APPLY(); // MODE_MDM, EN_BUF, VOUT_CAP, VIN_CAP, EN_MMXH // K15 is not important. - 240918
	rdk::Timer::WAIT(3e-3); //VIN Cap off -> All Overflow / VOUT Cap off -> getting worse.

	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").connect().power(ON).APPLY(); 
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").connect().power(ON).APPLY();	
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").connect().power(ON).APPLY();	
	rdk::Timer::WAIT(3e-3);

	//IC Turn on
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("1.8V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();	//For spike

	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("1.0V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("1.8V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();	//For spike
	rdk::Timer::WAIT(3e-3);

	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("1.0V",rdkenum::R2V,rdkenum::R3mA,"3.0mA","-3.0mA").APPLY(); //Narrow range important.
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R30mA,"3.0mA","-3.0mA").APPLY();
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").APPLY();
	DPIN_Levelset("MODE_mdm","3.6V", "0.0V", "1.8V", "1.8V",CLOSE_,ON_);
	rdk::Timer::WAIT(15e-3); 

	I2C_Write(0x6A,0x5A); 
	rdk::Timer::WAIT(1e-3); // enter test mode 
	I2C_Write(0x6A,0xA5); 
	rdk::Timer::WAIT(3e-3); // enter test mode   

	MMXH_PMU_Slewrate("EN_mmxh_pmu"  ,"Slow");   //for spike
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").APPLY(); //EN Float-1
	rdk::Timer::WAIT(3e-3);
	rdk::MMXH::PMU("EN_mmxh_pmu").disconnect().power(OFF).APPLY(); // EN float-3
	rdk::Timer::WAIT(3e-3);
	MMXH_PMU_Slewrate("EN_mmxh_pmu"  ,"VeryFast");   //for spike

	I2C_Write(0x25,0x10); 
	rdk::Timer::WAIT(1e-3); // (T_PLIMOFF=1);

	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("0.8V",rdkenum::R2V,rdkenum::R3mA,"3.0mA","-3.0mA").APPLY();
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("3.0V",rdkenum::R7V,rdkenum::R240mA,"240.0mA","-240.0mA").APPLY(); //Lower VIN&VOUT - KinetIC Temporary confirmed.
//	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("1.0V",rdkenum::R2V,rdkenum::R3mA,"3.0mA","-3.0mA").connect().power(ON).APPLY();
//	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R240mA,"240.0mA","-240.0mA").connect().power(ON).APPLY(); //Wide Range better.
	rdk::Timer::WAIT(3e-3);

	//MMXH_PMU_Slewrate("LX_mmxh_pmu" ,"VerySlow");  //for spike
	//rdk::MFHP::PMU("LX_mfhp_pmu").slewrate_i(1.0).APPLY();//for spike

	rdk::MFHP::PMU("LX_mfhp_pmu").isvm("0mA",rdkenum::R300mA,rdkenum::R7V,"5.0V","-5.0V").connect(rdkenum::PORTA,rdkenum::PORTA).power(ON).APPLY(); //Sink 0mA is fine. //300 Current Range is the best. - 240924
	rdk::MMXH::PMU("LX_mmxh_pmu").isvm("0uA",rdkenum::R300uA,rdkenum::R7V,"5.0V","-5.0V").connect().power(ON).APPLY(); // 240mA Current Range is bad. other range is fine. - 240924
	rdk::Timer::WAIT(3e-3);


	I2C_Write(0x26,0x08);
	rdk::Timer::WAIT(1e-3); // (T_FSW=1);
	I2C_Write(0x45,0x80); 
	rdk::Timer::WAIT(1e-3); // (DIS_IPKMIN=1);
	I2C_Write(0x44,0x00); 
	rdk::Timer::WAIT(1e-3); // (FSW_SEL=2'b00, 1MHz Option);
	I2C_Write(0x24,0x80); 
	rdk::Timer::WAIT(3e-3); // ( DIS_LPWR=1);

// pre measure
 	OFCArray<ValDUT> TON_pre2(99,0); 

	rdk::Digital::Pin("BUF_mmxh_dcl").vohl("2.0V","1.0V").connect().power(ON).APPLY(); 
	rdk::MMXH::TMU("BUF_mmxh_tmu").event(rdkenum::COMPVOL_HYS_FALL).count(64).trigger(rdkenum::START,rdkenum::SOFT,"NONE",rdkenum::FALLING).APPLY(); //Adjusted for wavefrom
	RscTMUPin tmu_a("BUF_mmxh_tmu"); tmu_a.setCondition("TimeOut","10.0mS"); // setting time-out

	for(int i=0; i<5; i++)
	{
		rdk::MMXH::TMU("BUF_mmxh_tmu").START().WAIT_ACQ("1mS");
		rdk::MMXH::TMU("BUF_mmxh_tmu").STOP();
		rdk::MMXH::TMU("BUF_mmxh_tmu").GET_RESULT_FREQ(TON_pre2[i],rdkenum::COMPVOL_FALL); //Adjusted for wavefrom
		dlgout.precision(3);
		dlgout<<TON_pre2[i]<<endl;
	}

	I2C_Write(0x6A,0x00);
	rdk::Timer::WAIT(1e-3);

	//MMXH_PMU_Slewrate("LX_mmxh_pmu" ,"VeryFast");  //for spike
	//rdk::MFHP::PMU("LX_mfhp_pmu").slewrate_i(10.0).APPLY();//for spike

// clean up
	MMXH_PMU_Slewrate("VIN_mmxh_pmu" ,"Slow");  //for spike

	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R240mA,"240.0mA","-240.0mA").APPLY();
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").APPLY();
	rdk::Timer::WAIT(3e-3);
	DPIN_Levelset("MODE_mdm",OPEN_,OFF_);	
    rdk::Digital::Pin("BUF_mmxh_dcl").disconnect().power(OFF).APPLY();
    rdk::MFHP::PMU("LX_mfhp_pmu").disconnect().power(OFF).APPLY();	//Jack
	rdk::MMXH::PMU("LX_mmxh_pmu").disconnect().power(OFF).APPLY();	//Jack
	rdk::MMXH::PMU("VIN_mmxh_pmu").disconnect().power(OFF).APPLY();	
	rdk::MMXH::PMU("VOUT_mmxh_pmu").disconnect().power(OFF).APPLY();	
	rdk::CW("K_ALL").off().APPLY();
	rdk::Timer::WAIT(3e-3);

	MMXH_PMU_Slewrate("VIN_mmxh_pmu" ,"VeryFast");  //for spike

	for(ItrDUTs itrDut(DUT_ACTIVE); !itrDut.isDone(); itrDut++) 
	{
		double SortData[5];
		for(int mcnt = 0; mcnt < 5; mcnt++) SortData[mcnt] = TON_pre2[mcnt][*itrDut].getAsDouble();
		quicksort(SortData,0,5-1);
		TON_pre[*itrDut] = SortData[2];

    	TON_pre_err[*itrDut] = (TON_target - TON_pre[*itrDut].getAsDouble()) / (TON_pre[*itrDut].getAsDouble()+1e-9) ; 
	}


// TON pre-meas
	result |= Judge(test_id,"TON_pre",    "T_TON_TRIM_LS.TON_pre",        TON_pre,"SoftBins.BIN31"); if(RscDUTs(DUT_ACTIVE).isEmpty()) return result; test_id++;
	result |= Judge(test_id,"TON_pre_err","T_TON_TRIM_LS.TON_pre_err",TON_pre_err,"SoftBins.BIN31"); if(RscDUTs(DUT_ACTIVE).isEmpty()) return result; test_id++;

// TON trim table
    for(ItrDUTs itrDut(DUT_ACTIVE); !itrDut.isDone(); itrDut++) 
	{
		double temp_data_err = TON_pre_err[*itrDut].getAsDouble() * 100;
		if (temp_data_err >= -50.0 && temp_data_err<50.0)
		{
			if (temp_data_err >= -3.59 && temp_data_err< -1.04)		{ ton_code[*itrDut] = 240; }//
			if (temp_data_err >= -6.72 && temp_data_err< -3.59)		{ ton_code[*itrDut] = 224; }//
			if (temp_data_err >= -10.04 && temp_data_err< -6.72)	{ ton_code[*itrDut] = 208; }//
			if (temp_data_err >= -13.61 && temp_data_err< -10.04)	{ ton_code[*itrDut] = 192; }//
			if (temp_data_err >= -17.29 && temp_data_err< -13.61)	{ ton_code[*itrDut] = 176; }//
			if (temp_data_err >= -20.95 && temp_data_err< -17.29)	{ ton_code[*itrDut] = 160; }//
			if (temp_data_err >= -24.59 && temp_data_err< -20.95)	{ ton_code[*itrDut] = 144; }//
			if (temp_data_err >= -50.0 && temp_data_err< -24.59)	{ ton_code[*itrDut] = 128; }//

			if (temp_data_err >= 19.65 && temp_data_err< 50.0)		{ ton_code[*itrDut] = 112; }//
			if (temp_data_err >= 16.77 && temp_data_err< 19.65)		{ ton_code[*itrDut] = 96; }//
			if (temp_data_err >= 13.70 && temp_data_err< 16.77)		{ ton_code[*itrDut] = 80; }//
			if (temp_data_err >= 10.69 && temp_data_err< 13.70)		{ ton_code[*itrDut] = 64; }//
			if (temp_data_err >= 7.83 && temp_data_err< 10.69)		{ ton_code[*itrDut] = 48; }//
			if (temp_data_err >= 4.89 && temp_data_err< 7.83)		{ ton_code[*itrDut] = 32; }//
			if (temp_data_err >= 1.66 && temp_data_err< 4.89)		{ ton_code[*itrDut] = 16; }//
			if (temp_data_err >= -1.04 && temp_data_err< 1.66)		{ ton_code[*itrDut] = 0; }//
	    }
		else ton_code[*itrDut]= 0; // 

       if(EN_OTP43_47[*itrDut]==0) { ton_code[*itrDut] = RD_OTP43_47[*itrDut].getAsInt(); } 
	} 

	result |= Judge(test_id,"TON_code",	ton_code,   -0.5, 255.5,"SoftBins.BIN31","SoftBins.BIN31","Dec"); if(RscDUTs(DUT_ACTIVE).isEmpty())return result; test_id++;


//----------------------------------------------------------------------------------------------------------------------------------------------------------------------------

	
// Sim Setup
	rdk::CW("K2;K7;K12;K13;K16").on().APPLY(); // MODE_MDM, EN_BUF, VOUT_CAP, VIN_CAP, EN_MMXH
	rdk::Timer::WAIT(3e-3);

	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").connect().power(ON).APPLY(); 
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").connect().power(ON).APPLY();	
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").connect().power(ON).APPLY();	
	rdk::Timer::WAIT(3e-3);

	//IC Turn on
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("1.8V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();	//For spike

	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("1.0V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("1.8V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();	//For spike
	rdk::Timer::WAIT(3e-3);

	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("1.0V",rdkenum::R2V,rdkenum::R3mA,"3.0mA","-3.0mA").APPLY(); //Narrow range important.
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R30mA,"3.0mA","-3.0mA").APPLY();
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").APPLY();
	DPIN_Levelset("MODE_mdm","3.6V", "0.0V", "1.8V", "1.8V",CLOSE_,ON_);
	rdk::Timer::WAIT(15e-3); 

	I2C_Write(0x6A,0x5A); 
	rdk::Timer::WAIT(1e-3); // enter test mode 
	I2C_Write(0x6A,0xA5); 
	rdk::Timer::WAIT(3e-3); // enter test mode   

	MMXH_PMU_Slewrate("EN_mmxh_pmu"  ,"Slow");   //for spike	
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").APPLY(); //EN Float-1
	rdk::Timer::WAIT(3e-3);
	rdk::MMXH::PMU("EN_mmxh_pmu").disconnect().power(OFF).APPLY(); // EN float-3
	rdk::Timer::WAIT(3e-3);
	MMXH_PMU_Slewrate("EN_mmxh_pmu"  ,"VeryFast");   //for spike	

	I2C_Write(0x25,0x10); 
	rdk::Timer::WAIT(1e-3); // (T_PLIMOFF=1);
	
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("0.8V",rdkenum::R2V,rdkenum::R3mA,"3.0mA","-3.0mA").APPLY();
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("3.0V",rdkenum::R7V,rdkenum::R240mA,"240.0mA","-240.0mA").APPLY(); //Lower VIN&VOUT - KinetIC Temporary confirmed.
	rdk::Timer::WAIT(3e-3);

	rdk::MFHP::PMU("LX_mfhp_pmu").isvm("-0mA",rdkenum::R300mA,rdkenum::R7V,"5.0V","-5.0V").connect(rdkenum::PORTA,rdkenum::PORTA).power(ON).APPLY(); 
	rdk::MMXH::PMU("LX_mmxh_pmu").isvm("-0uA",rdkenum::R300uA,rdkenum::R7V,"5.0V","-5.0V").connect().power(ON).APPLY(); 
	rdk::Timer::WAIT(3e-3);

	I2C_Write(0x26,0x08);
	rdk::Timer::WAIT(1e-3); // (T_FSW=1);
	I2C_Write(0x45,0x80); 
	rdk::Timer::WAIT(1e-3); // (DIS_IPKMIN=1);
	I2C_Write(0x44,0x00); 
	rdk::Timer::WAIT(1e-3); // (FSW_SEL=2'b00, 1MHz Option);
	I2C_Write(0x24,0x80); 
	rdk::Timer::WAIT(3e-3); // ( DIS_LPWR=1);

    I2C_Write(0x43,ton_code); 
	rdk::Timer::WAIT(3e-3); 

// sim measure
	OFCArray<ValDUT> TON_sim2(99,0); 

	rdk::Digital::Pin("BUF_mmxh_dcl").vohl("2.0V","1.0V").connect().power(ON).APPLY(); 
	rdk::MMXH::TMU("BUF_mmxh_tmu").event(rdkenum::COMPVOL_HYS_FALL).count(64).trigger(rdkenum::START,rdkenum::SOFT,"NONE",rdkenum::FALLING).APPLY(); //Adjusted for wavefrom
	RscTMUPin tmu_b("BUF_mmxh_tmu"); tmu_b.setCondition("TimeOut","10.0mS"); // setting time-out

	for(int i=0; i<5; i++)
	{
		rdk::MMXH::TMU("BUF_mmxh_tmu").START().WAIT_ACQ("1mS");
		rdk::MMXH::TMU("BUF_mmxh_tmu").STOP();
		rdk::MMXH::TMU("BUF_mmxh_tmu").GET_RESULT_FREQ(TON_sim2[i],rdkenum::COMPVOL_FALL); //Adjusted for wavefrom
		dlgout.precision(3);
		dlgout<<TON_sim2[i]<<endl;
	}

	I2C_Write(0x6A,0x00);
	rdk::Timer::WAIT(1e-3);


// clean up	
	MMXH_PMU_Slewrate("VIN_mmxh_pmu" ,"Slow");   //for spike

	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R240mA,"240.0mA","-240.0mA").APPLY();
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").APPLY();
	rdk::Timer::WAIT(3e-3);
	DPIN_Levelset("MODE_mdm",OPEN_,OFF_);	
    rdk::Digital::Pin("BUF_mmxh_dcl").disconnect().power(OFF).APPLY();
    rdk::MFHP::PMU("LX_mfhp_pmu").disconnect().power(OFF).APPLY();
	rdk::MMXH::PMU("LX_mmxh_pmu").disconnect().power(OFF).APPLY();
	rdk::MMXH::PMU("VIN_mmxh_pmu").disconnect().power(OFF).APPLY();	
	rdk::MMXH::PMU("VOUT_mmxh_pmu").disconnect().power(OFF).APPLY();	
	rdk::CW("K_ALL").off().APPLY();
	rdk::Timer::WAIT(3e-3);

	MMXH_PMU_Slewrate("VIN_mmxh_pmu" ,"VeryFast");   //for spike


	for(ItrDUTs itrDut(DUT_ACTIVE); !itrDut.isDone(); itrDut++) 
	{
		double SortData[5];
		for(int mcnt = 0; mcnt < 5; mcnt++) SortData[mcnt] = TON_sim2[mcnt][*itrDut].getAsDouble();
		quicksort(SortData,0,5-1);
		TON_sim[*itrDut] = SortData[2];

		TON_sim_err[*itrDut] = (TON_target - TON_sim[*itrDut].getAsDouble()) / (TON_sim[*itrDut].getAsDouble()+1e-9) ; 
	}

	result |= Judge(test_id,"TON_sim",    "T_TON_TRIM_LS.TON_sim",        TON_sim,"SoftBins.BIN31"); if(RscDUTs(DUT_ACTIVE).isEmpty()) return result; test_id++;
	result |= Judge(test_id,"TON_sim_err","T_TON_TRIM_LS.TON_sim_err",TON_sim_err,"SoftBins.BIN31"); if(RscDUTs(DUT_ACTIVE).isEmpty()) return result; test_id++;

	return result;
} // T_TON_Trim


RsltAllDUTCtnr
TPG::T_TON_BURN()
{
	//TestConditions.apply();
	RsltAllDUTCtnr result;
if (en_trim == 1)
{
	rdk::CW("K2;K12;K13;K16").on().APPLY(); // MODE MDM, EN MMXH, VIN_CAP, VOUT_CAP 
	rdk::Timer::WAIT(3e-3); 

	//IC Turn on
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("1.8V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").connect().power(ON).APPLY(); //For spike
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("1.8V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").connect().power(ON).APPLY();	//For spike
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("1.8V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").connect().power(ON).APPLY();	//For spike

	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").APPLY();
	DPIN_Levelset("MODE_mdm","3.6V", "0.0V", "1.8V", "1.8V",CLOSE_,ON_);
	rdk::Timer::WAIT(15e-3); 

	I2C_Write(0x6A,0x5A);	  rdk::Timer::WAIT(1e-3); // enter test mode 
	I2C_Write(0x6A,0xA5);	  rdk::Timer::WAIT(1e-3); // enter test mode  2. Enter Test Mode.
	I2C_Write(0x43,ton_code); rdk::Timer::WAIT(1e-3); //3. Write target OTP values into REG 0x40 to 0x48.
	I2C_Write(0x20,0x03);	  rdk::Timer::WAIT(1e-3); // 4. Write REG 0x20 = 0x00 to select data in REG 0x40 to be burned.
	I2C_Write(0x21,0x09);	  rdk::Timer::WAIT(1e-3); // 5. Write REG 0x21=0x09 (OTP_CLK_REQ=1, EXVPP_EN=1).

	for(ItrDUTs itrDut(DUT_ACTIVE); !itrDut.isDone(); itrDut++) 
	{
		VHEN1[*itrDut] = EN_OTP43_47[*itrDut] * 1.0 * 5;
		VHEN2[*itrDut] = EN_OTP43_47[*itrDut] * 1.1 * 5;
		VHEN3[*itrDut] = EN_OTP43_47[*itrDut] * 1.2 * 5;
		VHEN4[*itrDut] = EN_OTP43_47[*itrDut] * 1.3 * 5;
		VHEN5[*itrDut] = EN_OTP43_47[*itrDut] * 1.4 * 5;

		//For VIN : If burend chip, VIN off, VOUT off
		VIEN[*itrDut] = EN_OTP43_47[*itrDut] * 5.5; //5.5V
		VOEN[*itrDut] = EN_OTP43_47[*itrDut] * 3.6; //3.6V
	}										  
		
	//If burend chip, VIN & VOUT off slowly
	MMXH_PMU_Slewrate("VIN_mmxh_pmu","Slow");   //for spike
	MMXH_PMU_Slewrate("VOUT_mmxh_pmu","Slow");   //for spike
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim(VIEN,rdkenum::R7V,rdkenum::R240mA,"200.0mA","-200.0mA").APPLY(); // VIN 5.5 V is needed for Burn //Check 0V and 5.5V both with DGT
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim(VOEN,rdkenum::R7V,rdkenum::R240mA,"200.0mA","-200.0mA").APPLY();
	rdk::Timer::WAIT(3e-3);	
	MMXH_PMU_Slewrate("VOUT_mmxh_pmu","VeryFast");   //for spike
	MMXH_PMU_Slewrate("VIN_mmxh_pmu","VeryFast");   //for spike

	//Burn
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim(VHEN1,rdkenum::R7V,rdkenum::R240mA,"200.0mA","-200.0mA").APPLY();
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim(VHEN2,rdkenum::R7V,rdkenum::R240mA,"200.0mA","-200.0mA").APPLY();
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim(VHEN3,rdkenum::R7V,rdkenum::R240mA,"200.0mA","-200.0mA").APPLY();
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim(VHEN4,rdkenum::R7V,rdkenum::R240mA,"200.0mA","-200.0mA").APPLY();
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim(VHEN5,rdkenum::R7V,rdkenum::R240mA,"200.0mA","-200.0mA").APPLY();
	rdk::Timer::WAIT(1e-3); 

	I2C_Write(0x21,0x0B); //7. Write 0x21 = 0x0B to program the OTP(BURN_EN=1). 8. Wait 1ms.
	rdk::Timer::WAIT(1e-3); 
	I2C_Write(0x21,0x09); //9. Write 0x21 = 0x09 to stop OTP programming.
	rdk::Timer::WAIT(1e-3); 

	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim(VHEN5,rdkenum::R7V,rdkenum::R240mA,"200.0mA","-200.0mA").APPLY();
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim(VHEN4,rdkenum::R7V,rdkenum::R240mA,"200.0mA","-200.0mA").APPLY();
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim(VHEN3,rdkenum::R7V,rdkenum::R240mA,"200.0mA","-200.0mA").APPLY();
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim(VHEN2,rdkenum::R7V,rdkenum::R240mA,"200.0mA","-200.0mA").APPLY();
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim(VHEN1,rdkenum::R7V,rdkenum::R240mA,"200.0mA","-200.0mA").APPLY();
	rdk::Timer::WAIT(1e-3); 

	I2C_Write(0x6A,0x00); // exit test mode
	rdk::Timer::WAIT(1e-3); 


	// clean up

	MMXH_PMU_Slewrate("VIN_mmxh_pmu" ,"Slow");  //for spike
	MMXH_PMU_Slewrate("VOUT_mmxh_pmu","Slow");  //for spike
	MMXH_PMU_Slewrate("EN_mmxh_pmu"  ,"Slow");  //for spike	

	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R240mA,"200.0mA","-200.0mA").APPLY();
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();
	rdk::Timer::WAIT(3e-3);
	DPIN_Levelset("MODE_mdm",OPEN_,OFF_);
	rdk::MMXH::PMU("VOUT_mmxh_pmu").disconnect().power(OFF).APPLY();
	rdk::MMXH::PMU("VIN_mmxh_pmu").disconnect().power(OFF).APPLY();
	rdk::MMXH::PMU("EN_mmxh_pmu").disconnect().power(OFF).APPLY();
	rdk::CW("K_ALL").off().APPLY();
	rdk::Timer::WAIT(3e-3);	

	MMXH_PMU_Slewrate("VIN_mmxh_pmu" ,"VeryFast");  //for spike
	MMXH_PMU_Slewrate("VOUT_mmxh_pmu","VeryFast");  //for spike
	MMXH_PMU_Slewrate("EN_mmxh_pmu"  ,"VeryFast");  //for spike	

}
	result |= Judge(test_id,"TON_burn", "T_BURN.BURN", EN_OTP41_47,"SoftBins.BIN31"); if(RscDUTs(DUT_ACTIVE).isEmpty())return result; test_id++;
	
	return result;
} // T_TON_Burn


RsltAllDUTCtnr
TPG::T_TON_POST()
{

	RsltAllDUTCtnr result;

	ValDUT TON_post;
	ValDUT TON_post_err;

// Post Setup
	rdk::CW("K2;K7;K12;K13;K16").on().APPLY(); // MODE_MDM, EN_BUF, VOUT_CAP, VIN_CAP, EN_MMXH
	rdk::Timer::WAIT(3e-3);

	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").connect().power(ON).APPLY(); 
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").connect().power(ON).APPLY();	
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").connect().power(ON).APPLY();	
	rdk::Timer::WAIT(3e-3);

	//IC Turn on
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("1.8V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();	//For spike

	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("1.0V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("1.8V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();	//For spike
	rdk::Timer::WAIT(3e-3);

	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("1.0V",rdkenum::R2V,rdkenum::R3mA,"3.0mA","-3.0mA").APPLY(); //Narrow range important.
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R30mA,"3.0mA","-3.0mA").APPLY();
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").APPLY();
	DPIN_Levelset("MODE_mdm","3.6V", "0.0V", "1.8V", "1.8V",CLOSE_,ON_);
	rdk::Timer::WAIT(15e-3);  

	I2C_Write(0x6A,0x5A); 
	rdk::Timer::WAIT(1e-3); // enter test mode 
	I2C_Write(0x6A,0xA5); 
	rdk::Timer::WAIT(3e-3); // enter test mode   

	MMXH_PMU_Slewrate("EN_mmxh_pmu"  ,"Slow");   //for spike	
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").APPLY(); //EN Float-1
	rdk::Timer::WAIT(3e-3);
	rdk::MMXH::PMU("EN_mmxh_pmu").disconnect().power(OFF).APPLY(); // EN float-3
	rdk::Timer::WAIT(3e-3);
	MMXH_PMU_Slewrate("EN_mmxh_pmu"  ,"VeryFast");   //for spike	
	
	I2C_Write(0x25,0x10); 
	rdk::Timer::WAIT(1e-3); // (T_PLIMOFF=1);

	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("0.8V",rdkenum::R2V,rdkenum::R3mA,"3.0mA","-3.0mA").APPLY();
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("3.0V",rdkenum::R7V,rdkenum::R240mA,"240.0mA","-240.0mA").APPLY(); //Lower VIN&VOUT - KinetIC Temporary confirmed.
	rdk::Timer::WAIT(3e-3);

	rdk::MFHP::PMU("LX_mfhp_pmu").isvm("-0mA",rdkenum::R300mA,rdkenum::R7V,"5.0V","-5.0V").connect(rdkenum::PORTA,rdkenum::PORTA).power(ON).APPLY(); 
	rdk::MMXH::PMU("LX_mmxh_pmu").isvm("-0uA",rdkenum::R300uA,rdkenum::R7V,"5.0V","-5.0V").connect().power(ON).APPLY(); 
	rdk::Timer::WAIT(3e-3);

	I2C_Write(0x26,0x08);
	rdk::Timer::WAIT(1e-3); // (T_FSW=1);
	I2C_Write(0x45,0x80); 
	rdk::Timer::WAIT(1e-3); // (DIS_IPKMIN=1);
	I2C_Write(0x44,0x00); 
	rdk::Timer::WAIT(1e-3); // (FSW_SEL=2'b00, 1MHz Option);
	I2C_Write(0x24,0x80); 
	rdk::Timer::WAIT(3e-3); // ( DIS_LPWR=1);

// Post measure
	OFCArray<ValDUT> TON_post2(99,0); 
	
	rdk::Digital::Pin("BUF_mmxh_dcl").vohl("2.0V","1.0V").connect().power(ON).APPLY(); 
	rdk::MMXH::TMU("BUF_mmxh_tmu").event(rdkenum::COMPVOL_HYS_FALL).count(64).trigger(rdkenum::START,rdkenum::SOFT,"NONE",rdkenum::FALLING).APPLY(); //Adjusted for wavefrom
	RscTMUPin tmu_a("BUF_mmxh_tmu"); tmu_a.setCondition("TimeOut","10.0mS"); // setting time-out

	for(int i=0; i<5; i++)
	{
		rdk::MMXH::TMU("BUF_mmxh_tmu").START().WAIT_ACQ("1mS");
		rdk::MMXH::TMU("BUF_mmxh_tmu").STOP();
		rdk::MMXH::TMU("BUF_mmxh_tmu").GET_RESULT_FREQ(TON_post2[i],rdkenum::COMPVOL_FALL); //Adjusted for wavefrom
		dlgout.precision(3);
		dlgout<<TON_post2[i]<<endl;
	}

	I2C_Write(0x6A,0x00);
	rdk::Timer::WAIT(1e-3);
	
// clean up
	MMXH_PMU_Slewrate("VIN_mmxh_pmu" ,"Slow");  //for spike

	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("0.0V",rdkenum::R2V,rdkenum::R3mA,"3.0mA","-3.0mA").APPLY();
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R240mA,"240.0mA","-240.0mA").APPLY(); 
	rdk::Timer::WAIT(3e-3);
	DPIN_Levelset("MODE_mdm",OPEN_,OFF_);	
    rdk::Digital::Pin("BUF_mmxh_dcl").disconnect().power(OFF).APPLY();
	rdk::MFHP::PMU("LX_mfhp_pmu").disconnect().power(OFF).APPLY();
	rdk::MMXH::PMU("LX_mmxh_pmu").disconnect().power(OFF).APPLY();
	rdk::MMXH::PMU("VIN_mmxh_pmu").disconnect().power(OFF).APPLY();	
	rdk::MMXH::PMU("VOUT_mmxh_pmu").disconnect().power(OFF).APPLY();	
	rdk::CW("K_ALL").off().APPLY();
	rdk::Timer::WAIT(3e-3);

	MMXH_PMU_Slewrate("VIN_mmxh_pmu" ,"VeryFast");  //for spike

	for(ItrDUTs itrDut(DUT_ACTIVE); !itrDut.isDone(); itrDut++) 
	{
		double SortData[5];
		for(int mcnt = 0; mcnt < 5; mcnt++) SortData[mcnt] = TON_post2[mcnt][*itrDut].getAsDouble();
		quicksort(SortData,0,5-1);
		TON_post[*itrDut] = SortData[2];

		TON_post_err[*itrDut] = (TON_target - TON_post[*itrDut].getAsDouble()) / (TON_post[*itrDut].getAsDouble()+1e-9); 
	}

// TON post-meas
	result |= Judge(test_id,"TON_post",    "T_TON_TRIM_LS.TON_post",        TON_post,"SoftBins.BIN31"); if(RscDUTs(DUT_ACTIVE).isEmpty()) return result; test_id++;
	result |= Judge(test_id,"TON_post_err","T_TON_TRIM_LS.TON_post_err",TON_post_err,"SoftBins.BIN31"); if(RscDUTs(DUT_ACTIVE).isEmpty()) return result; test_id++;



//////////////////////////////////////////TON_POST_3p6V//////////////////////////////////////
	//ktb8316_discharge(); // Discharge For preventing from affection of previous item

	ValDUT TON_post_3p6V;
	ValDUT TON_post_3p6V_err;

// post_3p6V Setup
	rdk::CW("K2;K7;K12;K13;K16").on().APPLY(); // MODE_MDM, EN_BUF, VOUT_CAP, VIN_CAP, EN_MMXH
	rdk::Timer::WAIT(3e-3);

	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").connect().power(ON).APPLY(); 
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").connect().power(ON).APPLY();	
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").connect().power(ON).APPLY();	
	rdk::Timer::WAIT(3e-3);

	//IC Turn on
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("1.8V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();	//For spike

	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("1.0V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").connect().power(ON).APPLY();
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("1.8V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").connect().power(ON).APPLY();	//For spike
	rdk::Timer::WAIT(3e-3);

	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("1.0V",rdkenum::R2V,rdkenum::R3mA,"3.0mA","-3.0mA").APPLY(); //Narrow range important.
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R30mA,"3.0mA","-3.0mA").APPLY();
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").APPLY();
	DPIN_Levelset("MODE_mdm","3.6V", "0.0V", "1.8V", "1.8V",CLOSE_,ON_);
	rdk::Timer::WAIT(15e-3); 

	I2C_Write(0x6A,0x5A); 
	rdk::Timer::WAIT(1e-3); // enter test mode 
	I2C_Write(0x6A,0xA5); 
	rdk::Timer::WAIT(3e-3); // enter test mode   

	MMXH_PMU_Slewrate("EN_mmxh_pmu"  ,"Slow");  //for spike	
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").APPLY(); //EN Float-1
	rdk::Timer::WAIT(3e-3);
	rdk::MMXH::PMU("EN_mmxh_pmu").disconnect().power(OFF).APPLY(); // EN float-3
	rdk::Timer::WAIT(3e-3);
	MMXH_PMU_Slewrate("EN_mmxh_pmu"  ,"VeryFast");  //for spike	
	
	I2C_Write(0x25,0x10); 
	rdk::Timer::WAIT(1e-3); // (T_PLIMOFF=1);

	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("1.0V",rdkenum::R2V,rdkenum::R3mA,"3.0mA","-3.0mA").APPLY();
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R240mA,"240.0mA","-240.0mA").APPLY(); //Wide Range better.
	rdk::Timer::WAIT(3e-3);

	rdk::MFHP::PMU("LX_mfhp_pmu").isvm("-0mA",rdkenum::R300mA,rdkenum::R7V,"5.0V","-5.0V").connect(rdkenum::PORTA,rdkenum::PORTA).power(ON).APPLY(); 
	rdk::MMXH::PMU("LX_mmxh_pmu").isvm("-0uA",rdkenum::R300uA,rdkenum::R7V,"5.0V","-5.0V").connect().power(ON).APPLY(); 
	rdk::Timer::WAIT(3e-3);

	I2C_Write(0x26,0x08);
	rdk::Timer::WAIT(1e-3); // (T_FSW=1);
	I2C_Write(0x45,0x80); 
	rdk::Timer::WAIT(1e-3); // (DIS_IPKMIN=1);
	I2C_Write(0x44,0x00); 
	rdk::Timer::WAIT(1e-3); // (FSW_SEL=2'b00, 1MHz Option);
	I2C_Write(0x24,0x80); 
	rdk::Timer::WAIT(3e-3); // ( DIS_LPWR=1);

// post_3p6V measure
	OFCArray<ValDUT> TON_post2_3p6V(99,0); 
	
	rdk::Digital::Pin("BUF_mmxh_dcl").vohl("2.0V","1.0V").connect().power(ON).APPLY(); 
	rdk::MMXH::TMU("BUF_mmxh_tmu").event(rdkenum::COMPVOL_HYS_FALL).count(64).trigger(rdkenum::START,rdkenum::SOFT,"NONE",rdkenum::FALLING).APPLY(); //Adjusted for wavefrom
	RscTMUPin tmu_b("BUF_mmxh_tmu"); tmu_b.setCondition("TimeOut","10.0mS"); // setting time-out

	for(int i=0; i<5; i++)
	{
		rdk::MMXH::TMU("BUF_mmxh_tmu").START().WAIT_ACQ("1mS");
		rdk::MMXH::TMU("BUF_mmxh_tmu").STOP();
		rdk::MMXH::TMU("BUF_mmxh_tmu").GET_RESULT_FREQ(TON_post2_3p6V[i],rdkenum::COMPVOL_FALL); //Adjusted for wavefrom
		dlgout.precision(3);
		dlgout<<TON_post2_3p6V[i]<<endl;
	}

	I2C_Write(0x6A,0x00);
	rdk::Timer::WAIT(1e-3);
	
// clean up
	MMXH_PMU_Slewrate("VIN_mmxh_pmu" ,"Slow");  //for spike

	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("0.0V",rdkenum::R2V,rdkenum::R3mA,"3.0mA","-3.0mA").APPLY();
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R240mA,"240.0mA","-240.0mA").APPLY(); 
	rdk::Timer::WAIT(3e-3);
	DPIN_Levelset("MODE_mdm",OPEN_,OFF_);	
    rdk::Digital::Pin("BUF_mmxh_dcl").disconnect().power(OFF).APPLY();
	rdk::MFHP::PMU("LX_mfhp_pmu").disconnect().power(OFF).APPLY();
	rdk::MMXH::PMU("LX_mmxh_pmu").disconnect().power(OFF).APPLY();
	rdk::MMXH::PMU("EN_mmxh_pmu").disconnect().power(OFF).APPLY();	
	rdk::MMXH::PMU("VIN_mmxh_pmu").disconnect().power(OFF).APPLY();	
	rdk::MMXH::PMU("VOUT_mmxh_pmu").disconnect().power(OFF).APPLY();	
	rdk::CW("K_ALL").off().APPLY();
	rdk::Timer::WAIT(3e-3);

	MMXH_PMU_Slewrate("VIN_mmxh_pmu" ,"VeryFast");  //for spike


	for(ItrDUTs itrDut(DUT_ACTIVE); !itrDut.isDone(); itrDut++) 
	{
		double SortData[5];
		for(int mcnt = 0; mcnt < 5; mcnt++) SortData[mcnt] = TON_post2_3p6V[mcnt][*itrDut].getAsDouble();
		quicksort(SortData,0,5-1);
		TON_post_3p6V[*itrDut] = SortData[2];

		TON_post_3p6V_err[*itrDut] = (TON_target - TON_post_3p6V[*itrDut].getAsDouble()) / (TON_post_3p6V[*itrDut].getAsDouble()+1e-9); 
	}

// TON post_3p6V-meas
	result |= Judge(test_id,"TON_post_3p6V",    "T_TON_TRIM_LS.TON_post_3p6V",        TON_post_3p6V,"SoftBins.BIN31"); if(RscDUTs(DUT_ACTIVE).isEmpty()) return result; test_id++;
	result |= Judge(test_id,"TON_post_3p6V_err","T_TON_TRIM_LS.TON_post_3p6V_err",TON_post_3p6V_err,"SoftBins.BIN31"); if(RscDUTs(DUT_ACTIVE).isEmpty()) return result; test_id++;

	return result;
} // T_TON_POST


RsltAllDUTCtnr
TPG::T_PULLDOWN_RES()
{
	RsltAllDUTCtnr result;
	test_id = 2100;	
	ValDUT LX_Dis_R;
	ValDUT MODE_PD_RES;
	ValDUT EN_PD_RES;

	ValDUT V_LX_DIS;
	ValDUT I_EN_PD;
	ValDUT I_MODE_PD;
	

// Setup
    rdk::CW("K1;K16").on().APPLY(); // EN_MMXH, VIN_CAP
	rdk::Timer::WAIT(3e-3);

	//IC Turn on
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("1.8V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").connect().power(ON).APPLY();	//For spike

	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();
	rdk::Timer::WAIT(5e-3);

	rdk::MMXH::PMU("MODE_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").connect().power(ON).APPLY();
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").APPLY(); 
	rdk::Timer::WAIT(5e-3);
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").connect().power(ON).APPLY();
	rdk::Timer::WAIT(15e-3); 
	
	//LX_Dis_R
	rdk::MFHP::PMU("LX_mfhp_pmu").isvm("5.0mA",rdkenum::R30mA,rdkenum::R2V,"2.0V","-2V").connect(rdkenum::PORTA,rdkenum::PORTA).power(ON).APPLY();
	rdk::Timer::WAIT(3e-3); 

	V_LX_DIS = rdk::MFHP::PMU("LX_mfhp_pmu").MEAS_V(100);	
	
	for(ItrDUTs itrDut(DUT_ACTIVE); !itrDut.isDone(); itrDut++) 
	{
		LX_Dis_R[*itrDut] = (V_LX_DIS[*itrDut].getAsDouble()/0.005); 
    }

	rdk::MFHP::PMU("LX_mfhp_pmu").isvm("0.0mA",rdkenum::R30mA,rdkenum::R2V,"2.0V","-2V").APPLY();
	rdk::Timer::WAIT(3e-3);

	//EN_PD_RES
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("0.3V",rdkenum::R2V,rdkenum::R30uA,"30.0uA","-30.0uA").APPLY();
	rdk::Timer::WAIT(3e-3); 

	I_EN_PD = rdk::MMXH::PMU("EN_mmxh_pmu").MEAS_I(100); //mV	
		
	for(ItrDUTs itrDut(DUT_ACTIVE); !itrDut.isDone(); itrDut++) 
	{
		EN_PD_RES[*itrDut] = (0.3/I_EN_PD[*itrDut].getAsDouble())/1000; 
    }
	
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R30uA,"30.0uA","-30.0uA").APPLY();
	rdk::Timer::WAIT(3e-3); 
	
	//MODE_PD_RES 
	rdk::MMXH::PMU("MODE_mmxh_pmu").vsim("0.3V",rdkenum::R7V,rdkenum::R30uA,"30.0uA","-30.0uA").APPLY();
	rdk::Timer::WAIT(3e-3); 

	I_MODE_PD = rdk::MMXH::PMU("MODE_mmxh_pmu").MEAS_I(100); //mV	
	

	rdk::MMXH::PMU("MODE_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R30uA,"30.0uA","-30.0uA").APPLY();
	rdk::Timer::WAIT(3e-3); 

// clean up
	MMXH_PMU_Slewrate("VIN_mmxh_pmu" ,"Slow");  //for spike

	rdk::MMXH::PMU("MODE_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R30uA,"30.0uA","-30.0uA").APPLY();
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R30uA,"30.0uA","-30.0uA").APPLY();
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").APPLY(); 
	rdk::Timer::WAIT(3e-3); 
	rdk::MMXH::PMU("MODE_mmxh_pmu").disconnect().power(OFF).APPLY();	
	rdk::MMXH::PMU("EN_mmxh_pmu").disconnect().power(OFF).APPLY();	
	rdk::MMXH::PMU("VIN_mmxh_pmu").disconnect().power(OFF).APPLY();	
	rdk::MFHP::PMU("LX_mfhp_pmu").disconnect().power(OFF).APPLY();	
	rdk::CW("K_ALL").off().APPLY();
	rdk::Timer::WAIT(3e-3); 

	MMXH_PMU_Slewrate("VIN_mmxh_pmu" ,"VeryFast");  //for spike

	for(ItrDUTs itrDut(DUT_ACTIVE); !itrDut.isDone(); itrDut++) 
	{
		MODE_PD_RES[*itrDut] = (0.3/I_MODE_PD[*itrDut].getAsDouble())/1000; 
    }

	result |= Judge(test_id,"LX_Dis_R",      LX_Dis_R, 20.0, 100.0, "SoftBins.BIN36","SoftBins.BIN36","Ohms"); if(RscDUTs(DUT_ACTIVE).isEmpty())return result;
	result |= Judge(test_id,"EN_PD_RES",    EN_PD_RES,200.0, 500.0, "SoftBins.BIN36","SoftBins.BIN36","KOhms"); if(RscDUTs(DUT_ACTIVE).isEmpty())return result;
	result |= Judge(test_id,"MODE_PD_RES",MODE_PD_RES,200.0, 500.0, "SoftBins.BIN36","SoftBins.BIN36","KOhms"); if(RscDUTs(DUT_ACTIVE).isEmpty())return result;


	return result;
}


RsltAllDUTCtnr
TPG::T_INTER_POR_SEARCH()
{
	RsltAllDUTCtnr result;
	test_id = 2200;	
	ValDUT	INTER_POR_F;
	ValDUT	INTER_POR_R;

	RscTestCondition I2C_Timing("(Timing_I2C)");
	timing_set(Timming_Speed,I2C_Timing);

	//ktb8316_discharge(); // Discharge For preventing from affection of previous item

// Setup
    rdk::CW("K2;K3;K13;K16").on().APPLY(); //VIN_CAP, EN_MMXH, MODE_MDM, EN_MDM
	rdk::Timer::WAIT(3e-3);
	
	rdk::MMXH::PMU("MODE_mmxh_pmu").isvm("0.0A",rdkenum::R3mA,rdkenum::R7V,"7.0V","-7.0V").connect().power(ON).APPLY();	//Peer Review	
	
	//IC Turn on
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").connect().power(ON).APPLY();
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").connect().power(ON).APPLY();
	rdk::Timer::WAIT(5e-3);

	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").connect().power(ON).APPLY(); 
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").connect().power(ON).APPLY(); 
	rdk::Timer::WAIT(5e-3); 
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").connect().power(ON).APPLY(); 
	DPIN_Levelset("I2CPins","3.6V", "0.0V", "1.6V", "1.2V",CLOSE_,ON_);
	rdk::Timer::WAIT(15e-3); 

	I2C_Write2(0x6A,0x5A); 
	rdk::Timer::WAIT(1e-3); // enter test mode   
	I2C_Write2(0x6A,0xA5);
	rdk::Timer::WAIT(3e-3); // enter test mode   

	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").connect().power(ON).APPLY(); //EN Float-1
	rdk::Timer::WAIT(3e-3);
	rdk::MMXH::PMU("EN_mmxh_pmu").isvm("0.0mA",rdkenum::R3mA,rdkenum::R7V,"7.0V","-7V").connect().power(ON).APPLY(); //EN Float-2
	rdk::Timer::WAIT(3e-3);
	rdk::MMXH::PMU("EN_mmxh_pmu").disconnect().power(OFF).APPLY(); //EN Float-2
	rdk::Timer::WAIT(3e-3);

//INTER_POR_F
	ValDUT	dut_enter_F=0;
	ValDUT	temp_data = 99999;

	//int dut_int;
	int active_dut_cnt=0;
	int	active_dut_num=0;
	active_dut_num=RscDUTs(DUT_ACTIVE).getSize();


	for(int vx=0; vx<=70; vx = vx++)
	{
		double v_force_VD = 2.5 - vx*0.05; 

		rdk::MMXH::PMU("VIN_mmxh_pmu").vsim(v_force_VD,rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").connect().power(ON).APPLY(); //3mA Range best
		rdk::Timer::WAIT(3e-3);

		I2C_Write2(0x23,0x90); 
		rdk::Timer::WAIT(5e-3); // // set the readback path

		temp_data = I2C_Read(0x29);



		for(ItrDUTs itrDut(DUT_ACTIVE); !itrDut.isDone(); itrDut++) 
		{
			if(dut_enter_F[*itrDut].getAsInt() == 0)
			{			
				if( (temp_data[*itrDut].getAsInt()) != 0x01)  // 0x29 (RSVD[7:6] voSel[5:2] dout_rsense[1] TestmodeEn[0])
				{
					INTER_POR_F[*itrDut] = v_force_VD;
					active_dut_cnt++;			//for finish loop condition. 
					dut_enter_F[*itrDut]=1;		//check  Passed /Failed DUT, if Fail DUT still in the loop.
				}
			}

		}
		if(active_dut_num==active_dut_cnt)
		goto EXITFOR3;      		   
	} 
EXITFOR3:

//INTER_POR_R
	active_dut_cnt=0;
	active_dut_num=0;
	active_dut_num=RscDUTs(DUT_ACTIVE).getSize();

	temp_data = 99999;
	ValDUT	dut_enter_R=0;
	DPIN_Levelset("I2CPins","2.7V", "0.0V", "1.3V", "1.0V",CLOSE_,ON_);
	
	for(int vx=0; vx<=70; vx = vx++)
	{
		double v_force_VD = 1.2 + vx*0.05; 

		rdk::MMXH::PMU("VIN_mmxh_pmu").vsim(v_force_VD,rdkenum::R7V,rdkenum::R30mA,"30.0mA","-30.0mA").connect().power(ON).APPLY();
		rdk::MMXH::PMU("EN_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R30mA,"3.0mA","-3.0mA").connect().power(ON).APPLY();
		rdk::Timer::WAIT(5e-3);

		I2C_Write2(0x6A,0x5A); 
		rdk::Timer::WAIT(1e-3); // enter test mode 
		I2C_Write2(0x6A,0xA5); 
		rdk::Timer::WAIT(3e-3); // enter test mode   

		rdk::MMXH::PMU("EN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").APPLY(); //EN Float-1
		rdk::Timer::WAIT(1e-3);
		rdk::MMXH::PMU("EN_mmxh_pmu").isvm("0.0mA",rdkenum::R3mA,rdkenum::R7V,"7.0V","-7V").APPLY(); //EN Float-2
		rdk::Timer::WAIT(1e-3);
		rdk::MMXH::PMU("EN_mmxh_pmu").disconnect().power(OFF).APPLY(); //EN Float-2
		rdk::Timer::WAIT(3e-3);

		I2C_Write2(0x23,0x90); 
		rdk::Timer::WAIT(5e-3); // // set the readback path

		temp_data = I2C_Read(0x29);

		for(ItrDUTs itrDut(DUT_ACTIVE); !itrDut.isDone(); itrDut++) 
		{
			if(dut_enter_R[*itrDut].getAsInt() == 0)
			{
				if( (temp_data[*itrDut].getAsInt()) == 0x01)  // 0x29 (RSVD[7:6] voSel[5:2] dout_rsense[1] TestmodeEn[0])
				{
					INTER_POR_R[*itrDut] = v_force_VD;
					active_dut_cnt++;			//for finish loop condition. 
					dut_enter_R[*itrDut]=1;		//check  Passed /Failed DUT, if Fail DUT still in the loop.
				}
			}

		}
		if(active_dut_num==active_dut_cnt)
		goto EXITFOR4;      		   
	} 
EXITFOR4:

	I2C_Write2(0x6A,0x00); 
	rdk::Timer::WAIT(1e-3); // EXIT test mode

	// clean up
	rdk::MMXH::PMU("MODE_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").connect().power(ON).APPLY();
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").connect().power(ON).APPLY();
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").connect().power(ON).APPLY();
	rdk::Timer::WAIT(3e-3);	
	DPIN_Levelset("I2CPins",OPEN_,OFF_);
	rdk::MMXH::PMU("MODE_mmxh_pmu").disconnect().power(OFF).APPLY();	
	rdk::MMXH::PMU("VIN_mmxh_pmu").disconnect().power(OFF).APPLY();	
	rdk::MMXH::PMU("EN_mmxh_pmu").disconnect().power(OFF).APPLY();	
	rdk::MMXH::PMU("VOUT_mmxh_pmu").disconnect().power(OFF).APPLY();	
	rdk::CW("K_ALL").off().APPLY();
	rdk::Timer::WAIT(3e-3);

	result |= Judge(test_id,"INTER_POR_R", "T_INTER_POR_SEARCH_LS.INTER_POR_R", INTER_POR_R,"SoftBins.BIN33"); if(RscDUTs(DUT_ACTIVE).isEmpty())return result;  test_id++;
	result |= Judge(test_id,"INTER_POR_F", "T_INTER_POR_SEARCH_LS.INTER_POR_F", INTER_POR_F,"SoftBins.BIN33"); if(RscDUTs(DUT_ACTIVE).isEmpty())return result;  test_id++;

	return result;
} // T_INTER_POR_SEARCH



RsltAllDUTCtnr
TPG::T_INTER_POR_GNG()
{
	RsltAllDUTCtnr result;
	test_id = 2250;	
	ValDUT	INTER_POR_CK1;
	ValDUT	INTER_POR_CK2;
	ValDUT	INTER_POR_CK3;

	RscTestCondition I2C_Timing("(Timing_I2C)");
	timing_set(Timming_Speed,I2C_Timing);

	//ktb8316_discharge(); //Discharge For preventing from affection of previous item

// Setup
    rdk::CW("K2;K3;K13;K16").on().APPLY(); //MODE_MDM, EN_MDM, VIN_CAP, EN_MMXH
	rdk::Timer::WAIT(3e-3);

	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").connect().power(ON).APPLY(); 
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").connect().power(ON).APPLY();	
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").connect().power(ON).APPLY();	
	rdk::MMXH::PMU("MODE_mmxh_pmu").isvm("0.0A",rdkenum::R3mA,rdkenum::R7V,"7.0V","-7.0V").connect().power(ON).APPLY();	
	rdk::Timer::WAIT(3e-3);

	//IC Turn on
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("1.8V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY(); //For spike
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("1.8V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();	//For spike
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("1.8V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();	//For spike

	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").APPLY(); 
	DPIN_Levelset("I2CPins","3.6V", "0.0V", "1.6V", "1.2V",CLOSE_,ON_);
	rdk::Timer::WAIT(15e-3); 

	I2C_Write2(0x6A,0x5A); 
	rdk::Timer::WAIT(1e-3); // enter test mode   
	I2C_Write2(0x6A,0xA5);
	rdk::Timer::WAIT(3e-3); // enter test mode   
	I2C_Write2(0x23,0x90); 
	rdk::Timer::WAIT(2e-3); // // set the readback path

	MMXH_PMU_Slewrate("EN_mmxh_pmu"  ,"Slow");  //for spike	
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").APPLY(); //EN Float-1
	rdk::Timer::WAIT(3e-3);
	rdk::MMXH::PMU("EN_mmxh_pmu").isvm("0.0mA",rdkenum::R3mA,rdkenum::R7V,"7.0V","-7V").APPLY(); //EN Float-2
	rdk::Timer::WAIT(3e-3);
	MMXH_PMU_Slewrate("EN_mmxh_pmu"  ,"VeryFast");  //for spike	


//INTER_POR_CK1
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("1.8V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();	//For spike

	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("1.8V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY(); //For spike
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("1.8V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();	//For spike

	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("1.8V",rdkenum::R7V,rdkenum::R30mA,"30.0mA","-30.0mA").APPLY(); //For spike
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("1.8V",rdkenum::R7V,rdkenum::R30mA,"30.0mA","-30.0mA").APPLY();	//For spike
	
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("1.8V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").APPLY(); 
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("1.8V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").APPLY(); 
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").APPLY(); //When EN High->VOUT High temporary
	DPIN_Levelset("I2CPins","3.6V", "0.0V", "1.6V", "1.2V",CLOSE_,ON_);
	rdk::Timer::WAIT(15e-3); 

	I2C_Write2(0x6A,0x5A); 
	rdk::Timer::WAIT(1e-3); // enter test mode   
	I2C_Write2(0x6A,0xA5);
	rdk::Timer::WAIT(3e-3); // enter test mode   

	MMXH_PMU_Slewrate("EN_mmxh_pmu"  ,"Slow");  //for spike	
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").APPLY(); //EN Float-1
	rdk::Timer::WAIT(3e-3);
	rdk::MMXH::PMU("EN_mmxh_pmu").isvm("0.0mA",rdkenum::R3mA,rdkenum::R7V,"7.0V","-7V").APPLY(); //EN Float-2
	rdk::Timer::WAIT(3e-3);
	rdk::MMXH::PMU("EN_mmxh_pmu").disconnect().power(ON).APPLY(); //EN Float-2
	rdk::Timer::WAIT(5e-3);
	MMXH_PMU_Slewrate("EN_mmxh_pmu"  ,"VeryFast");  //for spike	

	I2C_Write2(0x23,0x90); 
	rdk::Timer::WAIT(2e-3); // // set the readback path

	INTER_POR_CK1 = I2C_Read(0x29);

//INTER_POR_CK2
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("1.8V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").connect().power(ON).APPLY();	//For spike

	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("1.3V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").APPLY(); 
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("1.3V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").APPLY(); 
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").APPLY(); 
	DPIN_Levelset("I2CPins","3.6V", "0.0V", "1.6V", "1.2V",CLOSE_,ON_); //Peer Review
	rdk::Timer::WAIT(15e-3); 

	I2C_Write2(0x6A,0x5A); 
	rdk::Timer::WAIT(1e-3); // enter test mode   
	I2C_Write2(0x6A,0xA5);
	rdk::Timer::WAIT(3e-3); // enter test mode   

	MMXH_PMU_Slewrate("EN_mmxh_pmu"  ,"Slow");  //for spike	
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").APPLY(); //EN Float-1
	rdk::Timer::WAIT(5e-3);
	rdk::MMXH::PMU("EN_mmxh_pmu").isvm("0.0mA",rdkenum::R3mA,rdkenum::R7V,"7.0V","-7V").APPLY(); //EN Float-2
	rdk::Timer::WAIT(5e-3);
	rdk::MMXH::PMU("EN_mmxh_pmu").disconnect().power(ON).APPLY(); //EN Float-2
	rdk::Timer::WAIT(7e-3);
	MMXH_PMU_Slewrate("EN_mmxh_pmu"  ,"VeryFast");  //for spike	

	I2C_Write2(0x23,0x90); 
	rdk::Timer::WAIT(2e-3); // // set the readback path

	INTER_POR_CK2 = I2C_Read(0x29);
//
//INTER_POR_CK3
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("1.8V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").connect().power(ON).APPLY();	//For spike

	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("2.1V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").APPLY(); 
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("2.1V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").APPLY(); 
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").APPLY(); 
	DPIN_Levelset("I2CPins","3.6V", "0.0V", "1.6V", "1.2V",CLOSE_,ON_); //Peer Review
	rdk::Timer::WAIT(15e-3); 

	I2C_Write2(0x6A,0x5A); 
	rdk::Timer::WAIT(1e-3); // enter test mode   
	I2C_Write2(0x6A,0xA5);
	rdk::Timer::WAIT(3e-3); // enter test mode   

	MMXH_PMU_Slewrate("EN_mmxh_pmu"  ,"Slow");  //for spike	
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").APPLY(); //EN Float-1
	rdk::Timer::WAIT(3e-3);
	rdk::MMXH::PMU("EN_mmxh_pmu").isvm("0.0mA",rdkenum::R3mA,rdkenum::R7V,"7.0V","-7V").APPLY(); //EN Float-2
	rdk::Timer::WAIT(3e-3);
	rdk::MMXH::PMU("EN_mmxh_pmu").disconnect().power(ON).APPLY(); //EN Float-2
	rdk::Timer::WAIT(5e-3);
	MMXH_PMU_Slewrate("EN_mmxh_pmu"  ,"VeryFast");  //for spike	

	I2C_Write2(0x23,0x90); 
	rdk::Timer::WAIT(2e-3); // // set the readback path

	INTER_POR_CK3 = I2C_Read(0x29);

	I2C_Write2(0x6A,0x00); 
	rdk::Timer::WAIT(1e-3); // EXIT test mode

	// clean up
	MMXH_PMU_Slewrate("VIN_mmxh_pmu"  ,"Slow");  //for spike	
	MMXH_PMU_Slewrate("VOUT_mmxh_pmu"  ,"Slow");  //for spike	

	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").APPLY();
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").APPLY();
	rdk::Timer::WAIT(3e-3);	
	DPIN_Levelset("I2CPins",OPEN_,OFF_);
	rdk::MMXH::PMU("MODE_mmxh_pmu").disconnect().power(OFF).APPLY();	
	rdk::MMXH::PMU("VIN_mmxh_pmu").disconnect().power(OFF).APPLY();	
	rdk::MMXH::PMU("VOUT_mmxh_pmu").disconnect().power(OFF).APPLY();	
	rdk::CW("K_ALL").off().APPLY();
	rdk::Timer::WAIT(3e-3);

	MMXH_PMU_Slewrate("VIN_mmxh_pmu"  , "VeryFast");  //for spike	
	MMXH_PMU_Slewrate("VOUT_mmxh_pmu"  ,"VeryFast");  //for spike	

	result |= Judge(test_id,"INTER_POR_CK1", "T_INTER_POR_GNG_LS.INTER_POR_H", INTER_POR_CK1,"SoftBins.BIN33"); if(RscDUTs(DUT_ACTIVE).isEmpty())return result;  test_id++;
	result |= Judge(test_id,"INTER_POR_CK2", "T_INTER_POR_GNG_LS.INTER_POR_L_T2K", INTER_POR_CK2,"SoftBins.BIN33"); if(RscDUTs(DUT_ACTIVE).isEmpty())return result;  test_id++;
	result |= Judge(test_id,"INTER_POR_CK3", "T_INTER_POR_GNG_LS.INTER_POR_H", INTER_POR_CK3,"SoftBins.BIN33"); if(RscDUTs(DUT_ACTIVE).isEmpty())return result;  test_id++;
	
	return result;
} // T_INTER_POR_GNG


RsltAllDUTCtnr 
TPG::T_REG_READ_POST()
{	
	RsltAllDUTCtnr result;
	ValDUT Read;
	test_id = 2300;	
	//ReadBack Part - local
	ValDUT RD_OTP40;
	ValDUT RD_OTP41;
	ValDUT RD_OTP42;
	ValDUT RD_OTP43;
	ValDUT RD_OTP44;
	ValDUT RD_OTP45;
	ValDUT RD_OTP46;
	ValDUT RD_OTP47;
	ValDUT RD_OTP48;

	RscTestCondition MODE_Timing("(Timing_MODE)");
	timing_set(Timming_Speed,MODE_Timing);

// Setup
    rdk::CW("K2;K3;K13;K16").on().APPLY(); // MODE_MDM, EN_MMXH, VIN_CAP, EN_MDM ? EN MDM과 MMXH를 둘 다 연결함.
	rdk::Timer::WAIT(1e-3);
	
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").connect().power(ON).APPLY(); 
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").connect().power(ON).APPLY(); 
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").connect().power(ON).APPLY(); 
	rdk::Timer::WAIT(1e-3);

//IC Turn on
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("1.8V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY(); //For spike
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("1.8V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();	//For spike
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("1.8V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();	//For spike

	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").APPLY();
	DPIN_Levelset("MODE_mdm","3.6V", "0.0V", "2.0V", "1.0V",CLOSE_,ON_);
	rdk::Timer::WAIT(3e-3); 

// Test Mode In	
	I2C_Write(0x6A,0x5A); // enter test mode 
	rdk::Timer::WAIT(1e-3); 
	I2C_Write(0x6A,0xA5); // enter test mode   
	rdk::Timer::WAIT(3e-3); 
		
//Read Register of TEST Part

	MMXH_PMU_Slewrate("EN_mmxh_pmu"  ,"Slow");  //for spike	
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R30mA,"3.0mA","-3.0mA").APPLY(); //EN Float-1
	rdk::Timer::WAIT(3e-3);
	rdk::MMXH::PMU("EN_mmxh_pmu").isvm("0.0uA",rdkenum::R3mA,rdkenum::R7V,"7.0V","-7V").APPLY(); 
	rdk::Timer::WAIT(3e-3);
	//rdk::MMXH::PMU("EN_mmxh_pmu").disconnect().power(OFF).APPLY(); //Keep connected for Read 0x27 - 241112
	DPIN_Levelset("MODE_mdm","3.6V", "0.0V", "2.0V", "1.0V",OPEN_,OFF_);	
	rdk::Timer::WAIT(3e-3);
    //rdk::CW("K16").off().APPLY();	 //Keep connected for Read 0x27 - 241112
	MMXH_PMU_Slewrate("EN_mmxh_pmu"  ,"VeryFast");  //for spike	


	//Read Register of TEST Part
	RscTestCondition I2C_Timing("(Timing_I2C)");
	timing_set(Timming_Speed,I2C_Timing);

	DPIN_Levelset("I2CPins","3.6V", "0.0V", "2.0V", "1.0V",CLOSE_,ON_);
	rdk::Timer::WAIT(3e-3);


//Read 0x6A
	I2C_Write2(0x23,0x90); // set the readback path   
	rdk::Timer::WAIT(1e-3); 

	Read = I2C_Read(0x6A);
	result |= Judge(test_id,"R2_REG_0x6A",	Read,   -0.5, 0.5,"SoftBins.BIN34","SoftBins.BIN34","Dec"); if(RscDUTs(DUT_ACTIVE).isEmpty())return result; test_id++;//Rev0p9
	
//Read 0x20
	I2C_Write2(0x23,0x90); // set the readback path 
	rdk::Timer::WAIT(1e-3);   

	Read = I2C_Read(0x20);
	result |= Judge(test_id,"R2_REG_0x20",	Read,   -0.5, 0.5,"SoftBins.BIN34","SoftBins.BIN34","Dec"); if(RscDUTs(DUT_ACTIVE).isEmpty())return result; test_id++;//Rev0p9

//Read 0x21
	I2C_Write2(0x23,0x90); // set the readback path
	rdk::Timer::WAIT(1e-3);  

	Read = I2C_Read(0x21);
	result |= Judge(test_id,"R2_REG_0x21",	Read,   -0.5, 255.5,"SoftBins.BIN34","SoftBins.BIN34","Dec"); if(RscDUTs(DUT_ACTIVE).isEmpty())return result; test_id++;

//Read 0x22
	I2C_Write2(0x23,0x90); // set the readback path   
	rdk::Timer::WAIT(1e-3); 

	Read = I2C_Read(0x22);
	result |= Judge(test_id,"R2_REG_0x22",	Read,   -0.5, 255.5,"SoftBins.BIN34","SoftBins.BIN34","Dec"); if(RscDUTs(DUT_ACTIVE).isEmpty())return result; test_id++;

//Read 0x23
	I2C_Write2(0x23,0x90); // set the readback path
	rdk::Timer::WAIT(1e-3);    

	Read = I2C_Read(0x23);
	result |= Judge(test_id,"R2_REG_0x23",	Read,   -0.5, 255.5,"SoftBins.BIN34","SoftBins.BIN34","Dec"); if(RscDUTs(DUT_ACTIVE).isEmpty())return result; test_id++;

//Read 0x24
	I2C_Write2(0x23,0x90); // set the readback path   
	rdk::Timer::WAIT(1e-3); 

	Read = I2C_Read(0x24);
	result |= Judge(test_id,"R2_REG_0x24",	Read,   -0.5, 255.5,"SoftBins.BIN34","SoftBins.BIN34","Dec"); if(RscDUTs(DUT_ACTIVE).isEmpty())return result; test_id++;

//Read 0x25
	I2C_Write2(0x23,0x90); // set the readback path
	rdk::Timer::WAIT(1e-3);    

	Read = I2C_Read(0x25);
	result |= Judge(test_id,"R2_REG_0x25",	Read,   -0.5, 255.5,"SoftBins.BIN34","SoftBins.BIN34","Dec"); if(RscDUTs(DUT_ACTIVE).isEmpty())return result; test_id++;

//Read 0x26
	I2C_Write2(0x23,0x90); // set the readback path   
	rdk::Timer::WAIT(1e-3); 

	Read = I2C_Read(0x26);
	result |= Judge(test_id,"R2_REG_0x26",	Read,   -0.5, 255.5,"SoftBins.BIN34","SoftBins.BIN34","Dec"); if(RscDUTs(DUT_ACTIVE).isEmpty())return result; test_id++;

//Read 0x27
	I2C_Write2(0x23,0x90); // set the readback path 
	rdk::Timer::WAIT(1e-3);   

	Read = I2C_Read(0x27);
	result |= Judge(test_id,"R2_REG_0x27",	Read,   1, 255.5,"SoftBins.BIN34","SoftBins.BIN34","Dec"); if(RscDUTs(DUT_ACTIVE).isEmpty())return result; test_id++;//Rev0p9

	ValDUT pfmcmp_code=0;
	ValDUT izxcmp_code=0;

	
	for(ItrDUTs itrDut(DUT_ACTIVE);!itrDut.isDone();itrDut++) 
	{
		int temp = Read[*itrDut];

		if(temp & 0x80)	{ pfmcmp_code[*itrDut]+=0x8;  }
		if(temp & 0x40)	{ pfmcmp_code[*itrDut]+=0x4;  }
		if(temp & 0x20)	{ pfmcmp_code[*itrDut]+=0x2;  }
		if(temp & 0x10)	{ pfmcmp_code[*itrDut]+=0x1;  }
		if(temp & 0x08)	{ izxcmp_code[*itrDut]+=0x8;  }
		if(temp & 0x04)	{ izxcmp_code[*itrDut]+=0x4;  }
		if(temp & 0x02)	{ izxcmp_code[*itrDut]+=0x2;  }
		if(temp & 0x01)	{ izxcmp_code[*itrDut]+=0x1;  }

	}
	result |= Judge(test_id,"pfmcmp_code",	pfmcmp_code,   -0.5, 15.5,"SoftBins.BIN35","SoftBins.BIN35","Dec"); if(RscDUTs(DUT_ACTIVE).isEmpty())return result; test_id++; //limit changed - 250226
	result |= Judge(test_id,"izxcmp_code",	izxcmp_code,   -0.5, 15.5,"SoftBins.BIN35","SoftBins.BIN35","Dec"); if(RscDUTs(DUT_ACTIVE).isEmpty())return result; test_id++; //limit changed - 250226
	 

//Read 0x28
	I2C_Write2(0x23,0x90); // set the readback path 
	rdk::Timer::WAIT(1e-3);   

	Read = I2C_Read(0x28);
	result |= Judge(test_id,"R2_REG_0x28",	Read,   -0.5, 255.5,"SoftBins.BIN34","SoftBins.BIN34","Dec"); if(RscDUTs(DUT_ACTIVE).isEmpty())return result; test_id++;

//Read 0x29
	I2C_Write2(0x23,0x90); // set the readback path 
	rdk::Timer::WAIT(1e-3);   

	Read = I2C_Read(0x29);
	result |= Judge(test_id,"R2_REG_0x29",	Read,   -0.5, 255.5,"SoftBins.BIN34","SoftBins.BIN34","Dec"); if(RscDUTs(DUT_ACTIVE).isEmpty())return result; test_id++;


//Read Register of OTP Part

//Read 0x40
	I2C_Write2(0x23,0x90); 
	rdk::Timer::WAIT(1e-3);
	
	RD_OTP40  = I2C_Read(0x40);  // Read OTP
	result |= Judge(test_id,"R2_REG_0x40",     RD_OTP40,  -0.5, 255.5,"SoftBins.BIN34","SoftBins.BIN34","Dec"); if(RscDUTs(DUT_ACTIVE).isEmpty())return result; test_id++;

//Read 0x41
	I2C_Write2(0x23,0x90); 
	rdk::Timer::WAIT(1e-3);

	RD_OTP41  = I2C_Read(0x41);  // Read OTP
	result |= Judge(test_id,"R2_REG_0x41",      RD_OTP41,  -0.5, 255.5,"SoftBins.BIN34","SoftBins.BIN34","Dec"); if(RscDUTs(DUT_ACTIVE).isEmpty())return result; test_id++;


//Read 0x42
	I2C_Write2(0x23,0x90); rdk::Timer::WAIT(1e-3);
	RD_OTP42  = I2C_Read(0x42);  // Read OTP
	result |= Judge(test_id,"R2_REG_0x42",      RD_OTP42,  -0.5, 255.5,"SoftBins.BIN34","SoftBins.BIN34","Dec"); if(RscDUTs(DUT_ACTIVE).isEmpty())return result; test_id++;


//Read 0x43
	I2C_Write2(0x23,0x90); 
	rdk::Timer::WAIT(1e-3);

	RD_OTP43  = I2C_Read(0x43);  // Read OTP
	result |= Judge(test_id,"R2_REG_0x43",         RD_OTP43,  -0.5, 255.5,"SoftBins.BIN34","SoftBins.BIN34","Dec"); if(RscDUTs(DUT_ACTIVE).isEmpty())return result; test_id++;

//Read 0x47 - 0x47 Fist, 0x44 is better to stable OTP READ. But display later. 240827
	I2C_Write2(0x23,0x90); 
	rdk::Timer::WAIT(1e-3);

	RD_OTP47  = I2C_Read(0x47);  // Read OTP

//Read 0x44
	I2C_Write2(0x23,0x90); 
	rdk::Timer::WAIT(1e-3);

	RD_OTP44  = I2C_Read(0x44);  // Read OTP
	result |= Judge(test_id,"R2_REG_0x44",RD_OTP44,  -0.5, 255.5,"SoftBins.BIN34","SoftBins.BIN34","Dec"); if(RscDUTs(DUT_ACTIVE).isEmpty())return result; test_id++;

//Read 0x45
	I2C_Write2(0x23,0x90); 
	rdk::Timer::WAIT(1e-3);

	RD_OTP45  = I2C_Read(0x45);  // Read OTP
	result |= Judge(test_id,"R2_REG_0x45",RD_OTP45,  -0.5, 255.5,"SoftBins.BIN34","SoftBins.BIN34","Dec"); if(RscDUTs(DUT_ACTIVE).isEmpty())return result; test_id++;

//Read 0x46
	I2C_Write2(0x23,0x90); 
	rdk::Timer::WAIT(1e-3);

//Display Read 0x47
	RD_OTP46  = I2C_Read(0x46);  // Read OTP
	result |= Judge(test_id,"R2_REG_0x46",RD_OTP46,  -0.5, 255.5,"SoftBins.BIN34","SoftBins.BIN34","Dec"); if(RscDUTs(DUT_ACTIVE).isEmpty())return result; test_id++;

//Display Read 0x47
	result |= Judge(test_id,"R2_REG_0x47",RD_OTP47,  -0.5, 255.5,"SoftBins.BIN34","SoftBins.BIN34","Dec"); if(RscDUTs(DUT_ACTIVE).isEmpty())return result; test_id++;

//Read 0x48
	I2C_Write2(0x23,0x90); 
	rdk::Timer::WAIT(1e-3);

	RD_OTP48  = I2C_Read(0x48);  // Read OTP
	result |= Judge(test_id,"R2_REG_0x48",RD_OTP48,  -0.5, 255.5,"SoftBins.BIN34","SoftBins.BIN34","Dec"); if(RscDUTs(DUT_ACTIVE).isEmpty())return result; test_id++;

// clean up
	I2C_Write(0x6A,0x00); //Exit Test Mode
	rdk::Timer::WAIT(1e-3); 

	MMXH_PMU_Slewrate("VIN_mmxh_pmu" ,"Slow");  //for spike
	MMXH_PMU_Slewrate("VOUT_mmxh_pmu","Slow");  //for spike

	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();
	rdk::Timer::WAIT(3e-3);
	rdk::MMXH::PMU("VOUT_mmxh_pmu").disconnect().power(OFF).APPLY();	
	rdk::MMXH::PMU("VIN_mmxh_pmu").disconnect().power(OFF).APPLY();	
	rdk::MMXH::PMU("EN_mmxh_pmu").disconnect().power(OFF).APPLY();	
	DPIN_Levelset("I2CPins",OPEN_,OFF_);
	rdk::CW("K_ALL").off().APPLY();
	rdk::Timer::WAIT(3e-3);
	
	MMXH_PMU_Slewrate("VIN_mmxh_pmu" ,"VeryFast");  //for spike
	MMXH_PMU_Slewrate("VOUT_mmxh_pmu","VeryFast");  //for spike

	return result;		
} //T_REG_READ_Post

RsltAllDUTCtnr
TPG::T_LEAKAGE_POST()
{
	RsltAllDUTCtnr result;
	test_id = 2400;	
	OFCArray<ValDUT> ILK_VIN_POST(1,100); 
	OFCArray<ValDUT> ILK_MODE_POST_H(1,100); 
	OFCArray<ValDUT> ILK_MODE_POST_L(1,100); 
	OFCArray<ValDUT> ILK_EN_POST_H(1,100); 
	OFCArray<ValDUT> ILK_EN_POST_L(1,100); 
	OFCArray<ValDUT> ILK_LX_POST_H(1,100); 
	OFCArray<ValDUT> ILK_LX_POST_L(1,100);
	OFCArray<ValDUT> ILK_VOUT_POST_H(1,100); 
	OFCArray<ValDUT> ILK_VOUT_POST_L(1,100); 

	OFCArray<ValDUT> ILK_VIN_DELTA(1,100); 
	OFCArray<ValDUT> ILK_MODE_DELTA_H(1,100); 
	OFCArray<ValDUT> ILK_MODE_DELTA_L(1,100); 
	OFCArray<ValDUT> ILK_EN_DELTA_H(1,100); 
	OFCArray<ValDUT> ILK_EN_DELTA_L(1,100); 
	OFCArray<ValDUT> ILK_LX_DELTA_H(1,100); 
	OFCArray<ValDUT> ILK_LX_DELTA_L(1,100);
	OFCArray<ValDUT> ILK_VOUT_DELTA_H(1,100); 
	OFCArray<ValDUT> ILK_VOUT_DELTA_L(1,100); 

	RscTestCondition MODE_Timing("(Timing_MODE)");
	timing_set(Timming_Speed,MODE_Timing);

	rdk::CW("K1;K16").on().APPLY();  //MODE_MMXH EN_MMXH // In ACCO, Using LX MFHP(FPVI), But Using MMXH in this.
	rdk::Timer::WAIT(3e-3);

	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").connect().power(ON).APPLY();
	rdk::MMXH::PMU("MODE_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").connect().power(ON).APPLY();
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R3mA,"3.0mA","-3.0mA").connect().power(ON).APPLY();
	rdk::Timer::WAIT(3e-3);

//IC Turn on
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("2.5V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();	//For spike
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("4.5V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();	//For spike
	
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("5.5V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();
	rdk::Timer::WAIT(3e-3);

//VIN_Leak_Post
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("5.5V",rdkenum::R7V,rdkenum::R30mA,"30.0mA","-30.0mA").APPLY();
	rdk::Timer::WAIT(5e-3);
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("5.5V",rdkenum::R7V,rdkenum::R30uA,"30.0uA","-30.0uA").APPLY();
	rdk::Timer::WAIT(3e-3);

	ILK_VIN_POST[0] = rdk::MMXH::PMU("VIN_mmxh_pmu").MEAS_I(100);

	MMXH_PMU_Slewrate("VIN_mmxh_pmu","Slow");   //for spike
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R30uA,"30.0uA","-30.0uA").APPLY();
	rdk::Timer::WAIT(3e-3);
	MMXH_PMU_Slewrate("VIN_mmxh_pmu","VeryFast");   //for spike

//Iik_modeh_post
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("2.5V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();	//For spike
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("4.5V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();	//For spike

	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("5.5V",rdkenum::R7V,rdkenum::R240mA,"240.0mA","-240.0mA").APPLY();
	rdk::Timer::WAIT(3e-3);
	rdk::MMXH::PMU("MODE_mmxh_pmu").vsim("5.5V",rdkenum::R7V,rdkenum::R300uA,"300.0uA","-300.0uA").APPLY();
	rdk::Timer::WAIT(3e-3);

	ILK_MODE_POST_H[0] = rdk::MMXH::PMU("MODE_mmxh_pmu").MEAS_I(100);

//Iik_model_post
	MMXH_PMU_Slewrate("MODE_mmxh_pmu","Slow");  //for spike
	rdk::MMXH::PMU("MODE_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R300uA,"300.0uA","-300.0uA").APPLY(); 
	rdk::Timer::WAIT(3e-3);
	MMXH_PMU_Slewrate("MODE_mmxh_pmu","VeryFast");  //for spike

	ILK_MODE_POST_L[0] = rdk::MMXH::PMU("MODE_mmxh_pmu").MEAS_I(100);	

	rdk::MMXH::PMU("MODE_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R30mA,"30.0mA","-30.0mA").APPLY(); 
	rdk::Timer::WAIT(3e-3);

//Ilk_vouth_post
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("2.5V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").connect().power(ON).APPLY();	//For spike
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("4.5V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();	//For spike
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("5.5V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();	//For spike

	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("5.5V",rdkenum::R7V,rdkenum::R30mA,"30.0mA","-30.0mA").APPLY();
	rdk::Timer::WAIT(3e-3);
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("5.5V",rdkenum::R7V,rdkenum::R300uA,"300.0uA","-300.0uA").APPLY();
	rdk::Timer::WAIT(3e-3);

	ILK_VOUT_POST_H[0] = rdk::MMXH::PMU("VOUT_mmxh_pmu").MEAS_I(100);
//Ilk_voutl_post
	MMXH_PMU_Slewrate("VOUT_mmxh_pmu","Slow");  //for spike
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R300uA,"300.0uA","-300.0uA").APPLY();
	rdk::Timer::WAIT(3e-3);
	MMXH_PMU_Slewrate("VOUT_mmxh_pmu","VeryFast");  //for spike

	ILK_VOUT_POST_L[0] = rdk::MMXH::PMU("VOUT_mmxh_pmu").MEAS_I(100);

//Clean up
	MMXH_PMU_Slewrate("VIN_mmxh_pmu","Slow");   //for spike
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R30mA,"30.0mA","-30.0mA").APPLY();
	rdk::Timer::WAIT(3e-3);
	rdk::MMXH::PMU("MODE_mmxh_pmu").disconnect().power(OFF).APPLY();
	rdk::MMXH::PMU("EN_mmxh_pmu").disconnect().power(OFF).APPLY();
	rdk::MMXH::PMU("VOUT_mmxh_pmu").disconnect().power(OFF).APPLY();
	rdk::MMXH::PMU("VIN_mmxh_pmu").disconnect().power(OFF).APPLY();

	rdk::CW("K_ALL").off().APPLY(); 
	rdk::Timer::WAIT(3e-3);
	MMXH_PMU_Slewrate("VIN_mmxh_pmu","VeryFast");   //for spike

	result |= Judge(test_id,"Ilk_vin_post",  "T_LEAK_POST_LS.Leak_Post",ILK_VIN_POST[0],"SoftBins.BIN8"); if(RscDUTs(DUT_ACTIVE).isEmpty())return result; test_id++;

	result |= Judge(test_id,"Ilk_modeh_post",  "T_LEAK_POST_LS.Leak_Post",ILK_MODE_POST_H[0],"SoftBins.BIN8"); if(RscDUTs(DUT_ACTIVE).isEmpty())return result; test_id++;
	result |= Judge(test_id,"Ilk_model_post",  "T_LEAK_POST_LS.Leak_Post",ILK_MODE_POST_L[0],"SoftBins.BIN8"); if(RscDUTs(DUT_ACTIVE).isEmpty())return result; test_id++;

	result |= Judge(test_id,"Ilk_vouth_post",  "T_LEAK_POST_LS.Leak_VOUT_H",ILK_VOUT_POST_H[0],"SoftBins.BIN8"); if(RscDUTs(DUT_ACTIVE).isEmpty())return result; test_id++;
	result |= Judge(test_id,"Ilk_voutl_post",  "T_LEAK_POST_LS.Leak_VOUT_L",ILK_VOUT_POST_L[0],"SoftBins.BIN8"); if(RscDUTs(DUT_ACTIVE).isEmpty())return result; test_id++;

//Ilk_enh_post
	rdk::CW("K1;K12;K13;K16").on().APPLY();  
	rdk::Timer::WAIT(3e-3);

	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").connect().power(ON).APPLY();
	rdk::MMXH::PMU("MODE_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").connect().power(ON).APPLY();
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").connect().power(ON).APPLY();
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").connect().power(ON).APPLY();
	rdk::Timer::WAIT(3e-3);

//IC Turn on
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("2.5V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();	//For spike
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("2.5V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();	//For spike

	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("4.5V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();	//For spike
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("4.5V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();	//For spike

	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("5.5V",rdkenum::R7V,rdkenum::R240mA,"100mA","-100mA").APPLY();//3mA best
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("5.5V",rdkenum::R7V,rdkenum::R240mA,"100mA","-100mA").APPLY();//3mA best
	rdk::Timer::WAIT(5e-3);

	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("5.5V",rdkenum::R7V,rdkenum::R3mA,"3mA","-3mA").APPLY();
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("5.5V",rdkenum::R7V,rdkenum::R3mA,"3mA","-3mA").APPLY();//3mA best
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("5.5V",rdkenum::R7V,rdkenum::R3mA,"3mA","-3mA").APPLY();
	rdk::Timer::WAIT(5e-3);
	
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("5.5V",rdkenum::R7V,rdkenum::R30uA,"30uA","-30uA").APPLY();
	rdk::Timer::WAIT(15e-3);
	ILK_EN_POST_H[0] = rdk::MMXH::PMU("EN_mmxh_pmu").MEAS_I(100);

//Ilk_enl_post
	MMXH_PMU_Slewrate("EN_mmxh_pmu","Slow");   //for spike	
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R3mA,"3mA","-3mA").APPLY();
	rdk::Timer::WAIT(5e-3);
	MMXH_PMU_Slewrate("EN_mmxh_pmu","VeryFast");   //for spike	

	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R30uA,"30uA","-30uA").APPLY();
	rdk::Timer::WAIT(10e-3);

	ILK_EN_POST_L[0] = rdk::MMXH::PMU("EN_mmxh_pmu").MEAS_I(100);
	
//Clean up
	MMXH_PMU_Slewrate("VIN_mmxh_pmu" ,"Slow");   //for spike
	MMXH_PMU_Slewrate("VOUT_mmxh_pmu","Slow");  //for spike

	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R30uA,"30.0uA","-30.0uA").APPLY();
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R3mA,"3mA","-3mA").APPLY();
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R3mA,"3mA","-3mA").APPLY();
	rdk::Timer::WAIT(3e-3);
	rdk::MMXH::PMU("VOUT_mmxh_pmu").disconnect().power(OFF).APPLY();
	rdk::MMXH::PMU("EN_mmxh_pmu").disconnect().power(OFF).APPLY();
	rdk::MMXH::PMU("VIN_mmxh_pmu").disconnect().power(OFF).APPLY();
	rdk::MMXH::PMU("MODE_mmxh_pmu").disconnect().power(OFF).APPLY();
	rdk::CW("K_ALL").off().APPLY(); 
	rdk::Timer::WAIT(3e-3);

	MMXH_PMU_Slewrate("VIN_mmxh_pmu" ,"VeryFast");   //for spike
	MMXH_PMU_Slewrate("VOUT_mmxh_pmu","VeryFast");  //for spike

	result |= Judge(test_id,"Ilk_enh_post",  "T_LEAK_POST_LS.Leak_Post",ILK_EN_POST_H[0],"SoftBins.BIN8"); if(RscDUTs(DUT_ACTIVE).isEmpty())return result; test_id++;
	result |= Judge(test_id,"Ilk_enl_post",  "T_LEAK_POST_LS.Leak_Post",ILK_EN_POST_L[0],"SoftBins.BIN8"); if(RscDUTs(DUT_ACTIVE).isEmpty())return result; test_id++;

// Setup - LX Lkg
    rdk::CW("K2;K13;K16").on().APPLY(); // MODE_MDM, EN_MMXH, VIN_CAP
	rdk::Timer::WAIT(1e-3);

	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R3mA,"3mA","-3mA").connect().power(ON).APPLY();
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R3mA,"3mA","-3mA").connect().power(ON).APPLY();
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R3mA,"3mA","-3mA").connect().power(ON).APPLY();
	rdk::MMXH::PMU("LX_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R3mA,"3mA","-3mA").connect().power(ON).APPLY();
	rdk::Timer::WAIT(1e-3);

//IC Turn on
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("1.8V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();	//For spike
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("1.8V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();	//For spike

	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();
	rdk::Timer::WAIT(5e-3);

	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R3mA,"3mA","-3mA").APPLY();
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R3mA,"3mA","-3mA").APPLY();
	rdk::Timer::WAIT(3e-3); 
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R3mA,"3mA","-3mA").APPLY();
	DPIN_Levelset("MODE_mdm","3.6V", "0.0V", "1.8V", "1.8V",CLOSE_,ON_);
	rdk::Timer::WAIT(5e-3); 

// Test Mode In	
	I2C_Write(0x6A,0x5A); // enter test mode 
	rdk::Timer::WAIT(1e-3); 
	I2C_Write(0x6A,0xA5); // enter test mode   
	rdk::Timer::WAIT(3e-3); 

	I2C_Write(0x25,0x01); // (T_DISABLE_DRVR=1);
	rdk::Timer::WAIT(1e-3); 

	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("4.5V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();	//For spike

	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("5.5V",rdkenum::R7V,rdkenum::R3mA,"3mA","-3mA").APPLY();
	rdk::Timer::WAIT(6e-3); 
//Ilk_lxh_post
	rdk::MMXH::PMU("LX_mmxh_pmu").vsim("2.5V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();	//For spike
	rdk::MMXH::PMU("LX_mmxh_pmu").vsim("4.5V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").APPLY();	//For spike

	rdk::MMXH::PMU("LX_mmxh_pmu").vsim("5.5V",rdkenum::R7V,rdkenum::R3mA,"3mA","-3mA").APPLY();
	rdk::Timer::WAIT(5e-3);
	rdk::MMXH::PMU("LX_mmxh_pmu").vsim("5.5V",rdkenum::R7V,rdkenum::R30uA,"30.0uA","-30.0uA").APPLY();
	rdk::Timer::WAIT(5e-3);

	ILK_LX_POST_H[0] = rdk::MMXH::PMU("LX_mmxh_pmu").MEAS_I(100);

//Ilk_lxl_post
	MMXH_PMU_Slewrate("LX_mmxh_pmu","Slow");   //for spike
	rdk::MMXH::PMU("LX_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R30uA,"30.0uA","-30.0uA").APPLY();
	rdk::Timer::WAIT(5e-3);
	MMXH_PMU_Slewrate("LX_mmxh_pmu","VeryFast");   //for spike

	ILK_LX_POST_L[0] = rdk::MMXH::PMU("LX_mmxh_pmu").MEAS_I(100);

	I2C_Write(0x6A,0x00); //Exit Test mode
	rdk::Timer::WAIT(1e-3); 

// clean up
	MMXH_PMU_Slewrate("VIN_mmxh_pmu" ,"Slow");  //for spike
	MMXH_PMU_Slewrate("VOUT_mmxh_pmu","Slow");  //for spike
	MMXH_PMU_Slewrate("EN_mmxh_pmu"  ,"Slow");  //for spike	

	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R3mA,"3mA","-3mA").APPLY();
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R3mA,"3mA","-3mA").APPLY();
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R3mA,"3mA","-3mA").APPLY();
	rdk::Timer::WAIT(3e-3); 
	DPIN_Levelset("MODE_mdm",OPEN_,OFF_);
	rdk::MMXH::PMU("VOUT_mmxh_pmu").disconnect().power(OFF).APPLY();	
	rdk::MMXH::PMU("EN_mmxh_pmu").disconnect().power(OFF).APPLY();	
	rdk::MMXH::PMU("VIN_mmxh_pmu").disconnect().power(OFF).APPLY();	
	rdk::MMXH::PMU("LX_mmxh_pmu").disconnect().power(OFF).APPLY();	
	rdk::CW("K_ALL").off().APPLY();
	rdk::Timer::WAIT(3e-3); 

	MMXH_PMU_Slewrate("VIN_mmxh_pmu" ,"VeryFast");  //for spike
	MMXH_PMU_Slewrate("VOUT_mmxh_pmu","VeryFast");  //for spike
	MMXH_PMU_Slewrate("EN_mmxh_pmu"  ,"VeryFast");  //for spike	


	result |= Judge(test_id,"Ilk_lxh_post",  "T_LEAK_POST_LS.Leak_Post",ILK_LX_POST_H[0],"SoftBins.BIN8"); if(RscDUTs(DUT_ACTIVE).isEmpty())return result; test_id++;
	result |= Judge(test_id,"Ilk_lxl_post",  "T_LEAK_POST_LS.Leak_Post",ILK_LX_POST_L[0],"SoftBins.BIN8"); if(RscDUTs(DUT_ACTIVE).isEmpty())return result; test_id++;

//Delta Calulation
	//DELTA VIN
	for(ItrDUTs itrDut(DUT_ACTIVE);!itrDut.isDone();itrDut++) 
	{
		ILK_VIN_DELTA[0][*itrDut]    = ILK_VIN_PRE[0][*itrDut].getAsDouble()    -  ILK_VIN_POST[0][*itrDut].getAsDouble();
		ILK_MODE_DELTA_H[0][*itrDut] = ILK_MODE_PRE_H[0][*itrDut].getAsDouble() -  ILK_MODE_POST_H[0][*itrDut].getAsDouble();
		ILK_MODE_DELTA_L[0][*itrDut] = ILK_MODE_PRE_L[0][*itrDut].getAsDouble() -  ILK_MODE_POST_L[0][*itrDut].getAsDouble();
		ILK_EN_DELTA_H[0][*itrDut]   = ILK_EN_PRE_H[0][*itrDut].getAsDouble()   -  ILK_EN_POST_H[0][*itrDut].getAsDouble();
		ILK_EN_DELTA_L[0][*itrDut]   = ILK_EN_PRE_L[0][*itrDut].getAsDouble()   -  ILK_EN_POST_L[0][*itrDut].getAsDouble();
		ILK_LX_DELTA_H[0][*itrDut]   = ILK_LX_PRE_H[0][*itrDut].getAsDouble()   -  ILK_LX_POST_H[0][*itrDut].getAsDouble();
		ILK_LX_DELTA_L[0][*itrDut]   = ILK_LX_PRE_L[0][*itrDut].getAsDouble()   -  ILK_LX_POST_L[0][*itrDut].getAsDouble();
		ILK_VOUT_DELTA_H[0][*itrDut] = ILK_VOUT_PRE_H[0][*itrDut].getAsDouble() -  ILK_VOUT_POST_H[0][*itrDut].getAsDouble();
		ILK_VOUT_DELTA_L[0][*itrDut] = ILK_VOUT_PRE_L[0][*itrDut].getAsDouble() -  ILK_VOUT_POST_L[0][*itrDut].getAsDouble();
	}

	result |= Judge(test_id,"Ilk_vin_delta",   "T_LEAK_POST_LS.Leak_delta",		 ILK_VIN_DELTA[0],"SoftBins.BIN9"); if(RscDUTs(DUT_ACTIVE).isEmpty())return result; test_id++;
	result |= Judge(test_id,"Ilk_modeh_delta","T_LEAK_POST_LS.Leak_delta",		 ILK_MODE_DELTA_H[0],"SoftBins.BIN9"); if(RscDUTs(DUT_ACTIVE).isEmpty())return result; test_id++;
	result |= Judge(test_id,"Ilk_model_delta","T_LEAK_POST_LS.Leak_delta",		 ILK_MODE_DELTA_L[0],"SoftBins.BIN9"); if(RscDUTs(DUT_ACTIVE).isEmpty())return result; test_id++;
	result |= Judge(test_id,"Ilk_enh_delta",  "T_LEAK_POST_LS.Leak_delta",		 ILK_EN_DELTA_H[0],"SoftBins.BIN9"); if(RscDUTs(DUT_ACTIVE).isEmpty())return result; test_id++;
	result |= Judge(test_id,"Ilk_enl_delta",  "T_LEAK_POST_LS.Leak_delta",		 ILK_EN_DELTA_L[0],"SoftBins.BIN9"); if(RscDUTs(DUT_ACTIVE).isEmpty())return result; test_id++;
	result |= Judge(test_id,"Ilk_lxh_delta",  "T_LEAK_POST_LS.Leak_delta",		 ILK_LX_DELTA_H[0],"SoftBins.BIN9"); if(RscDUTs(DUT_ACTIVE).isEmpty())return result; test_id++;
	result |= Judge(test_id,"Ilk_lxl_delta",  "T_LEAK_POST_LS.Leak_delta",	     ILK_LX_DELTA_L[0],"SoftBins.BIN9"); if(RscDUTs(DUT_ACTIVE).isEmpty())return result; test_id++;
	result |= Judge(test_id,"Ilk_vouth_delta", "T_LEAK_POST_LS.Leak_VOUT_H_delta",  ILK_VOUT_DELTA_H[0],"SoftBins.BIN9"); if(RscDUTs(DUT_ACTIVE).isEmpty())return result; test_id++;
	result |= Judge(test_id,"Ilk_voutl_delta", "T_LEAK_POST_LS.Leak_VOUT_L_delta",  ILK_VOUT_DELTA_L[0],"SoftBins.BIN9"); if(RscDUTs(DUT_ACTIVE).isEmpty())return result; test_id++;
	
	return result;
} // T_LEAK_POST



RsltAllDUTCtnr
TPG::T_CONTINUITY_POST()
{
	RsltAllDUTCtnr result;

	test_id = 2500;	

	OFCArray<ValDUT> OS2_data(3,100); 
    OFCArray<ValDUT> meas_data(2,100);

	rdk::CW("K1;K16").on().APPLY(); 	
	rdk::Timer::WAIT(1.0e-3);

	rdk::MMXH::PMU("OS_mmxh_pmu").vsim("0.0V",rdkenum::R2V,rdkenum::R3mA,"3.0mA","-3.0mA").connect().power(ON).APPLY();	
	rdk::Timer::WAIT(1.0e-3);

	rdk::MMXH::PMU("VIN_mmxh_pmu").isvm("-0.1mA",rdkenum::R3mA,rdkenum::R2V,"2V","-2V").connect().power(ON).APPLY();
	rdk::Timer::WAIT(1.0e-3);
	meas_data[0] = rdk::MMXH::PMU("VIN_mmxh_pmu").MEAS_V(100);
	rdk::MMXH::PMU("VIN_mmxh_pmu").iforce("0.0uA").APPLY(); 
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("0.0V",rdkenum::R2V,rdkenum::R3mA,"3.0mA","-3.0mA").APPLY();
	result |= Judge(test_id,"OS2_VIN","T_CONT_LS.OS_N",meas_data[0],"SoftBins.BIN6"); if(RscDUTs(DUT_ACTIVE).isEmpty())return result;test_id++;

	rdk::MMXH::PMU("LX_mmxh_pmu").isvm("-0.1mA",rdkenum::R3mA,rdkenum::R2V,"2V","-2V").connect().power(ON).APPLY();
	rdk::Timer::WAIT(1.0e-3);
	meas_data[0] = rdk::MMXH::PMU("LX_mmxh_pmu").MEAS_V(100);
	rdk::MMXH::PMU("LX_mmxh_pmu").iforce("0.0uA").APPLY(); 
	rdk::MMXH::PMU("LX_mmxh_pmu").vsim("0.0V",rdkenum::R2V,rdkenum::R3mA,"3.0mA","-3.0mA").APPLY();
	result |= Judge(test_id,"OS2_LX","T_CONT_LS.OS_N",meas_data[0],"SoftBins.BIN6"); if(RscDUTs(DUT_ACTIVE).isEmpty())return result;test_id++;

	rdk::MMXH::PMU("VOUT_mmxh_pmu").isvm("-0.1mA",rdkenum::R3mA,rdkenum::R2V,"2V","-2V").connect().power(ON).APPLY();
	rdk::Timer::WAIT(1.0e-3);
	meas_data[0] = rdk::MMXH::PMU("VOUT_mmxh_pmu").MEAS_V(100);
	rdk::MMXH::PMU("VOUT_mmxh_pmu").iforce("0.0uA").APPLY(); 
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("0.0V",rdkenum::R2V,rdkenum::R3mA,"3.0mA","-3.0mA").APPLY();
	result |= Judge(test_id,"OS2_VOUT","T_CONT_LS.OS_N",meas_data[0],"SoftBins.BIN6"); if(RscDUTs(DUT_ACTIVE).isEmpty())return result;test_id++;

	rdk::MMXH::PMU("EN_mmxh_pmu").isvm("-0.1mA",rdkenum::R3mA,rdkenum::R2V,"2V","-2V").connect().power(ON).APPLY();
	rdk::Timer::WAIT(1.0e-3);
	meas_data[0] = rdk::MMXH::PMU("EN_mmxh_pmu").MEAS_V(100);
	rdk::MMXH::PMU("EN_mmxh_pmu").iforce("0.0uA").APPLY(); 
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("0.0V",rdkenum::R2V,rdkenum::R3mA,"3.0mA","-3.0mA").APPLY();
	result |= Judge(test_id,"OS2_EN","T_CONT_LS.OS_N",meas_data[0],"SoftBins.BIN6"); if(RscDUTs(DUT_ACTIVE).isEmpty())return result;test_id++;

	rdk::MMXH::PMU("MODE_mmxh_pmu").isvm("-0.1mA",rdkenum::R3mA,rdkenum::R2V,"2V","-2V").connect().power(ON).APPLY();
	rdk::Timer::WAIT(1.0e-3);
	meas_data[0] = rdk::MMXH::PMU("MODE_mmxh_pmu").MEAS_V(100);
	rdk::MMXH::PMU("MODE_mmxh_pmu").iforce("0.0uA").APPLY(); 
	rdk::MMXH::PMU("MODE_mmxh_pmu").vsim("0.0V",rdkenum::R2V,rdkenum::R3mA,"3.0mA","-3.0mA").APPLY();
	result |= Judge(test_id,"OS2_MODE","T_CONT_LS.OS_N",meas_data[0],"SoftBins.BIN6"); if(RscDUTs(DUT_ACTIVE).isEmpty())return result;test_id++;


// clean up
	rdk::MMXH::PMU("Allpins_mmxh_pmu").vsim("0.0V",rdkenum::R2V,rdkenum::R3mA,"3.0mA","-3.0mA").connect().power(ON).APPLY();	
	rdk::Timer::WAIT(1.0e-3);

	rdk::MMXH::PMU("Allpins_mmxh_pmu").disconnect().power(OFF).APPLY();
	rdk::CW("K1;K16").off().APPLY(); 
	timer.wait(1e-3); 

	return result;
	
} // T_CONTINUITY_POST

