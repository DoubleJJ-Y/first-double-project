#include "stdafx.h"
#include "math.h"
#include "DIO_Express.h"
#include<stdio.h>
extern int DIOExpressWriteData(int RegAddress, int data0);
extern int DIOExpressReadData(int RegAddress);

FOVI	EN(0, "EN");
FOVI	VOUT(1, "VOUT");
FOVI	MODE(2, "MODE");
FOVI	GNDS(3, "GNDS");
//FOVI	I2CPUP(4, "I2CPUP");

FPVI10	VIN(0, "VIN");
FPVI10	LX(1, "LX");
CBIT128 cbit;
QTMU_PLUS qtmu0(0);
DIO dio(0);
//DIO_PLUS dio(0);

int i = 0;
int j = 0;

#define K1 1//FOVI2 TO MODE
#define K2 2//DIO0 TO MODE
#define K3 3//DIO1 TO MODE
#define K4 4//FOVI0 TO OP07 OR TO EN
#define K5 5//OP07 TO EN
#define K6 6//BUF TO EN
#define K7 7//BUF TO LX
#define K8 8//FLOAT LX
#define K9 9//LX KELVIN CK
//#define K10 10//LX TO VOUT
#define K11 11//FOVI1 TO VOUT
#define K12 12//COUT TO GND
#define K13 13//CIN TO GND
#define K14 14//FPVI0 TO VIN
#define K15 15//GNDS KELVIN CK


double adresult[2] = { 0 };
double adresult1[2] = { 0 };
double adresult2[2] = { 0 };
double adresult3[2] = { 0 };
double adresult4[2] = { 0 };
///////////////////////////// FT & QA Select ///////////////////////////
#if 1
#define FT_TEST
#endif

int FT_QC = 0;
///////////////////////////// FT & QA Select ///////////////////////////
int en_search = 0;
int en_trim = 1;
int AllSimCOde = 0;

double Vbg_target = 1.2015;  
double vref_eaout_target = 0.6;
double ibias_target = 0.5;
double rsns_target=30.0;
double fosc_target=1000.0;
double hscl_target=750.0;
double vcl_target=600.0;
double zcs_target=50.0;
//double ton_target=280.0;
double ton_target=3.0;

double vbg_pre_err[2] = {0.0};
double vref_eaout_pre_err[2] = {0.0};
double ibias_pre_err[2] = {0.0};
double rsns_pre_err[2] = {0.0};
double fosc_pre_err[2] = {0.0};
double hscl_pre_err[2] = {0.0};
double vcl_pre_err[2] = {0.0};
double zcs_pre_err[2] = {0.0};
double ton_pre_err[2] = {0.0};

double ilk_vin_pre[2] = {0.0};
double ilk_enh_pre[2] = {0.0};
double ilk_enl_pre[2] = {0.0};
double ilk_modeh_pre[2] = {0.0};
double ilk_model_pre[2] = {0.0};
double ilk_lxh_pre[2] = {0.0};
double ilk_lxl_pre[2] = {0.0};
double ilk_vouth_pre[2] = {0.0};
double ilk_voutl_pre[2] = {0.0};

double ilk_vin_post[2] = {0.0};
double ilk_enh_post[2] = {0.0};
double ilk_enl_post[2] = {0.0};
double ilk_modeh_post[2] = {0.0};
double ilk_model_post[2] = {0.0};
double ilk_lxh_post[2] = {0.0};
double ilk_lxl_post[2] = {0.0};
double ilk_vouth_post[2] = {0.0};
double ilk_voutl_post[2] = {0.0};

double ilk_vin_delta[2] = {0.0};
double ilk_enh_delta[2] = {0.0};
double ilk_enl_delta[2] = {0.0};
double ilk_modeh_delta[2] = {0.0};
double ilk_model_delta[2] = {0.0};
double ilk_lxh_delta[2] = {0.0};
double ilk_lxl_delta[2] = {0.0};
double ilk_vouth_delta[2] = {0.0};
double ilk_voutl_delta[2] = {0.0};


int vbg_code[4]={0};
int vref_eaout_code[4]={0};
int ibias_code[4]={0};
int rsns_code[4]={0};
int fosc_code[4]={0};
int hscl_code[4]={0};
int vcl_code[4]={0};
int zcs_code[4]={0};
int ton_code[4]={0};

double VHEN1[2] = { 0.0 };
double VHEN2[2] = { 0.0 };
double VHEN3[2] = { 0.0 };
double VHEN4[2] = { 0.0 };
double VHEN5[2] = { 0.0 };

int Rdata1[2]={0};
int Rdata2[2] = { 0 };
int OTP27_03_VD[2] = { 0 };
int OTP40_07_VD[2] = { 0 };
int OTP40_47_VD[2] = { 0 };
int OTP41_07_VD[2] = { 0 };
int OTP41_03_VD[2] = { 0 };
int OTP41_47_VD[2] = { 0 };
int OTP42_07_VD[2] = { 0 };
int OTP42_02_VD[2] = { 0 };
int OTP42_47_VD[2] = { 0 };
int OTP43_07_VD[2] = { 0 };
int OTP43_03_VD[2] = { 0 };
int OTP43_47_VD[2] = { 0 };
int OTP47_07_VD[2] = { 0 };
int OTP47_05_VD[2] = { 0 };
int OTP48_07_VD[2] = { 0 };
int OTP48_04_VD[2] = { 0 };

int EN_OTP40_47_VD[2] = { 0 };
int EN_OTP41_03_VD[2] = { 0 };
int EN_OTP41_47_VD[2] = { 0 };
int EN_OTP42_02_VD[2] = { 0 };
int EN_OTP42_47_VD[2] = { 0 };
int EN_OTP43_03_VD[2] = { 0 };
int EN_OTP43_47_VD[2] = { 0 };
int EN_OTP47_05_VD[2] = { 0 };
int EN_OTP48_04_VD[2] = { 0 };

//multisite settings should be included here
DUT_API void HardWareCfg()
{
	StsSetModuleToSite(MD_FPVI10, SITE_1, 0, 1, 2, 3, -1);
	StsSetModuleToSite(MD_QTMUPLUS, SITE_1, 0, 1, -1);
	StsSetModuleToSite(MD_FOVI, SITE_1, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 32, 33, 34, 35, 36, 37, 38, 39, -1);
}
/************************************************************************/
/*                                                                      */
/************************************************************************/
//initialize function will be called before all the test functions.
DUT_API void InitBeforeTestFlow()
{

	EN.Set(FV, 0.0, FOVI_5V, FOVI_10MA, RELAY_ON);
	VOUT.Set(FV, 0.0, FOVI_5V, FOVI_10MA, RELAY_ON);
	MODE.Set(FV, 0.0, FOVI_5V, FOVI_10MA, RELAY_ON);
	GNDS.Set(FV, 0.0, FOVI_5V, FOVI_10MA, RELAY_ON);
	//I2CPUP.Set(FV, 0.0, FOVI_5V, FOVI_10MA, RELAY_ON);
	VIN.Set(FV, 0.0, FPVI10_5V, FPVI10_10MA, RELAY_ON);
	LX.Set(FV, 0.0, FPVI10_5V, FPVI10_10MA, RELAY_ON);
	delay_ms(3);
	EN.Set(FV, 0.0, FOVI_5V, FOVI_10MA, RELAY_OFF);
	VOUT.Set(FV, 0.0, FOVI_5V, FOVI_10MA, RELAY_OFF);
	MODE.Set(FV, 0.0, FOVI_5V, FOVI_10MA, RELAY_OFF);
	GNDS.Set(FV, 0.0, FOVI_5V, FOVI_10MA, RELAY_OFF);
	//I2CPUP.Set(FV, 0.0, FOVI_5V, FOVI_10MA, RELAY_OFF);
	VIN.Set(FV, 0.0, FPVI10_5V, FPVI10_10MA, RELAY_OFF);
	LX.Set(FV, 0.0, FPVI10_5V, FPVI10_10MA, RELAY_OFF);
	delay_ms(3);
	cbit.SetOn(-1);
	qtmu0.Disconnect();


//	dio.Init();
#if 0
	dio.I2CSet(2, 3, 0, 1, -1, -1, -1, -1);
	dio.I2CSetClockPeriod(Period);//Set the clock period
	dio.I2CSetDelay(0, Period / 6, Period / 2, Period * 2 / 3);//data for site1
	dio.I2CSetDelay(1, 0, Period / 2);//clk for site1
	dio.I2CSetDelay(2, Period / 6, Period / 2, Period * 2 / 3);//data for site1
	dio.I2CSetDelay(3, 0, Period / 2);//clk for site1
	dio.I2CSetDelay(4, Period / 6, Period / 2, Period * 2 / 3);//data for site1
	dio.I2CSetDelay(5, 0, Period / 2);//clk for site1
#endif

adresult4[1] = 0;//0=nothing//1=non stop on fail,
AllSimCOde = 0;	//0=nothing//1= all sim code write//2= only for ZCS_post2, zcs code write
vbg_code[0]=0;
vref_eaout_code[0]=0;
ibias_code[0]=0;
fosc_code[0]=0;
rsns_code[0]=0;
hscl_code[0]=0;
vcl_code[0]=0;
ton_code[0]=0;





}
/************************************************************************/
/*                                                                      */
/************************************************************************/
//initializefunction will be called after all the test functions.
DUT_API void InitAfterTestFlow()
{
	EN.Set(FV, 0.0, FOVI_5V, FOVI_10MA, RELAY_ON);
	VOUT.Set(FV, 0.0, FOVI_5V, FOVI_10MA, RELAY_ON);
	MODE.Set(FV, 0.0, FOVI_5V, FOVI_10MA, RELAY_ON);
	GNDS.Set(FV, 0.0, FOVI_5V, FOVI_10MA, RELAY_ON);
	//I2CPUP.Set(FV, 0.0, FOVI_5V, FOVI_10MA, RELAY_ON);
	VIN.Set(FV, 0.0, FPVI10_5V, FPVI10_10MA, RELAY_ON);
	LX.Set(FV, 0.0, FPVI10_5V, FPVI10_10MA, RELAY_ON);
	delay_ms(3);
	EN.Set(FV, 0.0, FOVI_5V, FOVI_10MA, RELAY_OFF);
	VOUT.Set(FV, 0.0, FOVI_5V, FOVI_10MA, RELAY_OFF);
	MODE.Set(FV, 0.0, FOVI_5V, FOVI_10MA, RELAY_OFF);
	GNDS.Set(FV, 0.0, FOVI_5V, FOVI_10MA, RELAY_OFF);
	//I2CPUP.Set(FV, 0.0, FOVI_5V, FOVI_10MA, RELAY_OFF);
	VIN.Set(FV, 0.0, FPVI10_5V, FPVI10_10MA, RELAY_OFF);
	LX.Set(FV, 0.0, FPVI10_5V, FPVI10_10MA, RELAY_OFF);
	delay_ms(3);
	cbit.SetOn(-1);
	qtmu0.Disconnect();
//	dio.Init();

	//if (adresult4[1] == 1)
	//{
		CAlwaysRun* pAlways = STSGetAlwaysRun();
		if (pAlways != NULL)
		{
			//�������ͨ�������������õı�ִ�к���
			pAlways->ClearFunctionName();
		}
	//}
}
/************************************************************************/
/*                                                                      */
/************************************************************************/
//Fail site hardware set function will be called after failed params, it can be called for serveral times. 
DUT_API void SetupFailSite(const unsigned char*byFailSite)
{
}
/************************************************************************/
/*                                                                      */
/************************************************************************/
DUT_API int T53_KELVIN_CK(short funcindex, LPCTSTR funclabel)
{
    //{{AFX_STS_PARAM_PROTOTYPES
    CParam *VIN_KEL_CK = StsGetParam(funcindex,"VIN_KEL_CK");
    CParam *LX_KEL_CK = StsGetParam(funcindex,"LX_KEL_CK");
    CParam *GNDS_KEL_CK = StsGetParam(funcindex,"GNDS_KEL_CK");
    //}}AFX_STS_PARAM_PROTOTYPES

    // TODO: Add your function code here
 	cbit.SetOn(K8,K9,K14,K15,-1);
	delay_ms(3);
	GNDS.Set(FV, 0.0, FOVI_5V, FOVI_10MA, RELAY_ON);
	VIN.Set(FV, 0.0, FPVI10_5V, FPVI10_10MA, RELAY_ON);
	LX.Set(FV, 0.0, FPVI10_5V, FPVI10_10MA, RELAY_ON);
	delay_ms(3);

	VIN.Set(FI, 1e-3f, FPVI10_2V, FPVI10_10MA, RELAY_ON);
	delay_ms(3);

	VIN.MeasureVI(50, 50);
	delay_ms(1);
	adresult[0] = VIN.GetMeasResult(0, MVRET);
	VIN_KEL_CK->SetTestResult(0, 0, adresult[0]/0.001);

	VIN.Set(FI, 0.0, FPVI10_2V, FPVI10_10MA, RELAY_ON);
	delay_ms(3);

	LX.Set(FI, 1e-3f, FPVI10_2V, FPVI10_10MA, RELAY_ON);
	delay_ms(3);

	LX.MeasureVI(50, 50);
	delay_ms(1);
	adresult[0] = LX.GetMeasResult(0, MVRET);
	LX_KEL_CK->SetTestResult(0, 0, adresult[0]/0.001);

	LX.Set(FI, 0.0, FPVI10_2V, FPVI10_10MA, RELAY_ON);
	delay_ms(3);

	GNDS.Set(FI, 1e-3f, FOVI_2V, FOVI_10MA, RELAY_ON);
	delay_ms(3);

	GNDS.MeasureVI(50, 50);
	delay_ms(1);
	adresult[0] = GNDS.GetMeasResult(0, MVRET);
	GNDS_KEL_CK->SetTestResult(0, 0, adresult[0]/0.001);

	GNDS.Set(FI, 0e-3f, FOVI_2V, FOVI_10MA, RELAY_ON);
	delay_ms(3);


	GNDS.Set(FV, 0.0, FOVI_5V, FOVI_10MA, RELAY_ON);
	VIN.Set(FV, 0.0, FPVI10_5V, FPVI10_10MA, RELAY_ON);
	LX.Set(FV, 0.0, FPVI10_5V, FPVI10_10MA, RELAY_ON);
	delay_ms(3);
	GNDS.Set(FV, 0.0, FOVI_5V, FOVI_10MA, RELAY_OFF);
	VIN.Set(FV, 0.0, FPVI10_5V, FPVI10_10MA, RELAY_OFF);
	LX.Set(FV, 0.0, FPVI10_5V, FPVI10_10MA, RELAY_OFF);
	delay_ms(3);
	cbit.SetOn(-1);
	//dio.Init();
	
	return 0;
}

DUT_API int T00_CONTINUITY_Pre(short funcindex, LPCTSTR funclabel)
{
    //{{AFX_STS_PARAM_PROTOTYPES
    CParam *OS1_VIN = StsGetParam(funcindex,"OS1_VIN");
    CParam *OS1_LX = StsGetParam(funcindex,"OS1_LX");
    CParam *OS1_VOUT = StsGetParam(funcindex,"OS1_VOUT");
    CParam *OS1_MODE = StsGetParam(funcindex,"OS1_MODE");
    CParam *OS1_EN = StsGetParam(funcindex,"OS1_EN");
    //}}AFX_STS_PARAM_PROTOTYPES

    // TODO: Add your function code here
	
	cbit.SetOn(K1,K4,K8,K11,-1);
	delay_ms(3);

	EN.Set(FV, 0.0, FOVI_5V, FOVI_10MA, RELAY_ON);
	VOUT.Set(FV, 0.0, FOVI_5V, FOVI_10MA, RELAY_ON);
	MODE.Set(FV, 0.0, FOVI_5V, FOVI_10MA, RELAY_ON);
	VIN.Set(FV, 0.0, FPVI10_5V, FPVI10_10MA, RELAY_ON);
	LX.Set(FV, 0.0, FPVI10_5V, FPVI10_10MA, RELAY_ON);
	delay_ms(3);

////////////////////
	VIN.Set(FI, -100e-6f, FPVI10_2V, FPVI10_10MA, RELAY_ON);
	delay_ms(3);

	VIN.MeasureVI(50, 50);
	delay_ms(1);
	adresult[0] = VIN.GetMeasResult(0, MVRET);
	OS1_VIN->SetTestResult(0, 0, adresult[0]);

	VIN.Set(FI, 0.0, FPVI10_2V, FPVI10_10MA, RELAY_ON);
	delay_ms(3);
	VIN.Set(FV, 0, FPVI10_2V, FPVI10_10MA, RELAY_ON);
	delay_ms(3);

	/////////////////////
	LX.Set(FI, -100e-6f, FPVI10_2V, FPVI10_10MA, RELAY_ON);
	delay_ms(3);

	LX.MeasureVI(50, 50);
	delay_ms(1);
	adresult[0] = LX.GetMeasResult(0, MVRET);
	OS1_LX->SetTestResult(0, 0, adresult[0]);

	LX.Set(FI, 0.0, FPVI10_2V, FPVI10_10MA, RELAY_ON);
	delay_ms(3);
	LX.Set(FV, 0, FPVI10_2V, FPVI10_10MA, RELAY_ON);
	delay_ms(3);

	/////////////////////////
	VOUT.Set(FI, -100e-6f, FOVI_2V, FOVI_10MA, RELAY_ON);
	delay_ms(3);

	VOUT.MeasureVI(50, 50);
	delay_ms(1);
	adresult[0] = VOUT.GetMeasResult(0, MVRET);
	OS1_VOUT->SetTestResult(0, 0, adresult[0]);

	VOUT.Set(FI, 0e-3f, FOVI_2V, FOVI_10MA, RELAY_ON);
	delay_ms(3);
	VOUT.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	delay_ms(3);


	/////////////////////////
	MODE.Set(FI, -100e-6f, FOVI_2V, FOVI_10MA, RELAY_ON);
	delay_ms(3);

	MODE.MeasureVI(50, 50);
	delay_ms(1);
	adresult[0] = MODE.GetMeasResult(0, MVRET);
	OS1_MODE->SetTestResult(0, 0, adresult[0]);

	MODE.Set(FI, 0e-3f, FOVI_2V, FOVI_10MA, RELAY_ON);
	delay_ms(3);
	MODE.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	delay_ms(3);

	/////////////////////////
	EN.Set(FI, -100e-6f, FOVI_2V, FOVI_10MA, RELAY_ON);
	delay_ms(10);

	EN.MeasureVI(50, 50);
	delay_ms(1);
	adresult[0] = EN.GetMeasResult(0, MVRET);
	OS1_EN->SetTestResult(0, 0, adresult[0]);

	EN.Set(FI, 0e-3f, FOVI_2V, FOVI_10MA, RELAY_ON);
	delay_ms(3);
	EN.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	delay_ms(3);

	EN.Set(FV, 0.0, FOVI_5V, FOVI_10MA, RELAY_OFF);
	VOUT.Set(FV, 0.0, FOVI_5V, FOVI_10MA, RELAY_OFF);
	MODE.Set(FV, 0.0, FOVI_5V, FOVI_10MA, RELAY_OFF);
	VIN.Set(FV, 0.0, FPVI10_5V, FPVI10_10MA, RELAY_OFF);
	LX.Set(FV, 0.0, FPVI10_5V, FPVI10_10MA, RELAY_OFF);
	delay_ms(3);
	cbit.SetOn(-1);
	delay_ms(3);
    return 0;
}


DUT_API int T01_Leakage_Pre(short funcindex, LPCTSTR funclabel)
{
    //{{AFX_STS_PARAM_PROTOTYPES
    CParam *Ilk_vin_pre = StsGetParam(funcindex,"Ilk_vin_pre");
    CParam *Ilk_enh_pre = StsGetParam(funcindex,"Ilk_enh_pre");
    CParam *Ilk_enl_pre = StsGetParam(funcindex,"Ilk_enl_pre");
    CParam *Ilk_modeh_pre = StsGetParam(funcindex,"Ilk_modeh_pre");
    CParam *Ilk_model_pre = StsGetParam(funcindex,"Ilk_model_pre");
    CParam *Ilk_lxh_pre = StsGetParam(funcindex,"Ilk_lxh_pre");
    CParam *Ilk_lxl_pre = StsGetParam(funcindex,"Ilk_lxl_pre");
    CParam *Ilk_vouth_pre = StsGetParam(funcindex,"Ilk_vouth_pre");
    CParam *Ilk_voutl_pre = StsGetParam(funcindex,"Ilk_voutl_pre");
    //}}AFX_STS_PARAM_PROTOTYPES

    // TODO: Add your function code here
	cbit.SetOn(K1,K4,K8,K11,/*K12,K13,*/-1);
	delay_ms(3);

	EN.Set(FV, 0.0, FOVI_10V, FOVI_100UA, RELAY_ON);
//	VOUT.Set(FV, 0.0, FOVI_5V, FOVI_10MA, RELAY_ON);
	MODE.Set(FV, 0.0, FOVI_10V, FOVI_100UA, RELAY_ON);
	VIN.Set(FV, 0.0, FPVI10_10V, FPVI10_10MA, RELAY_ON);
//	LX.Set(FV, 0.0, FPVI10_5V, FPVI10_10MA, RELAY_ON);
	delay_ms(3);
	VIN.Set(FV, 5.5, FPVI10_10V, FPVI10_10MA, RELAY_ON);
	delay_ms(3);
	VIN.Set(FV, 5.5, FPVI10_10V, FPVI10_1MA, RELAY_ON);
	delay_ms(3);

	VIN.MeasureVI(50, 50);
	delay_ms(1);
	adresult[0] = VIN.GetMeasResult(0, MIRET);
	ilk_vin_pre[0] = adresult[0]*1e6f;
	Ilk_vin_pre->SetTestResult(0, 0, ilk_vin_pre[0]);

	VIN.Set(FV, 5.5, FPVI10_10V, FPVI10_10MA, RELAY_ON);
	delay_ms(3);
	VIN.Set(FV, 5.5, FPVI10_10V, FPVI10_100MA, RELAY_ON);
	delay_ms(3);

	MODE.Set(FV, 5.5, FOVI_10V, FOVI_100UA, RELAY_ON);
	delay_ms(3);

	MODE.MeasureVI(50, 50);
	delay_ms(1);
	adresult[0] = MODE.GetMeasResult(0, MIRET);
	ilk_modeh_pre[0] = adresult[0]*1e6f;
	Ilk_modeh_pre->SetTestResult(0, 0, ilk_modeh_pre[0]);

	MODE.Set(FV, 0.0, FOVI_10V, FOVI_100UA, RELAY_ON);
	delay_ms(3);

	MODE.MeasureVI(50, 50);
	delay_ms(1);
	adresult[0] = MODE.GetMeasResult(0, MIRET);
	ilk_model_pre[0] = adresult[0]*1e6f;
	Ilk_model_pre->SetTestResult(0, 0, ilk_model_pre[0]);


	MODE.Set(FV, 0.0, FOVI_5V, FOVI_10MA, RELAY_ON);
	delay_ms(3);
	VOUT.Set(FV, 5.5, FOVI_10V, FOVI_10MA, RELAY_ON);
	delay_ms(3);
	VOUT.Set(FV, 5.5, FOVI_10V, FOVI_1MA, RELAY_ON);
	delay_ms(3);
	VOUT.Set(FV, 5.5, FOVI_10V, FOVI_100UA, RELAY_ON);
	delay_ms(3);

	VOUT.MeasureVI(50, 50);
	delay_ms(10);

	adresult[0] = VOUT.GetMeasResult(0, MIRET);
	ilk_vouth_pre[0] = adresult[0]*1e6f;
	Ilk_vouth_pre->SetTestResult(0, 0, ilk_vouth_pre[0]);

	VOUT.Set(FV, 0.0, FOVI_10V, FOVI_10MA, RELAY_ON);
	delay_ms(3);

	VOUT.MeasureVI(50, 50);
	delay_ms(1);
	adresult[0] = VOUT.GetMeasResult(0, MIRET);
	ilk_voutl_pre[0] = adresult[0]*1e6f;
	Ilk_voutl_pre->SetTestResult(0, 0, ilk_voutl_pre[0]);

	VOUT.Set(FV, 0.0, FOVI_10V, FOVI_100UA, RELAY_ON);
	delay_ms(3);
	VIN.Set(FV, 0.0, FPVI10_10V, FPVI10_10UA, RELAY_ON);
	delay_ms(3);
	EN.Set(FV, 0.0, FOVI_10V, FOVI_10MA, RELAY_OFF);
	VOUT.Set(FV, 0.0, FOVI_10V, FOVI_10MA, RELAY_OFF);
	MODE.Set(FV, 0.0, FOVI_10V, FOVI_10MA, RELAY_OFF);
	VIN.Set(FV, 0.0, FPVI10_10V, FPVI10_10MA, RELAY_OFF);
	LX.Set(FV, 0.0, FPVI10_10V, FPVI10_10MA, RELAY_OFF);
	delay_ms(3);
	cbit.SetOn(-1);
	delay_ms(3);


//////////////////////////////////////////////////
	cbit.SetOn(K1,K4,K8,K11,K12,K13,-1);
	delay_ms(3);

	EN.Set(FV, 0.0, FOVI_10V, FOVI_100UA, RELAY_ON);
	MODE.Set(FV, 0.0, FOVI_10V, FOVI_100UA, RELAY_ON);
	VIN.Set(FV, 0.0, FPVI10_10V, FPVI10_100MA, RELAY_ON);
	delay_ms(3);
	VIN.Set(FV, 5.5, FPVI10_10V, FPVI10_100MA, RELAY_ON);
	delay_ms(3);

	EN.Set(FV, 5.5, FOVI_10V, FOVI_1MA, RELAY_ON);
	delay_ms(3);

	EN.MeasureVI(50, 50);
	delay_ms(1);

	adresult[0] = EN.GetMeasResult(0, MIRET);
	ilk_enh_pre[0] = adresult[0]*1e6f;
	Ilk_enh_pre->SetTestResult(0, 0, ilk_enh_pre[0]);

	EN.Set(FV, 0.0, FOVI_10V, FOVI_100UA, RELAY_ON);
	delay_ms(3);

	EN.MeasureVI(50, 50);
	delay_ms(1);
	adresult[0] = EN.GetMeasResult(0, MIRET);
	ilk_enl_pre[0] = adresult[0]*1e6f;
	Ilk_enl_pre->SetTestResult(0, 0, ilk_enl_pre[0]);

	VIN.Set(FV, 0.0, FPVI10_10V, FPVI10_100MA, RELAY_ON);
	delay_ms(3);
	VIN.Set(FV, 0.0, FPVI10_10V, FPVI10_100MA, RELAY_OFF);
	EN.Set(FV, 0.0, FOVI_10V, FOVI_100UA, RELAY_OFF);
	MODE.Set(FV, 0.0, FOVI_10V, FOVI_100UA, RELAY_OFF);
	delay_ms(3);

/////////////////////////
	cbit.SetOn(K2,/*K3,*/K4,K13,K8,K11,-1);//K3 is used for read//2024/08/21,add K11,VOUT_fovi
	delay_ms(3);
	dio.Connect();
	delay_ms(1);

	VOUT.Set(FV, 1.0, FOVI_5V, FOVI_100MA, RELAY_ON);	//2024/08/21,set VOUT = 1V can let ic stage more stable
	//I2CPUP.Set(FV, 3.6, FOVI_5V, FOVI_100MA, RELAY_ON);
	VIN.Set(FV, 3.6, FPVI10_10V, FPVI10_100MA, RELAY_ON);
	EN.Set(FV, 3.6, FOVI_5V, FOVI_100MA, RELAY_ON);
	delay_ms(3);

	DIOExpressWriteData(0x6a,0x5a);
	delay_ms(1);
	DIOExpressWriteData(0x6a,0xa5);
	delay_ms(3);

//	DIOExpressWriteData(0x23,0x90);
//	delay_ms(3);
//	EN.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_ON);
//	delay_ms(3);
//	EN.Set(FI, 0.0, FOVI_5V, FOVI_100UA, RELAY_ON);
//	delay_ms(3);
//	DIOExpressReadData(0x29);
//	delay_ms(1);

	DIOExpressWriteData(0x25,0x01);
	delay_ms(1);

	VIN.Set(FV, 5.5, FPVI10_10V, FPVI10_100MA, RELAY_ON);
	delay_ms(1);
	LX.Set(FV, 5.5, FPVI10_10V, FPVI10_100UA, RELAY_ON);
	delay_ms(3);

	LX.MeasureVI(1000, 50);
	delay_ms(1);
	adresult[0] = LX.GetMeasResult(0, MIRET);
	ilk_lxh_pre[0] = adresult[0]*1e6f;
	Ilk_lxh_pre->SetTestResult(0, 0, ilk_lxh_pre[0]);

	LX.Set(FV, 0.0, FPVI10_10V, FPVI10_100UA, RELAY_ON);
	delay_ms(3);

	LX.MeasureVI(50, 50);
	delay_ms(1);
	adresult[0] = LX.GetMeasResult(0, MIRET);
	ilk_lxl_pre[0] = adresult[0]*1e6f;
	Ilk_lxl_pre->SetTestResult(0, 0, ilk_lxl_pre[0]);

	DIOExpressWriteData(0x6a,0x00);
	delay_ms(1);
	dio.Disconnect();
	delay_ms(1);

	VIN.Set(FV, 0.0, FPVI10_10V, FPVI10_100MA, RELAY_ON);
	EN.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_ON);
	//I2CPUP.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_ON);
	VOUT.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_ON);	//2024/08/21,set VOUT = 1V can let ic stage more stable
	delay_ms(3);
	VOUT.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_OFF);	//2024/08/21,set VOUT = 1V can let ic stage more stable
	VIN.Set(FV, 0.0, FPVI10_10V, FPVI10_100MA, RELAY_OFF);
	EN.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_OFF);
	//I2CPUP.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_OFF);
	delay_ms(3);
	cbit.SetOn(-1);
	delay_ms(3);

	return 0;
}


DUT_API int T02_REG_read_pre(short funcindex, LPCTSTR funclabel)
{
    //{{AFX_STS_PARAM_PROTOTYPES
    CParam *R1_REG_0x6A = StsGetParam(funcindex,"R1_REG_0x6A");
    CParam *R1_REG_0x20 = StsGetParam(funcindex,"R1_REG_0x20");
    CParam *R1_REG_0x21 = StsGetParam(funcindex,"R1_REG_0x21");
    CParam *R1_REG_0x22 = StsGetParam(funcindex,"R1_REG_0x22");
    CParam *R1_REG_0x23 = StsGetParam(funcindex,"R1_REG_0x23");
    CParam *R1_REG_0x24 = StsGetParam(funcindex,"R1_REG_0x24");
    CParam *R1_REG_0x25 = StsGetParam(funcindex,"R1_REG_0x25");
    CParam *R1_REG_0x26 = StsGetParam(funcindex,"R1_REG_0x26");
    CParam *R1_REG_0x27 = StsGetParam(funcindex,"R1_REG_0x27");
    CParam *R1_REG_0x28 = StsGetParam(funcindex,"R1_REG_0x28");
    CParam *R1_REG_0x29 = StsGetParam(funcindex,"R1_REG_0x29");
    CParam *R1_REG_0x40 = StsGetParam(funcindex,"R1_REG_0x40");
    CParam *R1_REG_0x41 = StsGetParam(funcindex,"R1_REG_0x41");
    CParam *R1_REG_0x42 = StsGetParam(funcindex,"R1_REG_0x42");
    CParam *R1_REG_0x43 = StsGetParam(funcindex,"R1_REG_0x43");
    CParam *R1_REG_0x44 = StsGetParam(funcindex,"R1_REG_0x44");
    CParam *R1_REG_0x45 = StsGetParam(funcindex,"R1_REG_0x45");
    CParam *R1_REG_0x46 = StsGetParam(funcindex,"R1_REG_0x46");
    CParam *R1_REG_0x47 = StsGetParam(funcindex,"R1_REG_0x47");
    CParam *R1_REG_0x48 = StsGetParam(funcindex,"R1_REG_0x48");
    //}}AFX_STS_PARAM_PROTOTYPES

    //TODO: Add your function code here
	dio.SetVOH(2.0);
	dio.SetVOL(1.0);

	cbit.SetOn(K1,K2,K3,K4,K13,K11,/*K12,*/-1);//K3 is used for read//2024/08/21,add K11,K12,VOUT_fovi and Cout
	delay_ms(3);
	dio.Connect();
	delay_ms(1);

	VOUT.Set(FV, 3.6, FOVI_5V, FOVI_100MA, RELAY_ON);	//2024/08/21,Set VOUT = 3.6V can make ic stable.
	MODE.Set(FI, 0.0, FOVI_5V, FOVI_1MA, RELAY_ON);
	//I2CPUP.Set(FV, 1.0, FOVI_5V, FOVI_100MA, RELAY_ON);
	VIN.Set(FV, 3.6, FPVI10_5V, FPVI10_100MA, RELAY_ON);
	EN.Set(FV, 3.6, FOVI_5V, FOVI_100MA, RELAY_ON);
	delay_ms(3);

	DIOExpressWriteData(0x6a,0x5a);
	delay_ms(1);
	DIOExpressWriteData(0x6a,0xa5);
	delay_ms(3);

	EN.Set(FV, -0.0, FOVI_1V, FOVI_100MA, RELAY_ON);
	delay_ms(3);
	EN.Set(FI, 0.0, FOVI_5V, FOVI_100UA, RELAY_ON);
	delay_ms(3);

	DIOExpressWriteData(0x23,0x90);   delay_ms(1);
	adresult[0] = DIOExpressReadData(0x6a);
	R1_REG_0x6A->SetTestResult(0, 0, adresult[0]);

	DIOExpressWriteData(0x23,0x90);   delay_ms(1);
	adresult[0] = DIOExpressReadData(0x20);
	R1_REG_0x20->SetTestResult(0, 0, adresult[0]);

	DIOExpressWriteData(0x23,0x90);   delay_ms(1);
	adresult[0] = DIOExpressReadData(0x21);
	R1_REG_0x21->SetTestResult(0, 0, adresult[0]);

	DIOExpressWriteData(0x23,0x90);   delay_ms(1);
	adresult[0] = DIOExpressReadData(0x22);
	R1_REG_0x22->SetTestResult(0, 0, adresult[0]);

	DIOExpressWriteData(0x23,0x90);   delay_ms(1);
	adresult[0] = DIOExpressReadData(0x23);
	R1_REG_0x23->SetTestResult(0, 0, adresult[0]);

	DIOExpressWriteData(0x23,0x90);   delay_ms(1);
	adresult[0] = DIOExpressReadData(0x24);
	R1_REG_0x24->SetTestResult(0, 0, adresult[0]);

	DIOExpressWriteData(0x23,0x90);   delay_ms(1);
	adresult[0] = DIOExpressReadData(0x25);
	R1_REG_0x25->SetTestResult(0, 0, adresult[0]);

	DIOExpressWriteData(0x23,0x90);   delay_ms(1);
	adresult[0] = DIOExpressReadData(0x26);
	R1_REG_0x26->SetTestResult(0, 0, adresult[0]);

	DIOExpressWriteData(0x23,0x90);   delay_ms(1);
	adresult[0] = DIOExpressReadData(0x27);
	R1_REG_0x27->SetTestResult(0, 0, adresult[0]);

	DIOExpressWriteData(0x23,0x90);   delay_ms(1);
	adresult[0] = DIOExpressReadData(0x28);
	R1_REG_0x28->SetTestResult(0, 0, adresult[0]);

	DIOExpressWriteData(0x23,0x90);   delay_ms(1);
	adresult[0] = DIOExpressReadData(0x29);
	R1_REG_0x29->SetTestResult(0, 0, adresult[0]);

////////////init of OTP burn bit////////
	EN_OTP40_47_VD[0] = 0;
	EN_OTP41_03_VD[0] = 0;
	EN_OTP41_47_VD[0] = 0;
	EN_OTP42_02_VD[0] = 0;
	EN_OTP42_47_VD[0] = 0;
	EN_OTP43_03_VD[0] = 0;
	EN_OTP43_47_VD[0] = 0;
	EN_OTP47_05_VD[0] = 0;
	EN_OTP48_04_VD[0] = 0;
///////////////////////////////////////
	DIOExpressWriteData(0x23,0x90);   delay_ms(1);
	OTP40_07_VD[0] = DIOExpressReadData(0x40);
	R1_REG_0x40->SetTestResult(0, 0, OTP40_07_VD[0]);

	if ((OTP40_07_VD[0] & 0xF0) == 0x00)
		EN_OTP40_47_VD[0] = 1; // fresh die
	else
		EN_OTP40_47_VD[0] = 0;// burned, Trim can not be done

	DIOExpressWriteData(0x23,0x90);   delay_ms(1);
	OTP41_07_VD[0] = DIOExpressReadData(0x41);
	OTP41_03_VD[0] = OTP41_07_VD[0] & 0x0F;//ibias_code
	OTP41_47_VD[0] = OTP41_07_VD[0] & 0xF0;//fosc_code
	R1_REG_0x41->SetTestResult(0, 0, OTP41_07_VD[0]);

	if ((OTP41_07_VD[0] & 0x0F) == 0x00)
		EN_OTP41_03_VD[0] = 1; // fresh die
	else
		EN_OTP41_03_VD[0] = 0;// burned, Trim can not be done

	if ((OTP41_07_VD[0] & 0xF0) == 0x00)
		EN_OTP41_47_VD[0] = 1; // fresh die
	else
		EN_OTP41_47_VD[0] = 0;// burned, Trim can not be done
	
	DIOExpressWriteData(0x23,0x90);   delay_ms(1);
	OTP42_07_VD[0] = DIOExpressReadData(0x42);
	OTP42_02_VD[0] = OTP42_07_VD[0] & 0x07;//vcl_code
	OTP42_47_VD[0] = OTP42_07_VD[0] & 0xF0;//hscl_code
	R1_REG_0x42->SetTestResult(0, 0, OTP42_07_VD[0]);

	if ((OTP42_07_VD[0] & 0x07) == 0x00)
		EN_OTP42_02_VD[0] = 1; // fresh die
	else
		EN_OTP42_02_VD[0] = 0;// burned, Trim can not be done

	if ((OTP42_07_VD[0] & 0xF8) == 0x00)
		EN_OTP42_47_VD[0] = 1; // fresh die
	else
		EN_OTP42_47_VD[0] = 0;// burned, Trim can not be done

	DIOExpressWriteData(0x23,0x90);   delay_ms(1);
	OTP43_07_VD[0] = DIOExpressReadData(0x43);
	OTP43_03_VD[0] = OTP43_07_VD[0] & 0x0F;//zcs_code
	OTP43_47_VD[0] = OTP43_07_VD[0] & 0xF0;//ton_code
	R1_REG_0x43->SetTestResult(0, 0, OTP43_07_VD[0]);

	if ((OTP43_07_VD[0] & 0x0F) == 0x00)
		EN_OTP43_03_VD[0] = 1; // fresh die
	else
		EN_OTP43_03_VD[0] = 0;// burned, Trim can not be done

	if ((OTP43_07_VD[0] & 0xF0) == 0x00)
		EN_OTP43_47_VD[0] = 1; // fresh die
	else
		EN_OTP43_47_VD[0] = 0;// burned, Trim can not be done


//2024/08/21,SWAP 0x47 to early than 0x44 is better to stable OTP_READ.
	DIOExpressWriteData(0x23,0x90);   delay_ms(1);
	OTP47_07_VD[0] = DIOExpressReadData(0x47);
	R1_REG_0x47->SetTestResult(0, 0, OTP47_07_VD[0]);

	if ((OTP47_07_VD[0] & 0x3F) == 0x00)
		EN_OTP47_05_VD[0] = 1; // fresh die
	else
		EN_OTP47_05_VD[0] = 0;// burned, Trim can not be done
	

//2024/08/21,SWAP 0x44 read to last than 0x47 is better to stable OTP_READ.
	DIOExpressWriteData(0x23, 0x90);   delay_ms(1);
	adresult[0] = DIOExpressReadData(0x44);
	R1_REG_0x44->SetTestResult(0, 0, adresult[0]);

	DIOExpressWriteData(0x23,0x90);   delay_ms(1);
	adresult[0] = DIOExpressReadData(0x45);
	R1_REG_0x45->SetTestResult(0, 0, adresult[0]);

	DIOExpressWriteData(0x23,0x90);   delay_ms(1);
	adresult[0] = DIOExpressReadData(0x46);
	R1_REG_0x46->SetTestResult(0, 0, adresult[0]);




	DIOExpressWriteData(0x23,0x90);   delay_ms(1);
	OTP48_07_VD[0] = DIOExpressReadData(0x48);
	R1_REG_0x48->SetTestResult(0, 0, OTP48_07_VD[0]);
	if ((OTP48_07_VD[0] & 0x1F) == 0x00)
		EN_OTP48_04_VD[0] = 1; // fresh die
	else
		EN_OTP48_04_VD[0] = 0;// burned, Trim can not be done


	

	DIOExpressWriteData(0x6a,0x00);
	delay_ms(1);
	VIN.Set(FV, 0.0, FPVI10_5V, FPVI10_100MA, RELAY_ON);
	EN.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_ON);
	//I2CPUP.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_ON);
	MODE.Set(FV, 0.0, FOVI_5V, FOVI_1MA, RELAY_ON);
	VOUT.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_ON);
	delay_ms(3);
	VOUT.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_OFF);
	MODE.Set(FV, 0.0, FOVI_5V, FOVI_1MA, RELAY_OFF);
	VIN.Set(FV, 0.0, FPVI10_5V, FPVI10_100MA, RELAY_OFF);
	EN.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_OFF);
	//I2CPUP.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_OFF);
	delay_ms(3);
	cbit.SetOn(-1);
	delay_ms(3);

    return 0;
}


DUT_API int T03_VBG_Trim(short funcindex, LPCTSTR funclabel)
{
    //{{AFX_STS_PARAM_PROTOTYPES
    CParam *VBG_pre = StsGetParam(funcindex,"VBG_pre");
    CParam *VBG_pre_err = StsGetParam(funcindex,"VBG_pre_err");
    CParam *VBG_code = StsGetParam(funcindex,"VBG_code");
    CParam *VBG_sim = StsGetParam(funcindex,"VBG_sim");
    CParam *VBG_sim_err = StsGetParam(funcindex,"VBG_sim_err");
    //}}AFX_STS_PARAM_PROTOTYPES

    // TODO: Add your function code here

	cbit.SetOn(K2,/*K3,*/K4,K13,K11,-1);//K3 is used for read,add K11_VOUT_FOVI
	delay_ms(3);
	dio.Connect();
	delay_ms(1);

	//I2CPUP.Set(FV, 3.6, FOVI_5V, FOVI_100MA, RELAY_ON);
	VOUT.Set(FV, 3.6, FOVI_5V, FOVI_100MA, RELAY_ON);	//2024/08/21,set VOUT = 1V or 3.6V can let ic stage more stable
	VIN.Set(FV, 3.6, FPVI10_5V, FPVI10_100MA, RELAY_ON);
	EN.Set(FV, 3.6, FOVI_5V, FOVI_100MA, RELAY_ON);
	delay_ms(3);

	DIOExpressWriteData(0x6a,0x5a);
	delay_ms(1);
	DIOExpressWriteData(0x6a,0xa5);
	delay_ms(3);

	EN.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_ON);
	delay_ms(3);
	EN.Set(FI, 0.0, FOVI_5V, FOVI_100UA, RELAY_ON);
	delay_ms(3);


	cbit.SetCBITOff(K4);
	cbit.SetCBITOn(K5);
	delay_ms(3);

	DIOExpressWriteData(0x24,0x04);
	delay_ms(1);
	DIOExpressWriteData(0x23,0x08);
	delay_ms(1);

	EN.MeasureVI(50, 50);
	delay_ms(3);
	adresult[0] = EN.GetMeasResult(0, MVRET);

	DIOExpressWriteData(0x6a,0x00);
	delay_ms(1);
	dio.Disconnect();
	delay_ms(1);

	VIN.Set(FV, 0.0, FPVI10_5V, FPVI10_100MA, RELAY_ON);
	EN.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_ON);
	//I2CPUP.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_ON);
	delay_ms(3);
	cbit.SetOn(-1);
	delay_ms(3);

	VBG_pre->SetTestResult(0, 0, adresult[0]);
	VBG_pre_err->SetTestResult(0, 0, (Vbg_target-adresult[0])/(adresult[0]+1e-9f)*100);
	vbg_pre_err[0]=(Vbg_target-adresult[0])/(adresult[0]+1e-9f)*100;

		if (vbg_pre_err[0] >= -50 && vbg_pre_err[0]<50)
		{
			if (vbg_pre_err[0] >= 0.12 && vbg_pre_err[0]< 0.31)			{ vbg_code[0] = 63; }//
			if (vbg_pre_err[0] >= 0.31 && vbg_pre_err[i]< 0.49)			{ vbg_code[0] = 62; }//
			if (vbg_pre_err[0] >= 0.49 && vbg_pre_err[i]< 0.66)			{ vbg_code[0] = 61; }//
			if (vbg_pre_err[0] >= 0.66 && vbg_pre_err[i]< 0.82)			{ vbg_code[0] = 60; }//
			if (vbg_pre_err[0] >= 0.82 && vbg_pre_err[i]< 0.99)		    { vbg_code[0] = 59; }//
			if (vbg_pre_err[0] >= 0.99 && vbg_pre_err[i]< 1.15)			{ vbg_code[0] = 58; }//
			if (vbg_pre_err[0] >= 1.15 && vbg_pre_err[i]< 1.32)			{ vbg_code[0] = 57; }//
			if (vbg_pre_err[0] >= 1.32 && vbg_pre_err[i]< 1.50)			{ vbg_code[0] = 56; }//
			if (vbg_pre_err[0] >= 1.50 && vbg_pre_err[i]< 1.67)			{ vbg_code[0] = 55; }//
			if (vbg_pre_err[0] >= 1.67 && vbg_pre_err[i]< 1.83)			{ vbg_code[0] = 54; }//
			if (vbg_pre_err[0] >= 1.83 && vbg_pre_err[i]< 1.99)			{ vbg_code[0] = 53; }//
			if (vbg_pre_err[0] >= 1.99 && vbg_pre_err[i]< 2.16)			{ vbg_code[0] = 52; }//
			if (vbg_pre_err[0] >= 2.16 && vbg_pre_err[i]< 2.33)			{ vbg_code[0] = 51; }//
			if (vbg_pre_err[0] >= 2.33 && vbg_pre_err[i]< 2.49)			{ vbg_code[0] = 50; }//
			if (vbg_pre_err[0] >= 2.49 && vbg_pre_err[i]< 2.65)			{ vbg_code[0] = 49; }//
			if (vbg_pre_err[0] >= 2.65 && vbg_pre_err[i]< 2.83)			{ vbg_code[0] = 48; }//
			if (vbg_pre_err[0] >= 2.83 && vbg_pre_err[0]< 3.01)			{ vbg_code[0] = 47; }//
			if (vbg_pre_err[0] >= 3.01 && vbg_pre_err[0]< 3.17)			{ vbg_code[0] = 46; }//
			if (vbg_pre_err[0] >= 3.17 && vbg_pre_err[0]< 3.33)			{ vbg_code[0] = 45; }//
			if (vbg_pre_err[0] >= 3.33 && vbg_pre_err[0]< 3.49)			{ vbg_code[0] = 44; }//
			if (vbg_pre_err[0] >= 3.49 && vbg_pre_err[0]< 3.65)			{ vbg_code[0] = 43; }//
			if (vbg_pre_err[0] >= 3.65 && vbg_pre_err[0]< 3.80)			{ vbg_code[0] = 42; }//
			if (vbg_pre_err[0] >= 3.80 && vbg_pre_err[0]< 3.96)			{ vbg_code[0] = 41; }//
			if (vbg_pre_err[0] >= 3.96 && vbg_pre_err[0]< 4.13)			{ vbg_code[0] = 40; }//
			if (vbg_pre_err[0] >= 4.13 && vbg_pre_err[0]< 4.30)			{ vbg_code[0] = 39; }//
			if (vbg_pre_err[0] >= 4.30 && vbg_pre_err[0]< 4.45)			{ vbg_code[0] = 38; }//
			if (vbg_pre_err[0] >= 4.45 && vbg_pre_err[0]< 4.60)			{ vbg_code[0] = 37; }//
			if (vbg_pre_err[0] >= 4.60 && vbg_pre_err[0]< 4.76)			{ vbg_code[0] = 36; }//
			if (vbg_pre_err[0] >= 4.76 && vbg_pre_err[0]< 4.92)			{ vbg_code[0] = 35; }//
			if (vbg_pre_err[0] >= 4.92 && vbg_pre_err[0]< 5.07)			{ vbg_code[0] = 34; }//
			if (vbg_pre_err[0] >= 5.07 && vbg_pre_err[0]< 5.20)			{ vbg_code[0] = 33; }//
			if (vbg_pre_err[0] >= 5.20 && vbg_pre_err[0]< 50.0)			{ vbg_code[0] = 32; }//

			if (vbg_pre_err[0] >= -50.0 && vbg_pre_err[0]< -5.59)    	{ vbg_code[0] = 31; }//
			if (vbg_pre_err[0] >= -5.59 && vbg_pre_err[0]< -5.40)		{ vbg_code[0] = 30; }//
			if (vbg_pre_err[0] >= -5.40 && vbg_pre_err[0]< -5.22)		{ vbg_code[0] = 29; }//
			if (vbg_pre_err[0] >= -5.22 && vbg_pre_err[0]< -5.02)		{ vbg_code[0] = 28; }//
			if (vbg_pre_err[0] >= -5.02 && vbg_pre_err[0]< -4.83)		{ vbg_code[0] = 27; }//
			if (vbg_pre_err[0] >= -4.83 && vbg_pre_err[0]< -4.64)		{ vbg_code[0] = 26; }//
			if (vbg_pre_err[0] >= -4.64 && vbg_pre_err[0]< -4.46)		{ vbg_code[0] = 25; }//
			if (vbg_pre_err[0] >= -4.46 && vbg_pre_err[0]< -4.26)		{ vbg_code[0] = 24; }//
			if (vbg_pre_err[0] >= -4.26 && vbg_pre_err[0]< -4.06)		{ vbg_code[0] = 23; }//
			if (vbg_pre_err[0] >= -4.06 && vbg_pre_err[0]< -3.88)		{ vbg_code[0] = 22; }//
			if (vbg_pre_err[0] >= -3.88 && vbg_pre_err[0]< -3.70)		{ vbg_code[0] = 21; }//
			if (vbg_pre_err[0] >= -3.70 && vbg_pre_err[0]< -3.51)		{ vbg_code[0] = 20; }//
			if (vbg_pre_err[0] >= -3.51 && vbg_pre_err[0]< -3.32)		{ vbg_code[0] = 19; }//
			if (vbg_pre_err[0] >= -3.32 && vbg_pre_err[0]< -3.14)		{ vbg_code[0] = 18; }//
			if (vbg_pre_err[0] >= -3.14 && vbg_pre_err[0]< -2.96)		{ vbg_code[0] = 17; }//
			if (vbg_pre_err[0] >= -2.96 && vbg_pre_err[0]< -2.77)		{ vbg_code[0] = 16; }//
			if (vbg_pre_err[0] >= -2.77 && vbg_pre_err[0]< -2.57)		{ vbg_code[0] = 15; }//
			if (vbg_pre_err[0] >= -2.57 && vbg_pre_err[0]< -2.39)		{ vbg_code[0] = 14; }//
			if (vbg_pre_err[0] >= -2.39 && vbg_pre_err[0]< -2.22)		{ vbg_code[0] = 13; }//
			if (vbg_pre_err[0] >= -2.22 && vbg_pre_err[0]< -2.03)		{ vbg_code[0] = 12; }//
			if (vbg_pre_err[0] >= -2.03 && vbg_pre_err[0]< -1.85)		{ vbg_code[0] = 11; }//
			if (vbg_pre_err[0] >= -1.85 && vbg_pre_err[0]< -1.67)		{ vbg_code[0] = 10; }//
			if (vbg_pre_err[0] >= -1.67 && vbg_pre_err[0]< -1.50)		{ vbg_code[0] = 9; }//
			if (vbg_pre_err[0] >= -1.50 && vbg_pre_err[0]< -1.31)		{ vbg_code[0] = 8; }//
			if (vbg_pre_err[0] >= -1.31 && vbg_pre_err[0]< -1.13)		{ vbg_code[0] = 7; }//
			if (vbg_pre_err[0] >= -1.13 && vbg_pre_err[0]< -0.95)		{ vbg_code[0] = 6; }//
			if (vbg_pre_err[0] >= -0.95 && vbg_pre_err[0]< -0.77)		{ vbg_code[0] = 5; }//
			if (vbg_pre_err[0] >= -0.77 && vbg_pre_err[0]< -0.60)		{ vbg_code[0] = 4; }//
			if (vbg_pre_err[0] >= -0.60 && vbg_pre_err[0]< -0.43)		{ vbg_code[0] = 3; }//
			if (vbg_pre_err[0] >= -0.43 && vbg_pre_err[0]< -0.26)		{ vbg_code[0] = 2; }//
			if (vbg_pre_err[0] >= -0.26 && vbg_pre_err[0]< -0.09)		{ vbg_code[0] = 1; }//
			if (vbg_pre_err[0] >= -0.09 && vbg_pre_err[0]< 0.12)		{ vbg_code[0] = 0; }//

		}
		else
			vbg_code[0] = 0; //


		/******************* already trimmed dies -> set to reading of OTP ******************/
		if ((EN_OTP47_05_VD[0] == 0))
		{
			vbg_code[0] = OTP47_07_VD[0];
		}

	VBG_code->SetTestResult(0, 0,vbg_code[0]);


	cbit.SetOn(K2,/*K3,*/K4, K13, K11, -1);//K3 is used for read//2024/08/21,add K11_VOUT_FOVI
	delay_ms(3);
	dio.Connect();
	delay_ms(1);

	//I2CPUP.Set(FV, 3.6, FOVI_5V, FOVI_100MA, RELAY_ON);
	VIN.Set(FV, 3.6, FPVI10_5V, FPVI10_100MA, RELAY_ON);
	EN.Set(FV, 3.6, FOVI_5V, FOVI_100MA, RELAY_ON);
	delay_ms(3);

	DIOExpressWriteData(0x6a,0x5a);
	delay_ms(1);
	DIOExpressWriteData(0x6a,0xa5);
	delay_ms(3);

	EN.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_ON);
	delay_ms(3);
	EN.Set(FI, 0.0, FOVI_5V, FOVI_100UA, RELAY_ON);
	delay_ms(3);


	cbit.SetCBITOff(K4);
	cbit.SetCBITOn(K5);
	delay_ms(3);

	DIOExpressWriteData(0x24,0x04);
	delay_ms(1);
	DIOExpressWriteData(0x23,0x08);
	delay_ms(1);
#if 0	
	int code[64]={0};
	double tempp[64]={0.0};

	for(i=0;i<64;i++)
	{
	DIOExpressWriteData(0x47,code[0]+i);
	delay_ms(1);
	EN.MeasureVI(50, 50);
	delay_ms(3);
	tempp[i] = EN.GetMeasResult(0, MVRET);
	}
#endif


	DIOExpressWriteData(0x47,vbg_code[0]);
	delay_ms(1);

	EN.MeasureVI(50, 50);
	delay_ms(3);
	adresult[0] = EN.GetMeasResult(0, MVRET);



	DIOExpressWriteData(0x6a,0x00);
	delay_ms(1);
	dio.Disconnect();
	delay_ms(1);

	VIN.Set(FV, 0.0, FPVI10_5V, FPVI10_100MA, RELAY_ON);
	EN.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_ON);
	//I2CPUP.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_ON);
	VOUT.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_ON);	//2024/08/21,set VOUT = 1V or 3.6V can let ic stage more stable
	delay_ms(3);
	VOUT.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_OFF);	//2024/08/21,set VOUT = 1V or 3.6V can let ic stage more stable
	VIN.Set(FV, 0.0, FPVI10_5V, FPVI10_100MA, RELAY_OFF);
	EN.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_OFF);
	//I2CPUP.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_OFF);
	delay_ms(3);	
	cbit.SetOn(-1);
	delay_ms(3);

	VBG_sim->SetTestResult(0, 0, adresult[0]);
	VBG_sim_err->SetTestResult(0, 0, (adresult[0]-Vbg_target)/(adresult[0]+1e-9f)*100);
	adresult[0]=adresult[0]-Vbg_target;

    return 0;
}


DUT_API int T04_VBG_BURN(short funcindex, LPCTSTR funclabel)
{
    //{{AFX_STS_PARAM_PROTOTYPES
    CParam *VBG_burn = StsGetParam(funcindex,"VBG_burn");
    //}}AFX_STS_PARAM_PROTOTYPES

    // TODO: Add your function code here
	if (en_trim == 1)
	{
	//EN_OTP47_05_VD[0]=1;

	cbit.SetOn(K2,/*K3,*/K4,K11,K12,K13,-1);
	delay_ms(3);

	//I2CPUP.Set(FV, 3.6, FOVI_5V, FOVI_100MA, RELAY_ON);
	VIN.Set(FV, 3.6, FPVI10_5V, FPVI10_100MA, RELAY_ON);
	EN.Set(FV, 3.6, FOVI_5V, FOVI_100MA, RELAY_ON);
	delay_ms(3);
	dio.Connect();
	delay_ms(3);
	DIOExpressWriteData(0x6a,0x5a);
	delay_ms(1);
	DIOExpressWriteData(0x6a,0xa5);
	delay_ms(1);

	DIOExpressWriteData(0x47,vbg_code[0]);
	delay_ms(1);
	DIOExpressWriteData(0x20,0x07);
	delay_ms(1);
	DIOExpressWriteData(0x21,0x09);
	delay_ms(1);

	VOUT.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_ON);
	delay_ms(3);	

	VHEN1[0] = EN_OTP47_05_VD[0] * 1.0 * 5;
	VHEN2[0] = EN_OTP47_05_VD[0] * 1.1 * 5;
	VHEN3[0] = EN_OTP47_05_VD[0] * 1.2 * 5;
	VHEN4[0] = EN_OTP47_05_VD[0] * 1.3 * 5;
	VHEN5[0] = EN_OTP47_05_VD[0] * 1.4 * 5;

	VOUT.Set(FV, VHEN1[0], FOVI_10V, FOVI_100MA, RELAY_ON);
	VOUT.Set(FV, VHEN2[0], FOVI_10V, FOVI_100MA, RELAY_ON);
	VOUT.Set(FV, VHEN3[0], FOVI_10V, FOVI_100MA, RELAY_ON);
	VOUT.Set(FV, VHEN4[0], FOVI_10V, FOVI_100MA, RELAY_ON);
	VOUT.Set(FV, VHEN5[0], FOVI_10V, FOVI_100MA, RELAY_ON);
	delay_ms(1);	

	DIOExpressWriteData(0x21,0x0B);
	delay_ms(1);
	DIOExpressWriteData(0x21,0x09);
	delay_ms(1);

	VOUT.Set(FV, VHEN5[0], FOVI_10V, FOVI_100MA, RELAY_ON);
	VOUT.Set(FV, VHEN4[0], FOVI_10V, FOVI_100MA, RELAY_ON);
	VOUT.Set(FV, VHEN3[0], FOVI_10V, FOVI_100MA, RELAY_ON);
	VOUT.Set(FV, VHEN2[0], FOVI_10V, FOVI_100MA, RELAY_ON);
	VOUT.Set(FV, VHEN1[0], FOVI_10V, FOVI_100MA, RELAY_ON);
	delay_ms(1);	


	DIOExpressWriteData(0x6a,0x00);
	delay_ms(1);


	VOUT.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_ON);	
	VIN.Set(FV, 0.0, FPVI10_5V, FPVI10_100MA, RELAY_ON);
	EN.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_ON);
	//I2CPUP.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_ON);
	delay_ms(1);
	dio.Disconnect();
	delay_ms(1);
	cbit.SetOn(-1);
	delay_ms(1);

	VBG_burn->SetTestResult(0, 0, EN_OTP47_05_VD[0]);

	}

	return 0;
}


DUT_API int T05_VBG_Post(short funcindex, LPCTSTR funclabel)
{
    //{{AFX_STS_PARAM_PROTOTYPES
    CParam *VBG_post = StsGetParam(funcindex,"VBG_post");
    CParam *VBG_post_err = StsGetParam(funcindex,"VBG_post_err");
    //}}AFX_STS_PARAM_PROTOTYPES

    // TODO: Add your function code here
	cbit.SetOn(K2,/*K3,*/K4,K13,-1);//K3 is used for read
	delay_ms(3);
	dio.Connect();
	delay_ms(1);

	//I2CPUP.Set(FV, 3.6, FOVI_5V, FOVI_100MA, RELAY_ON);
	VIN.Set(FV, 3.6, FPVI10_5V, FPVI10_100MA, RELAY_ON);
	EN.Set(FV, 3.6, FOVI_5V, FOVI_100MA, RELAY_ON);
	delay_ms(3);

	DIOExpressWriteData(0x6a,0x5a);
	delay_ms(1);
	DIOExpressWriteData(0x6a,0xa5);
	delay_ms(3);

	DIOExpressWriteData(0x23,0x90);
	delay_ms(3);
	DIOExpressReadData(0x29);
	delay_ms(1);

	EN.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_ON);
	delay_ms(3);
	EN.Set(FI, 0.0, FOVI_5V, FOVI_100UA, RELAY_ON);
	delay_ms(3);


	cbit.SetCBITOff(K4);
	cbit.SetCBITOn(K5);
	delay_ms(3);

	DIOExpressWriteData(0x24,0x04);
	delay_ms(1);
	DIOExpressWriteData(0x23,0x08);
	delay_ms(1);

	EN.MeasureVI(50, 50);
	delay_ms(3);
	adresult[0] = EN.GetMeasResult(0, MVRET);

	DIOExpressWriteData(0x6a,0x00);
	delay_ms(1);
	dio.Disconnect();
	delay_ms(1);

	VIN.Set(FV, 0.0, FPVI10_5V, FPVI10_100MA, RELAY_ON);
	EN.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_ON);
	//I2CPUP.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_ON);
	delay_ms(3);
	VIN.Set(FV, 0.0, FPVI10_5V, FPVI10_100MA, RELAY_OFF);
	EN.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_OFF);
	//I2CPUP.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_OFF);
	delay_ms(3);
	cbit.SetOn(-1);
	delay_ms(3);

	VBG_post->SetTestResult(0, 0, adresult[0]);
	VBG_post_err->SetTestResult(0, 0, (Vbg_target-adresult[0])/(adresult[0]+1e-9f)*100);
	adresult[0]=adresult[0]-Vbg_target;

    return 0;
}


DUT_API int T06_VREF600M_Trim(short funcindex, LPCTSTR funclabel)
{
    //{{AFX_STS_PARAM_PROTOTYPES
    CParam *VREF600M_pre = StsGetParam(funcindex,"VREF600M_pre");
    CParam *VREF600M_pre_err = StsGetParam(funcindex,"VREF600M_pre_err");
    CParam *VREF600M_code = StsGetParam(funcindex,"VREF600M_code");
    CParam *VREF600M_sim = StsGetParam(funcindex,"VREF600M_sim");
    CParam *VREF600M_sim_err = StsGetParam(funcindex,"VREF600M_sim_err");
    //}}AFX_STS_PARAM_PROTOTYPES

    // TODO: Add your function code here


    return 0;
}


DUT_API int T07_VREF600M_BURN(short funcindex, LPCTSTR funclabel)
{
    //{{AFX_STS_PARAM_PROTOTYPES
    CParam *VREF600M_burn = StsGetParam(funcindex,"VREF600M_burn");
    //}}AFX_STS_PARAM_PROTOTYPES

    // TODO: Add your function code here
    return 0;
}


DUT_API int T08_VREF600M_Post(short funcindex, LPCTSTR funclabel)
{
    //{{AFX_STS_PARAM_PROTOTYPES
    CParam *VREF600M_post = StsGetParam(funcindex,"VREF600M_post");
    CParam *VREF600M_post_err = StsGetParam(funcindex,"VREF600M_post_err");
    //}}AFX_STS_PARAM_PROTOTYPES

    // TODO: Add your function code here
    return 0;
}


DUT_API int T09_VREF_EAOUT_Trim(short funcindex, LPCTSTR funclabel)
{
    //{{AFX_STS_PARAM_PROTOTYPES
    CParam *VREF_EAOUT_pre = StsGetParam(funcindex,"VREF_EAOUT_pre");
    CParam *VREF_EAOUT_pre_err = StsGetParam(funcindex,"VREF_EAOUT_pre_err");
    CParam *VREF_EAOUT_code = StsGetParam(funcindex,"VREF_EAOUT_code");
    CParam *VREF_EAOUT_sim = StsGetParam(funcindex,"VREF_EAOUT_sim");
    CParam *VREF_EAOUT_sim_err = StsGetParam(funcindex,"VREF_EAOUT_sim_err");
    //}}AFX_STS_PARAM_PROTOTYPES

    // TODO: Add your function code here
	cbit.SetOn(K2,/*K3,*/K4,K11,K12,K13,-1);//K3 is used for read
	delay_ms(3);
	dio.Connect();
	delay_ms(1);

	VOUT.Set(FV, 3.6, FOVI_5V, FOVI_100MA, RELAY_ON);
	//I2CPUP.Set(FV, 3.6, FOVI_5V, FOVI_100MA, RELAY_ON);
	VIN.Set(FV, 3.6, FPVI10_5V, FPVI10_100MA, RELAY_ON);
	EN.Set(FV, 3.6, FOVI_5V, FOVI_100MA, RELAY_ON);
	delay_ms(3);

	DIOExpressWriteData(0x6a,0x5a);
	delay_ms(1);
	DIOExpressWriteData(0x6a,0xa5);
	delay_ms(3);

if (AllSimCOde == 1)
{
	DIOExpressWriteData(0x47, vbg_code[0]);	delay_ms(1);
	//DIOExpressWriteData(0x40, vref_eaout_code[0]);	delay_ms(1);
	//DIOExpressWriteData(0x41, ibias_code[0] /*+ fosc_code[0]*/);	delay_ms(1);
	//DIOExpressWriteData(0x48, rsns_code[0]);	delay_ms(1);
	//DIOExpressWriteData(0x42, hscl_code[0] + vcl_code[0]);	delay_ms(1);
	//DIOExpressWriteData(0x43,ton_code[0]);	delay_ms(1);
}



	if (AllSimCOde == 1)
	{
		DIOExpressWriteData(0x47, vbg_code[0]);	delay_ms(1);
		//DIOExpressWriteData(0x40, vref_eaout_code[0]);	delay_ms(1);
		//DIOExpressWriteData(0x41, ibias_code[0] + fosc_code[0]);	delay_ms(1);
		//DIOExpressWriteData(0x48, rsns_code[0]);	delay_ms(1);
		//DIOExpressWriteData(0x42, hscl_code[0] + vcl_code[0]);	delay_ms(1);
		//DIOExpressWriteData(0x43,ton_code[0]);	delay_ms(1);
	}



	EN.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_ON);
	delay_ms(3);
	EN.Set(FI, 0.0, FOVI_5V, FOVI_100UA, RELAY_ON);
	delay_ms(3);


	cbit.SetCBITOff(K4);
	cbit.SetCBITOn(K5);
	delay_ms(3);

	DIOExpressWriteData(0x25,0x0D);
	delay_ms(1);
	DIOExpressWriteData(0x23,0xC9);
	delay_ms(1);

	EN.MeasureVI(50, 50);
	delay_ms(3);
	adresult[0] = EN.GetMeasResult(0, MVRET);

	DIOExpressWriteData(0x6a,0x00);
	delay_ms(1);
	dio.Disconnect();
	delay_ms(1);

	VOUT.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_ON);
	VIN.Set(FV, 0.0, FPVI10_5V, FPVI10_100MA, RELAY_ON);
	EN.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_ON);
	//I2CPUP.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_ON);
	delay_ms(3);
	cbit.SetOn(-1);
	delay_ms(3);

	VREF_EAOUT_pre->SetTestResult(0, 0, adresult[0]);
	VREF_EAOUT_pre_err->SetTestResult(0, 0, (vref_eaout_target - adresult[0])/(adresult[0]+1e-9f)*100);
	vref_eaout_pre_err[0]=(vref_eaout_target - adresult[0])/(adresult[0]+1e-9f)*100;

		if (vref_eaout_pre_err[0] >= -50 && vref_eaout_pre_err[0]<50)
		{
			if (vref_eaout_pre_err[0] >= -1.03 && vref_eaout_pre_err[0]< -0.34)		{ vref_eaout_code[0] = 240; }//
			if (vref_eaout_pre_err[0] >= -1.72 && vref_eaout_pre_err[0]< -1.03)		{ vref_eaout_code[0] = 224; }//
			if (vref_eaout_pre_err[0] >= -2.40 && vref_eaout_pre_err[0]< -1.72)		{ vref_eaout_code[0] = 208; }//
			if (vref_eaout_pre_err[0] >= -3.07 && vref_eaout_pre_err[0]< -2.40)		{ vref_eaout_code[0] = 192; }//
			if (vref_eaout_pre_err[0] >= -3.72 && vref_eaout_pre_err[0]< -3.07)		{ vref_eaout_code[0] = 176; }//
			if (vref_eaout_pre_err[0] >= -4.36 && vref_eaout_pre_err[0]< -3.72)		{ vref_eaout_code[0] = 160; }//
			if (vref_eaout_pre_err[0] >= -4.99 && vref_eaout_pre_err[0]< -4.36)		{ vref_eaout_code[0] = 144; }//
			if (vref_eaout_pre_err[0] >= -50.0 && vref_eaout_pre_err[0]< -4.99)		{ vref_eaout_code[0] = 128; }//

			if (vref_eaout_pre_err[0] >= 4.74 && vref_eaout_pre_err[0]< 50.0)		{ vref_eaout_code[0] = 112; }//
			if (vref_eaout_pre_err[0] >= 3.98 && vref_eaout_pre_err[0]< 4.74)		{ vref_eaout_code[0] = 96; }//
			if (vref_eaout_pre_err[0] >= 3.23 && vref_eaout_pre_err[0]< 3.98)		{ vref_eaout_code[0] = 80; }//
			if (vref_eaout_pre_err[0] >= 2.49 && vref_eaout_pre_err[0]< 3.23)		{ vref_eaout_code[0] = 64; }//
			if (vref_eaout_pre_err[0] >= 1.77 && vref_eaout_pre_err[0]< 2.49)		{ vref_eaout_code[0] = 48; }//
			if (vref_eaout_pre_err[0] >= 1.06 && vref_eaout_pre_err[0]< 1.77)		{ vref_eaout_code[0] = 32; }//
			if (vref_eaout_pre_err[0] >= 0.35 && vref_eaout_pre_err[0]< 1.06)		{ vref_eaout_code[0] = 16; }//
			if (vref_eaout_pre_err[0] >= -0.34 && vref_eaout_pre_err[0]< 0.35)		{ vref_eaout_code[0] = 0; }//

		}
		else
			vref_eaout_code[0] = 0; //


		/******************* already trimmed dies -> set to reading of OTP ******************/
		if ((EN_OTP40_47_VD[0] == 0))
		{
			vref_eaout_code[0] = OTP40_07_VD[0];
		}


	VREF_EAOUT_code->SetTestResult(0, 0, vref_eaout_code[0]);


	cbit.SetOn(K2,/*K3,*/K4,K11,K12,K13,-1);//K3 is used for read
	delay_ms(3);
	dio.Connect();
	delay_ms(1);

	VOUT.Set(FV, 3.6, FOVI_5V, FOVI_100MA, RELAY_ON);
	//I2CPUP.Set(FV, 3.6, FOVI_5V, FOVI_100MA, RELAY_ON);
	VIN.Set(FV, 3.6, FPVI10_5V, FPVI10_100MA, RELAY_ON);
	EN.Set(FV, 3.6, FOVI_5V, FOVI_100MA, RELAY_ON);
	delay_ms(3);

	DIOExpressWriteData(0x6a,0x5a);
	delay_ms(1);
	DIOExpressWriteData(0x6a,0xa5);
	delay_ms(3);

if (AllSimCOde == 1)
{
	DIOExpressWriteData(0x47, vbg_code[0]);	delay_ms(1);
	//DIOExpressWriteData(0x40, vref_eaout_code[0]);	delay_ms(1);
	//DIOExpressWriteData(0x41, ibias_code[0] /*+ fosc_code[0]*/);	delay_ms(1);
	//DIOExpressWriteData(0x48, rsns_code[0]);	delay_ms(1);
	//DIOExpressWriteData(0x42, hscl_code[0] + vcl_code[0]);	delay_ms(1);
	//DIOExpressWriteData(0x43,ton_code[0]);	delay_ms(1);
}



	EN.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_ON);
	delay_ms(3);
	EN.Set(FI, 0.0, FOVI_5V, FOVI_100UA, RELAY_ON);
	delay_ms(3);


	cbit.SetCBITOff(K4);
	cbit.SetCBITOn(K5);
	delay_ms(3);

	DIOExpressWriteData(0x25,0x0D);
	delay_ms(1);
	DIOExpressWriteData(0x23,0xC9);
	delay_ms(1);

#if 0
	int code[16]={0,16,32,48,64,80,96,112,128,144,160,176,192,208,224,240};
		
	double tempp[64]={0.0};

	for(i=0;i<16;i++)
	{
	DIOExpressWriteData(0x40,code[i]);
	delay_ms(1);
	EN.MeasureVI(50, 50);
	delay_ms(3);
	tempp[i] = EN.GetMeasResult(0, MVRET);
	}
#endif



	DIOExpressWriteData(0x40,vref_eaout_code[0]);
	delay_ms(1);

	EN.MeasureVI(50, 50);
	delay_ms(3);
	adresult[0] = EN.GetMeasResult(0, MVRET);

	DIOExpressWriteData(0x6a,0x00);
	delay_ms(1);
	dio.Disconnect();
	delay_ms(1);

	VOUT.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_ON);
	VIN.Set(FV, 0.0, FPVI10_5V, FPVI10_100MA, RELAY_ON);
	EN.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_ON);
	//I2CPUP.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_ON);
	delay_ms(3);
	VOUT.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_OFF);
	VIN.Set(FV, 0.0, FPVI10_5V, FPVI10_100MA, RELAY_OFF);
	EN.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_OFF);
	//I2CPUP.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_OFF);
	delay_ms(3);	
	cbit.SetOn(-1);
	delay_ms(3);

	VREF_EAOUT_sim->SetTestResult(0, 0, adresult[0]);
	VREF_EAOUT_sim_err->SetTestResult(0, 0, (vref_eaout_target - adresult[0])/(adresult[0]+1e-9f)*100);

    return 0;
}



DUT_API int T10_VREF_EAOUT_BURN(short funcindex, LPCTSTR funclabel)
{
    //{{AFX_STS_PARAM_PROTOTYPES
    CParam *VREF_EAOUT_burn = StsGetParam(funcindex,"VREF_EAOUT_burn");
    //}}AFX_STS_PARAM_PROTOTYPES

    // TODO: Add your function code here
	if (en_trim == 1)
	{

	//EN_OTP40_47_VD[0]=1;

	cbit.SetOn(K2,/*K3,*/K4,K11,K12,K13,-1);
	delay_ms(3);

	//I2CPUP.Set(FV, 3.6, FOVI_5V, FOVI_100MA, RELAY_ON);
	VIN.Set(FV, 3.6, FPVI10_5V, FPVI10_100MA, RELAY_ON);
	EN.Set(FV, 3.6, FOVI_5V, FOVI_100MA, RELAY_ON);
	delay_ms(3);
	dio.Connect();
	delay_ms(3);
	DIOExpressWriteData(0x6a,0x5a);
	delay_ms(1);
	DIOExpressWriteData(0x6a,0xa5);
	delay_ms(1);

	DIOExpressWriteData(0x40,vref_eaout_code[0]);
	delay_ms(1);
	DIOExpressWriteData(0x20,0x00);
	delay_ms(1);
	DIOExpressWriteData(0x21,0x09);
	delay_ms(1);

	VOUT.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_ON);
	delay_ms(3);	

	VHEN1[0] = EN_OTP40_47_VD[0] * 1.0 * 5;
	VHEN2[0] = EN_OTP40_47_VD[0] * 1.1 * 5;
	VHEN3[0] = EN_OTP40_47_VD[0] * 1.2 * 5;
	VHEN4[0] = EN_OTP40_47_VD[0] * 1.3 * 5;
	VHEN5[0] = EN_OTP40_47_VD[0] * 1.4 * 5;

	VOUT.Set(FV, VHEN1[0], FOVI_10V, FOVI_100MA, RELAY_ON);
	VOUT.Set(FV, VHEN2[0], FOVI_10V, FOVI_100MA, RELAY_ON);
	VOUT.Set(FV, VHEN3[0], FOVI_10V, FOVI_100MA, RELAY_ON);
	VOUT.Set(FV, VHEN4[0], FOVI_10V, FOVI_100MA, RELAY_ON);
	VOUT.Set(FV, VHEN5[0], FOVI_10V, FOVI_100MA, RELAY_ON);
	delay_ms(1);	

	DIOExpressWriteData(0x21,0x0B);
	delay_ms(1);
	DIOExpressWriteData(0x21,0x09);
	delay_ms(1);

	VOUT.Set(FV, VHEN5[0], FOVI_10V, FOVI_100MA, RELAY_ON);
	VOUT.Set(FV, VHEN4[0], FOVI_10V, FOVI_100MA, RELAY_ON);
	VOUT.Set(FV, VHEN3[0], FOVI_10V, FOVI_100MA, RELAY_ON);
	VOUT.Set(FV, VHEN2[0], FOVI_10V, FOVI_100MA, RELAY_ON);
	VOUT.Set(FV, VHEN1[0], FOVI_10V, FOVI_100MA, RELAY_ON);
	delay_ms(1);	


	DIOExpressWriteData(0x6a,0x00);
	delay_ms(1);


	VOUT.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_ON);	
	VIN.Set(FV, 0.0, FPVI10_5V, FPVI10_100MA, RELAY_ON);
	EN.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_ON);
	//I2CPUP.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_ON);
	delay_ms(1);
	dio.Disconnect();
	delay_ms(1);
	cbit.SetOn(-1);
	delay_ms(1);

	VREF_EAOUT_burn->SetTestResult(0, 0, EN_OTP40_47_VD[0]);

	}
	
	return 0;
}


DUT_API int T11_VREF_EAOUT_Post(short funcindex, LPCTSTR funclabel)
{
    //{{AFX_STS_PARAM_PROTOTYPES
    CParam *VREF_EAOUT_post = StsGetParam(funcindex,"VREF_EAOUT_post");
    CParam *VREF_EAOUT_post_err = StsGetParam(funcindex,"VREF_EAOUT_post_err");
    //}}AFX_STS_PARAM_PROTOTYPES

    // TODO: Add your function code here
	cbit.SetOn(K2,/*K3,*/K4,K11,K12,K13,-1);//K3 is used for read
	delay_ms(3);
	dio.Connect();
	delay_ms(1);

	VOUT.Set(FV, 3.6, FOVI_5V, FOVI_100MA, RELAY_ON);
	//I2CPUP.Set(FV, 3.6, FOVI_5V, FOVI_100MA, RELAY_ON);
	VIN.Set(FV, 3.6, FPVI10_5V, FPVI10_100MA, RELAY_ON);
	EN.Set(FV, 3.6, FOVI_5V, FOVI_100MA, RELAY_ON);
	delay_ms(3);

	DIOExpressWriteData(0x6a,0x5a);
	delay_ms(1);
	DIOExpressWriteData(0x6a,0xa5);
	delay_ms(3);



	EN.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_ON);
	delay_ms(3);
	EN.Set(FI, 0.0, FOVI_5V, FOVI_100UA, RELAY_ON);
	delay_ms(3);


	cbit.SetCBITOff(K4);
	cbit.SetCBITOn(K5);
	delay_ms(3);

	DIOExpressWriteData(0x25,0x0D);
	delay_ms(1);
	DIOExpressWriteData(0x23,0xC9);
	delay_ms(1);



	EN.MeasureVI(50, 50);
	delay_ms(3);
	adresult[0] = EN.GetMeasResult(0, MVRET);

	DIOExpressWriteData(0x6a,0x00);
	delay_ms(1);
	dio.Disconnect();
	delay_ms(1);

	VOUT.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_ON);
	VIN.Set(FV, 0.0, FPVI10_5V, FPVI10_100MA, RELAY_ON);
	EN.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_ON);
	//I2CPUP.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_ON);
	delay_ms(3);
	VOUT.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_OFF);
	VIN.Set(FV, 0.0, FPVI10_5V, FPVI10_100MA, RELAY_OFF);
	EN.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_OFF);
	//I2CPUP.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_OFF);
	delay_ms(3);
	cbit.SetOn(-1);
	delay_ms(3);

	VREF_EAOUT_post->SetTestResult(0, 0, adresult[0]);
	VREF_EAOUT_post_err->SetTestResult(0, 0, (vref_eaout_target - adresult[0])/(adresult[0]+1e-9f)*100);

    return 0;
}


DUT_API int T12_IBIAS_Trim(short funcindex, LPCTSTR funclabel)
{
    //{{AFX_STS_PARAM_PROTOTYPES
    CParam *IBIAS_pre = StsGetParam(funcindex,"IBIAS_pre");
    CParam *IBIAS_pre_err = StsGetParam(funcindex,"IBIAS_pre_err");
    CParam *IBIAS_code = StsGetParam(funcindex,"IBIAS_code");
    CParam *IBIAS_sim = StsGetParam(funcindex,"IBIAS_sim");
    CParam *IBIAS_sim_err = StsGetParam(funcindex,"IBIAS_sim_err");
    //}}AFX_STS_PARAM_PROTOTYPES

    // TODO: Add your function code here
	cbit.SetOn(K2,/*K3,*/K4,/*K11,K12,*/K13,-1);//K3 is used for read
	delay_ms(3);
	dio.Connect();
	delay_ms(1);

//	VOUT.Set(FV, 3.6, FOVI_5V, FOVI_100MA, RELAY_ON);
	//I2CPUP.Set(FV, 3.6, FOVI_5V, FOVI_100MA, RELAY_ON);
	VIN.Set(FV, 3.6, FPVI10_5V, FPVI10_100MA, RELAY_ON);
	EN.Set(FV, 3.6, FOVI_5V, FOVI_100MA, RELAY_ON);
	delay_ms(3);

	DIOExpressWriteData(0x6a,0x5a);
	delay_ms(1);
	DIOExpressWriteData(0x6a,0xa5);
	delay_ms(3);

if (AllSimCOde == 1)
{
	DIOExpressWriteData(0x47, vbg_code[0]);	delay_ms(1);
	DIOExpressWriteData(0x40, vref_eaout_code[0]);	delay_ms(1);
	//DIOExpressWriteData(0x41, ibias_code[0] /*+ fosc_code[0]*/);	delay_ms(1);
	//DIOExpressWriteData(0x48, rsns_code[0]);	delay_ms(1);
	//DIOExpressWriteData(0x42, hscl_code[0] + vcl_code[0]);	delay_ms(1);
	//DIOExpressWriteData(0x43,ton_code[0]);	delay_ms(1);
}


	EN.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_ON);
	delay_ms(3);

	DIOExpressWriteData(0x24,0x04);
	delay_ms(1);
	DIOExpressWriteData(0x23,0x88);
	delay_ms(1);


	EN.Set(FV, 0.0, FOVI_5V, FOVI_10UA, RELAY_ON);
	delay_ms(3);

	EN.MeasureVI(50, 50);
	delay_ms(3);

	adresult[0] = EN.GetMeasResult(0, MIRET)*-1e6f;

	EN.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_ON);
	delay_ms(3);

	DIOExpressWriteData(0x6a,0x00);
	delay_ms(1);
	dio.Disconnect();
	delay_ms(1);

	VIN.Set(FV, 0.0, FPVI10_5V, FPVI10_100MA, RELAY_ON);
	EN.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_ON);
	//I2CPUP.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_ON);
	delay_ms(3);
	cbit.SetOn(-1);
	delay_ms(3);

	IBIAS_pre->SetTestResult(0, 0, adresult[0]);
	IBIAS_pre_err->SetTestResult(0, 0, (ibias_target-adresult[0])/(adresult[0]+1e-9f)*100);
	ibias_pre_err[0]=(ibias_target-adresult[0])/(adresult[0]+1e-9f)*100;

		if (ibias_pre_err[0] >= -50 && ibias_pre_err[0]<50)
		{
			if (ibias_pre_err[0] >= -3.56 && ibias_pre_err[0]< -0.92)		{ ibias_code[0] = 15; }//
			if (ibias_pre_err[0] >= -6.64 && ibias_pre_err[0]< -3.56)		{ ibias_code[0] = 14; }//
			if (ibias_pre_err[0] >= -9.15 && ibias_pre_err[0]< -6.64)		{ ibias_code[0] = 13; }//
			if (ibias_pre_err[0] >= -10.99 && ibias_pre_err[0]< -9.15)		{ ibias_code[0] = 12; }//
			if (ibias_pre_err[0] >= -12.68 && ibias_pre_err[0]< -10.99)		{ ibias_code[0] = 11; }//
			if (ibias_pre_err[0] >= -14.72 && ibias_pre_err[0]< -12.68)		{ ibias_code[0] = 10; }//
			if (ibias_pre_err[0] >= -17.18 && ibias_pre_err[0]< -14.72)		{ ibias_code[0] = 9; }//
			if (ibias_pre_err[0] >= -50.0 && ibias_pre_err[0]< -17.18)		{ ibias_code[0] = 8; }//

			if (ibias_pre_err[0] >= 23.27 && ibias_pre_err[0]< 50.0)		{ ibias_code[0] = 7; }//
			if (ibias_pre_err[0] >= 19.45 && ibias_pre_err[0]< 23.27)		{ ibias_code[0] = 6; }//
			if (ibias_pre_err[0] >= 16.07 && ibias_pre_err[0]< 19.45)		{ ibias_code[0] = 5; }//
			if (ibias_pre_err[0] >= 12.52 && ibias_pre_err[0]< 16.07)		{ ibias_code[0] = 4; }//
			if (ibias_pre_err[0] >= 8.67 && ibias_pre_err[0]< 12.52)		{ ibias_code[0] = 3; }//
			if (ibias_pre_err[0] >= 4.84 && ibias_pre_err[0]< 8.67)			{ ibias_code[0] = 2; }//
			if (ibias_pre_err[0] >= 1.54 && ibias_pre_err[0]< 4.84)			{ ibias_code[0] = 1; }//
			if (ibias_pre_err[0] >= -0.92 && ibias_pre_err[0]< 1.54)		{ ibias_code[0] = 0; }//

		}
		else
			ibias_code[0] = 0; //


		/******************* already trimmed dies -> set to reading of OTP ******************/
		if ((EN_OTP41_03_VD[0] == 0))
		{
			ibias_code[0] = OTP41_03_VD[0];
		}


	IBIAS_code->SetTestResult(0, 0, ibias_code[0]);


	cbit.SetOn(K2,/*K3,*/K4,/*K11,K12,*/K13,-1);//K3 is used for read
	delay_ms(3);
	dio.Connect();
	delay_ms(1);

//	VOUT.Set(FV, 3.6, FOVI_5V, FOVI_100MA, RELAY_ON);
	//I2CPUP.Set(FV, 3.6, FOVI_5V, FOVI_100MA, RELAY_ON);
	VIN.Set(FV, 3.6, FPVI10_5V, FPVI10_100MA, RELAY_ON);
	EN.Set(FV, 3.6, FOVI_5V, FOVI_100MA, RELAY_ON);
	delay_ms(3);

	DIOExpressWriteData(0x6a,0x5a);
	delay_ms(1);
	DIOExpressWriteData(0x6a,0xa5);
	delay_ms(3);

if (AllSimCOde == 1)
{
	DIOExpressWriteData(0x47, vbg_code[0]);	delay_ms(1);
	DIOExpressWriteData(0x40, vref_eaout_code[0]);	delay_ms(1);
	//DIOExpressWriteData(0x41, ibias_code[0] /*+ fosc_code[0]*/);	delay_ms(1);
	//DIOExpressWriteData(0x48, rsns_code[0]);	delay_ms(1);
	//DIOExpressWriteData(0x42, hscl_code[0] + vcl_code[0]);	delay_ms(1);
	//DIOExpressWriteData(0x43,ton_code[0]);	delay_ms(1);
}


	EN.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_ON);
	delay_ms(3);

	DIOExpressWriteData(0x24,0x04);
	delay_ms(1);
	DIOExpressWriteData(0x23,0x88);
	delay_ms(1);

	EN.Set(FV, 0.0, FOVI_5V, FOVI_10UA, RELAY_ON);
	delay_ms(3);

#if 0
	int code[16]={0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15};
		
	double tempp[64]={0.0};

	for(i=0;i<16;i++)
	{
	DIOExpressWriteData(0x41,code[i]);
	delay_ms(1);
	EN.MeasureVI(50, 50);
	delay_ms(3);
	tempp[i] = EN.GetMeasResult(0, MIRET)*-1e6f;
	}
#endif

	DIOExpressWriteData(0x41,ibias_code[0]);
	delay_ms(1);
	EN.MeasureVI(50, 50);
	delay_ms(3);
	adresult[0] = EN.GetMeasResult(0, MIRET)*-1e6f;

	EN.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_ON);
	delay_ms(3);

	DIOExpressWriteData(0x6a,0x00);
	delay_ms(1);
	dio.Disconnect();
	delay_ms(1);

	VIN.Set(FV, 0.0, FPVI10_5V, FPVI10_100MA, RELAY_ON);
	EN.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_ON);
	//I2CPUP.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_ON);
	delay_ms(3);
	VIN.Set(FV, 0.0, FPVI10_5V, FPVI10_100MA, RELAY_OFF);
	EN.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_OFF);
	//I2CPUP.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_OFF);
	delay_ms(3);	
	cbit.SetOn(-1);
	delay_ms(3);

	IBIAS_sim->SetTestResult(0, 0, adresult[0]);
	IBIAS_sim_err->SetTestResult(0, 0, (ibias_target-adresult[0])/(adresult[0]+1e-9f)*100);


    return 0;
}


DUT_API int T13_IBIAS_BURN(short funcindex, LPCTSTR funclabel)
{
    //{{AFX_STS_PARAM_PROTOTYPES
    CParam *IBIAS_burn = StsGetParam(funcindex,"IBIAS_burn");
    //}}AFX_STS_PARAM_PROTOTYPES

    // TODO: Add your function code here
	if (en_trim == 1)
	{
	//EN_OTP41_03_VD[0]=1;

	cbit.SetOn(K2,/*K3,*/K4,K11,K12,K13,-1);
	delay_ms(3);

	//I2CPUP.Set(FV, 3.6, FOVI_5V, FOVI_100MA, RELAY_ON);
	VIN.Set(FV, 3.6, FPVI10_5V, FPVI10_100MA, RELAY_ON);
	EN.Set(FV, 3.6, FOVI_5V, FOVI_100MA, RELAY_ON);
	delay_ms(3);
	dio.Connect();
	delay_ms(3);
	DIOExpressWriteData(0x6a,0x5a);
	delay_ms(1);
	DIOExpressWriteData(0x6a,0xa5);
	delay_ms(1);

	DIOExpressWriteData(0x41,ibias_code[0]);
	delay_ms(1);
	DIOExpressWriteData(0x20,0x01);
	delay_ms(1);
	DIOExpressWriteData(0x21,0x09);
	delay_ms(1);

	VOUT.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_ON);
	delay_ms(3);	

	VHEN1[0] = EN_OTP41_03_VD[0] * 1.0 * 5;
	VHEN2[0] = EN_OTP41_03_VD[0] * 1.1 * 5;
	VHEN3[0] = EN_OTP41_03_VD[0] * 1.2 * 5;
	VHEN4[0] = EN_OTP41_03_VD[0] * 1.3 * 5;
	VHEN5[0] = EN_OTP41_03_VD[0] * 1.4 * 5;

	VOUT.Set(FV, VHEN1[0], FOVI_10V, FOVI_100MA, RELAY_ON);
	VOUT.Set(FV, VHEN2[0], FOVI_10V, FOVI_100MA, RELAY_ON);
	VOUT.Set(FV, VHEN3[0], FOVI_10V, FOVI_100MA, RELAY_ON);
	VOUT.Set(FV, VHEN4[0], FOVI_10V, FOVI_100MA, RELAY_ON);
	VOUT.Set(FV, VHEN5[0], FOVI_10V, FOVI_100MA, RELAY_ON);
	delay_ms(1);	

	DIOExpressWriteData(0x21,0x0B);
	delay_ms(1);
	DIOExpressWriteData(0x21,0x09);
	delay_ms(1);

	VOUT.Set(FV, VHEN5[0], FOVI_10V, FOVI_100MA, RELAY_ON);
	VOUT.Set(FV, VHEN4[0], FOVI_10V, FOVI_100MA, RELAY_ON);
	VOUT.Set(FV, VHEN3[0], FOVI_10V, FOVI_100MA, RELAY_ON);
	VOUT.Set(FV, VHEN2[0], FOVI_10V, FOVI_100MA, RELAY_ON);
	VOUT.Set(FV, VHEN1[0], FOVI_10V, FOVI_100MA, RELAY_ON);
	delay_ms(1);	


	DIOExpressWriteData(0x6a,0x00);
	delay_ms(1);


	VOUT.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_ON);	
	VIN.Set(FV, 0.0, FPVI10_5V, FPVI10_100MA, RELAY_ON);
	EN.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_ON);
	//I2CPUP.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_ON);
	delay_ms(1);
	dio.Disconnect();
	delay_ms(1);
	cbit.SetOn(-1);
	delay_ms(1);



	IBIAS_burn->SetTestResult(0, 0, EN_OTP41_03_VD[0]);

	}
    return 0;
}


DUT_API int T14_IBIAS_Post(short funcindex, LPCTSTR funclabel)
{
    //{{AFX_STS_PARAM_PROTOTYPES
    CParam *IBIAS_post = StsGetParam(funcindex,"IBIAS_post");
    CParam *IBIAS_post_err = StsGetParam(funcindex,"IBIAS_post_err");
    //}}AFX_STS_PARAM_PROTOTYPES

    // TODO: Add your function code here
	cbit.SetOn(K2,/*K3,*/K4,/*K11,K12,*/K13,-1);//K3 is used for read
	delay_ms(3);
	dio.Connect();
	delay_ms(1);


//	VOUT.Set(FV, 3.6, FOVI_5V, FOVI_100MA, RELAY_ON);
	//I2CPUP.Set(FV, 3.6, FOVI_5V, FOVI_100MA, RELAY_ON);
	VIN.Set(FV, 3.6, FPVI10_5V, FPVI10_100MA, RELAY_ON);
	EN.Set(FV, 3.6, FOVI_5V, FOVI_100MA, RELAY_ON);
	delay_ms(3);

	DIOExpressWriteData(0x6a,0x5a);
	delay_ms(1);
	DIOExpressWriteData(0x6a,0xa5);
	delay_ms(3);

	//DIOExpressWriteData(0x23,0x90);
	//delay_ms(3);
	//DIOExpressReadData(0x29);
	//delay_ms(1);

	EN.Set(FV, -0.0, FOVI_1V, FOVI_100MA, RELAY_ON);
	delay_ms(3);

	DIOExpressWriteData(0x24,0x04);
	delay_ms(1);
	DIOExpressWriteData(0x23,0x88);
	delay_ms(1);

	EN.Set(FV, 0.0, FOVI_1V, FOVI_10UA, RELAY_ON);
	delay_ms(3);

	EN.MeasureVI(1000, 100);
	delay_ms(3);

	adresult[0] = EN.GetMeasResult(0, MIRET)*-1e6f;

	EN.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_ON);
	delay_ms(3);


	DIOExpressWriteData(0x6a,0x00);
	delay_ms(1);
	dio.Disconnect();
	delay_ms(1);

	VIN.Set(FV, 0.0, FPVI10_5V, FPVI10_100MA, RELAY_ON);
	EN.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_ON);
	//I2CPUP.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_ON);
	delay_ms(3);
	VIN.Set(FV, 0.0, FPVI10_5V, FPVI10_100MA, RELAY_OFF);
	EN.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_OFF);
	//I2CPUP.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_OFF);
	delay_ms(3);	
	cbit.SetOn(-1);
	delay_ms(3);

	IBIAS_post->SetTestResult(0, 0, adresult[0]);
	IBIAS_post_err->SetTestResult(0, 0, (ibias_target-adresult[0])/(adresult[0]+1e-9f)*100);


    return 0;
}


DUT_API int T15_RSNS_Trim(short funcindex, LPCTSTR funclabel)
{
    //{{AFX_STS_PARAM_PROTOTYPES
    CParam *RSNS_pre = StsGetParam(funcindex,"RSNS_pre");
    CParam *RSNS_pre_err = StsGetParam(funcindex,"RSNS_pre_err");
    CParam *RSNS_code = StsGetParam(funcindex,"RSNS_code");
    CParam *RSNS_sim = StsGetParam(funcindex,"RSNS_sim");
    CParam *RSNS_sim_err = StsGetParam(funcindex,"RSNS_sim_err");
    //}}AFX_STS_PARAM_PROTOTYPES

    // TODO: Add your function code here
	cbit.SetOn(K1,K2,K3,K4,/*K11,K12,*/K13,-1);//K3 is used for read
	delay_ms(3);
	dio.Connect();
	delay_ms(1);

	MODE.Set(FI, 0.0, FOVI_5V, FOVI_1MA, RELAY_ON);
	//I2CPUP.Set(FV, 1.0, FOVI_5V, FOVI_100MA, RELAY_ON);
	VIN.Set(FV, 3.6, FPVI10_5V, FPVI10_100MA, RELAY_ON);
	EN.Set(FV, 3.6, FOVI_5V, FOVI_100MA, RELAY_ON);
	delay_ms(3);

	DIOExpressWriteData(0x6a,0x5a);
	delay_ms(1);
	DIOExpressWriteData(0x6a,0xa5);
	delay_ms(3);

if (AllSimCOde == 1)
{
	DIOExpressWriteData(0x47, vbg_code[0]);	delay_ms(1);
	DIOExpressWriteData(0x40, vref_eaout_code[0]);	delay_ms(1);
	DIOExpressWriteData(0x41, ibias_code[0] /*+ fosc_code[0]*/);	delay_ms(1);
	//DIOExpressWriteData(0x48, rsns_code[0]);	delay_ms(1);
	//DIOExpressWriteData(0x42, hscl_code[0] + vcl_code[0]);	delay_ms(1);
	//DIOExpressWriteData(0x43,ton_code[0]);	delay_ms(1);
}



	EN.Set(FV, -0.0, FOVI_1V, FOVI_100MA, RELAY_ON);
	delay_ms(3);
	EN.Set(FV, -0.0, FOVI_1V, FOVI_100MA, RELAY_OFF);
	delay_ms(3);

	DIOExpressWriteData(0x21,0x40);
	delay_ms(1);

	dio.Disconnect();
	delay_ms(1);

	MODE.Set(FV, 0.0, FOVI_5V, FOVI_1MA, RELAY_ON);
	delay_ms(3);
	MODE.MeasureVI(100, 50);
	delay_ms(3);
	adresult[0] = MODE.GetMeasResult(0, MIRET)*-1e6f;


	VIN.Set(FV, 0.0, FPVI10_5V, FPVI10_100MA, RELAY_ON);
	EN.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_ON);
	//I2CPUP.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_ON);
	delay_ms(3);
	VOUT.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_OFF);
	VIN.Set(FV, 0.0, FPVI10_5V, FPVI10_100MA, RELAY_OFF);
	EN.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_OFF);
	//I2CPUP.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_OFF);
	MODE.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_OFF);
	delay_ms(3);
	cbit.SetOn(-1);
	delay_ms(3);

	RSNS_pre->SetTestResult(0, 0, adresult[0]);
	RSNS_pre_err->SetTestResult(0, 0, (rsns_target - adresult[0])/(adresult[0]+1e-9f)*100);
	rsns_pre_err[0]=(rsns_target - adresult[0])/(adresult[0]+1e-9f)*100;

		if (rsns_pre_err[0] >= -50 && rsns_pre_err[0]<50)
		{
			if (rsns_pre_err[0] >= -1.27 && rsns_pre_err[0]< -0.45)		{ rsns_code[0] = 31; }//
			if (rsns_pre_err[0] >= -2.07 && rsns_pre_err[0]< -1.27)		{ rsns_code[0] = 30; }//
			if (rsns_pre_err[0] >= -2.93 && rsns_pre_err[0]< -2.07)		{ rsns_code[0] = 29; }//
			if (rsns_pre_err[0] >= -3.71 && rsns_pre_err[0]< -2.93)		{ rsns_code[0] = 28; }//
			if (rsns_pre_err[0] >= -4.52 && rsns_pre_err[0]< -3.71)		{ rsns_code[0] = 27; }//
			if (rsns_pre_err[0] >= -5.30 && rsns_pre_err[0]< -4.52)		{ rsns_code[0] = 26; }//
			if (rsns_pre_err[0] >= -6.09 && rsns_pre_err[0]< -5.30)		{ rsns_code[0] = 25; }//
			if (rsns_pre_err[0] >= -6.95 && rsns_pre_err[0]< -6.09)		{ rsns_code[0] = 24; }//
			if (rsns_pre_err[0] >= -7.76 && rsns_pre_err[0]< -6.95)		{ rsns_code[0] = 23; }//
			if (rsns_pre_err[0] >= -8.56 && rsns_pre_err[0]< -7.76)		{ rsns_code[0] = 22; }//
			if (rsns_pre_err[0] >= -9.41 && rsns_pre_err[0]< -8.56)		{ rsns_code[0] = 21; }//
			if (rsns_pre_err[0] >= -10.21 && rsns_pre_err[0]< -9.41)	{ rsns_code[0] = 20; }//
			if (rsns_pre_err[0] >= -11.03 && rsns_pre_err[0]< -10.21)	{ rsns_code[0] = 19; }//
			if (rsns_pre_err[0] >= -11.84 && rsns_pre_err[0]< -11.03)	{ rsns_code[0] = 18; }//
			if (rsns_pre_err[0] >= -12.67 && rsns_pre_err[0]< -11.84)	{ rsns_code[0] = 17; }//
			if (rsns_pre_err[0] >= -50.0 && rsns_pre_err[0]< -12.67)	{ rsns_code[0] = 16; }//

			if (rsns_pre_err[0] >= 11.88 && rsns_pre_err[0]< 50.0)		{ rsns_code[0] = 15; }//
			if (rsns_pre_err[0] >= 11.07 && rsns_pre_err[0]< 11.88)		{ rsns_code[0] = 14; }//
			if (rsns_pre_err[0] >= 10.21 && rsns_pre_err[0]< 11.07)		{ rsns_code[0] = 13; }//
			if (rsns_pre_err[0] >= 9.43 && rsns_pre_err[0]< 10.21)		{ rsns_code[0] = 12; }//
			if (rsns_pre_err[0] >= 8.60 && rsns_pre_err[0]< 9.43)		{ rsns_code[0] = 11; }//
			if (rsns_pre_err[0] >= 7.80 && rsns_pre_err[0]< 8.60)		{ rsns_code[0] = 10; }//
			if (rsns_pre_err[0] >= 6.99 && rsns_pre_err[0]< 7.80)		{ rsns_code[0] = 9; }//
			if (rsns_pre_err[0] >= 6.15 && rsns_pre_err[0]< 6.99)		{ rsns_code[0] = 8; }//
			if (rsns_pre_err[0] >= 5.34 && rsns_pre_err[0]< 6.15)		{ rsns_code[0] = 7; }//
			if (rsns_pre_err[0] >= 4.50 && rsns_pre_err[0]< 5.34)		{ rsns_code[0] = 6; }//
			if (rsns_pre_err[0] >= 3.68 && rsns_pre_err[0]< 4.50)		{ rsns_code[0] = 5; }//
			if (rsns_pre_err[0] >= 2.92 && rsns_pre_err[0]< 3.68)		{ rsns_code[0] = 4; }//
			if (rsns_pre_err[0] >= 2.11 && rsns_pre_err[0]< 2.92)		{ rsns_code[0] = 3; }//
			if (rsns_pre_err[0] >= 1.27 && rsns_pre_err[0]< 2.11)		{ rsns_code[0] = 2; }//
			if (rsns_pre_err[0] >= 0.45 && rsns_pre_err[0]< 1.27)		{ rsns_code[0] = 1; }//
			if (rsns_pre_err[0] >= -0.45 && rsns_pre_err[0]< 0.45)		{ rsns_code[0] = 0; }//

		}
		else
			rsns_code[0] = 0; //


		/******************* already trimmed dies -> set to reading of OTP ******************/
		if ((EN_OTP48_04_VD[0] == 0))
		{
			rsns_code[0] = OTP48_07_VD[0];
		}


	RSNS_code->SetTestResult(0, 0, rsns_code[0]);



	cbit.SetOn(K1,K2,K3,K4,/*K11,K12,*/K13,-1);//K3 is used for read
	delay_ms(3);
	dio.Connect();
	delay_ms(1);

	MODE.Set(FI, 0.0, FOVI_5V, FOVI_1MA, RELAY_ON);
	//I2CPUP.Set(FV, 1.0, FOVI_5V, FOVI_100MA, RELAY_ON);
	VIN.Set(FV, 3.6, FPVI10_5V, FPVI10_100MA, RELAY_ON);
	EN.Set(FV, 3.6, FOVI_5V, FOVI_100MA, RELAY_ON);
	delay_ms(3);

	DIOExpressWriteData(0x6a,0x5a);
	delay_ms(1);
	DIOExpressWriteData(0x6a,0xa5);
	delay_ms(3);

if (AllSimCOde == 1)
{
	DIOExpressWriteData(0x47, vbg_code[0]);	delay_ms(1);
	DIOExpressWriteData(0x40, vref_eaout_code[0]);	delay_ms(1);
	DIOExpressWriteData(0x41, ibias_code[0] /*+ fosc_code[0]*/);	delay_ms(1);
	//DIOExpressWriteData(0x48, rsns_code[0]);	delay_ms(1);
	//DIOExpressWriteData(0x42, hscl_code[0] + vcl_code[0]);	delay_ms(1);
	//DIOExpressWriteData(0x43,ton_code[0]);	delay_ms(1);
}


	EN.Set(FV, -0.0, FOVI_1V, FOVI_100MA, RELAY_ON);
	delay_ms(3);
	EN.Set(FV, -0.0, FOVI_1V, FOVI_100MA, RELAY_OFF);
	delay_ms(3);

	DIOExpressWriteData(0x21,0x40);
	delay_ms(1);

#if 1
	DIOExpressWriteData(0x48,rsns_code[0]);
	delay_ms(1);

	dio.Disconnect();
	delay_ms(1);

	MODE.Set(FV, 0.0, FOVI_5V, FOVI_1MA, RELAY_ON);
	delay_ms(3);
	MODE.MeasureVI(100, 50);
	delay_ms(3);
	adresult[0] = MODE.GetMeasResult(0, MIRET)*-1e6f;
#endif


#if 0
	int code[32]={0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31};
		
	double tempp[64]={0.0};

	for(i=0;i<32;i++)
	{
	dio.Connect();
	delay_ms(3);

	DIOExpressWriteData(0x48,code[i]);
	delay_ms(3);

	dio.Disconnect();
	delay_ms(3);
	MODE.Set(FV, 0.0, FOVI_5V, FOVI_1MA, RELAY_ON);
	delay_ms(3);
	MODE.MeasureVI(100, 50);
	delay_ms(3);
	tempp[i] = MODE.GetMeasResult(0, MIRET)*-1e6f;

	}
#endif

	VIN.Set(FV, 0.0, FPVI10_5V, FPVI10_100MA, RELAY_ON);
	EN.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_ON);
	//I2CPUP.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_ON);
	delay_ms(3);
	VOUT.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_OFF);
	VIN.Set(FV, 0.0, FPVI10_5V, FPVI10_100MA, RELAY_OFF);
	EN.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_OFF);
	//I2CPUP.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_OFF);
	MODE.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_OFF);
	delay_ms(3);
	cbit.SetOn(-1);
	delay_ms(3);

	RSNS_sim->SetTestResult(0, 0, adresult[0]);
	RSNS_sim_err->SetTestResult(0, 0, (rsns_target - adresult[0])/(adresult[0]+1e-9f)*100);

    return 0;
}


DUT_API int T16_RSNS_BURN(short funcindex, LPCTSTR funclabel)
{
    //{{AFX_STS_PARAM_PROTOTYPES
    CParam *RSNS_burn = StsGetParam(funcindex,"RSNS_burn");
    //}}AFX_STS_PARAM_PROTOTYPES

    // TODO: Add your function code here
	if (en_trim == 1)
	{
	//EN_OTP48_04_VD[0]=1;

	cbit.SetOn(K2,/*K3,*/K4,K11,K12,K13,-1);
	delay_ms(3);

	//I2CPUP.Set(FV, 3.6, FOVI_5V, FOVI_100MA, RELAY_ON);
	VIN.Set(FV, 3.6, FPVI10_5V, FPVI10_100MA, RELAY_ON);
	EN.Set(FV, 3.6, FOVI_5V, FOVI_100MA, RELAY_ON);
	delay_ms(3);
	dio.Connect();
	delay_ms(3);
	DIOExpressWriteData(0x6a,0x5a);
	delay_ms(1);
	DIOExpressWriteData(0x6a,0xa5);
	delay_ms(1);

	DIOExpressWriteData(0x48,rsns_code[0]);
	delay_ms(1);
	DIOExpressWriteData(0x20,0x08);
	delay_ms(1);
	DIOExpressWriteData(0x21,0x09);
	delay_ms(1);

	VOUT.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_ON);
	delay_ms(3);	

	VHEN1[0] = EN_OTP48_04_VD[0] * 1.0 * 5;
	VHEN2[0] = EN_OTP48_04_VD[0] * 1.1 * 5;
	VHEN3[0] = EN_OTP48_04_VD[0] * 1.2 * 5;
	VHEN4[0] = EN_OTP48_04_VD[0] * 1.3 * 5;
	VHEN5[0] = EN_OTP48_04_VD[0] * 1.4 * 5;

	VOUT.Set(FV, VHEN1[0], FOVI_10V, FOVI_100MA, RELAY_ON);
	VOUT.Set(FV, VHEN2[0], FOVI_10V, FOVI_100MA, RELAY_ON);
	VOUT.Set(FV, VHEN3[0], FOVI_10V, FOVI_100MA, RELAY_ON);
	VOUT.Set(FV, VHEN4[0], FOVI_10V, FOVI_100MA, RELAY_ON);
	VOUT.Set(FV, VHEN5[0], FOVI_10V, FOVI_100MA, RELAY_ON);
	delay_ms(1);	

	DIOExpressWriteData(0x21,0x0B);
	delay_ms(1);
	DIOExpressWriteData(0x21,0x09);
	delay_ms(1);

	VOUT.Set(FV, VHEN5[0], FOVI_10V, FOVI_100MA, RELAY_ON);
	VOUT.Set(FV, VHEN4[0], FOVI_10V, FOVI_100MA, RELAY_ON);
	VOUT.Set(FV, VHEN3[0], FOVI_10V, FOVI_100MA, RELAY_ON);
	VOUT.Set(FV, VHEN2[0], FOVI_10V, FOVI_100MA, RELAY_ON);
	VOUT.Set(FV, VHEN1[0], FOVI_10V, FOVI_100MA, RELAY_ON);
	delay_ms(1);	


	DIOExpressWriteData(0x6a,0x00);
	delay_ms(1);


	VOUT.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_ON);	
	VIN.Set(FV, 0.0, FPVI10_5V, FPVI10_100MA, RELAY_ON);
	EN.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_ON);
	//I2CPUP.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_ON);
	delay_ms(1);
	dio.Disconnect();
	delay_ms(1);
	cbit.SetOn(-1);
	delay_ms(1);


	RSNS_burn->SetTestResult(0, 0, EN_OTP48_04_VD[0]);

	}

    return 0;
}


DUT_API int T17_RSNS_Post(short funcindex, LPCTSTR funclabel)
{
    //{{AFX_STS_PARAM_PROTOTYPES
    CParam *RSNS_post = StsGetParam(funcindex,"RSNS_post");
    CParam *RSNS_post_err = StsGetParam(funcindex,"RSNS_post_err");
    //}}AFX_STS_PARAM_PROTOTYPES

    // TODO: Add your function code here
	cbit.SetOn(K1,K2,K3,K4,/*K11,K12,*/K13,-1);//K3 is used for read
	delay_ms(3);
	dio.Connect();
	delay_ms(1);

	MODE.Set(FI, 0.0, FOVI_5V, FOVI_1MA, RELAY_ON);
	//I2CPUP.Set(FV, 1.0, FOVI_5V, FOVI_100MA, RELAY_ON);
	VIN.Set(FV, 3.6, FPVI10_5V, FPVI10_100MA, RELAY_ON);
	EN.Set(FV, 3.6, FOVI_5V, FOVI_100MA, RELAY_ON);
	delay_ms(3);

	DIOExpressWriteData(0x6a,0x5a);
	delay_ms(1);
	DIOExpressWriteData(0x6a,0xa5);
	delay_ms(3);

	EN.Set(FV, -0.0, FOVI_1V, FOVI_100MA, RELAY_ON);
	delay_ms(3);
	EN.Set(FV, -0.0, FOVI_1V, FOVI_100MA, RELAY_OFF);
	delay_ms(3);

	DIOExpressWriteData(0x21,0x40);
	delay_ms(1);

	dio.Disconnect();
	delay_ms(1);

	MODE.Set(FV, 0.0, FOVI_5V, FOVI_1MA, RELAY_ON);
	delay_ms(3);
	MODE.MeasureVI(100, 50);
	delay_ms(3);
	adresult[0] = MODE.GetMeasResult(0, MIRET)*-1e6f;


	VIN.Set(FV, 0.0, FPVI10_5V, FPVI10_100MA, RELAY_ON);
	EN.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_ON);
	//I2CPUP.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_ON);
	delay_ms(3);
	VOUT.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_OFF);
	VIN.Set(FV, 0.0, FPVI10_5V, FPVI10_100MA, RELAY_OFF);
	EN.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_OFF);
	//I2CPUP.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_OFF);
	MODE.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_OFF);
	delay_ms(3);
	cbit.SetOn(-1);
	delay_ms(3);

	RSNS_post->SetTestResult(0, 0, adresult[0]);
	RSNS_post_err->SetTestResult(0, 0, (rsns_target - adresult[0])/(adresult[0]+1e-9f)*100);

    return 0;
}


DUT_API int T18_FOSC_Trim(short funcindex, LPCTSTR funclabel)
{
    //{{AFX_STS_PARAM_PROTOTYPES
    CParam *FOSC_pre = StsGetParam(funcindex,"FOSC_pre");
    CParam *FOSC_pre_err = StsGetParam(funcindex,"FOSC_pre_err");
    CParam *FOSC_code = StsGetParam(funcindex,"FOSC_code");
    CParam *FOSC_sim = StsGetParam(funcindex,"FOSC_sim");
    CParam *FOSC_sim_err = StsGetParam(funcindex,"FOSC_sim_err");
    //}}AFX_STS_PARAM_PROTOTYPES

    // TODO: Add your function code here
	cbit.SetOn(K2,/*K3,*/K4,K6,K13,-1);//K3 is used for read
	delay_ms(3);
	dio.Connect();
	delay_ms(1);

	//I2CPUP.Set(FV, 3.6, FOVI_5V, FOVI_100MA, RELAY_ON);
	VIN.Set(FV, 3.6, FPVI10_5V, FPVI10_100MA, RELAY_ON);
	EN.Set(FV, 3.6, FOVI_5V, FOVI_100MA, RELAY_ON);
	delay_ms(3);

	DIOExpressWriteData(0x6a,0x5a);
	delay_ms(1);
	DIOExpressWriteData(0x6a,0xa5);
	delay_ms(3);

if (AllSimCOde == 1)
{
	DIOExpressWriteData(0x47, vbg_code[0]);	delay_ms(1);
	DIOExpressWriteData(0x40, vref_eaout_code[0]);	delay_ms(1);
	DIOExpressWriteData(0x41, ibias_code[0] /*+ fosc_code[0]*/);	delay_ms(1);
	DIOExpressWriteData(0x48, rsns_code[0]);	delay_ms(1);
	//DIOExpressWriteData(0x42, hscl_code[0] + vcl_code[0]);	delay_ms(1);
	//DIOExpressWriteData(0x43,ton_code[0]);	delay_ms(1);
}


//	DIOExpressWriteData(0x23,0x90);
//	delay_ms(3);
//	DIOExpressReadData(0x29);
//	delay_ms(1);

	EN.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_ON);
	delay_ms(3);
	EN.Set(FI, 0.0, FOVI_5V, FOVI_100UA, RELAY_ON);
	delay_ms(3);
	EN.Set(FI, 0.0, FOVI_5V, FOVI_100UA, RELAY_OFF);
	delay_ms(3);

	cbit.SetCBITOff(K4);
	delay_ms(3);

	DIOExpressWriteData(0x44,0x40);
	delay_ms(1);
	DIOExpressWriteData(0x24,0x04);
	delay_ms(1);
	DIOExpressWriteData(0x23,0xEB);
	delay_ms(1);


	qtmu0.SetStartInput(QTMU_PLUS_IMPEDANCE_1M, QTMU_PLUS_VRNG_5V, QTMU_PLUS_FILTER_10MHz);
	qtmu0.SetStopInput(QTMU_PLUS_IMPEDANCE_1M, QTMU_PLUS_VRNG_5V, QTMU_PLUS_FILTER_10MHz);
	qtmu0.SetStartTrigger(1.2, QTMU_PLUS_POS_SLOPE);
	qtmu0.SetStopTrigger(1, QTMU_PLUS_POS_SLOPE);
	qtmu0.SetInSource(QTMU_PLUS_SINGLE_SOURCE);
	qtmu0.Connect();

	qtmu0.MeasFreq(QTMU_PLUS_COARSE, QTMU_PLUS_TRNG_US, 20, 5); //timeout=2ms

	adresult[0] = qtmu0.GetMeasureResult(0);
	fosc_pre_err[0] = (fosc_target - adresult[0]) / (adresult[0] + 1e-20f) * 100;



	DIOExpressWriteData(0x21,0x00);
	delay_ms(1);
	dio.Disconnect();
	qtmu0.Disconnect();
	delay_ms(1);

	VIN.Set(FV, 0.0, FPVI10_5V, FPVI10_100MA, RELAY_ON);
	EN.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_ON);
	//I2CPUP.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_ON);
	delay_ms(3);
	cbit.SetOn(-1);
	delay_ms(3);

	FOSC_pre->SetTestResult(0, 0, adresult[0]);
	FOSC_pre_err->SetTestResult(0, 0, fosc_pre_err[0]);


		if (fosc_pre_err[0] >= -70.0 && fosc_pre_err[0]<100.0)
		{
			if (fosc_pre_err[0] >= -6.77 && fosc_pre_err[0]< -2.34)		{ fosc_code[0] = 240; }//
			if (fosc_pre_err[0] >= -10.76 && fosc_pre_err[0]< -6.77)	{ fosc_code[0] = 224; }//
			if (fosc_pre_err[0] >= -14.47 && fosc_pre_err[0]< -10.76)	{ fosc_code[0] = 208; }//
			if (fosc_pre_err[0] >= -17.85 && fosc_pre_err[0]< -14.47)	{ fosc_code[0] = 192; }//
			if (fosc_pre_err[0] >= -20.93 && fosc_pre_err[0]< -17.85)	{ fosc_code[0] = 176; }//
			if (fosc_pre_err[0] >= -23.83 && fosc_pre_err[0]< -20.93)	{ fosc_code[0] = 160; }//
			if (fosc_pre_err[0] >= -26.55 && fosc_pre_err[0]< -23.83)	{ fosc_code[0] = 144; }//
			if (fosc_pre_err[0] >= -70.0 && fosc_pre_err[0]< -26.55)	{ fosc_code[0] = 128; }//

			if (fosc_pre_err[0] >= 45.94 && fosc_pre_err[0]< 100)		{ fosc_code[0] = 112; }//
			if (fosc_pre_err[0] >= 36.23 && fosc_pre_err[0]< 45.94)		{ fosc_code[0] = 96; }//
			if (fosc_pre_err[0] >= 27.76 && fosc_pre_err[0]< 36.23)		{ fosc_code[0] = 80; }//
			if (fosc_pre_err[0] >= 20.37 && fosc_pre_err[0]< 27.76)		{ fosc_code[0] = 64; }//
			if (fosc_pre_err[0] >= 13.76 && fosc_pre_err[0]< 20.37)		{ fosc_code[0] = 48; }//
			if (fosc_pre_err[0] >= 7.80 && fosc_pre_err[0]< 13.76)		{ fosc_code[0] = 32; }//
			if (fosc_pre_err[0] >= 2.49 && fosc_pre_err[0]< 7.80)		{ fosc_code[0] = 16; }//
			if (fosc_pre_err[0] >= -2.34 && fosc_pre_err[0]< 2.49)		{ fosc_code[0] = 0; }//


		}
		else
			fosc_code[0] = 0; //


		/******************* already trimmed dies -> set to reading of OTP ******************/
		if ((EN_OTP41_47_VD[0] == 0))
		{
			fosc_code[0] = OTP41_47_VD[0];
		}


	FOSC_code->SetTestResult(0, 0, fosc_code[0]);

	cbit.SetOn(K2,/*K3,*/K4,K6,K13,-1);//K3 is used for read
	delay_ms(3);
	dio.Connect();
	delay_ms(1);

	//I2CPUP.Set(FV, 3.6, FOVI_5V, FOVI_100MA, RELAY_ON);
	VIN.Set(FV, 3.6, FPVI10_5V, FPVI10_100MA, RELAY_ON);
	EN.Set(FV, 3.6, FOVI_5V, FOVI_100MA, RELAY_ON);
	delay_ms(3);

	DIOExpressWriteData(0x6a,0x5a);
	delay_ms(1);
	DIOExpressWriteData(0x6a,0xa5);
	delay_ms(3);

if (AllSimCOde == 1)
{
	DIOExpressWriteData(0x47, vbg_code[0]);	delay_ms(1);
	DIOExpressWriteData(0x40, vref_eaout_code[0]);	delay_ms(1);
	//DIOExpressWriteData(0x41, ibias_code[0] /*+ fosc_code[0]*/);	delay_ms(1);
	DIOExpressWriteData(0x48, rsns_code[0]);	delay_ms(1);
	//DIOExpressWriteData(0x42, hscl_code[0] + vcl_code[0]);	delay_ms(1);
	//DIOExpressWriteData(0x43,ton_code[0]);	delay_ms(1);
}


//	DIOExpressWriteData(0x23,0x90);
//	delay_ms(3);
//	DIOExpressReadData(0x29);
//	delay_ms(1);

	EN.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_ON);
	delay_ms(3);
	EN.Set(FI, 0.0, FOVI_5V, FOVI_100UA, RELAY_ON);
	delay_ms(3);
	EN.Set(FI, 0.0, FOVI_5V, FOVI_100UA, RELAY_OFF);
	delay_ms(3);

	cbit.SetCBITOff(K4);
	delay_ms(3);

	qtmu0.SetStartInput(QTMU_PLUS_IMPEDANCE_1M, QTMU_PLUS_VRNG_5V, QTMU_PLUS_FILTER_10MHz);
	qtmu0.SetStopInput(QTMU_PLUS_IMPEDANCE_1M, QTMU_PLUS_VRNG_5V, QTMU_PLUS_FILTER_10MHz);
	qtmu0.SetStartTrigger(1.2, QTMU_PLUS_POS_SLOPE);
	qtmu0.SetStopTrigger(1, QTMU_PLUS_POS_SLOPE);
	qtmu0.SetInSource(QTMU_PLUS_SINGLE_SOURCE);
	qtmu0.Connect();


	DIOExpressWriteData(0x44,0x40);
	delay_ms(1);
	DIOExpressWriteData(0x24,0x04);
	delay_ms(1);
	DIOExpressWriteData(0x23,0xEB);
	delay_ms(1);

	DIOExpressWriteData(0x41,ibias_code[0] + fosc_code[0]);
	delay_ms(1);	
	qtmu0.MeasFreq(QTMU_PLUS_COARSE, QTMU_PLUS_TRNG_US, 20, 5); //timeout=2ms
	delay_ms(1);
	adresult[0] = qtmu0.GetMeasureResult(0);

#if 0
	int code[16]={0,16,32,48,64,80,96,112,128,144,160,176,192,208,224,240};
		
	double tempp[64]={0.0};

	for(i=0;i<16;i++)
	{
	DIOExpressWriteData(0x41,code[i]);
	delay_ms(1);
	qtmu0.MeasFreq(QTMU_PLUS_COARSE, QTMU_PLUS_TRNG_US, 20, 5); //timeout=2ms
	delay_ms(3);
	tempp[i] = qtmu0.GetMeasureResult(0);
	}
#endif



	DIOExpressWriteData(0x21,0x00);
	delay_ms(1);
	dio.Disconnect();
	qtmu0.Disconnect();
	delay_ms(1);

	VIN.Set(FV, 0.0, FPVI10_5V, FPVI10_100MA, RELAY_ON);
	EN.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_ON);
	//I2CPUP.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_ON);
	delay_ms(3);
	VIN.Set(FV, 0.0, FPVI10_5V, FPVI10_100MA, RELAY_OFF);
	EN.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_OFF);
	//I2CPUP.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_OFF);
	delay_ms(3);
	cbit.SetOn(-1);
	delay_ms(3);

	FOSC_sim->SetTestResult(0, 0, adresult[0]);
	FOSC_sim_err->SetTestResult(0, 0, (fosc_target - adresult[0])/(adresult[0]+1e-9f)*100);


    return 0;
}


DUT_API int T19_FOSC_BURN(short funcindex, LPCTSTR funclabel)
{
    //{{AFX_STS_PARAM_PROTOTYPES
    CParam *FOSC_burn = StsGetParam(funcindex,"FOSC_burn");
    //}}AFX_STS_PARAM_PROTOTYPES

    // TODO: Add your function code here
	if (en_trim == 1)
	{
	//EN_OTP41_47_VD[0]=1;

	cbit.SetOn(K2,/*K3,*/K4,K11,K12,K13,-1);
	delay_ms(3);

	//I2CPUP.Set(FV, 3.6, FOVI_5V, FOVI_100MA, RELAY_ON);
	VIN.Set(FV, 3.6, FPVI10_5V, FPVI10_100MA, RELAY_ON);
	EN.Set(FV, 3.6, FOVI_5V, FOVI_100MA, RELAY_ON);
	delay_ms(3);
	dio.Connect();
	delay_ms(3);
	DIOExpressWriteData(0x6a,0x5a);
	delay_ms(1);
	DIOExpressWriteData(0x6a,0xa5);
	delay_ms(1);

	DIOExpressWriteData(0x41,fosc_code[0]);
	delay_ms(1);
	DIOExpressWriteData(0x20,0x01);
	delay_ms(1);
	DIOExpressWriteData(0x21,0x09);
	delay_ms(1);

	VOUT.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_ON);
	delay_ms(3);	

	VHEN1[0] = EN_OTP41_47_VD[0] * 1.0 * 5;
	VHEN2[0] = EN_OTP41_47_VD[0] * 1.1 * 5;
	VHEN3[0] = EN_OTP41_47_VD[0] * 1.2 * 5;
	VHEN4[0] = EN_OTP41_47_VD[0] * 1.3 * 5;
	VHEN5[0] = EN_OTP41_47_VD[0] * 1.4 * 5;

	VOUT.Set(FV, VHEN1[0], FOVI_10V, FOVI_100MA, RELAY_ON);
	VOUT.Set(FV, VHEN2[0], FOVI_10V, FOVI_100MA, RELAY_ON);
	VOUT.Set(FV, VHEN3[0], FOVI_10V, FOVI_100MA, RELAY_ON);
	VOUT.Set(FV, VHEN4[0], FOVI_10V, FOVI_100MA, RELAY_ON);
	VOUT.Set(FV, VHEN5[0], FOVI_10V, FOVI_100MA, RELAY_ON);
	delay_ms(1);	

	DIOExpressWriteData(0x21,0x0B);
	delay_ms(1);
	DIOExpressWriteData(0x21,0x09);
	delay_ms(1);

	VOUT.Set(FV, VHEN5[0], FOVI_10V, FOVI_100MA, RELAY_ON);
	VOUT.Set(FV, VHEN4[0], FOVI_10V, FOVI_100MA, RELAY_ON);
	VOUT.Set(FV, VHEN3[0], FOVI_10V, FOVI_100MA, RELAY_ON);
	VOUT.Set(FV, VHEN2[0], FOVI_10V, FOVI_100MA, RELAY_ON);
	VOUT.Set(FV, VHEN1[0], FOVI_10V, FOVI_100MA, RELAY_ON);
	delay_ms(1);	


	DIOExpressWriteData(0x6a,0x00);
	delay_ms(1);


	VOUT.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_ON);	
	VIN.Set(FV, 0.0, FPVI10_5V, FPVI10_100MA, RELAY_ON);
	EN.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_ON);
	//I2CPUP.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_ON);
	delay_ms(1);
	dio.Disconnect();
	delay_ms(1);
	cbit.SetOn(-1);
	delay_ms(1);


	FOSC_burn->SetTestResult(0, 0, EN_OTP41_47_VD[0]);

	}

    return 0;
}


DUT_API int T20_FOSC_Post(short funcindex, LPCTSTR funclabel)
{
    //{{AFX_STS_PARAM_PROTOTYPES
    CParam *FOSC_post = StsGetParam(funcindex,"FOSC_post");
    CParam *FOSC_post_err = StsGetParam(funcindex,"FOSC_post_err");
    //}}AFX_STS_PARAM_PROTOTYPES

    // TODO: Add your function code here
	cbit.SetOn(K2,/*K3,*/K4,K6,K13,-1);//K3 is used for read
	delay_ms(3);
	dio.Connect();
	delay_ms(1);

	//I2CPUP.Set(FV, 3.6, FOVI_5V, FOVI_100MA, RELAY_ON);
	VIN.Set(FV, 3.6, FPVI10_5V, FPVI10_100MA, RELAY_ON);
	EN.Set(FV, 3.6, FOVI_5V, FOVI_100MA, RELAY_ON);
	delay_ms(3);

	DIOExpressWriteData(0x6a,0x5a);
	delay_ms(1);
	DIOExpressWriteData(0x6a,0xa5);
	delay_ms(3);

//	DIOExpressWriteData(0x23,0x90);
//	delay_ms(3);
//	DIOExpressReadData(0x29);
//	delay_ms(1);

	EN.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_ON);
	delay_ms(3);
	EN.Set(FI, 0.0, FOVI_5V, FOVI_100UA, RELAY_ON);
	delay_ms(3);
	EN.Set(FI, 0.0, FOVI_5V, FOVI_100UA, RELAY_OFF);
	delay_ms(3);

	cbit.SetCBITOff(K4);
	delay_ms(3);

	DIOExpressWriteData(0x44,0x40);
	delay_ms(1);
	DIOExpressWriteData(0x24,0x04);
	delay_ms(1);
	DIOExpressWriteData(0x23,0xEB);
	delay_ms(1);


	qtmu0.SetStartInput(QTMU_PLUS_IMPEDANCE_1M, QTMU_PLUS_VRNG_5V, QTMU_PLUS_FILTER_10MHz);
	qtmu0.SetStopInput(QTMU_PLUS_IMPEDANCE_1M, QTMU_PLUS_VRNG_5V, QTMU_PLUS_FILTER_10MHz);
	qtmu0.SetStartTrigger(1.2, QTMU_PLUS_POS_SLOPE);
	qtmu0.SetStopTrigger(1, QTMU_PLUS_POS_SLOPE);
	qtmu0.SetInSource(QTMU_PLUS_SINGLE_SOURCE);
	qtmu0.Connect();

	qtmu0.MeasFreq(QTMU_PLUS_COARSE, QTMU_PLUS_TRNG_US, 20, 5); //timeout=2ms

	adresult[0] = qtmu0.GetMeasureResult(0);

	DIOExpressWriteData(0x21,0x00);
	delay_ms(1);
	dio.Disconnect();
	qtmu0.Disconnect();
	delay_ms(1);

	VIN.Set(FV, 0.0, FPVI10_5V, FPVI10_100MA, RELAY_ON);
	EN.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_ON);
	//I2CPUP.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_ON);
	delay_ms(3);
	VIN.Set(FV, 0.0, FPVI10_5V, FPVI10_100MA, RELAY_OFF);
	EN.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_OFF);
	//I2CPUP.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_OFF);
	delay_ms(3);
	cbit.SetOn(-1);
	delay_ms(3);

	FOSC_post->SetTestResult(0, 0, adresult[0]);
	FOSC_post_err->SetTestResult(0, 0, (fosc_target - adresult[0])/(adresult[0]+1e-9f)*100);

    return 0;
}


DUT_API int T21_HSCL_Trim(short funcindex, LPCTSTR funclabel)
{
    //{{AFX_STS_PARAM_PROTOTYPES
    CParam *HSCL_pre = StsGetParam(funcindex,"HSCL_pre");
    CParam *HSCL_pre_err = StsGetParam(funcindex,"HSCL_pre_err");
    CParam *HSCL_code = StsGetParam(funcindex,"HSCL_code");
    CParam *HSCL_sim = StsGetParam(funcindex,"HSCL_sim");
    CParam *HSCL_sim_err = StsGetParam(funcindex,"HSCL_sim_err");
    //}}AFX_STS_PARAM_PROTOTYPES

    // TODO: Add your function code here

	cbit.SetOn(K2,/*K3,*/K4,K8,K13,-1);//K3 is used for read
	delay_ms(3);
	dio.Connect();
	delay_ms(1);

	//I2CPUP.Set(FV, 3.6, FOVI_5V, FOVI_100MA, RELAY_ON);
	VIN.Set(FV, 3.6, FPVI10_5V, FPVI10_10A, RELAY_ON);
	EN.Set(FV, 3.6, FOVI_5V, FOVI_100MA, RELAY_ON);
	delay_ms(3);

	DIOExpressWriteData(0x6a,0x5a);
	delay_ms(1);
	DIOExpressWriteData(0x6a,0xa5);
	delay_ms(3);

if (AllSimCOde == 1)
{
	DIOExpressWriteData(0x47, vbg_code[0]);	delay_ms(1);
	DIOExpressWriteData(0x40, vref_eaout_code[0]);	delay_ms(1);
	DIOExpressWriteData(0x41, ibias_code[0] + fosc_code[0]);	delay_ms(1);
	DIOExpressWriteData(0x48, rsns_code[0]);	delay_ms(1);
	//DIOExpressWriteData(0x42, hscl_code[0] + vcl_code[0]);	delay_ms(1);
	//DIOExpressWriteData(0x43,ton_code[0]);	delay_ms(1);
}


//	DIOExpressWriteData(0x23,0x90);
//	delay_ms(3);
//	DIOExpressReadData(0x29);
//	delay_ms(1);

	EN.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_ON);
	delay_ms(3);
	EN.Set(FI, 0.0, FOVI_5V, FOVI_100UA, RELAY_ON);
	delay_ms(3);

	DIOExpressWriteData(0x25,0x32);
	delay_ms(1);
	DIOExpressWriteData(0x26,0xE0);
	delay_ms(1);
	DIOExpressWriteData(0x23,0x4C);
	delay_ms(1);

	double Trig = 1;//trigger level
	double Trig_Point[2] = { 0 };
	double result[2] = { 0 };
	int sam = 89; //awgSize
	int interval = 200; //awgInterval��unit=us
	double hscl_Data[100] = { 0.0 };
	int i = 0;
	int	m = 0;

	double hscl_pre[2] = { 0 };
	double hscl_pre_err[2] = { 0 };
	LX.Set(FI, -0.45, FPVI10_5V, FPVI10_10A, RELAY_ON);

	STSAWGCreateRampData(&hscl_Data[0], sam, 1, -0.59, -1.47);
	LX.AwgLoader("hscl", FI, FPVI10_5V, FPVI10_10A, hscl_Data, sam);
	LX.AwgSelect("hscl", 0, sam - 1, 0, interval);

	EN.SetMeasVTrig(Trig, TRIG_RISING);
	EN.MeasureVI(sam, interval, MEAS_AWG);
	LX.MeasureVI(sam, interval, MEAS_AWG);

	STSEnableAWG(&LX);
	STSEnableMeas(&EN, &LX);
	STSAWGRunTriggerStop(&EN, &EN, &LX);

	//	StsAWGRun();


		Trig_Point[0] = EN.GetMeasResult(0, MVRET, TRIG_RESULT);
		m = Trig_Point[0] - 1;
		if (m<2)
		{
			hscl_pre[0] = -777;
		}
		else if (m>sam - 3)
		{
			hscl_pre[0] = -999;

		}
		else
		{
			hscl_pre[0] = 1e3f*hscl_Data[m] ;//FPVIO+FPVI1

		}

		hscl_pre_err[0] = (hscl_pre[0] + hscl_target) / (-hscl_pre[0] + 1e-20f) * 100;

		HSCL_pre->SetTestResult(0, 0, -hscl_pre[0]);
		HSCL_pre_err->SetTestResult(0, 0, hscl_pre_err[0]);


	DIOExpressWriteData(0x21,0x00);
	delay_ms(1);
	dio.Disconnect();
	delay_ms(1);


	LX.Set(FI, 0.0, FPVI10_5V, FPVI10_10A, RELAY_ON);
	delay_ms(3);
	VIN.Set(FV, 0.0, FPVI10_5V, FPVI10_10A, RELAY_ON);
	EN.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_ON);
	//I2CPUP.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_ON);
	delay_ms(3);
	cbit.SetOn(-1);
	delay_ms(3);

	if (hscl_pre_err[0] >= -70.0 && hscl_pre_err[0]<70.0)
		{
			if (hscl_pre_err[0] >= -5.34 && hscl_pre_err[0]< -1.46)		{ hscl_code[0] = 240; }//
			if (hscl_pre_err[0] >= -9.22 && hscl_pre_err[0]< -5.34)		{ hscl_code[0] = 224; }//
			if (hscl_pre_err[0] >= -13.11 && hscl_pre_err[0]< -9.22)	{ hscl_code[0] = 208; }//
			if (hscl_pre_err[0] >= -16.99 && hscl_pre_err[0]< -13.11)	{ hscl_code[0] = 192; }//
			if (hscl_pre_err[0] >= -20.87 && hscl_pre_err[0]< -16.99)	{ hscl_code[0] = 176; }//
			if (hscl_pre_err[0] >= -25.24 && hscl_pre_err[0]< -20.87)	{ hscl_code[0] = 160; }//
			if (hscl_pre_err[0] >= -29.13 && hscl_pre_err[0]< -25.24)	{ hscl_code[0] = 144; }//
			if (hscl_pre_err[0] >= -70.0 && hscl_pre_err[0]< -29.13)	{ hscl_code[0] = 128; }//

			if (hscl_pre_err[0] >= 25.24 && hscl_pre_err[0]< 70.0)		{ hscl_code[0] = 112; }//
			if (hscl_pre_err[0] >= 21.36 && hscl_pre_err[0]< 25.24)		{ hscl_code[0] = 96; }//
			if (hscl_pre_err[0] >= 17.48 && hscl_pre_err[0]< 21.36)		{ hscl_code[0] = 80; }//
			if (hscl_pre_err[0] >= 13.59 && hscl_pre_err[0]< 17.48)		{ hscl_code[0] = 64; }//
			if (hscl_pre_err[0] >= 9.71 && hscl_pre_err[0]< 13.59)		{ hscl_code[0] = 48; }//
			if (hscl_pre_err[0] >= 5.83 && hscl_pre_err[0]< 9.71)		{ hscl_code[0] = 32; }//
			if (hscl_pre_err[0] >= 1.94 && hscl_pre_err[0]< 5.83)		{ hscl_code[0] = 16; }//
			if (hscl_pre_err[0] >= -1.46 && hscl_pre_err[0]< 1.94)		{ hscl_code[0] = 0; }//

		}
		else
			hscl_code[0] = 0; //


		/******************* already trimmed dies -> set to reading of OTP ******************/
		if ((EN_OTP42_47_VD[0] == 0))
		{
			hscl_code[0] = OTP42_47_VD[0];
		}


	HSCL_code->SetTestResult(0, 0, hscl_code[0]);

	cbit.SetOn(K2,/*K3,*/K4,K8,K13,-1);//K3 is used for read
	delay_ms(3);
	dio.Connect();
	delay_ms(1);

#if 1

	//I2CPUP.Set(FV, 3.6, FOVI_5V, FOVI_100MA, RELAY_ON);
	VIN.Set(FV, 3.6, FPVI10_5V, FPVI10_10A, RELAY_ON);
	EN.Set(FV, 3.6, FOVI_5V, FOVI_100MA, RELAY_ON);
	delay_ms(3);

	DIOExpressWriteData(0x6a,0x5a);
	delay_ms(1);
	DIOExpressWriteData(0x6a,0xa5);
	delay_ms(3);

if (AllSimCOde == 1)
{
	DIOExpressWriteData(0x47, vbg_code[0]);	delay_ms(1);
	DIOExpressWriteData(0x40, vref_eaout_code[0]);	delay_ms(1);
	DIOExpressWriteData(0x41, ibias_code[0] + fosc_code[0]);	delay_ms(1);
	DIOExpressWriteData(0x48, rsns_code[0]);	delay_ms(1);
	//DIOExpressWriteData(0x42, hscl_code[0] + vcl_code[0]);	delay_ms(1);
	//DIOExpressWriteData(0x43,ton_code[0]);	delay_ms(1);
}


//	DIOExpressWriteData(0x23,0x90);
//	delay_ms(3);
//	DIOExpressReadData(0x29);
//	delay_ms(1);

	EN.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_ON);
	delay_ms(3);
	EN.Set(FI, 0.0, FOVI_5V, FOVI_100UA, RELAY_ON);
	delay_ms(3);

	DIOExpressWriteData(0x25,0x32);
	delay_ms(1);
	DIOExpressWriteData(0x26,0xE0);
	delay_ms(1);
	DIOExpressWriteData(0x23,0x4C);
	delay_ms(1);
#endif

	Trig = 1;//trigger level
	sam = 89; //awgSize
	interval = 200; //awgInterval��unit=us
	double hscl_sim_Data[100] = { 0.0 };
	i = 0;
	m = 0;
	double hscl_sim[2] = { 0 };
	double hscl_sim_err[2] = { 0 };

#if 1

	DIOExpressWriteData(0x42,hscl_code[0]);
	delay_ms(1);

	for(i=0;i<2;i++)
	{
	Trig_Point[i]=0;
	result[i]=0;
	}

	LX.Set(FI, -0.45, FPVI10_5V, FPVI10_10A, RELAY_ON);

	STSAWGCreateRampData(&hscl_sim_Data[0], sam, 1, -0.59, -1.47);
	LX.AwgLoader("hscl", FI, FPVI10_5V, FPVI10_10A, hscl_sim_Data, sam);
	LX.AwgSelect("hscl", 0, sam - 1, 0, interval);

	EN.SetMeasVTrig(Trig, TRIG_RISING);
	EN.MeasureVI(sam, interval, MEAS_AWG);
	LX.MeasureVI(sam, interval, MEAS_AWG);

	STSEnableAWG(&LX);
	STSEnableMeas(&EN, &LX);
	STSAWGRunTriggerStop(&EN, &EN, &LX);

	//	StsAWGRun();

		Trig_Point[0] = EN.GetMeasResult(0, MVRET, TRIG_RESULT);
		m = Trig_Point[0] - 1;
		if (m<2)
		{
			hscl_sim[0] = -777;
		}
		else if (m>sam - 3)
		{
			hscl_sim[0] = -999;

		}
		else
		{
			hscl_sim[0] = 1e3f*hscl_sim_Data[m] ;//FPVIO+FPVI1

		}

	LX.Set(FI, 0.0, FPVI10_5V, FPVI10_10A, RELAY_ON);
	delay_ms(3);

#endif

#if 0
	int code[16]={0,16,32,48,64,80,96,112,128,144,160,176,192,208,224,240};
		
	double tempp[64]={0.0};

	for(i=0;i<2;i++)
	{
	Trig_Point[i]=0;
	result[i]=0;
	}
	dio.Connect();
	delay_ms(1);


	STSAWGCreateRampData(&hscl_sim_Data[0], sam, 1, -0.59, -1.47);
	LX.AwgLoader("hscl", FI, FPVI10_5V, FPVI10_10A, hscl_sim_Data, sam);
	LX.AwgSelect("hscl", 0, sam - 1, 0, interval);

	for(i=0;i<16;i++)
	{

	DIOExpressWriteData(0x42,code[i]);
	delay_ms(1);

	LX.Set(FI, -0.45, FPVI10_5V, FPVI10_10A, RELAY_ON);

	EN.SetMeasVTrig(Trig, TRIG_RISING);
	EN.MeasureVI(sam, interval, MEAS_AWG);
	LX.MeasureVI(sam, interval, MEAS_AWG);

	STSEnableAWG(&LX);
	STSEnableMeas(&EN, &LX);
	STSAWGRunTriggerStop(&EN, &EN, &LX);

		Trig_Point[0] = EN.GetMeasResult(0, MVRET, TRIG_RESULT);
		m = Trig_Point[0] - 1;
		if (m<2)
		{
			hscl_sim[0] = -777;
		}
		else if (m>sam - 3)
		{
			hscl_sim[0] = -999;

		}
		else
		{
			tempp[i] = 1e3f*hscl_sim_Data[m] ;//FPVIO+FPVI1

		}

	LX.Set(FI, -0.0, FPVI10_5V, FPVI10_10A, RELAY_ON);
	delay_ms(3);
	}
#endif


	DIOExpressWriteData(0x21,0x00);
	delay_ms(1);
	dio.Disconnect();
	delay_ms(1);

	VIN.Set(FV, 0.0, FPVI10_5V, FPVI10_10A, RELAY_ON);
	EN.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_ON);
	//I2CPUP.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_ON);
	LX.Set(FV, 0.0, FPVI10_5V, FPVI10_10A, RELAY_ON);
	delay_ms(3);


	VIN.Set(FV, 0.0, FPVI10_5V, FPVI10_10A, RELAY_OFF);
	EN.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_OFF);
	//I2CPUP.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_OFF);
	LX.Set(FV, 0.0, FPVI10_5V, FPVI10_10A, RELAY_OFF);
	delay_ms(3);
	cbit.SetOn(-1);
	delay_ms(3);

	hscl_sim_err[0] = (hscl_sim[0] + hscl_target) / (-hscl_sim[0] + 1e-20f) * 100;

	HSCL_sim->SetTestResult(0, 0, -hscl_sim[0]);
	HSCL_sim_err->SetTestResult(0, 0, hscl_sim_err[0]);

    return 0;
}


DUT_API int T22_HSCL_BURN(short funcindex, LPCTSTR funclabel)
{
    //{{AFX_STS_PARAM_PROTOTYPES
    CParam *HSCL_burn = StsGetParam(funcindex,"HSCL_burn");
    //}}AFX_STS_PARAM_PROTOTYPES

    // TODO: Add your function code here
	if (en_trim == 1)
	{
	//EN_OTP42_47_VD[0]=1;

	cbit.SetOn(K2,/*K3,*/K4,K11,K12,K13,-1);
	delay_ms(3);

	//I2CPUP.Set(FV, 3.6, FOVI_5V, FOVI_100MA, RELAY_ON);
	VIN.Set(FV, 3.6, FPVI10_5V, FPVI10_100MA, RELAY_ON);
	EN.Set(FV, 3.6, FOVI_5V, FOVI_100MA, RELAY_ON);
	delay_ms(3);
	dio.Connect();
	delay_ms(3);
	DIOExpressWriteData(0x6a,0x5a);
	delay_ms(1);
	DIOExpressWriteData(0x6a,0xa5);
	delay_ms(1);

	DIOExpressWriteData(0x42,hscl_code[0]);
	delay_ms(1);
	DIOExpressWriteData(0x20,0x02);
	delay_ms(1);
	DIOExpressWriteData(0x21,0x09);
	delay_ms(1);

	VOUT.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_ON);
	delay_ms(3);	

	VHEN1[0] = EN_OTP42_47_VD[0] * 1.0 * 5;
	VHEN2[0] = EN_OTP42_47_VD[0] * 1.1 * 5;
	VHEN3[0] = EN_OTP42_47_VD[0] * 1.2 * 5;
	VHEN4[0] = EN_OTP42_47_VD[0] * 1.3 * 5;
	VHEN5[0] = EN_OTP42_47_VD[0] * 1.4 * 5;

	VOUT.Set(FV, VHEN1[0], FOVI_10V, FOVI_100MA, RELAY_ON);
	VOUT.Set(FV, VHEN2[0], FOVI_10V, FOVI_100MA, RELAY_ON);
	VOUT.Set(FV, VHEN3[0], FOVI_10V, FOVI_100MA, RELAY_ON);
	VOUT.Set(FV, VHEN4[0], FOVI_10V, FOVI_100MA, RELAY_ON);
	VOUT.Set(FV, VHEN5[0], FOVI_10V, FOVI_100MA, RELAY_ON);
	delay_ms(1);	

	DIOExpressWriteData(0x21,0x0B);
	delay_ms(1);
	DIOExpressWriteData(0x21,0x09);
	delay_ms(1);

	VOUT.Set(FV, VHEN5[0], FOVI_10V, FOVI_100MA, RELAY_ON);
	VOUT.Set(FV, VHEN4[0], FOVI_10V, FOVI_100MA, RELAY_ON);
	VOUT.Set(FV, VHEN3[0], FOVI_10V, FOVI_100MA, RELAY_ON);
	VOUT.Set(FV, VHEN2[0], FOVI_10V, FOVI_100MA, RELAY_ON);
	VOUT.Set(FV, VHEN1[0], FOVI_10V, FOVI_100MA, RELAY_ON);
	delay_ms(1);	


	DIOExpressWriteData(0x6a,0x00);
	delay_ms(1);


	VOUT.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_ON);	
	VIN.Set(FV, 0.0, FPVI10_5V, FPVI10_100MA, RELAY_ON);
	EN.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_ON);
	//I2CPUP.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_ON);
	delay_ms(1);
	dio.Disconnect();
	delay_ms(1);
	cbit.SetOn(-1);
	delay_ms(1);

	HSCL_burn->SetTestResult(0, 0, EN_OTP42_47_VD[0]);

	}

    return 0;
}


DUT_API int T23_HSCL_Post(short funcindex, LPCTSTR funclabel)
{
    //{{AFX_STS_PARAM_PROTOTYPES
    CParam *HSCL_post = StsGetParam(funcindex,"HSCL_post");
    CParam *HSCL_post_err = StsGetParam(funcindex,"HSCL_post_err");
    //}}AFX_STS_PARAM_PROTOTYPES

    // TODO: Add your function code here
	cbit.SetOn(K2,/*K3,*/K4,K8,K13,-1);//K3 is used for read
	delay_ms(3);
	dio.Connect();
	delay_ms(1);

	//I2CPUP.Set(FV, 3.6, FOVI_5V, FOVI_100MA, RELAY_ON);
	VIN.Set(FV, 3.6, FPVI10_5V, FPVI10_10A, RELAY_ON);
	EN.Set(FV, 3.6, FOVI_5V, FOVI_100MA, RELAY_ON);
	delay_ms(3);

	DIOExpressWriteData(0x6a,0x5a);
	delay_ms(1);
	DIOExpressWriteData(0x6a,0xa5);
	delay_ms(3);

//	DIOExpressWriteData(0x23,0x90);
//	delay_ms(3);
//	DIOExpressReadData(0x29);
//	delay_ms(1);

	EN.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_ON);
	delay_ms(3);
	EN.Set(FI, 0.0, FOVI_5V, FOVI_100UA, RELAY_ON);
	delay_ms(3);

	DIOExpressWriteData(0x25,0x32);
	delay_ms(1);
	DIOExpressWriteData(0x26,0xE0);
	delay_ms(1);
	DIOExpressWriteData(0x23,0x4C);
	delay_ms(1);


	double Trig = 1;//trigger level
	double Trig_Point[2] = { 0 };
	double result[2] = { 0 };
	int sam = 89; //awgSize
	int interval = 200; //awgInterval��unit=us
	double hscl_Data[100] = { 0.0 };
	int i = 0;
	int	m = 0;

	double hscl_post[2] = { 0 };
	double hscl_post_err[2] = { 0 };
	LX.Set(FI, -0.45, FPVI10_5V, FPVI10_10A, RELAY_ON);

	STSAWGCreateRampData(&hscl_Data[0], sam, 1, -0.59, -1.47);
	LX.AwgLoader("hscl", FI, FPVI10_5V, FPVI10_10A, hscl_Data, sam);
	LX.AwgSelect("hscl", 0, sam - 1, 0, interval);

	EN.SetMeasVTrig(Trig, TRIG_RISING);
	EN.MeasureVI(sam, interval, MEAS_AWG);
	LX.MeasureVI(sam, interval, MEAS_AWG);

	STSEnableAWG(&LX);
	STSEnableMeas(&EN, &LX);
	STSAWGRunTriggerStop(&EN, &EN, &LX);

	//	StsAWGRun();

		Trig_Point[0] = EN.GetMeasResult(0, MVRET, TRIG_RESULT);
		m = Trig_Point[0] - 1;
		if (m<2)
		{
			hscl_post[0] = -777;
		}
		else if (m>sam - 3)
		{
			hscl_post[0] = -999;

		}
		else
		{
			hscl_post[0] = 1e3f*hscl_Data[m] ;//FPVIO+FPVI1

		}

		hscl_post_err[0] = (hscl_post[0] + hscl_target) / (-hscl_post[0] + 1e-20f) * 100;

		HSCL_post->SetTestResult(0, 0, -hscl_post[0]);
		HSCL_post_err->SetTestResult(0, 0, hscl_post_err[0]);


	DIOExpressWriteData(0x21,0x00);
	delay_ms(1);
	dio.Disconnect();
	delay_ms(1);
	LX.Set(FI, 0.0, FPVI10_5V, FPVI10_10A, RELAY_ON);
	delay_ms(3);
	VIN.Set(FV, 0.0, FPVI10_5V, FPVI10_10A, RELAY_ON);
	EN.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_ON);
	//I2CPUP.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_ON);
	LX.Set(FV, 0.0, FPVI10_5V, FPVI10_10A, RELAY_ON);
	delay_ms(3);
	VIN.Set(FV, 0.0, FPVI10_5V, FPVI10_10A, RELAY_OFF);
	EN.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_OFF);
	//I2CPUP.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_OFF);
	LX.Set(FV, 0.0, FPVI10_5V, FPVI10_10A, RELAY_OFF);
	delay_ms(3);
	cbit.SetOn(-1);
	delay_ms(3);

    return 0;
}


DUT_API int T24_VCL_Trim(short funcindex, LPCTSTR funclabel)
{
    //{{AFX_STS_PARAM_PROTOTYPES
    CParam *VCL_pre = StsGetParam(funcindex,"VCL_pre");
    CParam *VCL_pre_err = StsGetParam(funcindex,"VCL_pre_err");
    CParam *VCL_code = StsGetParam(funcindex,"VCL_code");
    CParam *VCL_sim = StsGetParam(funcindex,"VCL_sim");
    CParam *VCL_sim_err = StsGetParam(funcindex,"VCL_sim_err");
    //}}AFX_STS_PARAM_PROTOTYPES

    // TODO: Add your function code here
	cbit.SetOn(K2,/*K3,*/K4,K8,K13,-1);//K3 is used for read
	delay_ms(3);
	dio.Connect();
	delay_ms(1);

	//I2CPUP.Set(FV, 3.6, FOVI_5V, FOVI_100MA, RELAY_ON);
	VIN.Set(FV, 3.6, FPVI10_5V, FPVI10_1A, RELAY_ON);
	EN.Set(FV, 3.6, FOVI_5V, FOVI_100MA, RELAY_ON);
	delay_ms(3);

	DIOExpressWriteData(0x6a,0x5a);
	delay_ms(1);
	DIOExpressWriteData(0x6a,0xa5);
	delay_ms(3);

if (AllSimCOde == 1)
{
	DIOExpressWriteData(0x47, vbg_code[0]);	delay_ms(1);
	DIOExpressWriteData(0x40, vref_eaout_code[0]);	delay_ms(1);
	DIOExpressWriteData(0x41, ibias_code[0] + fosc_code[0]);	delay_ms(1);
	DIOExpressWriteData(0x48, rsns_code[0]);	delay_ms(1);
	DIOExpressWriteData(0x42, hscl_code[0] /*+ vcl_code[0]*/);	delay_ms(1);
	//DIOExpressWriteData(0x43,ton_code[0]);	delay_ms(1);
}


//	DIOExpressWriteData(0x23,0x90);
//	delay_ms(3);
//	DIOExpressReadData(0x29);
//	delay_ms(1);

	EN.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_ON);
	delay_ms(3);
	EN.Set(FI, 0.0, FOVI_5V, FOVI_100UA, RELAY_ON);
	delay_ms(3);

	DIOExpressWriteData(0x25,0x52);
	delay_ms(1);
	DIOExpressWriteData(0x26,0xE0);
	delay_ms(1);
	DIOExpressWriteData(0x23,0xCC);
	delay_ms(1);


	double Trig = 1;//trigger level
	double Trig_Point[2] = { 0 };
	double result[2] = { 0 };
	int sam = 89; //awgSize
	int interval = 200; //awgInterval��unit=us
	double vcl_Data[100] = { 0.0 };
	int i = 0;
	int	m = 0;

	double vcl_pre[2] = { 0 };
	double vcl_pre_err[2] = { 0 };
	LX.Set(FI, -0.35, FPVI10_5V, FPVI10_10A, RELAY_ON);

	STSAWGCreateRampData(&vcl_Data[0], sam, 1, -0.39, -1.27);
	LX.AwgLoader("vcl", FI, FPVI10_5V, FPVI10_10A, vcl_Data, sam);
	LX.AwgSelect("vcl", 0, sam - 1, 0, interval);

	EN.SetMeasVTrig(Trig, TRIG_RISING);
	EN.MeasureVI(sam, interval, MEAS_AWG);
	LX.MeasureVI(sam, interval, MEAS_AWG);

	STSEnableAWG(&LX);
	STSEnableMeas(&EN, &LX);
	STSAWGRunTriggerStop(&EN, &EN, &LX);

	//	StsAWGRun();


		Trig_Point[0] = EN.GetMeasResult(0, MVRET, TRIG_RESULT);
		m = Trig_Point[0] - 1;
		if (m<2)
		{
			vcl_pre[0] = -777;
		}
		else if (m>sam - 3)
		{
			vcl_pre[0] = -999;

		}
		else
		{
			vcl_pre[0] = 1e3f*vcl_Data[m] ;//FPVIO+FPVI1

		}

		vcl_pre_err[0] = (vcl_pre[0] + vcl_target) / (-vcl_pre[0] + 1e-20f) * 100;

		VCL_pre->SetTestResult(0, 0, -vcl_pre[0]);
		VCL_pre_err->SetTestResult(0, 0, vcl_pre_err[0]);

	LX.Set(FI, 0.0, FPVI10_5V, FPVI10_10A, RELAY_ON);
	delay_ms(3);
	DIOExpressWriteData(0x21,0x00);
	delay_ms(1);
	dio.Disconnect();
	delay_ms(1);

	VIN.Set(FV, 0.0, FPVI10_5V, FPVI10_1A, RELAY_ON);
	EN.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_ON);
	//I2CPUP.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_ON);
	//LX.Set(FV, 0.0, FPVI10_5V, FPVI10_1A, RELAY_ON);
	delay_ms(3);
	cbit.SetOn(-1);
	delay_ms(3);

	if (vcl_pre_err[0] >= -50.0 && vcl_pre_err[0]<50.0)
		{
			if (vcl_pre_err[0] >= -9.74 && vcl_pre_err[0]< -3.25)		{ vcl_code[0] = 7; }//
			if (vcl_pre_err[0] >= -16.23 && vcl_pre_err[0]< -9.74)		{ vcl_code[0] = 6; }//
			if (vcl_pre_err[0] >= -22.73 && vcl_pre_err[0]< -16.23)		{ vcl_code[0] = 5; }//
			if (vcl_pre_err[0] >= -50.0 && vcl_pre_err[0]< -22.73)		{ vcl_code[0] = 4; }//
			if (vcl_pre_err[0] >= 16.23 && vcl_pre_err[0]< 50.0)		{ vcl_code[0] = 3; }//
			if (vcl_pre_err[0] >= 9.74 && vcl_pre_err[0]< 16.23)		{ vcl_code[0] = 2; }//
			if (vcl_pre_err[0] >= 3.25 && vcl_pre_err[0]< 9.74)			{ vcl_code[0] = 1; }//
			if (vcl_pre_err[0] >= -3.25 && vcl_pre_err[0]< 3.25)		{ vcl_code[0] = 0; }//

		}
		else
			vcl_code[0] = 0; //


		/******************* already trimmed dies -> set to reading of OTP ******************/
		if ((EN_OTP42_02_VD[0] == 0))
		{
			vcl_code[0] = OTP42_02_VD[0];
		}


	VCL_code->SetTestResult(0, 0, vcl_code[0]);


	cbit.SetOn(K2,/*K3,*/K4,K8,K13,-1);//K3 is used for read
	delay_ms(3);
	dio.Connect();
	delay_ms(1);

	//I2CPUP.Set(FV, 3.6, FOVI_5V, FOVI_100MA, RELAY_ON);
	VIN.Set(FV, 3.6, FPVI10_5V, FPVI10_1A, RELAY_ON);
	EN.Set(FV, 3.6, FOVI_5V, FOVI_100MA, RELAY_ON);
	delay_ms(3);

	DIOExpressWriteData(0x6a,0x5a);
	delay_ms(1);
	DIOExpressWriteData(0x6a,0xa5);
	delay_ms(3);

if (AllSimCOde == 1)
{
	DIOExpressWriteData(0x47, vbg_code[0]);	delay_ms(1);
	DIOExpressWriteData(0x40, vref_eaout_code[0]);	delay_ms(1);
	DIOExpressWriteData(0x41, ibias_code[0] + fosc_code[0]);	delay_ms(1);
	DIOExpressWriteData(0x48, rsns_code[0]);	delay_ms(1);
	//DIOExpressWriteData(0x42, hscl_code[0] /*+ vcl_code[0]*/);	delay_ms(1);
	//DIOExpressWriteData(0x43,ton_code[0]);	delay_ms(1);
}


//	DIOExpressWriteData(0x23,0x90);
//	delay_ms(3);
//	DIOExpressReadData(0x29);
//	delay_ms(1);

	EN.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_ON);
	delay_ms(3);
	EN.Set(FI, 0.0, FOVI_5V, FOVI_100UA, RELAY_ON);
	delay_ms(3);

	DIOExpressWriteData(0x25,0x52);
	delay_ms(1);
	DIOExpressWriteData(0x26,0xE0);
	delay_ms(1);
	DIOExpressWriteData(0x23,0xCC);
	delay_ms(1);

	Trig = 1;//trigger level

	for(i=0;i<2;i++)
	{
	Trig_Point[i]=0;
	result[i]=0;
	}

	sam = 89; //awgSize
	interval = 200; //awgInterval��unit=us
	double vcl_sim_Data[100] = { 0.0 };
	i = 0;
	m = 0;

	double vcl_sim[2] = { 0 };
	double vcl_sim_err[2] = { 0 };

#if 1

	DIOExpressWriteData(0x42, hscl_code[0] + vcl_code[0]);
	delay_ms(1);

	LX.Set(FI, -0.35, FPVI10_5V, FPVI10_10A, RELAY_ON);

	STSAWGCreateRampData(&vcl_sim_Data[0], sam, 1, -0.39, -1.27);
	LX.AwgLoader("vcl", FI, FPVI10_5V, FPVI10_10A, vcl_sim_Data, sam);
	LX.AwgSelect("vcl", 0, sam - 1, 0, interval);

	EN.SetMeasVTrig(Trig, TRIG_RISING);
	EN.MeasureVI(sam, interval, MEAS_AWG);
	LX.MeasureVI(sam, interval, MEAS_AWG);

	STSEnableAWG(&LX);
	STSEnableMeas(&EN, &LX);
	STSAWGRunTriggerStop(&EN, &EN, &LX);

	//	StsAWGRun();


		Trig_Point[0] = EN.GetMeasResult(0, MVRET, TRIG_RESULT);
		m = Trig_Point[0] - 1;
		if (m<2)
		{
			vcl_sim[0] = -777;
		}
		else if (m>sam - 3)
		{
			vcl_sim[0] = -999;

		}
		else
		{
			vcl_sim[0] = 1e3f*vcl_sim_Data[m] ;//FPVIO+FPVI1

		}

		vcl_sim_err[0] = (vcl_sim[0] + vcl_target) / (-vcl_sim[0] + 1e-20f) * 100;

		VCL_sim->SetTestResult(0, 0, -vcl_sim[0]);
		VCL_sim_err->SetTestResult(0, 0, vcl_sim_err[0]);

	LX.Set(FI, 0.0, FPVI10_5V, FPVI10_10A, RELAY_ON);
	delay_ms(3);
#endif 


#if 0
	int code[16]={0,1,2,3,4,5,6,7};
		
	double tempp[64]={0.0};

	for(i=0;i<2;i++)
	{
	Trig_Point[i]=0;
	result[i]=0;
	}
	dio.Connect();
	delay_ms(1);

	STSAWGCreateRampData(&vcl_sim_Data[0], sam, 1, -0.39, -1.27);
	LX.AwgLoader("vcl", FI, FPVI10_5V, FPVI10_10A, vcl_sim_Data, sam);
	LX.AwgSelect("vcl", 0, sam - 1, 0, interval);

	for(i=0;i<16;i++)
	{

	DIOExpressWriteData(0x42,code[i]);
	delay_ms(1);

	LX.Set(FI, -0.35, FPVI10_5V, FPVI10_10A, RELAY_ON);

	EN.SetMeasVTrig(Trig, TRIG_RISING);
	EN.MeasureVI(sam, interval, MEAS_AWG);
	LX.MeasureVI(sam, interval, MEAS_AWG);

	STSEnableAWG(&LX);
	STSEnableMeas(&EN, &LX);
	STSAWGRunTriggerStop(&EN, &EN, &LX);

		Trig_Point[0] = EN.GetMeasResult(0, MVRET, TRIG_RESULT);
		m = Trig_Point[0] - 1;
		if (m<2)
		{
			vcl_sim[0] = -777;
		}
		else if (m>sam - 3)
		{
			vcl_sim[0] = -999;

		}
		else
		{
			tempp[i] = 1e3f*vcl_sim_Data[m] ;//FPVIO+FPVI1

		}

	LX.Set(FI, -0.0, FPVI10_5V, FPVI10_10A, RELAY_ON);
	delay_ms(3);
	}
#endif



	DIOExpressWriteData(0x21,0x00);
	delay_ms(1);
	dio.Disconnect();
	delay_ms(1);

	VIN.Set(FV, 0.0, FPVI10_5V, FPVI10_1A, RELAY_ON);
	EN.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_ON);
	//I2CPUP.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_ON);
	LX.Set(FV, 0.0, FPVI10_5V, FPVI10_10A, RELAY_ON);
	delay_ms(3);
	VIN.Set(FV, 0.0, FPVI10_5V, FPVI10_1A, RELAY_OFF);
	EN.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_OFF);
	//I2CPUP.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_OFF);
	LX.Set(FV, 0.0, FPVI10_5V, FPVI10_10A, RELAY_OFF);
	delay_ms(3);
	cbit.SetOn(-1);
	delay_ms(3);

    return 0;
}


DUT_API int T25_VCL_BURN(short funcindex, LPCTSTR funclabel)
{
    //{{AFX_STS_PARAM_PROTOTYPES
    CParam *VCL_burn = StsGetParam(funcindex,"VCL_burn");
    //}}AFX_STS_PARAM_PROTOTYPES

    // TODO: Add your function code here
	if (en_trim == 1)
	{
	//EN_OTP42_02_VD[0]=1;

	cbit.SetOn(K2,/*K3,*/K4,K11,K12,K13,-1);
	delay_ms(3);

	//I2CPUP.Set(FV, 3.6, FOVI_5V, FOVI_100MA, RELAY_ON);
	VIN.Set(FV, 3.6, FPVI10_5V, FPVI10_100MA, RELAY_ON);
	EN.Set(FV, 3.6, FOVI_5V, FOVI_100MA, RELAY_ON);
	delay_ms(3);
	dio.Connect();
	delay_ms(3);
	DIOExpressWriteData(0x6a,0x5a);
	delay_ms(1);
	DIOExpressWriteData(0x6a,0xa5);
	delay_ms(1);

	DIOExpressWriteData(0x42,vcl_code[0]);
	delay_ms(1);
	DIOExpressWriteData(0x20,0x02);
	delay_ms(1);
	DIOExpressWriteData(0x21,0x09);
	delay_ms(1);

	VOUT.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_ON);
	delay_ms(3);	

	VHEN1[0] = EN_OTP42_02_VD[0] * 1.0 * 5;
	VHEN2[0] = EN_OTP42_02_VD[0] * 1.1 * 5;
	VHEN3[0] = EN_OTP42_02_VD[0] * 1.2 * 5;
	VHEN4[0] = EN_OTP42_02_VD[0] * 1.3 * 5;
	VHEN5[0] = EN_OTP42_02_VD[0] * 1.4 * 5;

	VOUT.Set(FV, VHEN1[0], FOVI_10V, FOVI_100MA, RELAY_ON);
	VOUT.Set(FV, VHEN2[0], FOVI_10V, FOVI_100MA, RELAY_ON);
	VOUT.Set(FV, VHEN3[0], FOVI_10V, FOVI_100MA, RELAY_ON);
	VOUT.Set(FV, VHEN4[0], FOVI_10V, FOVI_100MA, RELAY_ON);
	VOUT.Set(FV, VHEN5[0], FOVI_10V, FOVI_100MA, RELAY_ON);
	delay_ms(1);	

	DIOExpressWriteData(0x21,0x0B);
	delay_ms(1);
	DIOExpressWriteData(0x21,0x09);
	delay_ms(1);

	VOUT.Set(FV, VHEN5[0], FOVI_10V, FOVI_100MA, RELAY_ON);
	VOUT.Set(FV, VHEN4[0], FOVI_10V, FOVI_100MA, RELAY_ON);
	VOUT.Set(FV, VHEN3[0], FOVI_10V, FOVI_100MA, RELAY_ON);
	VOUT.Set(FV, VHEN2[0], FOVI_10V, FOVI_100MA, RELAY_ON);
	VOUT.Set(FV, VHEN1[0], FOVI_10V, FOVI_100MA, RELAY_ON);
	delay_ms(1);	


	DIOExpressWriteData(0x6a,0x00);
	delay_ms(1);


	VOUT.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_ON);	
	VIN.Set(FV, 0.0, FPVI10_5V, FPVI10_100MA, RELAY_ON);
	EN.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_ON);
	//I2CPUP.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_ON);
	delay_ms(1);
	dio.Disconnect();
	delay_ms(1);
	cbit.SetOn(-1);
	delay_ms(1);


	VCL_burn->SetTestResult(0, 0, EN_OTP42_02_VD[0]);

	}

    return 0;
}


DUT_API int T26_VCL_Post(short funcindex, LPCTSTR funclabel)
{
    //{{AFX_STS_PARAM_PROTOTYPES
    CParam *VCL_post = StsGetParam(funcindex,"VCL_post");
    CParam *VCL_post_err = StsGetParam(funcindex,"VCL_post_err");
    //}}AFX_STS_PARAM_PROTOTYPES

    // TODO: Add your function code here
	cbit.SetOn(K2,/*K3,*/K4,K8,K13,-1);//K3 is used for read
	delay_ms(3);
	dio.Connect();
	delay_ms(1);

	//I2CPUP.Set(FV, 3.6, FOVI_5V, FOVI_100MA, RELAY_ON);
	VIN.Set(FV, 3.6, FPVI10_5V, FPVI10_1A, RELAY_ON);
	EN.Set(FV, 3.6, FOVI_5V, FOVI_100MA, RELAY_ON);
	delay_ms(3);

	DIOExpressWriteData(0x6a,0x5a);
	delay_ms(1);
	DIOExpressWriteData(0x6a,0xa5);
	delay_ms(3);

//	DIOExpressWriteData(0x23,0x90);
//	delay_ms(3);
//	DIOExpressReadData(0x29);
//	delay_ms(1);

	EN.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_ON);
	delay_ms(3);
	EN.Set(FI, 0.0, FOVI_5V, FOVI_100UA, RELAY_ON);
	delay_ms(3);

	DIOExpressWriteData(0x25,0x52);
	delay_ms(1);
	DIOExpressWriteData(0x26,0xE0);
	delay_ms(1);
	DIOExpressWriteData(0x23,0xCC);
	delay_ms(1);

	double Trig = 1;//trigger level
	double Trig_Point[2] = { 0 };
	double result[2] = { 0 };
	int sam = 89; //awgSize
	int interval = 200; //awgInterval��unit=us
	double vcl_Data[100] = { 0.0 };
	int i = 0;
	int	m = 0;

	double vcl_post[2] = { 0 };
	double vcl_post_err[2] = { 0 };

	LX.Set(FI, -0.35, FPVI10_5V, FPVI10_10A, RELAY_ON);

	STSAWGCreateRampData(&vcl_Data[0], sam, 1, -0.39, -1.27);
	LX.AwgLoader("vcl", FI, FPVI10_5V, FPVI10_10A, vcl_Data, sam);
	LX.AwgSelect("vcl", 0, sam - 1, 0, interval);

	EN.SetMeasVTrig(Trig, TRIG_RISING);
	EN.MeasureVI(sam, interval, MEAS_AWG);
	LX.MeasureVI(sam, interval, MEAS_AWG);

	STSEnableAWG(&LX);
	STSEnableMeas(&EN, &LX);
	STSAWGRunTriggerStop(&EN, &EN, &LX);


	//	StsAWGRun();


		Trig_Point[0] = EN.GetMeasResult(0, MVRET, TRIG_RESULT);
		m = Trig_Point[0] - 1;
		if (m<2)
		{
			vcl_post[0] = -777;
		}
		else if (m>sam - 3)
		{
			vcl_post[0] = -999;

		}
		else
		{
			vcl_post[0] = 1e3f*vcl_Data[m] ;//FPVIO+FPVI1

		}


	LX.Set(FI, 0.0, FPVI10_5V, FPVI10_10A, RELAY_ON);
	delay_ms(3);

	DIOExpressWriteData(0x21,0x00);
	delay_ms(1);
	dio.Disconnect();
	delay_ms(1);

	VIN.Set(FV, 0.0, FPVI10_5V, FPVI10_1A, RELAY_ON);
	EN.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_ON);
	//I2CPUP.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_ON);
	LX.Set(FV, 0.0, FPVI10_5V, FPVI10_10A, RELAY_ON);
	delay_ms(3);
	VIN.Set(FV, 0.0, FPVI10_5V, FPVI10_1A, RELAY_OFF);
	EN.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_OFF);
	//I2CPUP.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_OFF);
	LX.Set(FV, 0.0, FPVI10_5V, FPVI10_10A, RELAY_OFF);
	delay_ms(3);
	cbit.SetOn(-1);
	delay_ms(3);

	vcl_post_err[0] = (vcl_post[0] + vcl_target) / (-vcl_post[0] + 1e-20f) * 100;

	VCL_post->SetTestResult(0, 0, -vcl_post[0] );
	VCL_post_err->SetTestResult(0, 0, vcl_post_err[0]);

    return 0;
}


DUT_API int T27_ZCS_Trim(short funcindex, LPCTSTR funclabel)
{
    //{{AFX_STS_PARAM_PROTOTYPES
    CParam *REG27_1 = StsGetParam(funcindex,"REG27_1");
    CParam *ZCS_pre = StsGetParam(funcindex,"ZCS_pre");
    CParam *ZCS_pre_err = StsGetParam(funcindex,"ZCS_pre_err");
    CParam *ZCS_code = StsGetParam(funcindex,"ZCS_code");
    CParam *REG27_2 = StsGetParam(funcindex,"REG27_2");
    CParam *ZCS_sim = StsGetParam(funcindex,"ZCS_sim");
    CParam *ZCS_sim_err = StsGetParam(funcindex,"ZCS_sim_err");
    CParam *REG27_delta = StsGetParam(funcindex,"REG27_delta");
    //}}AFX_STS_PARAM_PROTOTYPES

    // TODO: Add your function code here
////2024/08/21 mod
//1. add vout = 3.6V at befort
//2. EN current range drop to 10mA, swap to after than all I2C write then FV=0V and drop current range to 100uA 
//3. VIN and VOUT set 3.6V at begin, after i2c write, change voltage to 4.2V
////2024/08/21 mod
	Rdata1[0] = 0;
	Rdata2[0] = 0;
	double VVINset = 2.5;
	cbit.SetOn(K2/*,K3*/, K4, K8, K13, K11,/*K1,*/-1);//K3 is used for read
	delay_ms(3);
	dio.Connect();
	delay_ms(1);
	VOUT.Set(FV, 0.0, FOVI_10V, FOVI_100MA, RELAY_ON);
	VIN.Set(FV, 0.0, FPVI10_10V, FPVI10_1A, RELAY_ON);
	EN.Set(FV, 0.0, FOVI_10V, FOVI_10MA, RELAY_ON);
	delay_ms(3);
	//I2CPUP.Set(FV, 3.6, FOVI_10V, FOVI_100MA, RELAY_ON);
	VOUT.Set(FV, VVINset, FOVI_10V, FOVI_100MA, RELAY_ON);
	//MODE.Set(FV, 3.6, FOVI_10V, FOVI_10MA, RELAY_ON);
	VIN.Set(FV, VVINset, FPVI10_10V, FPVI10_1A, RELAY_ON, 3);
	delay_ms(10);
	EN.Set(FV, 3.6, FOVI_10V, FOVI_10MA, RELAY_ON, 2);
	delay_ms(3);

	DIOExpressWriteData(0x6a, 0x5a);
	delay_ms(1);
	DIOExpressWriteData(0x6a, 0xa5);
	delay_ms(3);

	if (AllSimCOde == 1)
	{
		DIOExpressWriteData(0x47, vbg_code[0]);	delay_ms(1);
		DIOExpressWriteData(0x40, vref_eaout_code[0]);	delay_ms(1);
		DIOExpressWriteData(0x41, ibias_code[0] + fosc_code[0]);	delay_ms(1);
		DIOExpressWriteData(0x48, rsns_code[0]);	delay_ms(1);
		DIOExpressWriteData(0x42, hscl_code[0] + vcl_code[0]);	delay_ms(1);
		//DIOExpressWriteData(0x43,ton_code[0]);	delay_ms(1);
	}

	//	DIOExpressWriteData(0x23,0x90);
	//	delay_ms(3);
	//	DIOExpressReadData(0x29);
	//	delay_ms(1);

	EN.Set(FV, 0.0, FOVI_10V, FOVI_10MA, RELAY_ON);
	delay_ms(3);
	EN.Set(FI, 0.0, FOVI_10V, FOVI_100UA, RELAY_SENSE_ON);
	delay_ms(3);
	cbit.SetCBITOn(K3);//EN_DIO
	delay_ms(3);

	DIOExpressWriteData(0x23, 0x90);   delay_ms(1);
	Rdata1[0] = DIOExpressReadData(0x27);
	Rdata1[0] = Rdata1[0] & 0x0F;
	REG27_1->SetTestResult(0, 0, Rdata1[0]);

	cbit.SetCBITOff(K3);//EN_DIO
	cbit.SetCBITOff(K4);//FOVI0_to_EN
	delay_ms(3);
	cbit.SetCBITOn(K5);//EN_to_op07_to_FOVI0
	delay_ms(3);

	DIOExpressWriteData(0x25, 0x50);
	delay_ms(1);
	//DIOExpressWriteData(0x26,0xE0);
	//delay_ms(1);
	DIOExpressWriteData(0x23, 0x8C);
	delay_ms(1);


	double Trig = 1;//trigger level
	double Trig_Point[2] = { 0 };
	double result[2] = { 0 };
	int sam = 101; //awgSize
	int interval = 200; //awgInterval��unit=us
	double zcs_Data[110] = { 0.0 };
	int i = 0;
	int	m = 0;

	double zcs_pre[2] = { 0 };
	double zcs_pre_err[2] = { 0 };

	LX.Set(FI, -0.01, FPVI10_10V, FPVI10_1A, RELAY_ON);

	STSAWGCreateRampData(&zcs_Data[0], sam, 1, -0.01, -0.21);
	LX.AwgLoader("zcs", FI, FPVI10_10V, FPVI10_1A, zcs_Data, sam);
	LX.AwgSelect("zcs", 0, sam - 1, 0, interval);


	EN.SetMeasVTrig(Trig, TRIG_FALLING);
	EN.MeasureVI(sam, interval, MEAS_AWG);
	LX.MeasureVI(sam, interval, MEAS_AWG);

	STSEnableAWG(&LX);
	STSEnableMeas(&EN, &LX);
	STSAWGRunTriggerStop(&EN, &EN, &LX);

	//	StsAWGRun();


	Trig_Point[0] = EN.GetMeasResult(0, MVRET, TRIG_RESULT);
	m = Trig_Point[0] - 1;
	if (m<2)
	{
		zcs_pre[0] = -777;
	}
	else if (m>sam - 3)
	{
		zcs_pre[0] = -999;

	}
	else
	{
		zcs_pre[0] = 1e3f*zcs_Data[m];//FPVIO+FPVI1

	}

	zcs_pre_err[0] = (zcs_pre[0] + zcs_target) / (-zcs_pre[0] + 1e-20f) * 100;

	ZCS_pre->SetTestResult(0, 0, -zcs_pre[0]);
	ZCS_pre_err->SetTestResult(0, 0, zcs_pre_err[0]);

	LX.Set(FI, 0.0, FPVI10_10V, FPVI10_1A, RELAY_ON);
	delay_ms(3);
	DIOExpressWriteData(0x21, 0x00);
	delay_ms(1);
	dio.Disconnect();
	delay_ms(1);

	cbit.SetCBITOff(K5);//EN_to_op07_to_FOVI0
	delay_ms(3);
	cbit.SetCBITOn(K4);//FOVI0_to_EN
	delay_ms(3);

	//VIN.Set(FV, 0.0, FPVI10_10V, FPVI10_1A, RELAY_ON);
	EN.Set(FV, 0.0, FOVI_10V, FOVI_100MA, RELAY_ON);
	//I2CPUP.Set(FV, 0.0, FOVI_10V, FOVI_100MA, RELAY_ON);
	//LX.Set(FV, 0.0, FPVI10_10V, FPVI10_1A, RELAY_ON);
	//MODE.Set(FV, 0.0, FOVI_10V, FOVI_10MA, RELAY_ON);
	delay_ms(3);
	//cbit.SetOn(-1);
	//delay_ms(3);

	if (zcs_pre_err[0] >= -70.0 && zcs_pre_err[0]<70.0)
	{
		if (zcs_pre_err[0] >= -4.55 && zcs_pre_err[0]< -1.14)		{ zcs_code[0] = 15; }//
		if (zcs_pre_err[0] >= -7.95 && zcs_pre_err[0]< -4.55)		{ zcs_code[0] = 14; }//
		if (zcs_pre_err[0] >= -11.36 && zcs_pre_err[0]< -7.95)		{ zcs_code[0] = 13; }//
		if (zcs_pre_err[0] >= -15.91 && zcs_pre_err[0]< -11.36)		{ zcs_code[0] = 12; }//
		if (zcs_pre_err[0] >= -19.32 && zcs_pre_err[0]< -15.91)		{ zcs_code[0] = 11; }//
		if (zcs_pre_err[0] >= -22.73 && zcs_pre_err[0]< -19.32)		{ zcs_code[0] = 10; }//
		if (zcs_pre_err[0] >= -26.14 && zcs_pre_err[0]< -22.73)		{ zcs_code[0] = 9; }//
		if (zcs_pre_err[0] >= -70.0 && zcs_pre_err[0]< -26.14)		{ zcs_code[0] = 8; }//

		if (zcs_pre_err[0] >= 25.0 && zcs_pre_err[0]< 70.0)			{ zcs_code[0] = 7; }//
		if (zcs_pre_err[0] >= 20.45 && zcs_pre_err[0]< 25.0)		{ zcs_code[0] = 6; }//
		if (zcs_pre_err[0] >= 17.05 && zcs_pre_err[0]< 20.45)		{ zcs_code[0] = 5; }//
		if (zcs_pre_err[0] >= 13.64 && zcs_pre_err[0]< 17.05)		{ zcs_code[0] = 4; }//
		if (zcs_pre_err[0] >= 9.09 && zcs_pre_err[0]< 13.64)		{ zcs_code[0] = 3; }//
		if (zcs_pre_err[0] >= 5.68 && zcs_pre_err[0]< 9.09)			{ zcs_code[0] = 2; }//
		if (zcs_pre_err[0] >= 2.27 && zcs_pre_err[0]< 5.68)			{ zcs_code[0] = 1; }//
		if (zcs_pre_err[0] >= -1.14 && zcs_pre_err[0]< 2.27)		{ zcs_code[0] = 0; }//
	}
	else
		zcs_code[0] = 0; //


	/******************* already trimmed dies -> set to reading of OTP ******************/
	if ((EN_OTP43_03_VD[0] == 0))
	{
		zcs_code[0] = OTP43_03_VD[0];
	}


	ZCS_code->SetTestResult(0, 0, zcs_code[0]);


	//cbit.SetOn(K2,/*K3,*/K4, K8, K13, K11/*,K1*/, -1);//K3 is used for read
	//delay_ms(3);
	dio.Connect();
	delay_ms(1);

	VOUT.Set(FV, VVINset, FOVI_10V, FOVI_100MA, RELAY_ON);
	//MODE.Set(FV, 3.6, FOVI_10V, FOVI_10MA, RELAY_ON);
	//I2CPUP.Set(FV, 3.6, FOVI_10V, FOVI_100MA, RELAY_ON);
	VIN.Set(FV, VVINset, FPVI10_10V, FPVI10_1A, RELAY_ON, 3);
	delay_ms(10);
	EN.Set(FV, 3.6, FOVI_10V, FOVI_10MA, RELAY_ON, 2);
	delay_ms(3);


	DIOExpressWriteData(0x6a, 0x5a);
	delay_ms(1);
	DIOExpressWriteData(0x6a, 0xa5);
	delay_ms(3);

	if (AllSimCOde == 1)
	{
		DIOExpressWriteData(0x47, vbg_code[0]);	delay_ms(1);
		DIOExpressWriteData(0x40, vref_eaout_code[0]);	delay_ms(1);
		DIOExpressWriteData(0x41, ibias_code[0] + fosc_code[0]);	delay_ms(1);
		DIOExpressWriteData(0x48, rsns_code[0]);	delay_ms(1);
		DIOExpressWriteData(0x42, hscl_code[0] + vcl_code[0]);	delay_ms(1);
		//DIOExpressWriteData(0x43,ton_code[0]);	delay_ms(1);
	}

	//	DIOExpressWriteData(0x23,0x90);
	//	delay_ms(3);
	//	DIOExpressReadData(0x29);
	//	delay_ms(1);

	EN.Set(FV, 0.0, FOVI_10V, FOVI_10MA, RELAY_ON);
	delay_ms(3);
	EN.Set(FI, 0.0, FOVI_10V, FOVI_100UA, RELAY_SENSE_ON);
	delay_ms(3);
	cbit.SetCBITOn(K3);//EN_DIO
	delay_ms(3);
	DIOExpressWriteData(0x23, 0x90);   delay_ms(1);
	Rdata2[0] = DIOExpressReadData(0x27);
	Rdata2[0] = Rdata2[0] & 0x0F;
	REG27_2->SetTestResult(0, 0, Rdata2[0]);
	REG27_delta->SetTestResult(0, 0, (Rdata2[0] - Rdata1[0]));
	cbit.SetCBITOff(K3);//EN_DIO
	cbit.SetCBITOff(K4);//FOVI0_to_EN
	delay_ms(3);
	cbit.SetCBITOn(K5);//EN_to_op07_to_FOVI0
	delay_ms(3);

	DIOExpressWriteData(0x25, 0x50);
	delay_ms(1);
	//DIOExpressWriteData(0x26,0xE0);
	delay_ms(1);
	DIOExpressWriteData(0x23, 0x8C);
	delay_ms(1);



	Trig = 1;//trigger level

	for (i = 0; i<2; i++)
	{
		Trig_Point[i] = 0;
		result[i] = 0;
	}

	sam = 101; //awgSize
	interval = 200; //awgInterval��unit=us
	double zcs_sim_Data[110] = { 0.0 };
	i = 0;
	m = 0;

	double zcs_sim[2] = { 0 };
	double zcs_sim_err[2] = { 0 };

#if 1

	DIOExpressWriteData(0x43, zcs_code[0]);
	delay_ms(1);

	LX.Set(FI, -0.01, FPVI10_10V, FPVI10_1A, RELAY_ON);

	STSAWGCreateRampData(&zcs_sim_Data[0], sam, 1, -0.01, -0.21);
	LX.AwgLoader("zcs", FI, FPVI10_10V, FPVI10_1A, zcs_sim_Data, sam);
	LX.AwgSelect("zcs", 0, sam - 1, 0, interval);


	EN.SetMeasVTrig(Trig, TRIG_FALLING);
	EN.MeasureVI(sam, interval, MEAS_AWG);
	LX.MeasureVI(sam, interval, MEAS_AWG);

	STSEnableAWG(&LX);
	STSEnableMeas(&EN, &LX);
	STSAWGRunTriggerStop(&EN, &EN, &LX);

	//	StsAWGRun();


	Trig_Point[0] = EN.GetMeasResult(0, MVRET, TRIG_RESULT);
	m = Trig_Point[0] - 1;
	if (m<2)
	{
		zcs_sim[0] = -777;
	}
	else if (m>sam - 3)
	{
		zcs_sim[0] = -999;

	}
	else
	{
		zcs_sim[0] = 1e3f*zcs_sim_Data[m] ;//FPVIO+FPVI1

	}
#endif

#if 0
	int code[16]={0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15};

	double tempp[64]={0.0};

	for(i=0;i<2;i++)
	{
		Trig_Point[i]=0;
		result[i]=0;
	}
	dio.Connect();
	delay_ms(1);

	STSAWGCreateRampData(&zcs_sim_Data[0], sam, 1, -0.01, -0.21);
	LX.AwgLoader("zcs", FI, FPVI10_10V, FPVI10_1A, zcs_sim_Data, sam);
	LX.AwgSelect("zcs", 0, sam - 1, 0, interval);

	for(i=0;i<16;i++)
	{

		DIOExpressWriteData(0x43,code[i]);
		delay_ms(1);

		LX.Set(FI, -0.01, FPVI10_10V, FPVI10_1A, RELAY_ON);

		EN.SetMeasVTrig(Trig, TRIG_FALLING);
		EN.MeasureVI(sam, interval, MEAS_AWG);
		LX.MeasureVI(sam, interval, MEAS_AWG);

		STSEnableAWG(&LX);
		STSEnableMeas(&EN, &LX);
		STSAWGRunTriggerStop(&EN, &EN, &LX);

		Trig_Point[0] = EN.GetMeasResult(0, MVRET, TRIG_RESULT);
		m = Trig_Point[0] - 1;
		if (m<2)
		{
			zcs_sim[0] = -777;
		}
		else if (m>sam - 3)
		{
			zcs_sim[0] = -999;

	}
		else
		{
			tempp[i] = 1e3f*zcs_sim_Data[m];//FPVIO+FPVI1

		}

		LX.Set(FI, -0.0, FPVI10_10V, FPVI10_1A, RELAY_ON);
		delay_ms(3);
}
#endif


	LX.Set(FI, 0.0, FPVI10_10V, FPVI10_1A, RELAY_ON);
	delay_ms(3);
	DIOExpressWriteData(0x21, 0x00);
	delay_ms(1);
	dio.Disconnect();
	delay_ms(1);

	cbit.SetCBITOff(K5);//EN_to_op07_to_FOVI0
	delay_ms(3);
	cbit.SetCBITOn(K4);//FOVI0_to_EN
	delay_ms(3);

	VIN.Set(FV, 0.0, FPVI10_10V, FPVI10_1A, RELAY_ON);
	EN.Set(FV, 0.0, FOVI_10V, FOVI_100MA, RELAY_ON);
	//I2CPUP.Set(FV, 0.0, FOVI_10V, FOVI_100MA, RELAY_ON);
	LX.Set(FV, 0.0, FPVI10_10V, FPVI10_1A, RELAY_ON);
	//MODE.Set(FV, 0.0, FOVI_10V, FOVI_10MA, RELAY_ON);
	VOUT.Set(FV, 0.0, FOVI_10V, FOVI_100MA, RELAY_ON);
	delay_ms(3);
	//MODE.Set(FV, 0.0, FOVI_10V, FOVI_10MA, RELAY_OFF);
	VOUT.Set(FV, 0.0, FOVI_10V, FOVI_100MA, RELAY_OFF);
	VIN.Set(FV, 0.0, FPVI10_10V, FPVI10_1A, RELAY_OFF);
	EN.Set(FV, 0.0, FOVI_10V, FOVI_100MA, RELAY_OFF);
	//I2CPUP.Set(FV, 0.0, FOVI_10V, FOVI_100MA, RELAY_OFF);
	LX.Set(FV, 0.0, FPVI10_10V, FPVI10_1A, RELAY_OFF);
	delay_ms(3);

	zcs_sim_err[0] = (zcs_sim[0] + zcs_target) / (-zcs_sim[0] + 1e-20f) * 100;
	ZCS_sim->SetTestResult(0, 0, -zcs_sim[0]);
	ZCS_sim_err->SetTestResult(0, 0, zcs_sim_err[0]);

	cbit.SetOn(-1);
	delay_ms(3);


	return 0;
}


DUT_API int T28_ZCS_BURN(short funcindex, LPCTSTR funclabel)
{
    //{{AFX_STS_PARAM_PROTOTYPES
    CParam *ZCS_burn = StsGetParam(funcindex,"ZCS_burn");
    //}}AFX_STS_PARAM_PROTOTYPES

    // TODO: Add your function code here
	if (en_trim == 1)
	{
	//EN_OTP43_03_VD[0]=1;

	cbit.SetOn(K2,/*K3,*/K4,K11,K12,K13,-1);
	delay_ms(3);

	//I2CPUP.Set(FV, 3.6, FOVI_5V, FOVI_100MA, RELAY_ON);
	VIN.Set(FV, 3.6, FPVI10_5V, FPVI10_100MA, RELAY_ON);
	EN.Set(FV, 3.6, FOVI_5V, FOVI_100MA, RELAY_ON);
	delay_ms(3);
	dio.Connect();
	delay_ms(3);
	DIOExpressWriteData(0x6a,0x5a);
	delay_ms(1);
	DIOExpressWriteData(0x6a,0xa5);
	delay_ms(1);

	DIOExpressWriteData(0x43,zcs_code[0]);
	delay_ms(1);
	DIOExpressWriteData(0x20,0x03);
	delay_ms(1);
	DIOExpressWriteData(0x21,0x09);
	delay_ms(1);

	VOUT.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_ON);
	delay_ms(3);	

	VHEN1[0] = EN_OTP43_03_VD[0] * 1.0 * 5;
	VHEN2[0] = EN_OTP43_03_VD[0] * 1.1 * 5;
	VHEN3[0] = EN_OTP43_03_VD[0] * 1.2 * 5;
	VHEN4[0] = EN_OTP43_03_VD[0] * 1.3 * 5;
	VHEN5[0] = EN_OTP43_03_VD[0] * 1.4 * 5;

	VOUT.Set(FV, VHEN1[0], FOVI_10V, FOVI_100MA, RELAY_ON);
	VOUT.Set(FV, VHEN2[0], FOVI_10V, FOVI_100MA, RELAY_ON);
	VOUT.Set(FV, VHEN3[0], FOVI_10V, FOVI_100MA, RELAY_ON);
	VOUT.Set(FV, VHEN4[0], FOVI_10V, FOVI_100MA, RELAY_ON);
	VOUT.Set(FV, VHEN5[0], FOVI_10V, FOVI_100MA, RELAY_ON);
	delay_ms(1);	

	DIOExpressWriteData(0x21,0x0B);
	delay_ms(1);
	DIOExpressWriteData(0x21,0x09);
	delay_ms(1);

	VOUT.Set(FV, VHEN5[0], FOVI_10V, FOVI_100MA, RELAY_ON);
	VOUT.Set(FV, VHEN4[0], FOVI_10V, FOVI_100MA, RELAY_ON);
	VOUT.Set(FV, VHEN3[0], FOVI_10V, FOVI_100MA, RELAY_ON);
	VOUT.Set(FV, VHEN2[0], FOVI_10V, FOVI_100MA, RELAY_ON);
	VOUT.Set(FV, VHEN1[0], FOVI_10V, FOVI_100MA, RELAY_ON);
	delay_ms(1);	


	DIOExpressWriteData(0x6a,0x00);
	delay_ms(1);


	VOUT.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_ON);	
	VIN.Set(FV, 0.0, FPVI10_5V, FPVI10_100MA, RELAY_ON);
	EN.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_ON);
	//I2CPUP.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_ON);
	delay_ms(1);
	dio.Disconnect();
	delay_ms(1);
	cbit.SetOn(-1);
	delay_ms(1);

	ZCS_burn->SetTestResult(0, 0, EN_OTP43_03_VD[0]);

	}

    return 0;
}


DUT_API int T29_ZCS_Post(short funcindex, LPCTSTR funclabel)
{
    //{{AFX_STS_PARAM_PROTOTYPES
    CParam *REG27_3 = StsGetParam(funcindex,"REG27_3");
    CParam *ZCS_post = StsGetParam(funcindex,"ZCS_post");
    CParam *ZCS_post_err = StsGetParam(funcindex,"ZCS_post_err");
    CParam *ZCS_Reg27_vin3p6 = StsGetParam(funcindex,"ZCS_Reg27_vin3p6");
    CParam *ZCS_post_vin3p6 = StsGetParam(funcindex,"ZCS_post_vin3p6");
    CParam *ZCS_Reg27_vin5p5 = StsGetParam(funcindex,"ZCS_Reg27_vin5p5");
    CParam *ZCS_post_vin5p5 = StsGetParam(funcindex,"ZCS_post_vin5p5");
    //}}AFX_STS_PARAM_PROTOTYPES
	// TODO: Add your function code here
	cbit.SetOn(K2,/*K3,*/K4, K8, K13, K11, -1);//K3 is used for read
	delay_ms(3);
	dio.Connect();
	delay_ms(1);

	VIN.Set(FV, 0.0, FPVI10_10V, FPVI10_1A, RELAY_ON);
	EN.Set(FV, 0.0, FOVI_10V, FOVI_10MA, RELAY_ON);
	VOUT.Set(FV, 0.0, FOVI_10V, FOVI_100MA, RELAY_ON);
	//I2CPUP.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_ON);
	LX.Set(FV, 0.0, FPVI10_10V, FPVI10_1A, RELAY_ON);
	delay_ms(3);

	LX.Set(FI, 0.0, FPVI10_10V, FPVI10_1A, RELAY_ON);
	VOUT.Set(FV, 2.5, FOVI_10V, FOVI_100MA, RELAY_ON);
	VIN.Set(FV, 2.5, FPVI10_10V, FPVI10_1A, RELAY_ON, 3);
	delay_ms(10);
	EN.Set(FV, 3.6, FOVI_10V, FOVI_10MA, RELAY_ON, 2);
	delay_ms(3);

	DIOExpressWriteData(0x6a, 0x5a);
	delay_ms(1);
	DIOExpressWriteData(0x6a, 0xa5);
	delay_ms(1);

	if (AllSimCOde == 1)
	{
		DIOExpressWriteData(0x47, vbg_code[0]);	delay_ms(1);
		DIOExpressWriteData(0x40, vref_eaout_code[0]);	delay_ms(1);
		DIOExpressWriteData(0x41, ibias_code[0] + fosc_code[0]);	delay_ms(1);
		DIOExpressWriteData(0x48, rsns_code[0]);	delay_ms(1);
		DIOExpressWriteData(0x42, hscl_code[0] + vcl_code[0]);	delay_ms(1);
		DIOExpressWriteData(0x43, zcs_code[0] + ton_code[0]);		delay_ms(1);
	}

	//	DIOExpressWriteData(0x23,0x90);
	//	delay_ms(3);
	//	DIOExpressReadData(0x29);
	//	delay_ms(1);

	EN.Set(FV, 0.0, FOVI_10V, FOVI_10MA, RELAY_ON);
	delay_ms(3);
	EN.Set(FI, 0.0, FOVI_10V, FOVI_100UA, RELAY_SENSE_ON);
	delay_ms(3);

	cbit.SetCBITOn(K3);//EN_DIO
	delay_ms(3);
	DIOExpressWriteData(0x23, 0x90);   delay_ms(1);
	Rdata1[0] = DIOExpressReadData(0x27);
	REG27_3->SetTestResult(0, 0, (Rdata1[0] & 0x0F));


	if (AllSimCOde == 2)
	{
		Rdata1[0] = DIOExpressReadData(0x43);
		Rdata1[1] = Rdata1[0] & 0xF0;
		DIOExpressWriteData(0x43, zcs_code[0] + Rdata1[1]);	delay_ms(1);
	}



	cbit.SetCBITOff(K3);//EN_DIO
	cbit.SetCBITOff(K4);//FOVI0_to_EN
	delay_ms(3);
	cbit.SetCBITOn(K5);//EN_to_op07_to_FOVI0
	delay_ms(3);


	DIOExpressWriteData(0x25, 0x50);
	delay_ms(1);
	//DIOExpressWriteData(0x26,0xE0);
	delay_ms(1);
	DIOExpressWriteData(0x23, 0x8C);
	delay_ms(1);




	double Trig = 1;//trigger level
	double Trig_Point[2] = { 0 };
	double result[2] = { 0 };
	int sam = 201; //awgSize
	int interval = 100; //awgInterval��unit=us
	double zcs_Data[210] = { 0.0 };
	int i = 0;
	int	m = 0;

	double zcs_post[2] = { 0 };
	double zcs_post_err[2] = { 0 };
	LX.Set(FI, -0.01, FPVI10_10V, FPVI10_1A, RELAY_ON);

	STSAWGCreateRampData(&zcs_Data[0], sam, 1, -0.01, -0.21);
	LX.AwgLoader("zcs_post", FI, FPVI10_10V, FPVI10_1A, zcs_Data, sam);
	LX.AwgSelect("zcs_post", 0, sam - 1, 0, interval);

	EN.SetMeasVTrig(Trig, TRIG_FALLING);
	EN.MeasureVI(sam, interval, MEAS_AWG);
	LX.MeasureVI(sam, interval, MEAS_AWG);

	//*
	STSEnableAWG(&LX);
	STSEnableMeas(&EN, &LX);
	STSAWGRunTriggerStop(&EN, &EN, &LX);
	//StsAWGRun();
	/*/
	VIN.MeasureVI(sam, interval, MEAS_AWG);
	STSEnableAWG(&LX);
	STSEnableMeas(&EN, &LX, &VIN);
	//STSAWGRunTriggerStop(&EN, &EN, &LX,&VIN);
	StsAWGRun();
	//*/

	Trig_Point[0] = EN.GetMeasResult(0, MVRET, TRIG_RESULT);
	m = Trig_Point[0] - 1;
	if (m<2)
	{
		zcs_post[0] = -777;
	}
	else if (m>sam - 3)
	{
		zcs_post[0] = -999;

	}
	else
	{
		zcs_post[0] = 1e3f*zcs_Data[m];//FPVIO+FPVI1

	}

	ZCS_post->SetTestResult(0, 0, -zcs_post[0]);
	ZCS_post_err->SetTestResult(0, 0, zcs_post_err[0]);

	LX.Set(FI, 0.0, FPVI10_10V, FPVI10_1A, RELAY_ON);
	delay_ms(3);

	DIOExpressWriteData(0x21, 0x00);
	delay_ms(1);
	dio.Disconnect();
	delay_ms(1);

	cbit.SetCBITOff(K5);//EN_to_op07_to_FOVI0
	delay_ms(3);
	cbit.SetCBITOn(K4);//FOVI0_to_EN
	delay_ms(3);

	VIN.Set(FV, 0.0, FPVI10_10V, FPVI10_1A, RELAY_ON);
	EN.Set(FV, 0.0, FOVI_10V, FOVI_10MA, RELAY_ON);
	VOUT.Set(FV, 0.0, FOVI_10V, FOVI_100MA, RELAY_ON);
	//I2CPUP.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_ON);
	LX.Set(FV, 0.0, FPVI10_10V, FPVI10_1A, RELAY_ON);
	delay_ms(3);

///ZCS_Reg27_vin3p6///ZCS_post_vin3p6
	LX.Set(FI, 0.0, FPVI10_10V, FPVI10_1A, RELAY_ON);
	VOUT.Set(FV, 3.6, FOVI_10V, FOVI_100MA, RELAY_ON);
	VIN.Set(FV, 3.6, FPVI10_10V, FPVI10_1A, RELAY_ON, 3);
	delay_ms(10);
	EN.Set(FV, 3.6, FOVI_10V, FOVI_10MA, RELAY_ON, 2);
	delay_ms(3);
	dio.Connect();
	delay_ms(3);

	DIOExpressWriteData(0x6a, 0x5a);
	delay_ms(1);
	DIOExpressWriteData(0x6a, 0xa5);
	delay_ms(1);

	if (AllSimCOde == 1)
	{
		DIOExpressWriteData(0x47, vbg_code[0]);	delay_ms(1);
		DIOExpressWriteData(0x40, vref_eaout_code[0]);	delay_ms(1);
		DIOExpressWriteData(0x41, ibias_code[0] + fosc_code[0]);	delay_ms(1);
		DIOExpressWriteData(0x48, rsns_code[0]);	delay_ms(1);
		DIOExpressWriteData(0x42, hscl_code[0] + vcl_code[0]);	delay_ms(1);
		DIOExpressWriteData(0x43, zcs_code[0] + ton_code[0]);		delay_ms(1);
	}

	//	DIOExpressWriteData(0x23,0x90);
	//	delay_ms(3);
	//	DIOExpressReadData(0x29);
	//	delay_ms(1);

	EN.Set(FV, 0.0, FOVI_10V, FOVI_10MA, RELAY_ON);
	delay_ms(3);
	EN.Set(FI, 0.0, FOVI_10V, FOVI_100UA, RELAY_SENSE_ON);
	delay_ms(3);

	cbit.SetCBITOn(K3);//EN_DIO
	delay_ms(3);
	DIOExpressWriteData(0x23, 0x90);   delay_ms(1);
	Rdata1[0] = DIOExpressReadData(0x27);
	ZCS_Reg27_vin3p6->SetTestResult(0, 0, (Rdata1[0] & 0x0F));


	if (AllSimCOde == 2)
	{
		Rdata1[0] = DIOExpressReadData(0x43);
		Rdata1[1] = Rdata1[0] & 0xF0;
		DIOExpressWriteData(0x43, zcs_code[0] + Rdata1[1]);	delay_ms(1);
	}



	cbit.SetCBITOff(K3);//EN_DIO

	cbit.SetCBITOff(K4);//FOVI0_to_EN
	delay_ms(3);
	cbit.SetCBITOn(K5);//EN_to_op07_to_FOVI0
	delay_ms(3);

	DIOExpressWriteData(0x25, 0x50);
	delay_ms(1);
	//DIOExpressWriteData(0x26,0xE0);
	delay_ms(1);
	DIOExpressWriteData(0x23, 0x8C);
	delay_ms(1);

	Trig_Point[0] = 0;
	Trig_Point[1] = 0;
	i = 0;
	m = 0;
	zcs_post[0] = 0;
	zcs_post[1] = 0;

	LX.Set(FI, -0.01, FPVI10_10V, FPVI10_1A, RELAY_ON);

	LX.AwgLoader("zcs_post", FI, FPVI10_10V, FPVI10_1A, zcs_Data, sam);
	LX.AwgSelect("zcs_post", 0, sam - 1, 0, interval);

	EN.SetMeasVTrig(Trig, TRIG_FALLING);
	EN.MeasureVI(sam, interval, MEAS_AWG);
	LX.MeasureVI(sam, interval, MEAS_AWG);

	//*
	STSEnableAWG(&LX);
	STSEnableMeas(&EN, &LX);
	STSAWGRunTriggerStop(&EN, &EN, &LX);
	//StsAWGRun();
	/*/
	VIN.MeasureVI(sam, interval, MEAS_AWG);
	STSEnableAWG(&LX);
	STSEnableMeas(&EN, &LX, &VIN);
	STSAWGRunTriggerStop(&EN, &EN, &LX,&VIN);
	//StsAWGRun();
	//*/

	Trig_Point[0] = EN.GetMeasResult(0, MVRET, TRIG_RESULT);
	m = Trig_Point[0] - 1;
	if (m<2)
	{
		zcs_post[0] = -777;
	}
	else if (m>sam - 3)
	{
		zcs_post[0] = -999;

	}
	else
	{
		zcs_post[0] = 1e3f*zcs_Data[m];//FPVIO+FPVI1

	}

	ZCS_post_vin3p6->SetTestResult(0, 0, -zcs_post[0]);

	LX.Set(FI, 0.0, FPVI10_10V, FPVI10_1A, RELAY_ON);
	delay_ms(3);

	DIOExpressWriteData(0x21, 0x00);
	delay_ms(1);
	dio.Disconnect();
	delay_ms(1);

	cbit.SetCBITOff(K5);//EN_to_op07_to_FOVI0
	delay_ms(3);
	cbit.SetCBITOn(K4);//FOVI0_to_EN
	delay_ms(3);

	VIN.Set(FV, 0.0, FPVI10_10V, FPVI10_1A, RELAY_ON);
	EN.Set(FV, 0.0, FOVI_10V, FOVI_10MA, RELAY_ON);
	VOUT.Set(FV, 0.0, FOVI_10V, FOVI_100MA, RELAY_ON);
	//I2CPUP.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_ON);
	LX.Set(FV, 0.0, FPVI10_10V, FPVI10_1A, RELAY_ON);
	delay_ms(3);

///ZCS_Reg27_vin5p5///ZCS_post_vin5p5
	LX.Set(FI, 0.0, FPVI10_10V, FPVI10_1A, RELAY_ON);
	VOUT.Set(FV, 3.6, FOVI_10V, FOVI_100MA, RELAY_ON);
	VIN.Set(FV, 5.5, FPVI10_10V, FPVI10_1A, RELAY_ON, 3);
	delay_ms(10);
	EN.Set(FV, 3.6, FOVI_10V, FOVI_10MA, RELAY_ON, 2);
	delay_ms(3);
	dio.Connect();
	delay_ms(3);

	DIOExpressWriteData(0x6a, 0x5a);
	delay_ms(1);
	DIOExpressWriteData(0x6a, 0xa5);
	delay_ms(1);

	if (AllSimCOde == 1)
	{
		DIOExpressWriteData(0x47, vbg_code[0]);	delay_ms(1);
		DIOExpressWriteData(0x40, vref_eaout_code[0]);	delay_ms(1);
		DIOExpressWriteData(0x41, ibias_code[0] + fosc_code[0]);	delay_ms(1);
		DIOExpressWriteData(0x48, rsns_code[0]);	delay_ms(1);
		DIOExpressWriteData(0x42, hscl_code[0] + vcl_code[0]);	delay_ms(1);
		DIOExpressWriteData(0x43, zcs_code[0] + ton_code[0]);		delay_ms(1);
	}

	//	DIOExpressWriteData(0x23,0x90);
	//	delay_ms(3);
	//	DIOExpressReadData(0x29);
	//	delay_ms(1);

	EN.Set(FV, 0.0, FOVI_10V, FOVI_10MA, RELAY_ON);
	delay_ms(3);
	EN.Set(FI, 0.0, FOVI_10V, FOVI_100UA, RELAY_SENSE_ON);
	delay_ms(3);

	cbit.SetCBITOn(K3);//EN_DIO
	delay_ms(3);
	DIOExpressWriteData(0x23, 0x90);   delay_ms(1);
	Rdata1[0] = DIOExpressReadData(0x27);
	ZCS_Reg27_vin5p5->SetTestResult(0, 0, (Rdata1[0] & 0x0F));


	if (AllSimCOde == 2)
	{
		Rdata1[0] = DIOExpressReadData(0x43);
		Rdata1[1] = Rdata1[0] & 0xF0;
		DIOExpressWriteData(0x43, zcs_code[0] + Rdata1[1]);	delay_ms(1);
	}



	cbit.SetCBITOff(K3);//EN_DIO

	cbit.SetCBITOff(K4);//FOVI0_to_EN
	delay_ms(3);
	cbit.SetCBITOn(K5);//EN_to_op07_to_FOVI0
	delay_ms(3);

	DIOExpressWriteData(0x25, 0x50);
	delay_ms(1);
	//DIOExpressWriteData(0x26,0xE0);
	delay_ms(1);
	DIOExpressWriteData(0x23, 0x8C);
	delay_ms(1);

	Trig_Point[0] = 0;
	Trig_Point[1] = 0;
	i = 0;
	m = 0;
	zcs_post[0] = 0;
	zcs_post[1] = 0;

	LX.Set(FI, -0.01, FPVI10_10V, FPVI10_1A, RELAY_ON);

	LX.AwgLoader("zcs_post", FI, FPVI10_10V, FPVI10_1A, zcs_Data, sam);
	LX.AwgSelect("zcs_post", 0, sam - 1, 0, interval);

	EN.SetMeasVTrig(Trig, TRIG_FALLING);
	EN.MeasureVI(sam, interval, MEAS_AWG);
	LX.MeasureVI(sam, interval, MEAS_AWG);

	//*
	STSEnableAWG(&LX);
	STSEnableMeas(&EN, &LX);
	STSAWGRunTriggerStop(&EN, &EN, &LX);
	//StsAWGRun();
	/*/
	VIN.MeasureVI(sam, interval, MEAS_AWG);
	STSEnableAWG(&LX);
	STSEnableMeas(&EN, &LX, &VIN);
	//STSAWGRunTriggerStop(&EN, &EN, &LX,&VIN);
	StsAWGRun();
	//*/

	Trig_Point[0] = EN.GetMeasResult(0, MVRET, TRIG_RESULT);
	m = Trig_Point[0] - 1;
	if (m<2)
	{
		zcs_post[0] = -777;
	}
	else if (m>sam - 3)
	{
		zcs_post[0] = -999;

	}
	else
	{
		zcs_post[0] = 1e3f*zcs_Data[m];//FPVIO+FPVI1

	}

	ZCS_post_vin5p5->SetTestResult(0, 0, -zcs_post[0]);

	LX.Set(FI, 0.0, FPVI10_10V, FPVI10_1A, RELAY_ON);
	delay_ms(3);

	DIOExpressWriteData(0x21, 0x00);
	delay_ms(1);
	dio.Disconnect();
	delay_ms(1);

	cbit.SetCBITOff(K5);//EN_to_op07_to_FOVI0
	delay_ms(3);
	cbit.SetCBITOn(K4);//FOVI0_to_EN
	delay_ms(3);

	VIN.Set(FV, 0.0, FPVI10_10V, FPVI10_1A, RELAY_ON);
	EN.Set(FV, 0.0, FOVI_10V, FOVI_10MA, RELAY_ON);
	VOUT.Set(FV, 0.0, FOVI_10V, FOVI_100MA, RELAY_ON);
	//I2CPUP.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_ON);
	LX.Set(FV, 0.0, FPVI10_10V, FPVI10_1A, RELAY_ON);
	delay_ms(3);

	VOUT.Set(FV, 0.0, FOVI_10V, FOVI_100MA, RELAY_OFF);
	LX.Set(FV, 0.0, FPVI10_10V, FPVI10_1A, RELAY_OFF);
	VIN.Set(FV, 0.0, FPVI10_10V, FPVI10_1A, RELAY_OFF);
	EN.Set(FV, 0.0, FOVI_10V, FOVI_10MA, RELAY_OFF);
	//I2CPUP.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_OFF);
	delay_ms(3);
	cbit.SetOn(-1);
	delay_ms(3);


    return 0;
}


DUT_API int T30_RDSON(short funcindex, LPCTSTR funclabel)
{
    //{{AFX_STS_PARAM_PROTOTYPES
    CParam *HS_RDSON = StsGetParam(funcindex,"HS_RDSON");
    CParam *LS_RDSON = StsGetParam(funcindex,"LS_RDSON");
    //}}AFX_STS_PARAM_PROTOTYPES

    // TODO: Add your function code here
	cbit.SetOn(K2,/*K3,*/K4,K8,K13,-1);
	delay_ms(3);

	dio.Connect();
	delay_ms(1);

	//I2CPUP.Set(FV, 3.6, FOVI_5V, FOVI_100MA, RELAY_ON);
	VIN.Set(FV, 3.6, FPVI10_5V, FPVI10_1A, RELAY_ON);
	EN.Set(FV, 3.6, FOVI_5V, FOVI_100MA, RELAY_ON);
	delay_ms(3);

	DIOExpressWriteData(0x6a,0x5a);
	delay_ms(1);
	DIOExpressWriteData(0x6a,0xa5);
	delay_ms(3);

	EN.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_ON);
	delay_ms(3);
	EN.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_OFF);
	delay_ms(3);

/*	DIOExpressWriteData(0x23,0x90);
	delay_ms(3);
	DIOExpressReadData(0x29);
	delay_ms(1);
*/
	DIOExpressWriteData(0x25,0x20);
	delay_ms(1);

	LX.Set(FI, -0.15, FPVI10_5V, FPVI10_1A, RELAY_ON);
	delay_ms(3);

	LX.MeasureVI(50, 50);
	delay_ms(3);
	adresult[0] = LX.GetMeasResult(0, MVRET);
	VIN.MeasureVI(50, 50);
	delay_ms(3);
	adresult1[0] = VIN.GetMeasResult(0, MVRET);

	HS_RDSON->SetTestResult(0, 0, (adresult1[0]-adresult[0])/0.15*1000);

	LX.Set(FI, -0.0, FPVI10_5V, FPVI10_1A, RELAY_ON);
	delay_ms(3);

	DIOExpressWriteData(0x25,0x40);
	delay_ms(1);

	LX.Set(FI, -0.15, FPVI10_5V, FPVI10_1A, RELAY_ON);
	delay_ms(3);

	LX.MeasureVI(50, 50);
	delay_ms(3);
	adresult[0] = LX.GetMeasResult(0, MVRET);

	LS_RDSON->SetTestResult(0, 0, -adresult[0]/0.15*1000);

	LX.Set(FI, 0.0, FPVI10_5V, FPVI10_1A, RELAY_ON);
	delay_ms(3);

	DIOExpressWriteData(0x21,0x00);
	delay_ms(1);
	dio.Disconnect();
	delay_ms(1);

	VIN.Set(FV, 0.0, FPVI10_5V, FPVI10_1A, RELAY_ON);
	EN.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_ON);
	//I2CPUP.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_ON);
	LX.Set(FV, 0.0, FPVI10_5V, FPVI10_1A, RELAY_ON);
	delay_ms(3);
	VIN.Set(FV, 0.0, FPVI10_5V, FPVI10_1A, RELAY_OFF);
	EN.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_OFF);
	//I2CPUP.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_OFF);
	LX.Set(FV, 0.0, FPVI10_5V, FPVI10_1A, RELAY_OFF);
	delay_ms(3);
	cbit.SetOn(-1);
	delay_ms(3);

    return 0;
}


DUT_API int T31_EA_OFFSET(short funcindex, LPCTSTR funclabel)
{
    //{{AFX_STS_PARAM_PROTOTYPES
    CParam *EA_offset = StsGetParam(funcindex,"EA_offset");
    //}}AFX_STS_PARAM_PROTOTYPES

    // TODO: Add your function code here
	cbit.SetOn(K2,/*K3,*/K4,K11,K12,K13,-1);//K3 is used for read
	delay_ms(3);
	dio.Connect();
	delay_ms(1);

	VOUT.Set(FV, 3.6, FOVI_5V, FOVI_100MA, RELAY_ON);
	//I2CPUP.Set(FV, 3.6, FOVI_5V, FOVI_100MA, RELAY_ON);
	VIN.Set(FV, 3.6, FPVI10_5V, FPVI10_100MA, RELAY_ON);
	EN.Set(FV, 3.6, FOVI_5V, FOVI_100MA, RELAY_ON);
	delay_ms(3);

	DIOExpressWriteData(0x6a,0x5a);
	delay_ms(1);
	DIOExpressWriteData(0x6a,0xa5);
	delay_ms(3);

	EN.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_ON);
	delay_ms(3);
	EN.Set(FI, 0.0, FOVI_5V, FOVI_100UA, RELAY_ON);
	delay_ms(3);

	cbit.SetCBITOff(K4);
	cbit.SetCBITOn(K5);
	delay_ms(3);

	EN.Set(FI, 0.0, FOVI_5V, FOVI_100UA, RELAY_ON);
	delay_ms(3);

	DIOExpressWriteData(0x25,0x0D);
	delay_ms(1);
	DIOExpressWriteData(0x23,0xC9);
	delay_ms(1);

	EN.MeasureVI(50, 50);
	delay_ms(3);
	adresult[0] = EN.GetMeasResult(0, MVRET);

	EA_offset->SetTestResult(0, 0, adresult[0]);


	DIOExpressWriteData(0x6a,0x00);
	delay_ms(1);
	dio.Disconnect();
	delay_ms(1);

	VOUT.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_ON);
	VIN.Set(FV, 0.0, FPVI10_5V, FPVI10_100MA, RELAY_ON);
	EN.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_ON);
	//I2CPUP.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_ON);
	delay_ms(3);
	VOUT.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_OFF);
	VIN.Set(FV, 0.0, FPVI10_5V, FPVI10_100MA, RELAY_OFF);
	EN.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_OFF);
	//I2CPUP.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_OFF);
	delay_ms(3);
	cbit.SetOn(-1);
	delay_ms(3);

    return 0;
}


DUT_API int T32_Comparator(short funcindex, LPCTSTR funclabel)
{
    //{{AFX_STS_PARAM_PROTOTYPES
    CParam *PWM_Comparator_L = StsGetParam(funcindex,"PWM_Comparator_L");
    CParam *PWM_Comparator_H = StsGetParam(funcindex,"PWM_Comparator_H");
    CParam *PFM_Comparator_L = StsGetParam(funcindex,"PFM_Comparator_L");
    CParam *PFM_Comparator_H = StsGetParam(funcindex,"PFM_Comparator_H");
    //}}AFX_STS_PARAM_PROTOTYPES

    // TODO: Add your function code here
	cbit.SetOn(K2,/*K3,*/K4,K8,K11,K12,K13,-1);
	delay_ms(3);
	dio.Connect();
	delay_ms(1);

	//I2CPUP.Set(FV, 3.6, FOVI_5V, FOVI_100MA, RELAY_ON);
	VIN.Set(FV, 3.6, FPVI10_5V, FPVI10_100MA, RELAY_ON);
	EN.Set(FV, 3.6, FOVI_5V, FOVI_100MA, RELAY_ON);
	delay_ms(3);

	DIOExpressWriteData(0x6a,0x5a);
	delay_ms(1);
	DIOExpressWriteData(0x6a,0xa5);
	delay_ms(1);

	DIOExpressWriteData(0x23,0x90);
	delay_ms(3);

	EN.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_ON);
	delay_ms(3);
	EN.Set(FI, 0.0, FOVI_5V, FOVI_100MA, RELAY_ON);
	delay_ms(3);



	DIOExpressWriteData(0x25,0x01);
	delay_ms(1);
	DIOExpressWriteData(0x26,0x04);
	delay_ms(1);
	DIOExpressWriteData(0x23,0x0C);
	delay_ms(1);


	LX.Set(FV, 1.22, FPVI10_5V, FPVI10_100MA, RELAY_ON);
	VOUT.Set(FV, 1.22, FOVI_2V, FOVI_100MA, RELAY_ON);
	delay_ms(3);

	EN.MeasureVI(500, 50);
	delay_ms(3);

	adresult[0] = EN.GetMeasResult(0, MVRET);

	PWM_Comparator_L->SetTestResult(0, 0, adresult[0]);

	LX.Set(FV, 1.18, FPVI10_5V, FPVI10_100MA, RELAY_ON);
	VOUT.Set(FV, 1.18, FOVI_2V, FOVI_100MA, RELAY_ON);
	delay_ms(3);


	EN.MeasureVI(500, 50);
	delay_ms(3);
	adresult[0] = EN.GetMeasResult(0, MVRET);

	PWM_Comparator_H->SetTestResult(0, 0, adresult[0]);

	DIOExpressWriteData(0x6a,0x00);
	delay_ms(1);
	dio.Disconnect();
	delay_ms(1);

	LX.Set(FV, 0.0, FPVI10_5V, FPVI10_100MA, RELAY_ON);
	VOUT.Set(FV, 0.0, FOVI_2V, FOVI_100MA, RELAY_ON);
	VIN.Set(FV, 0.0, FPVI10_5V, FPVI10_100MA, RELAY_ON);
	EN.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_ON);
	//I2CPUP.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_ON);
	delay_ms(3);
	LX.Set(FV, 0.0, FPVI10_5V, FPVI10_100MA, RELAY_OFF);
	VOUT.Set(FV, 0.0, FOVI_1V, FOVI_100MA, RELAY_OFF);
	VIN.Set(FV, 0.0, FPVI10_5V, FPVI10_100MA, RELAY_OFF);
	EN.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_OFF);
	//I2CPUP.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_OFF);
	delay_ms(3);
	cbit.SetOn(-1);
	delay_ms(3);


	cbit.SetOn(K2,/*K3,*/K4,K8,K11,K12,K13,-1);
	delay_ms(3);
	dio.Connect();
	delay_ms(1);

	//I2CPUP.Set(FV, 3.6, FOVI_5V, FOVI_100MA, RELAY_ON);
	VIN.Set(FV, 3.6, FPVI10_5V, FPVI10_100MA, RELAY_ON);
	EN.Set(FV, 3.6, FOVI_5V, FOVI_100MA, RELAY_ON);
	delay_ms(3);

	DIOExpressWriteData(0x6a,0x5a);
	delay_ms(1);
	DIOExpressWriteData(0x6a,0xa5);
	delay_ms(1);

	DIOExpressWriteData(0x23,0x90);
	delay_ms(3);

	EN.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_ON);
	delay_ms(3);
	EN.Set(FI, 0.0, FOVI_5V, FOVI_100MA, RELAY_ON);
	delay_ms(3);

	DIOExpressWriteData(0x25,0x09);
	delay_ms(1);
	DIOExpressWriteData(0x23,0x0C);
	delay_ms(1);

	LX.Set(FV, 1.22, FPVI10_5V, FPVI10_100MA, RELAY_ON);
	VOUT.Set(FV, 1.22, FOVI_2V, FOVI_100MA, RELAY_ON);
	delay_ms(3);

	EN.MeasureVI(500, 50);
	delay_ms(3);

	adresult[0] = EN.GetMeasResult(0, MVRET);

	PFM_Comparator_L->SetTestResult(0, 0, adresult[0]);

	LX.Set(FV, 1.18, FPVI10_5V, FPVI10_100MA, RELAY_ON);
	VOUT.Set(FV, 1.18, FOVI_2V, FOVI_100MA, RELAY_ON);
	delay_ms(3);


	EN.MeasureVI(500, 50);
	delay_ms(3);
	adresult[0] = EN.GetMeasResult(0, MVRET);

	PFM_Comparator_H->SetTestResult(0, 0, adresult[0]);

	DIOExpressWriteData(0x6a,0x00);
	delay_ms(1);
	dio.Disconnect();
	delay_ms(1);

	LX.Set(FV, 0.0, FPVI10_5V, FPVI10_100MA, RELAY_ON);
	VOUT.Set(FV, 0.0, FOVI_2V, FOVI_100MA, RELAY_ON);
	VIN.Set(FV, 0.0, FPVI10_5V, FPVI10_100MA, RELAY_ON);
	EN.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_ON);
	//I2CPUP.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_ON);
	delay_ms(3);
	LX.Set(FV, 0.0, FPVI10_5V, FPVI10_100MA, RELAY_OFF);
	VOUT.Set(FV, 0.0, FOVI_1V, FOVI_100MA, RELAY_OFF);
	VIN.Set(FV, 0.0, FPVI10_5V, FPVI10_100MA, RELAY_OFF);
	EN.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_OFF);
	//I2CPUP.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_OFF);
	delay_ms(3);
	cbit.SetOn(-1);
	delay_ms(3);
    return 0;
}


DUT_API int T33_Neg_CL(short funcindex, LPCTSTR funclabel)
{
    //{{AFX_STS_PARAM_PROTOTYPES
    CParam *neg_CL = StsGetParam(funcindex,"neg_CL");
    //}}AFX_STS_PARAM_PROTOTYPES

    // TODO: Add your function code here
	cbit.SetOn(K2,/*K3,*/K4,K8,K13,-1);//K3 is used for read
	delay_ms(3);
	dio.Connect();
	delay_ms(1);

	//I2CPUP.Set(FV, 3.6, FOVI_5V, FOVI_100MA, RELAY_ON);
	VIN.Set(FV, 3.6, FPVI10_5V, FPVI10_1A, RELAY_ON);
	EN.Set(FV, 3.6, FOVI_5V, FOVI_100MA, RELAY_ON);
	delay_ms(3);

	DIOExpressWriteData(0x6a,0x5a);
	delay_ms(1);
	DIOExpressWriteData(0x6a,0xa5);
	delay_ms(1);

	EN.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_ON);
	delay_ms(3);
	EN.Set(FI, 0.0, FOVI_5V, FOVI_100UA, RELAY_ON);
	delay_ms(3);


	DIOExpressWriteData(0x25,0x50);
	delay_ms(1);
	DIOExpressWriteData(0x26,0xE4);
	delay_ms(1);
	DIOExpressWriteData(0x23,0x0E);
	delay_ms(1);

	double Trig = 1;//trigger level
	double Trig_Point[2] = { 0 };
	double result[2] = { 0 };
	int sam = 89; //awgSize
	int interval = 200; //awgInterval��unit=us
	double ncl_Data[100] = { 0.0 };
	int i = 0;
	int	m = 0;

	double ncl[2] = { 0.0 };

	LX.Set(FI, 0.05, FPVI10_5V, FPVI10_1A, RELAY_ON);

	STSAWGCreateRampData(&ncl_Data[0], sam, 1, 0.03, 0.47);
	LX.AwgLoader("neg_cl", FI, FPVI10_5V, FPVI10_1A, ncl_Data, sam);
	LX.AwgSelect("neg_cl", 0, sam - 1, 0, interval);

	EN.SetMeasVTrig(Trig, TRIG_RISING);
	EN.MeasureVI(sam, interval, MEAS_AWG);
	LX.MeasureVI(sam, interval, MEAS_AWG);

	STSEnableAWG(&LX);
	STSEnableMeas(&EN, &LX);
	STSAWGRunTriggerStop(&EN, &EN, &LX);

	//	StsAWGRun();


		Trig_Point[0] = EN.GetMeasResult(0, MVRET, TRIG_RESULT);
		m = Trig_Point[0] - 1;
		if (m<2)
		{
			ncl[0] = -777;
		}
		else if (m>sam - 3)
		{
			ncl[0] = -999;

		}
		else
		{
			ncl[0] = 1e3f*ncl_Data[m] ;//FPVIO+FPVI1

		}


		neg_CL->SetTestResult(0, 0, ncl[0]);


	LX.Set(FI, 0.0, FPVI10_5V, FPVI10_1A, RELAY_ON);
	delay_ms(3);

	DIOExpressWriteData(0x21,0x00);
	delay_ms(1);

	dio.Disconnect();
	delay_ms(1);

	VIN.Set(FV, 0.0, FPVI10_5V, FPVI10_1A, RELAY_ON);
	EN.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_ON);
	//I2CPUP.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_ON);
	LX.Set(FV, 0.0, FPVI10_5V, FPVI10_1A, RELAY_ON);
	delay_ms(3);
	VIN.Set(FV, 0.0, FPVI10_5V, FPVI10_1A, RELAY_OFF);
	EN.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_OFF);
	//I2CPUP.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_OFF);
	LX.Set(FV, 0.0, FPVI10_5V, FPVI10_1A, RELAY_OFF);
	delay_ms(3);
	cbit.SetOn(-1);
	delay_ms(3);

    return 0;
}


DUT_API int T34_Iin(short funcindex, LPCTSTR funclabel)
{
    //{{AFX_STS_PARAM_PROTOTYPES
    CParam *IQ_3p6 = StsGetParam(funcindex,"IQ_3p6");
    CParam *IQ_5p5 = StsGetParam(funcindex,"IQ_5p5");
    CParam *IQ_2p5 = StsGetParam(funcindex,"IQ_2p5");
    CParam *Ishdn_3p6 = StsGetParam(funcindex,"Ishdn_3p6");
    CParam *Ishdn_5p5 = StsGetParam(funcindex,"Ishdn_5p5");
    CParam *Ishdn_2p7 = StsGetParam(funcindex,"Ishdn_2p7");
    //}}AFX_STS_PARAM_PROTOTYPES

    // TODO: Add your function code here
	cbit.SetOn(K1,K2,/*K3,*/K4,K11,K12,K13,-1);//K3 is used for read
	delay_ms(3);
	dio.Connect();
	delay_ms(1);

	VOUT.Set(FV, 3.6, FOVI_10V, FOVI_100MA, RELAY_ON);
	//I2CPUP.Set(FV, 1.0, FOVI_5V, FOVI_100MA, RELAY_ON);
	VIN.Set(FV, 3.6, FPVI10_10V, FPVI10_100MA, RELAY_ON);
	EN.Set(FV, 3.6, FOVI_5V, FOVI_100MA, RELAY_ON);
	delay_ms(3);

	DIOExpressWriteData(0x6a,0x5a);
	delay_ms(1);
	DIOExpressWriteData(0x6a,0xa5);
	delay_ms(3);

	//DIOExpressWriteData(0x23,0x90);
	//delay_ms(3);
	//DIOExpressReadData(0x29);
	//delay_ms(1);

	DIOExpressWriteData(0x25,0x08);
	delay_ms(1);
	DIOExpressWriteData(0x6a,0x00);
	delay_ms(1);

	MODE.Set(FV, 0.0, FOVI_10V, FOVI_100MA, RELAY_ON);
	VIN.Set(FV, 3.6, FPVI10_10V, FPVI10_10MA, RELAY_ON);
	delay_ms(20);

	//DIOExpressWriteData(0x23,0x90);
	//delay_ms(3);
	//DIOExpressReadData(0x29);
	//delay_ms(1);
	//VOUT.MeasureVI(500, 50);
	//delay_ms(3);
	VIN.MeasureVI(100, 50);
	delay_ms(3);
	adresult[0] = VIN.GetMeasResult(0, MIRET);

	IQ_3p6->SetTestResult(0, 0, adresult[0]*1e6f);

#if 1
	EN.Set(FV, 2.7, FOVI_5V, FOVI_100MA, RELAY_ON);
	delay_ms(3);
	VIN.Set(FV, 2.7, FPVI10_10V, FPVI10_10MA, RELAY_ON);
	VOUT.Set(FV, 2.7, FOVI_10V, FOVI_100MA, RELAY_ON);
	delay_ms(20);


	VIN.MeasureVI(100, 50);
	delay_ms(3);
	adresult[0] = VIN.GetMeasResult(0, MIRET);

	IQ_2p5->SetTestResult(0, 0, adresult[0]*1e6f);

//	EN.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_ON);
//	delay_ms(3);

	VIN.Set(FV, 5.5, FPVI10_10V, FPVI10_10MA, RELAY_ON);
	VOUT.Set(FV, 5.5, FOVI_10V, FOVI_100MA, RELAY_ON);
	EN.Set(FV, 5.5, FOVI_5V, FOVI_100MA, RELAY_ON);
	delay_ms(20);

	VIN.MeasureVI(100, 50);
	delay_ms(3);
	adresult[0] = VIN.GetMeasResult(0, MIRET);

	IQ_5p5->SetTestResult(0, 0, adresult[0]*1e6f);

#endif

	DIOExpressWriteData(0x6a,0x00);
	delay_ms(1);
	dio.Disconnect();
	delay_ms(1);
	MODE.Set(FV, 0.0, FOVI_10V, FOVI_100MA, RELAY_ON);
	VOUT.Set(FV, 0.0, FOVI_1V, FOVI_100MA, RELAY_ON);
	VIN.Set(FV, 0.0, FPVI10_5V, FPVI10_100MA, RELAY_ON);
	EN.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_ON);
	//I2CPUP.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_ON);
	delay_ms(3);


	cbit.SetOn(K1,K4,K8,K11,/*K12,K13,*/-1);
	delay_ms(3);

	EN.Set(FV, 0.0, FOVI_10V, FOVI_100UA, RELAY_ON);
//	VOUT.Set(FV, 0.0, FOVI_5V, FOVI_10MA, RELAY_ON);
	MODE.Set(FV, 0.0, FOVI_10V, FOVI_100UA, RELAY_ON);
	VIN.Set(FV, 0.0, FPVI10_10V, FPVI10_10MA, RELAY_ON);
//	LX.Set(FV, 0.0, FPVI10_5V, FPVI10_10MA, RELAY_ON);
	delay_ms(3);
	VIN.Set(FV, 5.5, FPVI10_10V, FPVI10_10MA, RELAY_ON);
	delay_ms(3);
	VIN.Set(FV, 5.5, FPVI10_10V, FPVI10_1MA, RELAY_ON);
	delay_ms(3);

	VIN.MeasureVI(50, 50);
	delay_ms(3);
	adresult[0] = VIN.GetMeasResult(0, MIRET);

	Ishdn_5p5->SetTestResult(0, 0, adresult[0]*1e6f);

	VIN.Set(FV, 3.6, FPVI10_10V, FPVI10_1MA, RELAY_ON);
	delay_ms(3);

	VIN.MeasureVI(50, 50);
	delay_ms(3);
	adresult[0] = VIN.GetMeasResult(0, MIRET);

	Ishdn_3p6->SetTestResult(0, 0, adresult[0]*1e6f);

	VIN.Set(FV, 2.7, FPVI10_10V, FPVI10_1MA, RELAY_ON);
	delay_ms(3);

	VIN.MeasureVI(50, 50);
	delay_ms(3);
	adresult[0] = VIN.GetMeasResult(0, MIRET);

	Ishdn_2p7->SetTestResult(0, 0, adresult[0]*1e6f);

	VOUT.Set(FV, 0.0, FOVI_1V, FOVI_100MA, RELAY_ON);
	VIN.Set(FV, 0.0, FPVI10_5V, FPVI10_100MA, RELAY_ON);
	EN.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_ON);
	//I2CPUP.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_ON);
	delay_ms(3);
	VOUT.Set(FV, 0.0, FOVI_1V, FOVI_100MA, RELAY_OFF);
	VIN.Set(FV, 0.0, FPVI10_5V, FPVI10_100MA, RELAY_OFF);
	EN.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_OFF);
	//I2CPUP.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_OFF);
	delay_ms(3);
	cbit.SetOn(-1);
	delay_ms(3);

    return 0;
}


DUT_API int T35_UVLO_Search(short funcindex, LPCTSTR funclabel)
{
    //{{AFX_STS_PARAM_PROTOTYPES
    CParam *UVLO_R = StsGetParam(funcindex,"UVLO_R");
    CParam *UVLO_F = StsGetParam(funcindex,"UVLO_F");
    CParam *UVLO_hys = StsGetParam(funcindex,"UVLO_hys");
    //}}AFX_STS_PARAM_PROTOTYPES

    // TODO: Add your function code here
	cbit.SetOn(K2,/*K3,*/K4,K13,-1);
	delay_ms(3);
	dio.Connect();
	delay_ms(3);

	//I2CPUP.Set(FV, 3.6, FOVI_5V, FOVI_100MA, RELAY_ON);
	VIN.Set(FV, 3.6, FPVI10_5V, FPVI10_100MA, RELAY_ON);
	EN.Set(FV, 3.6, FOVI_5V, FOVI_100MA, RELAY_ON);
	delay_ms(3);

	DIOExpressWriteData(0x6a,0x5a);
	delay_ms(1);
	DIOExpressWriteData(0x6a,0xa5);
	delay_ms(1);

	EN.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_ON);
	delay_ms(3);
	EN.Set(FI, 0.0, FOVI_5V, FOVI_100UA, RELAY_ON);
	delay_ms(3);

	//cbit.SetCBITOff(K4);
	//cbit.SetCBITOn(K5);
	//delay_ms(3);

	DIOExpressWriteData(0x24,0x04);
	delay_ms(1);
	DIOExpressWriteData(0x23,0x4A);
	delay_ms(1);

	double uvlo_f[2] = { 0 };
	double Trig = 1;//trigger level
	double Trig_Point[2] = { 0 };
	double result[2] = { 0 };
	int sam = 31; //awgSize
	int interval = 500; //awgInterval��unit=us
	double UVLO_f_Data[100] = { 0.0 };
	int i = 0;
	int	m = 0;
#if 1
	STSAWGCreateRampData(&UVLO_f_Data[0], sam, 1, 2.6, 2.0);
	VIN.AwgLoader("UVLO_f_Data", FV, FPVI10_5V, FPVI10_100MA, UVLO_f_Data, sam);
	VIN.AwgSelect("UVLO_f_Data", 0, sam - 1, sam -1, interval);
	EN.SetMeasVTrig(Trig, TRIG_FALLING);
	VIN.MeasureVI(sam, interval, MEAS_AWG);
	EN.MeasureVI(sam, interval, MEAS_AWG);

	STSEnableAWG(&VIN);
	STSEnableMeas(&VIN, &EN);
	//STSAWGRunTriggerStop(&EN, &VIN, &EN);
	StsAWGRun();

		Trig_Point[0] = EN.GetMeasResult(0, MVRET, TRIG_RESULT);
		m = Trig_Point[0] - 1;
		if (m<2)
		{
			uvlo_f[0] = -777;
		}
		else if (m>sam - 3)
		{
			uvlo_f[0] = -999;

		}
		else
		{
			uvlo_f[0] = UVLO_f_Data[m];//FPVIO+FPVI1

		}

		UVLO_F->SetTestResult(0, 0, uvlo_f[0]);
#endif

#if 1
	VIN.Set(FV, 2.0, FPVI10_5V, FPVI10_100MA, RELAY_ON, 0.5);
	delay_ms(3);

	double uvlo_r[2] = { 0.0, 0.0 };
	double vx = 0;

	for (vx = 0; vx <= 50; vx++)
	{
		VIN.Set(FV, 2.0 + vx*0.02, FPVI10_5V, FPVI10_100MA, RELAY_ON, 0.5);
		delay_ms(3);
/*		EN.Set(FV, 3.6, FOVI_5V, FOVI_100MA, RELAY_ON);
		delay_ms(1);

		DIOExpressWriteData(0x6a,0x5a);
		DIOExpressWriteData(0x6a,0xa5);

		EN.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_ON);
		delay_ms(1);
		EN.Set(FI, 0.0, FOVI_5V, FOVI_100UA, RELAY_ON);
		delay_ms(1);


		DIOExpressWriteData(0x24,0x04);
		delay_ms(1);
		DIOExpressWriteData(0x23,0x4A);
		delay_ms(1);
*/
		EN.MeasureVI(50, 10);

			adresult[0] = EN.GetMeasResult(0, MVRET);
			if ((adresult[0]>1.8))
			{
				uvlo_r[0] = 2.0 + vx*0.02;
				break;
			}
	
	}

		UVLO_R->SetTestResult(0, 0, uvlo_r[0]);
		UVLO_hys->SetTestResult(0, 0, (uvlo_r[0] - uvlo_f[0]) * 1000);

#endif

	DIOExpressWriteData(0x6a,0x00);
	delay_ms(1);
	dio.Disconnect();
	delay_ms(1);

	VIN.Set(FV, 0.0, FPVI10_5V, FPVI10_100MA, RELAY_ON);
	EN.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_ON);
	//I2CPUP.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_ON);
	delay_ms(3);
	VIN.Set(FV, 0.0, FPVI10_5V, FPVI10_100MA, RELAY_OFF);
	EN.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_OFF);
	//I2CPUP.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_OFF);
	delay_ms(3);
	cbit.SetOn(-1);
	delay_ms(3);

    return 0;
}


DUT_API int T36_UVLO_GNG(short funcindex, LPCTSTR funclabel)
{
    //{{AFX_STS_PARAM_PROTOTYPES
    CParam *UVLO_set = StsGetParam(funcindex,"UVLO_set");
    CParam *UVLO_R1 = StsGetParam(funcindex,"UVLO_R1");
    CParam *UVLO_R2 = StsGetParam(funcindex,"UVLO_R2");
    CParam *UVLO_F1 = StsGetParam(funcindex,"UVLO_F1");
    CParam *UVLO_F2 = StsGetParam(funcindex,"UVLO_F2");
    //}}AFX_STS_PARAM_PROTOTYPES

    // TODO: Add your function code here
	
	cbit.SetOn(K2,/*K3,*/K4,K13,-1);
	delay_ms(3);
	dio.Connect();
	delay_ms(3);

	//I2CPUP.Set(FV, 3.6, FOVI_5V, FOVI_100MA, RELAY_ON);
	VIN.Set(FV, 3.6, FPVI10_5V, FPVI10_100MA, RELAY_ON);
	EN.Set(FV, 3.6, FOVI_5V, FOVI_100MA, RELAY_ON);
	delay_ms(3);

	DIOExpressWriteData(0x6a,0x5a);
	delay_ms(1);
	DIOExpressWriteData(0x6a,0xa5);
	delay_ms(1);

	EN.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_ON);
	delay_ms(3);
	EN.Set(FI, 0.0, FOVI_5V, FOVI_100UA, RELAY_ON);
	delay_ms(3);

	//cbit.SetCBITOff(K4);
	//cbit.SetCBITOn(K5);
	//delay_ms(3);

	DIOExpressWriteData(0x24,0x04);
	delay_ms(1);
	DIOExpressWriteData(0x23,0x4A);
	delay_ms(1);	
	
///UVLO_set
	adresult[0] = 0;
	EN.MeasureVI(10, 10);
	adresult[0] = EN.GetMeasResult(0, MVRET);
	UVLO_set->SetTestResult(0, 0, adresult[0]);	
	
///UVLO_F1		
	adresult[0] = 0;
	VIN.Set(FV, 2.29, FPVI10_5V, FPVI10_100MA, RELAY_ON);
	delay_ms(10);
	EN.MeasureVI(10, 10);
	adresult[0] = EN.GetMeasResult(0, MVRET);
	UVLO_F1->SetTestResult(0, 0, adresult[0]);

///UVLO_F2	
	adresult[0] = 0;
	VIN.Set(FV, 1.91, FPVI10_5V, FPVI10_100MA, RELAY_ON);
	delay_ms(10);
	EN.MeasureVI(10, 10);
	adresult[0] = EN.GetMeasResult(0, MVRET);
	UVLO_F2->SetTestResult(0, 0, adresult[0]);
		
///UVLO_R1		
	adresult[0] = 0;
	VIN.Set(FV, 2.11, FPVI10_5V, FPVI10_100MA, RELAY_ON);
	delay_ms(10);
	EN.MeasureVI(10, 10);
	adresult[0] = EN.GetMeasResult(0, MVRET);
	UVLO_R1->SetTestResult(0, 0, adresult[0]);
		
///UVLO_R2		
	adresult[0] = 0;
	VIN.Set(FV, 2.49, FPVI10_5V, FPVI10_100MA, RELAY_ON);
	delay_ms(10);
	EN.MeasureVI(10, 10);
	adresult[0] = EN.GetMeasResult(0, MVRET);
	UVLO_R2->SetTestResult(0, 0, adresult[0]);
	
//power_off
	DIOExpressWriteData(0x6a,0x00);
	delay_ms(1);
	dio.Disconnect();
	delay_ms(1);

	VIN.Set(FV, 0.0, FPVI10_5V, FPVI10_100MA, RELAY_ON);
	EN.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_ON);
	//I2CPUP.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_ON);
	delay_ms(3);
	VIN.Set(FV, 0.0, FPVI10_5V, FPVI10_100MA, RELAY_OFF);
	EN.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_OFF);
	//I2CPUP.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_OFF);
	delay_ms(3);
	cbit.SetOn(-1);
	delay_ms(3);


	
	
    return 0;
}


DUT_API int T37_OVP_Search(short funcindex, LPCTSTR funclabel)
{
    //{{AFX_STS_PARAM_PROTOTYPES
    CParam *OVP_R = StsGetParam(funcindex,"OVP_R");
    CParam *OVP_F = StsGetParam(funcindex,"OVP_F");
    CParam *OVP_hys = StsGetParam(funcindex,"OVP_hys");
    //}}AFX_STS_PARAM_PROTOTYPES

    // TODO: Add your function code here
	cbit.SetOn(K2,/*K3,*/K4,K13,-1);
	delay_ms(3);
	dio.Connect();
	delay_ms(3);

	//I2CPUP.Set(FV, 3.6, FOVI_5V, FOVI_100MA, RELAY_ON);
	VIN.Set(FV, 5.3, FPVI10_10V, FPVI10_100MA, RELAY_ON);
	EN.Set(FV, 3.6, FOVI_5V, FOVI_100MA, RELAY_ON);
	delay_ms(3);

	DIOExpressWriteData(0x6a,0x5a);
	delay_ms(1);
	DIOExpressWriteData(0x6a,0xa5);
	delay_ms(1);

	EN.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_ON);
	delay_ms(3);
	EN.Set(FI, 0.0, FOVI_5V, FOVI_100UA, RELAY_ON);
	delay_ms(3);

	//cbit.SetCBITOff(K4);
	//cbit.SetCBITOn(K5);
	//delay_ms(3);

	DIOExpressWriteData(0x24,0x04);
	delay_ms(1);
	DIOExpressWriteData(0x23,0x8A);
	delay_ms(1);

	double ovp_r[2] = { 0 };
	double Trig = 3;//trigger level
	double Trig_Point[2] = { 0 };
	double result[2] = { 0 };
	int sam = 31; //awgSize
	int interval = 500; //awgInterval��unit=us
	double ovp_r_Data[100] = { 0.0 };
	int i = 0;
	int	m = 0;

	STSAWGCreateRampData(&ovp_r_Data[0], sam, 1, 5.3, 5.9);
	VIN.AwgLoader("ovp_r_Data", FV, FPVI10_10V, FPVI10_100MA, ovp_r_Data, sam);
	VIN.AwgSelect("ovp_r_Data", 0, sam - 1, sam - 1, interval);
	EN.SetMeasVTrig(Trig, TRIG_FALLING);
	VIN.MeasureVI(sam, interval, MEAS_AWG);
	EN.MeasureVI(sam, interval, MEAS_AWG);

	STSEnableAWG(&VIN);
	STSEnableMeas(&VIN, &EN);
	//STSAWGRunTriggerStop(&EN,&VIN, &EN);
	StsAWGRun();

		Trig_Point[0] = EN.GetMeasResult(0, MVRET, TRIG_RESULT);
		m = Trig_Point[0] - 1;
		if (m<2)
		{
			ovp_r[0] = -777;
		}
		else if (m>sam - 3)
		{
			ovp_r[0] = -999;

		}
		else
		{
			ovp_r[0] = ovp_r_Data[m];//FPVIO+FPVI1

		}

		OVP_R->SetTestResult(0, 0, ovp_r[0]);
#if 1

	VIN.Set(FV, 5.9, FPVI10_10V, FPVI10_100MA, RELAY_ON, 0.5);
	delay_ms(3);

	double ovp_f[2] = { 0.0, 0.0 };
	double vx = 0;

	for (vx = 0; vx <= 30; vx++)
	{
		VIN.Set(FV, 5.9 - vx*0.02, FPVI10_10V, FPVI10_100MA, RELAY_ON, 0.5);
		EN.MeasureVI(50, 10);

			adresult[0] = EN.GetMeasResult(0, MVRET);
			if ((adresult[0]>3))
			{
				ovp_f[0] = 5.9 - vx*0.02;
				break;
			}
	}

		OVP_F->SetTestResult(0, 0, ovp_f[0]);
		OVP_hys->SetTestResult(0, 0, (ovp_r[0] - ovp_f[0]) * 1000);

#endif 

	DIOExpressWriteData(0x6a,0x00);
	delay_ms(1);
	dio.Disconnect();
	delay_ms(1);

	VIN.Set(FV, 0.0, FPVI10_10V, FPVI10_100MA, RELAY_ON);
	EN.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_ON);
	//I2CPUP.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_ON);
	delay_ms(3);
	VIN.Set(FV, 0.0, FPVI10_10V, FPVI10_100MA, RELAY_OFF);
	EN.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_OFF);
	//I2CPUP.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_OFF);
	delay_ms(3);
	cbit.SetOn(-1);
	delay_ms(3);

    return 0;
}


DUT_API int T38_OVP_GNG(short funcindex, LPCTSTR funclabel)
{
    //{{AFX_STS_PARAM_PROTOTYPES
    CParam *OVP_set = StsGetParam(funcindex,"OVP_set");
    CParam *OVP_R1 = StsGetParam(funcindex,"OVP_R1");
    CParam *OVP_R2 = StsGetParam(funcindex,"OVP_R2");
    CParam *OVP_F1 = StsGetParam(funcindex,"OVP_F1");
    //}}AFX_STS_PARAM_PROTOTYPES

    // TODO: Add your function code here
	cbit.SetOn(K2,/*K3,*/K4,K13,-1);
	delay_ms(3);
	dio.Connect();
	delay_ms(3);

	//I2CPUP.Set(FV, 3.6, FOVI_5V, FOVI_100MA, RELAY_ON);
	VIN.Set(FV, 5.3, FPVI10_10V, FPVI10_100MA, RELAY_ON);
	EN.Set(FV, 3.6, FOVI_10V, FOVI_100MA, RELAY_ON);
	delay_ms(3);

	DIOExpressWriteData(0x6a,0x5a);
	delay_ms(1);
	DIOExpressWriteData(0x6a,0xa5);
	delay_ms(1);

	EN.Set(FV, 0.0, FOVI_10V, FOVI_100MA, RELAY_ON);
	delay_ms(3);
	EN.Set(FI, 0.0, FOVI_10V, FOVI_100UA, RELAY_ON);
	delay_ms(3);

	//cbit.SetCBITOff(K4);
	//cbit.SetCBITOn(K5);
	//delay_ms(3);

	DIOExpressWriteData(0x24,0x04);
	delay_ms(1);
	DIOExpressWriteData(0x23,0x8A);
	delay_ms(1);


///OVP_set
	adresult[0] = 0;
	EN.MeasureVI(10, 10);
	adresult[0] = EN.GetMeasResult(0, MVRET);
	OVP_set->SetTestResult(0, 0, adresult[0]);	

///OVP_R1
	adresult[0] = 0;
	VIN.Set(FV, 5.5, FPVI10_10V, FPVI10_100MA, RELAY_ON);
	delay_ms(10);
	EN.MeasureVI(10, 10);
	adresult[0] = EN.GetMeasResult(0, MVRET);
	OVP_R1->SetTestResult(0, 0, adresult[0]);

///OVP_R2
	adresult[0] = 0;
	VIN.Set(FV, 5.9, FPVI10_10V, FPVI10_100MA, RELAY_ON);
	delay_ms(10);
	EN.MeasureVI(10, 10);
	adresult[0] = EN.GetMeasResult(0, MVRET);
	OVP_R2->SetTestResult(0, 0, adresult[0]);

///OVP_F1
	adresult[0] = 0;
	VIN.Set(FV, 5.5, FPVI10_10V, FPVI10_100MA, RELAY_ON);
	delay_ms(10);
	EN.MeasureVI(10, 10);
	adresult[0] = EN.GetMeasResult(0, MVRET);
	OVP_F1->SetTestResult(0, 0, adresult[0]);

///OVP_F2




//power_off
	DIOExpressWriteData(0x6a,0x00);
	delay_ms(1);
	dio.Disconnect();
	delay_ms(1);

	VIN.Set(FV, 0.0, FPVI10_10V, FPVI10_100MA, RELAY_ON);
	EN.Set(FV, 0.0, FOVI_10V, FOVI_100MA, RELAY_ON);
	//I2CPUP.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_ON);
	delay_ms(3);
	VIN.Set(FV, 0.0, FPVI10_10V, FPVI10_100MA, RELAY_OFF);
	EN.Set(FV, 0.0, FOVI_10V, FOVI_100MA, RELAY_OFF);
	//I2CPUP.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_OFF);
	delay_ms(3);
	cbit.SetOn(-1);
	delay_ms(3);





	
    return 0;
}


DUT_API int T39_UV_THR_Search(short funcindex, LPCTSTR funclabel)
{
    //{{AFX_STS_PARAM_PROTOTYPES
    CParam *UV_THR_R = StsGetParam(funcindex,"UV_THR_R");
    CParam *UV_THR_F = StsGetParam(funcindex,"UV_THR_F");
    CParam *UV_THR_hys = StsGetParam(funcindex,"UV_THR_hys");
    //}}AFX_STS_PARAM_PROTOTYPES

    // TODO: Add your function code here
	cbit.SetOn(K2,/*K3,*/K4,K11,K12,K13,-1);
	delay_ms(3);
	dio.Connect();
	delay_ms(3);

	VOUT.Set(FV, 1.2, FOVI_5V, FOVI_100MA, RELAY_ON);
	//I2CPUP.Set(FV, 3.6, FOVI_5V, FOVI_100MA, RELAY_ON);
	VIN.Set(FV, 3.6, FPVI10_5V, FPVI10_100MA, RELAY_ON);
	EN.Set(FV, 3.6, FOVI_5V, FOVI_100MA, RELAY_ON);
	delay_ms(3);

	DIOExpressWriteData(0x6a,0x5a);
	delay_ms(1);
	DIOExpressWriteData(0x6a,0xa5);
	delay_ms(1);

	EN.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_ON);
	delay_ms(3);
	EN.Set(FI, 0.0, FOVI_5V, FOVI_100UA, RELAY_ON);
	delay_ms(3);

	//cbit.SetCBITOff(K4);
	//cbit.SetCBITOn(K5);
	//delay_ms(3);

	DIOExpressWriteData(0x24,0x04);
	delay_ms(1);
	DIOExpressWriteData(0x23,0x4B);
	delay_ms(1);

	double uv_thr_f[2] = { 0 };
	double Trig = 1;//trigger level
	double Trig_Point[2] = { 0 };
	double result[2] = { 0 };
	int sam = 61; //awgSize
	int interval = 500; //awgInterval��unit=us
	double UV_THR_f_Data[100] = { 0.0 };
	int i = 0;
	int	m = 0;

	STSAWGCreateRampData(&UV_THR_f_Data[0], sam, 1, 0.9, 0.3);
	VOUT.AwgLoader("UV_THR_f", FV, FOVI_5V, FOVI_100MA, UV_THR_f_Data, sam);
	VOUT.AwgSelect("UV_THR_f", 0, sam - 1, sam - 1, interval);
	EN.SetMeasVTrig(Trig, TRIG_RISING);
	VOUT.MeasureVI(sam, interval, MEAS_AWG);
	EN.MeasureVI(sam, interval, MEAS_AWG);

	STSEnableAWG(&VOUT);
	STSEnableMeas(&VOUT, &EN);
	//STSAWGRunTriggerStop(&EN,&VOUT, &EN);
	StsAWGRun();

		Trig_Point[0] = EN.GetMeasResult(0, MVRET, TRIG_RESULT);
		m = Trig_Point[0] - 1;
		if (m<2)
		{
			uv_thr_f[0] = -777;
		}
		else if (m>sam - 3)
		{
			uv_thr_f[0] = -999;

		}
		else
		{
			uv_thr_f[0] = UV_THR_f_Data[m];//FPVIO+FPVI1

		}

		UV_THR_F->SetTestResult(0, 0, uv_thr_f[0]);

#if 1
	VOUT.Set(FV, 0.2, FOVI_5V, FOVI_100MA, RELAY_ON);
	delay_ms(3);

	double uv_thr_r[2] = { 0.0, 0.0 };
	double vx = 0;

	for (vx = 0; vx <= 200; vx++)
	{
		VOUT.Set(FV, 0.2 + vx*0.005, FOVI_5V, FOVI_100MA, RELAY_ON, 0.5);
		delay_ms(3);
/*		EN.Set(FV, 3.6, FOVI_5V, FOVI_100MA, RELAY_ON);
		delay_ms(1);

		DIOExpressWriteData(0x6a,0x5a);
		DIOExpressWriteData(0x6a,0xa5);

		EN.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_ON);
		delay_ms(1);
		EN.Set(FI, 0.0, FOVI_5V, FOVI_100UA, RELAY_ON);
		delay_ms(1);


		DIOExpressWriteData(0x24,0x04);
		delay_ms(1);
		DIOExpressWriteData(0x23,0x4A);
		delay_ms(1);
*/
		EN.MeasureVI(50, 10);

			adresult[0] = EN.GetMeasResult(0, MVRET);
			if ((adresult[0]<1.8))
			{
				uv_thr_r[0] = 0.2 + vx*0.005;
				break;
			}
	
	}

		UV_THR_R->SetTestResult(0, 0, uv_thr_r[0]);
		UV_THR_hys->SetTestResult(0, 0, (uv_thr_r[0] - uv_thr_f[0]) * 1000);

#endif

	DIOExpressWriteData(0x6a,0x00);
	delay_ms(1);
	dio.Disconnect();
	delay_ms(1);

	VIN.Set(FV, 0.0, FPVI10_5V, FPVI10_100MA, RELAY_ON);
	EN.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_ON);
	//I2CPUP.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_ON);
	delay_ms(3);
	VIN.Set(FV, 0.0, FPVI10_5V, FPVI10_100MA, RELAY_OFF);
	EN.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_OFF);
	//I2CPUP.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_OFF);
	delay_ms(3);
	cbit.SetOn(-1);
	delay_ms(3);
    return 0;
}


DUT_API int T40_UV_THR_GNG(short funcindex, LPCTSTR funclabel)
{
    //{{AFX_STS_PARAM_PROTOTYPES
    CParam *UV_THR_set = StsGetParam(funcindex,"UV_THR_set");
    CParam *UV_THR_R1 = StsGetParam(funcindex,"UV_THR_R1");
    CParam *UV_THR_F1 = StsGetParam(funcindex,"UV_THR_F1");
    CParam *UV_THR_F2 = StsGetParam(funcindex,"UV_THR_F2");
    //}}AFX_STS_PARAM_PROTOTYPES

    // TODO: Add your function code here
	cbit.SetOn(K2,/*K3,*/K4,K11,K12,K13,-1);
	delay_ms(3);
	dio.Connect();
	delay_ms(3);

	VOUT.Set(FV, 1.2, FOVI_5V, FOVI_100MA, RELAY_ON);
	//I2CPUP.Set(FV, 3.6, FOVI_5V, FOVI_100MA, RELAY_ON);
	VIN.Set(FV, 3.6, FPVI10_5V, FPVI10_100MA, RELAY_ON);
	EN.Set(FV, 3.6, FOVI_5V, FOVI_100MA, RELAY_ON);
	delay_ms(3);

	DIOExpressWriteData(0x6a,0x5a);
	delay_ms(1);
	DIOExpressWriteData(0x6a,0xa5);
	delay_ms(1);

	EN.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_ON);
	delay_ms(3);
	EN.Set(FI, 0.0, FOVI_5V, FOVI_100UA, RELAY_ON);
	delay_ms(3);

	//cbit.SetCBITOff(K4);
	//cbit.SetCBITOn(K5);
	//delay_ms(3);

	DIOExpressWriteData(0x24,0x04);
	delay_ms(1);
	DIOExpressWriteData(0x23,0x4B);
	delay_ms(1);
	
///UV_THR_set
	adresult[0] = 0;
	EN.MeasureVI(10, 10);
	adresult[0] = EN.GetMeasResult(0, MVRET);

	UV_THR_set->SetTestResult(0, 0, adresult[0]);


///UV_THR_F1	
	adresult[0] = 0;
	VOUT.Set(FV, 0.72, FOVI_5V, FOVI_100MA, RELAY_ON);
	delay_ms(10);
	EN.MeasureVI(10, 10);
	adresult[0] = EN.GetMeasResult(0, MVRET);

	UV_THR_F1->SetTestResult(0, 0, adresult[0]);
	
///UV_THR_F2
	adresult[0] = 0;	
	VOUT.Set(FV, 0.54, FOVI_5V, FOVI_100MA, RELAY_ON);
	delay_ms(10);
	EN.MeasureVI(10, 10);
	adresult[0] = EN.GetMeasResult(0, MVRET);

	UV_THR_F2->SetTestResult(0, 0, adresult[0]);
	
///UV_THR_R1
	adresult[0] = 0;
	VOUT.Set(FV, 0.72, FOVI_5V, FOVI_100MA, RELAY_ON);
	delay_ms(10);
	EN.MeasureVI(10, 10);
	adresult[0] = EN.GetMeasResult(0, MVRET);

	UV_THR_R1->SetTestResult(0, 0, adresult[0]);

///UV_THR_R2	
	
	
	
//power_off	
	DIOExpressWriteData(0x6a,0x00);
	delay_ms(1);
	dio.Disconnect();
	delay_ms(1);

	VIN.Set(FV, 0.0, FPVI10_5V, FPVI10_100MA, RELAY_ON);
	EN.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_ON);
	//I2CPUP.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_ON);
	delay_ms(3);
	VIN.Set(FV, 0.0, FPVI10_5V, FPVI10_100MA, RELAY_OFF);
	EN.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_OFF);
	//I2CPUP.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_OFF);
	delay_ms(3);
	cbit.SetOn(-1);
	delay_ms(3);
	
	
	
    return 0;
}


DUT_API int T41_EN_VTH_Search(short funcindex, LPCTSTR funclabel)
{
    //{{AFX_STS_PARAM_PROTOTYPES
    CParam *EN_R = StsGetParam(funcindex,"EN_R");
    CParam *EN_F = StsGetParam(funcindex,"EN_F");
    CParam *EN_hys = StsGetParam(funcindex,"EN_hys");
    //}}AFX_STS_PARAM_PROTOTYPES

    // TODO: Add your function code here

	cbit.SetOn(K4,/*K13,*/K1,-1);
	delay_ms(3);

	MODE.Set(FV, 0.0, FOVI_1V, FOVI_10MA, RELAY_ON);
	VIN.Set(FV, 2.7, FPVI10_10V, FPVI10_100MA, RELAY_ON);
	EN.Set(FV, 2.7, FOVI_5V, FOVI_100MA, RELAY_ON);
	delay_ms(3);


	double en_f[2] = { 0 };
	double Trig = 4e-4f;//trigger level
	double Trig_Point[2] = { 0 };
	double result[2] = { 0 };
	int sam = 31; //awgSize
	int interval = 500; //awgInterval��unit=us
	double en_f_Data[100] = { 0.0 };
	int i = 0;
	int	m = 0;

#if 1

	STSAWGCreateRampData(&en_f_Data[0], sam, 1, 0.75, 0.45);
	EN.AwgLoader("EN_f", FV, FOVI_5V, FOVI_100MA, en_f_Data, sam);
	EN.AwgSelect("EN_f", 0, sam - 1, sam - 1, interval);
	VIN.SetMeasITrig(Trig, TRIG_FALLING);
	VIN.MeasureVI(sam, interval, MEAS_AWG);
	EN.MeasureVI(sam, interval, MEAS_AWG);

	STSEnableAWG(&EN);
	STSEnableMeas(&VIN, &EN);
	//STSAWGRunTriggerStop(&VIN, &VIN,&EN);
	StsAWGRun();

		Trig_Point[0] = VIN.GetMeasResult(0, MIRET, TRIG_RESULT);
		m = Trig_Point[0] - 1;
		if (m<2)
		{
			en_f[0] = -777;
		}
		else if (m>sam - 3)
		{
			en_f[0] = -999;

		}
		else
		{
			en_f[0] = en_f_Data[m];//FPVIO+FPVI1

		}

		EN_F->SetTestResult(0, 0, en_f[0]);

	EN.Set(FV, 0.2, FOVI_5V, FOVI_100MA, RELAY_ON);
	delay_ms(3);

#endif

	VIN.Set(FV, 5.5, FPVI10_10V, FPVI10_100MA, RELAY_ON, 0.5);
	EN.Set(FV, 0.2, FOVI_5V, FOVI_100MA, RELAY_ON);
	delay_ms(3);

	double en_r[2] = { 0.0, 0.0 };
	double vx = 0;

	for (vx = 0; vx <= 200; vx++)
	{
		EN.Set(FV, 0.3 + vx*0.005, FOVI_5V, FOVI_100MA, RELAY_ON, 0.5);
		delay_ms(3);
/*		EN.Set(FV, 3.6, FOVI_5V, FOVI_100MA, RELAY_ON);
		delay_ms(1);

		DIOExpressWriteData(0x6a,0x5a);
		DIOExpressWriteData(0x6a,0xa5);

		EN.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_ON);
		delay_ms(1);
		EN.Set(FI, 0.0, FOVI_5V, FOVI_100UA, RELAY_ON);
		delay_ms(1);


		DIOExpressWriteData(0x24,0x04);
		delay_ms(1);
		DIOExpressWriteData(0x23,0x4A);
		delay_ms(1);
*/
		VIN.MeasureVI(50, 10);

			adresult[0] = VIN.GetMeasResult(0, MIRET)*1e6f;
			if ((adresult[0]>500.0))
			{
				en_r[0] = 0.3 + vx*0.005;
				break;
			}
	
	}

		EN_R->SetTestResult(0, 0, en_r[0]);
		EN_hys->SetTestResult(0, 0, (en_r[0] - en_f[0]) * 1000);

	EN.Set(FV, 1.5, FOVI_5V, FOVI_100MA, RELAY_ON);
	VIN.Set(FV, 5.5, FPVI10_10V, FPVI10_100MA, RELAY_ON, 0.5);
	delay_ms(3);

#if 0
	for (vx = 0; vx <= 200; vx++)
	{
		EN.Set(FV, 0.9 - vx*0.005, FOVI_5V, FOVI_100MA, RELAY_ON, 0.5);
		delay_ms(3);
/*		EN.Set(FV, 3.6, FOVI_5V, FOVI_100MA, RELAY_ON);
		delay_ms(1);

		DIOExpressWriteData(0x6a,0x5a);
		DIOExpressWriteData(0x6a,0xa5);

		EN.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_ON);
		delay_ms(1);
		EN.Set(FI, 0.0, FOVI_5V, FOVI_100UA, RELAY_ON);
		delay_ms(1);


		DIOExpressWriteData(0x24,0x04);
		delay_ms(1);
		DIOExpressWriteData(0x23,0x4A);
		delay_ms(1);
*/
		VIN.MeasureVI(50, 10);

			adresult[0] = VIN.GetMeasResult(0, MIRET)*1e6f;
			if ((adresult[0]<100.0))
			{
				en_f[0] = 0.9 - vx*0.005;
				break;
			}
	
	}
		EN_F->SetTestResult(0, 0, en_f[0]);
#endif

	EN.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_ON);
	VIN.Set(FV, 0.0, FPVI10_10V, FPVI10_100MA, RELAY_ON);
	//I2CPUP.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_ON);
	delay_ms(3);
	VIN.Set(FV, 0.0, FPVI10_10V, FPVI10_100MA, RELAY_OFF);
	MODE.Set(FV, 0.0, FOVI_1V, FOVI_10MA, RELAY_OFF);
	EN.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_OFF);
	//I2CPUP.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_OFF);
	delay_ms(3);
	cbit.SetOn(-1);
	delay_ms(3);


    return 0;
}


DUT_API int T42_EN_VTH_GNG(short funcindex, LPCTSTR funclabel)
{
    //{{AFX_STS_PARAM_PROTOTYPES
    CParam *EN_VTH_set = StsGetParam(funcindex,"EN_VTH_set");
    CParam *EN_VTH_R1 = StsGetParam(funcindex,"EN_VTH_R1");
    CParam *EN_VTH_R2 = StsGetParam(funcindex,"EN_VTH_R2");
    CParam *EN_VTH_F1 = StsGetParam(funcindex,"EN_VTH_F1");
    CParam *EN_VTH_F2 = StsGetParam(funcindex,"EN_VTH_F2");
    //}}AFX_STS_PARAM_PROTOTYPES

    // TODO: Add your function code here
	cbit.SetOn(K4/*,K13*/,K1,-1);
	delay_ms(3);

	MODE.Set(FV, 0.0, FOVI_1V, FOVI_10MA, RELAY_ON);
	VIN.Set(FV, 2.7, FPVI10_10V, FPVI10_100MA, RELAY_ON);
	EN.Set(FV, 2.7, FOVI_5V, FOVI_100MA, RELAY_ON);
	delay_ms(5);
	VIN.Set(FV, 2.7, FPVI10_10V, FPVI10_10MA, RELAY_ON);


///EN_VTH_set
	EN.Set(FV, 2.7, FOVI_5V, FOVI_1MA, RELAY_ON);
	delay_ms(5);
	adresult[0] = 0;
	VIN.MeasureVI(60, 10);
	adresult[0] = VIN.GetMeasResult(0, MIRET);
	EN_VTH_set->SetTestResult(0, 0, adresult[0]*1e6f);	

///EN_VTH_F1
	adresult[0] = 0;
	EN.Set(FV, 0.79, FOVI_5V, FOVI_1MA, RELAY_ON);
	delay_ms(5);
	VIN.MeasureVI(60, 10);
	adresult[0] = VIN.GetMeasResult(0, MIRET);
	EN_VTH_F1->SetTestResult(0, 0, adresult[0]*1e6f);	

///EN_VTH_F2
	adresult[0] = 0;
	EN.Set(FV, 0.31, FOVI_5V, FOVI_1MA, RELAY_ON);
	delay_ms(5);
	VIN.MeasureVI(60, 10);
	adresult[0] = VIN.GetMeasResult(0, MIRET);
	EN_VTH_F2->SetTestResult(0, 0, adresult[0]*1e6f);	


	EN.Set(FV, 0.0, FOVI_5V, FOVI_1MA, RELAY_ON);
	VIN.Set(FV, 5.5, FPVI10_10V, FPVI10_10MA, RELAY_ON);
	delay_ms(5);

///EN_VTH_R1
	adresult[0] = 0;
	EN.Set(FV, 0.31, FOVI_5V, FOVI_1MA, RELAY_ON);
	delay_ms(5);
	VIN.MeasureVI(60, 10);
	adresult[0] = VIN.GetMeasResult(0, MIRET);
	EN_VTH_R1->SetTestResult(0, 0, adresult[0]*1e6f);	

///EN_VTH_R2
	adresult[0] = 0;
	VIN.Set(FV, 5.5, FPVI10_10V, FPVI10_100MA, RELAY_ON);	//iRANGE relax
	EN.Set(FV, 0.79, FOVI_5V, FOVI_1MA, RELAY_ON);
	delay_ms(3);
	VIN.MeasureVI(60, 10);
	adresult[0] = VIN.GetMeasResult(0, MIRET);
	EN_VTH_R2->SetTestResult(0, 0, adresult[0]*1e6f);	


//power_off
	EN.Set(FV, 0.0, FOVI_5V, FOVI_1MA, RELAY_ON);
	VIN.Set(FV, 0.0, FPVI10_10V, FPVI10_100MA, RELAY_ON);
	//I2CPUP.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_ON);
	delay_ms(3);
	VIN.Set(FV, 0.0, FPVI10_10V, FPVI10_100MA, RELAY_OFF);
	MODE.Set(FV, 0.0, FOVI_1V, FOVI_10MA, RELAY_OFF);
	EN.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_OFF);
	//I2CPUP.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_OFF);
	delay_ms(3);
	cbit.SetOn(-1);
	delay_ms(3);

    return 0;
}

DUT_API int T45_Ton_Trim(short funcindex, LPCTSTR funclabel)
{
    //{{AFX_STS_PARAM_PROTOTYPES
    CParam *Ton_pre = StsGetParam(funcindex,"Ton_pre");
    CParam *Ton_pre_err = StsGetParam(funcindex,"Ton_pre_err");
    CParam *Ton_code = StsGetParam(funcindex,"Ton_code");
    CParam *Ton_sim = StsGetParam(funcindex,"Ton_sim");
    CParam *Ton_sim_err = StsGetParam(funcindex,"Ton_sim_err");
    //}}AFX_STS_PARAM_PROTOTYPES

    // TODO: Add your function code here
	cbit.SetOn(/*K1,*/K2,/*K3,*/K4,K7,K11,K12,K13,-1);
	delay_ms(3);
//	MODE.Set(FI, 0.0, FOVI_5V, FOVI_100MA, RELAY_OFF);
	delay_ms(3);

	VOUT.Set(FV, 1.0, FOVI_5V, FOVI_100MA, RELAY_ON);
	VIN.Set(FV, 3.6, FPVI10_5V, FPVI10_100MA, RELAY_ON);
	EN.Set(FV, 3.6, FOVI_5V, FOVI_100MA, RELAY_ON);
	delay_ms(3);
	dio.Connect();
	delay_ms(3);
	DIOExpressWriteData(0x6a,0x5a);
	delay_ms(1);
	DIOExpressWriteData(0x6a,0xa5);
	delay_ms(1);

	EN.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_ON);
	delay_ms(3);
	EN.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_OFF);
	delay_ms(3);

	//DIOExpressWriteData(0x23,0x90);
	//delay_ms(3);
	//DIOExpressReadData(0x29);
	//delay_ms(1);

	DIOExpressWriteData(0x25,0x10);
	delay_ms(1);
	DIOExpressWriteData(0x26,0x08);
	delay_ms(1);
	DIOExpressWriteData(0x45,0x80);
	delay_ms(1);
	DIOExpressWriteData(0x44,0x00);
	delay_ms(1);
	DIOExpressWriteData(0x24,0x80);
	delay_ms(1);

//	MODE.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_ON);
//	delay_ms(3);

#if 0
	qtmu0.SetStartInput(QTMU_PLUS_IMPEDANCE_1M, QTMU_PLUS_VRNG_5V, QTMU_PLUS_FILTER_WIDEBAND);
	qtmu0.SetStopInput(QTMU_PLUS_IMPEDANCE_1M, QTMU_PLUS_VRNG_5V, QTMU_PLUS_FILTER_WIDEBAND);
	qtmu0.SetStartTrigger(2.5, QTMU_PLUS_POS_SLOPE);
	qtmu0.SetStopTrigger(1.2, QTMU_PLUS_NEG_SLOPE);
	qtmu0.SetInSource(QTMU_PLUS_SINGLE_SOURCE);
	qtmu0.Connect();

	//qtmu0.MeasFreq(QTMU_PLUS_COARSE, QTMU_PLUS_TRNG_US, 20, 5); //timeout=2ms
	qtmu0.Meas(QTMU_PLUS_FINE,QTMU_PLUS_TRNG_NS,5);
	adresult[0] = qtmu0.GetMeasureResult(0);
	adresult[0] = adresult[0] *1e3f;
#endif

	qtmu0.SetStartInput(QTMU_PLUS_IMPEDANCE_1M, QTMU_PLUS_VRNG_5V, QTMU_PLUS_FILTER_10MHz);
	qtmu0.SetStopInput(QTMU_PLUS_IMPEDANCE_1M, QTMU_PLUS_VRNG_5V, QTMU_PLUS_FILTER_10MHz);
	qtmu0.SetStartTrigger(2.5, QTMU_PLUS_POS_SLOPE);
	qtmu0.SetInSource(QTMU_PLUS_SINGLE_SOURCE);
	qtmu0.Connect();

	qtmu0.MeasFreq(QTMU_PLUS_FINE, QTMU_PLUS_TRNG_US, 20, 5); //timeout=2ms

	adresult[0] = qtmu0.GetMeasureResult(0);
	adresult[0] = adresult[0]/1e3f;

	ton_pre_err[0] = (ton_target -adresult[0]) / (adresult[0] + 1e-20f) * 100;

	DIOExpressWriteData(0x6a,0x00);
	delay_ms(1);
	dio.Disconnect();
	qtmu0.Disconnect();
	delay_ms(1);

	VIN.Set(FV, 0.0, FPVI10_5V, FPVI10_100MA, RELAY_ON);
	EN.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_ON);
	VOUT.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_ON);
	//I2CPUP.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_ON);
	delay_ms(3);
	VIN.Set(FV, 0.0, FPVI10_5V, FPVI10_100MA, RELAY_OFF);
	EN.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_OFF);
	VOUT.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_OFF);
	//I2CPUP.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_OFF);
	MODE.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_OFF);
	delay_ms(3);
	cbit.SetOn(-1);
	delay_ms(3);

	Ton_pre->SetTestResult(0, 0, adresult[0]);
	Ton_pre_err->SetTestResult(0, 0, ton_pre_err[0]);


		if (ton_pre_err[0] >= -50.0 && ton_pre_err[0]<50.0)
		{
			if (ton_pre_err[0] >= -3.59 && ton_pre_err[0]< -1.04)		{ ton_code[0] = 240; }//
			if (ton_pre_err[0] >= -6.72 && ton_pre_err[0]< -3.59)		{ ton_code[0] = 224; }//
			if (ton_pre_err[0] >= -10.04 && ton_pre_err[0]< -6.72)		{ ton_code[0] = 208; }//
			if (ton_pre_err[0] >= -13.61 && ton_pre_err[0]< -10.04)		{ ton_code[0] = 192; }//
			if (ton_pre_err[0] >= -17.29 && ton_pre_err[0]< -13.61)		{ ton_code[0] = 176; }//
			if (ton_pre_err[0] >= -20.95 && ton_pre_err[0]< -17.29)		{ ton_code[0] = 160; }//
			if (ton_pre_err[0] >= -24.59 && ton_pre_err[0]< -20.95)		{ ton_code[0] = 144; }//
			if (ton_pre_err[0] >= -50.0 && ton_pre_err[0]< -24.59)		{ ton_code[0] = 128; }//

			if (ton_pre_err[0] >= 19.65 && ton_pre_err[0]< 50.0)		{ ton_code[0] = 112; }//
			if (ton_pre_err[0] >= 16.77 && ton_pre_err[0]< 19.65)		{ ton_code[0] = 96; }//
			if (ton_pre_err[0] >= 13.70 && ton_pre_err[0]< 16.77)		{ ton_code[0] = 80; }//
			if (ton_pre_err[0] >= 10.69 && ton_pre_err[0]< 13.70)		{ ton_code[0] = 64; }//
			if (ton_pre_err[0] >= 7.83 && ton_pre_err[0]< 10.69)		{ ton_code[0] = 48; }//
			if (ton_pre_err[0] >= 4.89 && ton_pre_err[0]< 7.83)			{ ton_code[0] = 32; }//
			if (ton_pre_err[0] >= 1.66 && ton_pre_err[0]< 4.89)			{ ton_code[0] = 16; }//
			if (ton_pre_err[0] >= -1.04 && ton_pre_err[0]< 1.66)		{ ton_code[0] = 0; }//


		}
		else
			ton_code[0] = 0; //


		/******************* already trimmed dies -> set to reading of OTP ******************/
		if ((EN_OTP43_47_VD[0] == 0))
		{
			ton_code[0] = OTP43_47_VD[0];
		}


	Ton_code->SetTestResult(0, 0, ton_code[0]);

	cbit.SetOn(/*K1,*/K2,/*K3,*/K4,K7,K11,K12,K13,-1);
	delay_ms(3);
//	MODE.Set(FI, 0.0, FOVI_5V, FOVI_100MA, RELAY_OFF);
//	delay_ms(3);

	VOUT.Set(FV, 1.0, FOVI_5V, FOVI_100MA, RELAY_ON);
	VIN.Set(FV, 3.6, FPVI10_5V, FPVI10_100MA, RELAY_ON);
	EN.Set(FV, 3.6, FOVI_5V, FOVI_100MA, RELAY_ON);
	delay_ms(3);
	dio.Connect();
	delay_ms(3);
	DIOExpressWriteData(0x6a,0x5a);
	delay_ms(1);
	DIOExpressWriteData(0x6a,0xa5);
	delay_ms(1);

	EN.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_ON);
	delay_ms(3);
	EN.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_OFF);
	delay_ms(3);

	//DIOExpressWriteData(0x23,0x90);
	//delay_ms(3);
	//DIOExpressReadData(0x29);
	//delay_ms(1);

	DIOExpressWriteData(0x25,0x10);
	delay_ms(1);
	DIOExpressWriteData(0x26,0x08);
	delay_ms(1);
	DIOExpressWriteData(0x45,0x80);
	delay_ms(1);
	DIOExpressWriteData(0x44,0x00);
	delay_ms(1);
	DIOExpressWriteData(0x24,0x80);
	delay_ms(1);



//	MODE.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_ON);
//	delay_ms(3);
#if 0
	qtmu0.SetStartInput(QTMU_PLUS_IMPEDANCE_1M, QTMU_PLUS_VRNG_5V, QTMU_PLUS_FILTER_WIDEBAND);
	qtmu0.SetStopInput(QTMU_PLUS_IMPEDANCE_1M, QTMU_PLUS_VRNG_5V, QTMU_PLUS_FILTER_WIDEBAND);
	qtmu0.SetStartTrigger(2.5, QTMU_PLUS_POS_SLOPE);
	qtmu0.SetStopTrigger(1.2, QTMU_PLUS_NEG_SLOPE);
	qtmu0.SetInSource(QTMU_PLUS_SINGLE_SOURCE);
	qtmu0.Connect();

	DIOExpressWriteData(0x43,ton_code[0]);
	delay_ms(1);

	//qtmu0.MeasFreq(QTMU_PLUS_COARSE, QTMU_PLUS_TRNG_US, 20, 5); //timeout=2ms
	qtmu0.Meas(QTMU_PLUS_FINE,QTMU_PLUS_TRNG_NS,5);
	adresult[0] = qtmu0.GetMeasureResult(0);
	adresult[0] = adresult[0] *1e3f;
#endif 

	qtmu0.SetStartInput(QTMU_PLUS_IMPEDANCE_1M, QTMU_PLUS_VRNG_5V, QTMU_PLUS_FILTER_10MHz);
	qtmu0.SetStopInput(QTMU_PLUS_IMPEDANCE_1M, QTMU_PLUS_VRNG_5V, QTMU_PLUS_FILTER_10MHz);
	qtmu0.SetStartTrigger(2.5, QTMU_PLUS_POS_SLOPE);
	qtmu0.SetInSource(QTMU_PLUS_SINGLE_SOURCE);
	qtmu0.Connect();

#if 1
	DIOExpressWriteData(0x43,ton_code[0]);
	delay_ms(1);


	qtmu0.MeasFreq(QTMU_PLUS_FINE, QTMU_PLUS_TRNG_US, 20, 5); //timeout=2ms

	adresult[0] = qtmu0.GetMeasureResult(0);
	adresult[0] = adresult[0]/1e3f;
#endif

#if 0
	int code[16]={0,16,32,48,64,80,96,112,128,144,160,176,192,208,224,240};
		
	double tempp[64]={0.0};

	for(i=0;i<16;i++)
	{
	DIOExpressWriteData(0x43,code[i]);
	delay_ms(1);
	qtmu0.Meas(QTMU_PLUS_FINE,QTMU_PLUS_TRNG_NS,5);
	delay_ms(3);
	tempp[i] = qtmu0.GetMeasureResult(0)*1000;

	}
#endif

#if 0
	int code[16]={0,16,32,48,64,80,96,112,128,144,160,176,192,208,224,240};
		
	double tempp[64]={0.0};

	for(i=0;i<16;i++)
	{
	DIOExpressWriteData(0x43,code[i]);
	delay_ms(1);
	qtmu0.MeasFreq(QTMU_PLUS_FINE, QTMU_PLUS_TRNG_US, 20, 5); //timeout=2ms
	delay_ms(3);
	tempp[i] = qtmu0.GetMeasureResult(0)/1000;
	}
#endif

	DIOExpressWriteData(0x6a,0x00);
	delay_ms(1);
	dio.Disconnect();
	qtmu0.Disconnect();
	delay_ms(1);

	VIN.Set(FV, 0.0, FPVI10_5V, FPVI10_100MA, RELAY_ON);
	EN.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_ON);
	VOUT.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_ON);
	//I2CPUP.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_ON);
	delay_ms(3);
	VIN.Set(FV, 0.0, FPVI10_5V, FPVI10_100MA, RELAY_OFF);
	EN.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_OFF);
	VOUT.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_OFF);
	//I2CPUP.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_OFF);
	MODE.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_OFF);
	delay_ms(3);
	cbit.SetOn(-1);
	delay_ms(3);

	Ton_sim->SetTestResult(0, 0, adresult[0]);
	Ton_sim_err->SetTestResult(0, 0, (ton_target -adresult[0])/(adresult[0]+1e-9f)*100);

    return 0;
}


DUT_API int T46_Ton_BURN(short funcindex, LPCTSTR funclabel)
{
    //{{AFX_STS_PARAM_PROTOTYPES
    CParam *Ton_burn = StsGetParam(funcindex,"Ton_burn");
    //}}AFX_STS_PARAM_PROTOTYPES

    // TODO: Add your function code here
	if (en_trim == 1)
	{
	//EN_OTP43_47_VD[0]=1;

	cbit.SetOn(K2,/*K3,*/K4,K11,K12,K13,-1);
	delay_ms(3);

	//I2CPUP.Set(FV, 3.6, FOVI_5V, FOVI_100MA, RELAY_ON);
	VIN.Set(FV, 3.6, FPVI10_5V, FPVI10_100MA, RELAY_ON);
	EN.Set(FV, 3.6, FOVI_5V, FOVI_100MA, RELAY_ON);
	delay_ms(3);
	dio.Connect();
	delay_ms(3);
	DIOExpressWriteData(0x6a,0x5a);
	delay_ms(1);
	DIOExpressWriteData(0x6a,0xa5);
	delay_ms(1);

	DIOExpressWriteData(0x43,ton_code[0]);
	delay_ms(1);
	DIOExpressWriteData(0x20,0x03);
	delay_ms(1);
	DIOExpressWriteData(0x21,0x09);
	delay_ms(1);

	VOUT.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_ON);
	delay_ms(3);	

	VHEN1[0] = EN_OTP43_47_VD[0] * 1.0 * 5;
	VHEN2[0] = EN_OTP43_47_VD[0] * 1.1 * 5;
	VHEN3[0] = EN_OTP43_47_VD[0] * 1.2 * 5;
	VHEN4[0] = EN_OTP43_47_VD[0] * 1.3 * 5;
	VHEN5[0] = EN_OTP43_47_VD[0] * 1.4 * 5;

	VOUT.Set(FV, VHEN1[0], FOVI_10V, FOVI_100MA, RELAY_ON);
	VOUT.Set(FV, VHEN2[0], FOVI_10V, FOVI_100MA, RELAY_ON);
	VOUT.Set(FV, VHEN3[0], FOVI_10V, FOVI_100MA, RELAY_ON);
	VOUT.Set(FV, VHEN4[0], FOVI_10V, FOVI_100MA, RELAY_ON);
	VOUT.Set(FV, VHEN5[0], FOVI_10V, FOVI_100MA, RELAY_ON);
	delay_ms(1);	

	DIOExpressWriteData(0x21,0x0B);
	delay_ms(1);
	DIOExpressWriteData(0x21,0x09);
	delay_ms(1);

	VOUT.Set(FV, VHEN5[0], FOVI_10V, FOVI_100MA, RELAY_ON);
	VOUT.Set(FV, VHEN4[0], FOVI_10V, FOVI_100MA, RELAY_ON);
	VOUT.Set(FV, VHEN3[0], FOVI_10V, FOVI_100MA, RELAY_ON);
	VOUT.Set(FV, VHEN2[0], FOVI_10V, FOVI_100MA, RELAY_ON);
	VOUT.Set(FV, VHEN1[0], FOVI_10V, FOVI_100MA, RELAY_ON);
	delay_ms(1);	


	DIOExpressWriteData(0x6a,0x00);
	delay_ms(1);


	VOUT.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_ON);	
	VIN.Set(FV, 0.0, FPVI10_5V, FPVI10_100MA, RELAY_ON);
	EN.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_ON);
	//I2CPUP.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_ON);
	delay_ms(1);
	dio.Disconnect();
	delay_ms(1);
	cbit.SetOn(-1);
	delay_ms(1);

	Ton_burn->SetTestResult(0, 0, EN_OTP43_47_VD[0]);

	}

    return 0;
}


DUT_API int T47_Ton_Post(short funcindex, LPCTSTR funclabel)
{
    //{{AFX_STS_PARAM_PROTOTYPES
    CParam *Ton_post = StsGetParam(funcindex,"Ton_post");
    CParam *Ton_post_err = StsGetParam(funcindex,"Ton_post_err");
    //}}AFX_STS_PARAM_PROTOTYPES

    // TODO: Add your function code here
	cbit.SetOn(/*K1,*/K2,/*K3,*/K4,K7,K11,K12,K13,K8,-1);
	delay_ms(3);
	MODE.Set(FI, 0.0, FOVI_5V, FOVI_100MA, RELAY_OFF);
	delay_ms(3);

	VOUT.Set(FV, 1.0, FOVI_5V, FOVI_100MA, RELAY_ON);
	VIN.Set(FV, 3.6, FPVI10_5V, FPVI10_100MA, RELAY_ON);
	EN.Set(FV, 3.6, FOVI_5V, FOVI_100MA, RELAY_ON);
LX.Set(FI, -0.5e-3, FPVI10_5V, FPVI10_1MA, RELAY_ON);
	delay_ms(3);
	dio.Connect();
	delay_ms(3);
	DIOExpressWriteData(0x6a,0x5a);
	delay_ms(1);
	DIOExpressWriteData(0x6a,0xa5);
	delay_ms(1);

	EN.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_ON);
	delay_ms(3);
	EN.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_OFF);
	delay_ms(3);

	//DIOExpressWriteData(0x23,0x90);
	//delay_ms(3);
	//DIOExpressReadData(0x29);
	//delay_ms(1);

	DIOExpressWriteData(0x25,0x10);
	delay_ms(1);
	DIOExpressWriteData(0x26,0x08);
	delay_ms(1);
	DIOExpressWriteData(0x45,0x80);
	delay_ms(1);
	DIOExpressWriteData(0x44,0x00);
	delay_ms(1);
	DIOExpressWriteData(0x24,0x80);
	delay_ms(1);

	MODE.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_ON);
	delay_ms(3);

#if 0
	qtmu0.SetStartInput(QTMU_PLUS_IMPEDANCE_1M, QTMU_PLUS_VRNG_5V, QTMU_PLUS_FILTER_WIDEBAND);
	qtmu0.SetStopInput(QTMU_PLUS_IMPEDANCE_1M, QTMU_PLUS_VRNG_5V, QTMU_PLUS_FILTER_WIDEBAND);
	qtmu0.SetStartTrigger(2.5, QTMU_PLUS_POS_SLOPE);
	qtmu0.SetStopTrigger(1.2, QTMU_PLUS_NEG_SLOPE);
	qtmu0.SetInSource(QTMU_PLUS_SINGLE_SOURCE);
	qtmu0.Connect();

	//qtmu0.MeasFreq(QTMU_PLUS_COARSE, QTMU_PLUS_TRNG_US, 20, 5); //timeout=2ms
	qtmu0.Meas(QTMU_PLUS_FINE,QTMU_PLUS_TRNG_NS,5);
	adresult[0] = qtmu0.GetMeasureResult(0);
	adresult[0] = adresult[0] *1e3f;
#endif

	qtmu0.SetStartInput(QTMU_PLUS_IMPEDANCE_1M, QTMU_PLUS_VRNG_5V, QTMU_PLUS_FILTER_10MHz);
	qtmu0.SetStopInput(QTMU_PLUS_IMPEDANCE_1M, QTMU_PLUS_VRNG_5V, QTMU_PLUS_FILTER_10MHz);
	qtmu0.SetStartTrigger(2.5, QTMU_PLUS_POS_SLOPE);
	qtmu0.SetInSource(QTMU_PLUS_SINGLE_SOURCE);
	qtmu0.Connect();

	qtmu0.MeasFreq(QTMU_PLUS_FINE, QTMU_PLUS_TRNG_US, 20, 5); //timeout=2ms

	adresult[0] = qtmu0.GetMeasureResult(0);
	adresult[0] = adresult[0]/1e3f;

	DIOExpressWriteData(0x6a,0x00);
	delay_ms(1);
	dio.Disconnect();
	qtmu0.Disconnect();
	delay_ms(1);

	LX.Set(FI, 0.0, FPVI10_5V, FPVI10_1MA, RELAY_ON);
	VIN.Set(FV, 0.0, FPVI10_5V, FPVI10_100MA, RELAY_ON);
	EN.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_ON);
	VOUT.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_ON);
	//I2CPUP.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_ON);
	LX.Set(FV, 0.0, FPVI10_5V, FPVI10_1MA, RELAY_ON);
	delay_ms(3);
	LX.Set(FV, 0.0, FPVI10_5V, FPVI10_1MA, RELAY_OFF);
	VIN.Set(FV, 0.0, FPVI10_5V, FPVI10_100MA, RELAY_OFF);
	EN.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_OFF);
	VOUT.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_OFF);
	//I2CPUP.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_OFF);
	MODE.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_OFF);
	delay_ms(3);
	cbit.SetOn(-1);
	delay_ms(3);

	Ton_post->SetTestResult(0, 0, adresult[0]);
	Ton_post_err->SetTestResult(0, 0, (ton_target -adresult[0])/(adresult[0]+1e-9f)*100);

    return 0;
}


DUT_API int T48_Pulldown_RES(short funcindex, LPCTSTR funclabel)
{
    //{{AFX_STS_PARAM_PROTOTYPES
    CParam *LX_Dis_R = StsGetParam(funcindex,"LX_Dis_R");
    CParam *EN_PD_RES = StsGetParam(funcindex,"EN_PD_RES");
    CParam *MODE_PD_RES = StsGetParam(funcindex,"MODE_PD_RES");
    //}}AFX_STS_PARAM_PROTOTYPES

    // TODO: Add your function code here
	cbit.SetOn(K1,K4,K8,K13,-1);
	delay_ms(3);

	MODE.Set(FV, 0.0, FOVI_5V, FOVI_1MA, RELAY_ON);
	VIN.Set(FV, 3.6, FPVI10_10V, FPVI10_100MA, RELAY_ON);
	EN.Set(FV, 0.0, FOVI_5V, FOVI_1MA, RELAY_ON);
	delay_ms(3);

	LX.Set(FI, 5e-3f, FPVI10_1V, FPVI10_100MA, RELAY_ON);
	delay_ms(3);

	LX.MeasureVI(50, 50);
	delay_ms(3);
	adresult[0] = LX.GetMeasResult(0, MVRET);

	adresult[0] = adresult[0]/5e-3f;

	LX_Dis_R->SetTestResult(0, 0, adresult[0]);

	LX.Set(FI, 0.0, FPVI10_1V, FPVI10_100MA, RELAY_ON);
	delay_ms(3);

	EN.Set(FV, 0.3, FOVI_5V, FOVI_1MA, RELAY_ON);
	delay_ms(3);
	EN.MeasureVI(50, 50);
	delay_ms(3);

	adresult[0] = EN.GetMeasResult(0, MIRET);
	adresult[0] = 0.3/adresult[0];
	EN_PD_RES->SetTestResult(0, 0, adresult[0]/1e3f);

	EN.Set(FV, 0.0, FOVI_5V, FOVI_1MA, RELAY_ON);
	delay_ms(3);

	MODE.Set(FV, 0.3, FOVI_5V, FOVI_1MA, RELAY_ON);
	delay_ms(3);
	MODE.MeasureVI(50, 50);
	delay_ms(3);

	adresult[0] = MODE.GetMeasResult(0, MIRET);
	adresult[0] = 0.3/adresult[0];
	MODE_PD_RES->SetTestResult(0, 0, adresult[0]/1e3f);


	MODE.Set(FV, 0.0, FOVI_5V, FOVI_1MA, RELAY_ON);
	VIN.Set(FV, 0.0, FPVI10_10V, FPVI10_100MA, RELAY_ON);
	EN.Set(FV, 0.0, FOVI_5V, FOVI_1MA, RELAY_ON);
	LX.Set(FV, 0.0, FPVI10_1V, FPVI10_100MA, RELAY_ON);
	delay_ms(3);
	MODE.Set(FV, 0.0, FOVI_5V, FOVI_1MA, RELAY_OFF);
	VIN.Set(FV, 0.0, FPVI10_10V, FPVI10_100MA, RELAY_OFF);
	EN.Set(FV, 0.0, FOVI_5V, FOVI_1MA, RELAY_OFF);
	LX.Set(FV, 0.0, FPVI10_1V, FPVI10_100MA, RELAY_OFF);
	delay_ms(3);
	cbit.SetOn(-1);
	delay_ms(3);

    return 0;
}


DUT_API int T43_Inter_POR_Search(short funcindex, LPCTSTR funclabel)
{
    //{{AFX_STS_PARAM_PROTOTYPES
    CParam *INTER_POR_R = StsGetParam(funcindex,"INTER_POR_R");
    CParam *INTER_POR_F = StsGetParam(funcindex,"INTER_POR_F");
    //}}AFX_STS_PARAM_PROTOTYPES

    // TODO: Add your function code here

	double inter_por_r[2] = { 0.0, 0.0 };
	double inter_por_f[2] = { 0.0, 0.0 };
	double vx = 0;
	int temp_data[2]={0};

	dio.SetVOH(1.6);
	dio.SetVOL(1.2);
	delay_ms(3);

	cbit.SetOn(/*K1,*/K2,K3,K4,K13,-1);//K3 is used for read
	delay_ms(3);
	dio.Connect();
	delay_ms(1);

	//VOUT.Set(FV, 1.1, FOVI_5V, FOVI_100MA, RELAY_ON);
	MODE.Set(FI, 0.0, FOVI_5V, FOVI_1MA, RELAY_ON);
	//I2CPUP.Set(FV, 1.0, FOVI_5V, FOVI_100MA, RELAY_ON);
	VIN.Set(FV, 3.6, FPVI10_5V, FPVI10_100MA, RELAY_ON);
	EN.Set(FV, 3.6, FOVI_5V, FOVI_100MA, RELAY_ON);
	delay_ms(3);

	DIOExpressWriteData(0x6a,0x5a);
	delay_ms(1);
	DIOExpressWriteData(0x6a,0xa5);
	delay_ms(3);

	EN.Set(FV, -0.0, FOVI_1V, FOVI_100MA, RELAY_ON);
	delay_ms(3);
	EN.Set(FI, 0.0, FOVI_5V, FOVI_100UA, RELAY_ON);
	delay_ms(10);



	for (vx = 0; vx <= 70; vx++)
	{
		VIN.Set(FV, 2.5 - vx*0.05, FPVI10_5V, FPVI10_100MA, RELAY_ON, 0.5);
		delay_ms(3);
		//VIN.Measure(500,100);

		DIOExpressWriteData(0x23,0x90);
		delay_ms(1);

		temp_data[0] = DIOExpressReadData(0x29);
		delay_ms(1);

			if ((temp_data[0]!=0x01))
			{
				inter_por_f[0] = 2.5 - vx*0.05;
				break;
			}
	
	}

		INTER_POR_F->SetTestResult(0, 0, inter_por_f[0]);

	dio.SetVOH(1.3);
	dio.SetVOL(1.0);
	delay_ms(3);

	for (vx = 0; vx <= 70; vx++)
	{
		VIN.Set(FV, 1.2 + vx*0.05, FPVI10_5V, FPVI10_100MA, RELAY_ON, 0.5);
		EN.Set(FV, 3.6, FOVI_5V, FOVI_100MA, RELAY_ON);
		delay_ms(1);

		DIOExpressWriteData(0x6a,0x5a);
		delay_ms(1);
		DIOExpressWriteData(0x6a,0xa5);
		delay_ms(1);

		EN.Set(FV, -0.0, FOVI_1V, FOVI_100MA, RELAY_ON);
		delay_ms(1);
		EN.Set(FV, -0.0, FOVI_1V, FOVI_100MA, RELAY_OFF);
		delay_ms(1);

		DIOExpressWriteData(0x23,0x90);
		//delay_ms(3);

		temp_data[0] = DIOExpressReadData(0x29);
		//delay_ms(1);

			if ((temp_data[0]==0x01))
			{
				inter_por_r[0] = 1.2 + vx*0.05;
				break;
			}
	
	}

		INTER_POR_R->SetTestResult(0, 0, inter_por_r[0]);

	DIOExpressWriteData(0x6a,0x00);
	delay_ms(1);
	dio.Disconnect();
	delay_ms(1);

	dio.SetVOH(2.0);
	dio.SetVOL(1.0);

	VOUT.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_ON);
	MODE.Set(FV, 0.0, FOVI_5V, FOVI_1MA, RELAY_ON);
	VIN.Set(FV, 0.0, FPVI10_5V, FPVI10_100MA, RELAY_ON);
	EN.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_ON);
	//I2CPUP.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_ON);
	delay_ms(3);
	VOUT.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_OFF);
	MODE.Set(FV, 0.0, FOVI_5V, FOVI_1MA, RELAY_OFF);
	VIN.Set(FV, 0.0, FPVI10_5V, FPVI10_100MA, RELAY_OFF);
	EN.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_OFF);
	//I2CPUP.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_OFF);
	delay_ms(3);
	cbit.SetOn(-1);
	delay_ms(3);


    return 0;
}

DUT_API int T49_Inter_POR(short funcindex, LPCTSTR funclabel)
{
    //{{AFX_STS_PARAM_PROTOTYPES
    CParam *INTER_POR_CK1 = StsGetParam(funcindex,"INTER_POR_CK1");
    CParam *INTER_POR_CK2 = StsGetParam(funcindex,"INTER_POR_CK2");
    CParam *INTER_POR_CK3 = StsGetParam(funcindex,"INTER_POR_CK3");
    //}}AFX_STS_PARAM_PROTOTYPES

    // TODO: Add your function code here
	int temp_data[2]={0};
	dio.SetVOH(1.6);
	dio.SetVOL(1.2);
	delay_ms(3);

	cbit.SetOn(/*K1,*/K2,K3,K4,K13,-1);//K3 is used for read
	delay_ms(3);
	dio.Connect();
	delay_ms(1);

	//VOUT.Set(FV, 1.1, FOVI_5V, FOVI_100MA, RELAY_ON);
	MODE.Set(FI, 0.0, FOVI_5V, FOVI_1MA, RELAY_ON);
	//I2CPUP.Set(FV, 1.0, FOVI_5V, FOVI_100MA, RELAY_ON);
	VIN.Set(FV, 3.6, FPVI10_5V, FPVI10_100MA, RELAY_ON);
	EN.Set(FV, 3.6, FOVI_5V, FOVI_100MA, RELAY_ON);
	delay_ms(3);

	DIOExpressWriteData(0x6a,0x5a);
	delay_ms(1);
	DIOExpressWriteData(0x6a,0xa5);
	delay_ms(1);
	DIOExpressWriteData(0x23,0x90);
	delay_ms(1);

	EN.Set(FV, -0.0, FOVI_1V, FOVI_100MA, RELAY_ON);
	delay_ms(3);
	EN.Set(FI, 0.0, FOVI_5V, FOVI_100UA, RELAY_ON);
	delay_ms(10);

///INTER_POR_CK1
	VIN.Set(FV, 1.8, FPVI10_5V, FPVI10_100MA, RELAY_ON);
	delay_ms(3);
	EN.Set(FV, 3.6, FOVI_5V, FOVI_100MA, RELAY_ON);
	delay_ms(1);

	DIOExpressWriteData(0x6a, 0x5a);
	delay_ms(1);
	DIOExpressWriteData(0x6a, 0xa5);
	delay_ms(1);

	EN.Set(FV, -0.0, FOVI_1V, FOVI_100MA, RELAY_ON);
	delay_ms(1);
	EN.Set(FV, -0.0, FOVI_1V, FOVI_100MA, RELAY_OFF);
	delay_ms(1);

	DIOExpressWriteData(0x23, 0x90);

	temp_data[0] = DIOExpressReadData(0x29);
	delay_ms(1);
	INTER_POR_CK1->SetTestResult(0, 0, temp_data[0]);

///INTER_POR_CK2
	dio.SetVOH(1.3);
	dio.SetVOL(1.0);
	VIN.Set(FV, 1.3, FPVI10_5V, FPVI10_100MA, RELAY_ON);
	delay_ms(3);
	EN.Set(FV, 3.6, FOVI_5V, FOVI_100MA, RELAY_ON);
	delay_ms(1);

	DIOExpressWriteData(0x6a, 0x5a);
	delay_ms(1);
	DIOExpressWriteData(0x6a, 0xa5);
	delay_ms(1);

	EN.Set(FV, -0.0, FOVI_1V, FOVI_100MA, RELAY_ON);
	delay_ms(1);
	EN.Set(FV, -0.0, FOVI_1V, FOVI_100MA, RELAY_OFF);
	delay_ms(1);

	DIOExpressWriteData(0x23, 0x90);

	temp_data[0] = DIOExpressReadData(0x29);
	delay_ms(1);
	INTER_POR_CK2->SetTestResult(0, 0, temp_data[0]);

///INTER_POR_CK3
	dio.SetVOH(1.6);
	dio.SetVOL(1.2);
	VIN.Set(FV, 2.1, FPVI10_5V, FPVI10_100MA, RELAY_ON);
	delay_ms(3);
	EN.Set(FV, 3.6, FOVI_5V, FOVI_100MA, RELAY_ON);
	delay_ms(1);

	DIOExpressWriteData(0x6a, 0x5a);
	delay_ms(1);
	DIOExpressWriteData(0x6a, 0xa5);
	delay_ms(1);

	EN.Set(FV, -0.0, FOVI_1V, FOVI_100MA, RELAY_ON);
	delay_ms(1);
	EN.Set(FV, -0.0, FOVI_1V, FOVI_100MA, RELAY_OFF);
	delay_ms(1);

	DIOExpressWriteData(0x23, 0x90);

	temp_data[0] = DIOExpressReadData(0x29);
	delay_ms(1);
	INTER_POR_CK3->SetTestResult(0, 0, temp_data[0]);

//power_off
	DIOExpressWriteData(0x6a,0x00);
	delay_ms(1);
	dio.Disconnect();
	delay_ms(1);

	dio.SetVOH(2.0);
	dio.SetVOL(1.0);

	VOUT.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_ON);
	MODE.Set(FV, 0.0, FOVI_5V, FOVI_1MA, RELAY_ON);
	VIN.Set(FV, 0.0, FPVI10_5V, FPVI10_100MA, RELAY_ON);
	EN.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_ON);
	//I2CPUP.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_ON);
	delay_ms(3);
	VOUT.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_OFF);
	MODE.Set(FV, 0.0, FOVI_5V, FOVI_1MA, RELAY_OFF);
	VIN.Set(FV, 0.0, FPVI10_5V, FPVI10_100MA, RELAY_OFF);
	EN.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_OFF);
	//I2CPUP.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_OFF);
	delay_ms(3);
	cbit.SetOn(-1);
	delay_ms(3);



    return 0;
}


DUT_API int T50_REG_read_post(short funcindex, LPCTSTR funclabel)
{
    //{{AFX_STS_PARAM_PROTOTYPES
    CParam *R2_REG_0x6A = StsGetParam(funcindex,"R2_REG_0x6A");
    CParam *R2_REG_0x20 = StsGetParam(funcindex,"R2_REG_0x20");
    CParam *R2_REG_0x21 = StsGetParam(funcindex,"R2_REG_0x21");
    CParam *R2_REG_0x22 = StsGetParam(funcindex,"R2_REG_0x22");
    CParam *R2_REG_0x23 = StsGetParam(funcindex,"R2_REG_0x23");
    CParam *R2_REG_0x24 = StsGetParam(funcindex,"R2_REG_0x24");
    CParam *R2_REG_0x25 = StsGetParam(funcindex,"R2_REG_0x25");
    CParam *R2_REG_0x26 = StsGetParam(funcindex,"R2_REG_0x26");
    CParam *R2_REG_0x27 = StsGetParam(funcindex,"R2_REG_0x27");
    CParam *PFMCMP_code = StsGetParam(funcindex,"PFMCMP_code");
    CParam *IZXCMP_code = StsGetParam(funcindex,"IZXCMP_code");
    CParam *R2_REG_0x28 = StsGetParam(funcindex,"R2_REG_0x28");
    CParam *R2_REG_0x29 = StsGetParam(funcindex,"R2_REG_0x29");
    CParam *R2_REG_0x40 = StsGetParam(funcindex,"R2_REG_0x40");
    CParam *R2_REG_0x41 = StsGetParam(funcindex,"R2_REG_0x41");
    CParam *R2_REG_0x42 = StsGetParam(funcindex,"R2_REG_0x42");
    CParam *R2_REG_0x43 = StsGetParam(funcindex,"R2_REG_0x43");
    CParam *R2_REG_0x44 = StsGetParam(funcindex,"R2_REG_0x44");
    CParam *R2_REG_0x45 = StsGetParam(funcindex,"R2_REG_0x45");
    CParam *R2_REG_0x46 = StsGetParam(funcindex,"R2_REG_0x46");
    CParam *R2_REG_0x47 = StsGetParam(funcindex,"R2_REG_0x47");
    CParam *R2_REG_0x48 = StsGetParam(funcindex,"R2_REG_0x48");
    //}}AFX_STS_PARAM_PROTOTYPES

    // TODO: Add your function code here
	dio.SetVOH(2.0);
	dio.SetVOL(1.0);

	cbit.SetOn(/*K1,*/K2,K3,K4,K13,K11/*,K12*/,-1);//K3 is used for read//2024/08/21,add K11,K12,VOUT_fovi and Cout
	delay_ms(3);
	dio.Connect();
	delay_ms(1);

	VOUT.Set(FV, 3.6, FOVI_5V, FOVI_100MA, RELAY_ON);	//2024/08/21,Set VOUT = 3.6V can make ic stable.
	MODE.Set(FI, 0.0, FOVI_5V, FOVI_1MA, RELAY_ON);
	//I2CPUP.Set(FV, 1.0, FOVI_5V, FOVI_100MA, RELAY_ON);
	VIN.Set(FV, 3.6, FPVI10_5V, FPVI10_100MA, RELAY_ON);
	EN.Set(FV, 3.6, FOVI_5V, FOVI_100MA, RELAY_ON);
	delay_ms(3);

	DIOExpressWriteData(0x6a,0x5a);
	delay_ms(1);
	DIOExpressWriteData(0x6a,0xa5);
	delay_ms(3);

	EN.Set(FV, -0.0, FOVI_1V, FOVI_100MA, RELAY_ON);
	delay_ms(3);
	EN.Set(FI, 0.0, FOVI_5V, FOVI_100UA, RELAY_ON);
	delay_ms(3);


	DIOExpressWriteData(0x23,0x90);   delay_ms(1);
	adresult[0] = DIOExpressReadData(0x6a);
	R2_REG_0x6A->SetTestResult(0, 0, adresult[0]);

	DIOExpressWriteData(0x23,0x90);   delay_ms(1);
	adresult[0] = DIOExpressReadData(0x20);
	R2_REG_0x20->SetTestResult(0, 0, adresult[0]);

	DIOExpressWriteData(0x23,0x90);   delay_ms(1);
	adresult[0] = DIOExpressReadData(0x21);
	R2_REG_0x21->SetTestResult(0, 0, adresult[0]);

	DIOExpressWriteData(0x23,0x90);   delay_ms(1);
	adresult[0] = DIOExpressReadData(0x22);
	R2_REG_0x22->SetTestResult(0, 0, adresult[0]);

	DIOExpressWriteData(0x23,0x90);   delay_ms(1);
	adresult[0] = DIOExpressReadData(0x23);
	R2_REG_0x23->SetTestResult(0, 0, adresult[0]);

	DIOExpressWriteData(0x23,0x90);   delay_ms(1);
	adresult[0] = DIOExpressReadData(0x24);
	R2_REG_0x24->SetTestResult(0, 0, adresult[0]);

	DIOExpressWriteData(0x23,0x90);   delay_ms(1);
	adresult[0] = DIOExpressReadData(0x25);
	R2_REG_0x25->SetTestResult(0, 0, adresult[0]);

	DIOExpressWriteData(0x23,0x90);   delay_ms(1);
	adresult[0] = DIOExpressReadData(0x26);
	R2_REG_0x26->SetTestResult(0, 0, adresult[0]);

	DIOExpressWriteData(0x23,0x90);   delay_ms(1);
	adresult[0] = DIOExpressReadData(0x27);
	R2_REG_0x27->SetTestResult(0, 0, adresult[0]);

	int high[4]={999};
	int low[4]={999};
	int total[8]={0};
	int i=0;
	int temp={0};
	int pfmcmp_code=0;
	int izxcmp_code=0;

	temp = adresult[0];
	
	while(temp)
	{
	if(i<=3)
	{
	low[i]=temp%2;

	temp=temp/2;

	i++;
	}

	if(i>3)
	{
	high[i-4]=temp%2;

	temp=temp/2;

	i++;
	}
	}

	pfmcmp_code=high[0]*1+high[1]*2+high[2]*4+high[3]*8;
	izxcmp_code=low[0]*1+low[1]*2+low[2]*4+low[3]*8;

	PFMCMP_code->SetTestResult(0, 0, pfmcmp_code);
	IZXCMP_code->SetTestResult(0, 0, izxcmp_code);

	DIOExpressWriteData(0x23,0x90);   delay_ms(1);
	adresult[0] = DIOExpressReadData(0x28);
	R2_REG_0x28->SetTestResult(0, 0, adresult[0]);

	DIOExpressWriteData(0x23,0x90);   delay_ms(1);
	adresult[0] = DIOExpressReadData(0x29);
	R2_REG_0x29->SetTestResult(0, 0, adresult[0]);

	DIOExpressWriteData(0x23,0x90);   delay_ms(1);
	OTP40_47_VD[0] = DIOExpressReadData(0x40);
	R2_REG_0x40->SetTestResult(0, 0, OTP40_47_VD[0]);

	DIOExpressWriteData(0x23,0x90);   delay_ms(1);
	OTP41_07_VD[0] = DIOExpressReadData(0x41);
	R2_REG_0x41->SetTestResult(0, 0, OTP41_07_VD[0]);

	DIOExpressWriteData(0x23,0x90);   delay_ms(1);
	OTP42_07_VD[0] = DIOExpressReadData(0x42);
	R2_REG_0x42->SetTestResult(0, 0, OTP42_07_VD[0]);

	DIOExpressWriteData(0x23,0x90);   delay_ms(1);
	OTP43_07_VD[0] = DIOExpressReadData(0x43);
	R2_REG_0x43->SetTestResult(0, 0, OTP43_07_VD[0]);

//2024/08/21,SWAP 0x47 to early than 0x44 is better to stable OTP_READ.
	DIOExpressWriteData(0x23, 0x90);   delay_ms(1);
	OTP47_05_VD[0] = DIOExpressReadData(0x47);
	R2_REG_0x47->SetTestResult(0, 0, OTP47_05_VD[0]);

//2024/08/21,SWAP 0x44 read to last than 0x47 is better to stable OTP_READ.
	DIOExpressWriteData(0x23,0x90);   delay_ms(1);
	adresult[0] = DIOExpressReadData(0x44);
	R2_REG_0x44->SetTestResult(0, 0, adresult[0]);

	DIOExpressWriteData(0x23,0x90);   delay_ms(1);
	adresult[0] = DIOExpressReadData(0x45);
	R2_REG_0x45->SetTestResult(0, 0, adresult[0]);

	DIOExpressWriteData(0x23,0x90);   delay_ms(1);
	adresult[0] = DIOExpressReadData(0x46);
	R2_REG_0x46->SetTestResult(0, 0, adresult[0]);

	DIOExpressWriteData(0x23,0x90);   delay_ms(1);
	OTP48_04_VD[0] = DIOExpressReadData(0x48);
	R2_REG_0x48->SetTestResult(0, 0, OTP48_04_VD[0]);



	DIOExpressWriteData(0x6a,0x00);
	delay_ms(1);
	VIN.Set(FV, 0.0, FPVI10_5V, FPVI10_100MA, RELAY_ON);
	EN.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_ON);
	//I2CPUP.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_ON);
	MODE.Set(FV, 0.0, FOVI_5V, FOVI_1MA, RELAY_ON);
	VOUT.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_ON);	//2024/08/21,Set VOUT = 3.6V can make ic stable.
	delay_ms(3);
	VOUT.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_OFF);	//2024/08/21,Set VOUT = 3.6V can make ic stable.
	MODE.Set(FV, 0.0, FOVI_5V, FOVI_1MA, RELAY_OFF);
	VIN.Set(FV, 0.0, FPVI10_5V, FPVI10_100MA, RELAY_OFF);
	EN.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_OFF);
	//I2CPUP.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_OFF);
	delay_ms(3);
	cbit.SetOn(-1);
	delay_ms(3);
    return 0;
}


DUT_API int T51_Leakage_Post(short funcindex, LPCTSTR funclabel)
{
    //{{AFX_STS_PARAM_PROTOTYPES
    CParam *Ilk_vin_post = StsGetParam(funcindex,"Ilk_vin_post");
    CParam *Ilk_enh_post = StsGetParam(funcindex,"Ilk_enh_post");
    CParam *Ilk_enl_post = StsGetParam(funcindex,"Ilk_enl_post");
    CParam *Ilk_modeh_post = StsGetParam(funcindex,"Ilk_modeh_post");
    CParam *Ilk_model_post = StsGetParam(funcindex,"Ilk_model_post");
    CParam *Ilk_lxh_post = StsGetParam(funcindex,"Ilk_lxh_post");
    CParam *Ilk_lxl_post = StsGetParam(funcindex,"Ilk_lxl_post");
    CParam *Ilk_vouth_post = StsGetParam(funcindex,"Ilk_vouth_post");
    CParam *Ilk_voutl_post = StsGetParam(funcindex,"Ilk_voutl_post");
    CParam *Ilk_vin_delta = StsGetParam(funcindex,"Ilk_vin_delta");
    CParam *Ilk_enh_delta = StsGetParam(funcindex,"Ilk_enh_delta");
    CParam *Ilk_enl_delta = StsGetParam(funcindex,"Ilk_enl_delta");
    CParam *Ilk_modeh_delta = StsGetParam(funcindex,"Ilk_modeh_delta");
    CParam *Ilk_model_delta = StsGetParam(funcindex,"Ilk_model_delta");
    CParam *Ilk_lxh_delta = StsGetParam(funcindex,"Ilk_lxh_delta");
    CParam *Ilk_lxl_delta = StsGetParam(funcindex,"Ilk_lxl_delta");
    CParam *Ilk_vouth_delta = StsGetParam(funcindex,"Ilk_vouth_delta");
    CParam *Ilk_voutl_delta = StsGetParam(funcindex,"Ilk_voutl_delta");
    //}}AFX_STS_PARAM_PROTOTYPES

    // TODO: Add your function code here
	cbit.SetOn(K1,K4,K8,K11,/*K12,K13,*/-1);
	delay_ms(3);

	EN.Set(FV, 0.0, FOVI_10V, FOVI_100UA, RELAY_ON);
//	VOUT.Set(FV, 0.0, FOVI_5V, FOVI_10MA, RELAY_ON);
	MODE.Set(FV, 0.0, FOVI_10V, FOVI_100UA, RELAY_ON);
	VIN.Set(FV, 0.0, FPVI10_10V, FPVI10_10MA, RELAY_ON);
//	LX.Set(FV, 0.0, FPVI10_5V, FPVI10_10MA, RELAY_ON);
	delay_ms(3);
	VIN.Set(FV, 5.5, FPVI10_10V, FPVI10_10MA, RELAY_ON);
	delay_ms(3);
	VIN.Set(FV, 5.5, FPVI10_10V, FPVI10_1MA, RELAY_ON);
	delay_ms(3);

	VIN.MeasureVI(50, 50);
	delay_ms(1);
	adresult[0] = VIN.GetMeasResult(0, MIRET);
	ilk_vin_post[0] = adresult[0]*1e6f;
	Ilk_vin_post->SetTestResult(0, 0, ilk_vin_post[0]);

	VIN.Set(FV, 5.5, FPVI10_10V, FPVI10_10MA, RELAY_ON);
	delay_ms(3);
	VIN.Set(FV, 5.5, FPVI10_10V, FPVI10_100MA, RELAY_ON);
	delay_ms(3);

	MODE.Set(FV, 5.5, FOVI_10V, FOVI_100UA, RELAY_ON);
	delay_ms(3);

	MODE.MeasureVI(50, 50);
	delay_ms(1);
	adresult[0] = MODE.GetMeasResult(0, MIRET);
	ilk_modeh_post[0] = adresult[0]*1e6f;
	Ilk_modeh_post->SetTestResult(0, 0, ilk_modeh_post[0]);

	MODE.Set(FV, 0.0, FOVI_10V, FOVI_100UA, RELAY_ON);
	delay_ms(3);

	MODE.MeasureVI(50, 50);
	delay_ms(1);
	adresult[0] = MODE.GetMeasResult(0, MIRET);
	ilk_model_post[0] = adresult[0]*1e6f;
	Ilk_model_post->SetTestResult(0, 0, ilk_model_post[0]);


	MODE.Set(FV, 0.0, FOVI_5V, FOVI_10MA, RELAY_ON);
	delay_ms(3);
	VOUT.Set(FV, 5.5, FOVI_10V, FOVI_10MA, RELAY_ON);
	delay_ms(3);
	VOUT.Set(FV, 5.5, FOVI_10V, FOVI_1MA, RELAY_ON);
	delay_ms(3);
	VOUT.Set(FV, 5.5, FOVI_10V, FOVI_100UA, RELAY_ON);
	delay_ms(3);

	VOUT.MeasureVI(50, 50);
	delay_ms(10);

	adresult[0] = VOUT.GetMeasResult(0, MIRET);
	ilk_vouth_post[0] = adresult[0]*1e6f;
	Ilk_vouth_post->SetTestResult(0, 0, ilk_vouth_post[0]);

	VOUT.Set(FV, 0.0, FOVI_10V, FOVI_10MA, RELAY_ON);
	delay_ms(3);

	VOUT.MeasureVI(50, 50);
	delay_ms(1);
	adresult[0] = VOUT.GetMeasResult(0, MIRET);
	ilk_voutl_post[0] = adresult[0]*1e6f;
	Ilk_voutl_post->SetTestResult(0, 0, ilk_voutl_post[0]);

	VOUT.Set(FV, 0.0, FOVI_10V, FOVI_100UA, RELAY_ON);
	delay_ms(3);
	VIN.Set(FV, 0.0, FPVI10_10V, FPVI10_10UA, RELAY_ON);
	delay_ms(3);
	EN.Set(FV, 0.0, FOVI_10V, FOVI_10MA, RELAY_OFF);
	VOUT.Set(FV, 0.0, FOVI_10V, FOVI_10MA, RELAY_OFF);
	MODE.Set(FV, 0.0, FOVI_10V, FOVI_10MA, RELAY_OFF);
	VIN.Set(FV, 0.0, FPVI10_10V, FPVI10_10MA, RELAY_OFF);
	LX.Set(FV, 0.0, FPVI10_10V, FPVI10_10MA, RELAY_OFF);
	delay_ms(3);
	cbit.SetOn(-1);
	delay_ms(3);


//////////////////////////////////////////////////
	cbit.SetOn(K1,K4,K8,K11,K12,K13,-1);
	delay_ms(3);

	EN.Set(FV, 0.0, FOVI_10V, FOVI_100UA, RELAY_ON);
	MODE.Set(FV, 0.0, FOVI_10V, FOVI_100UA, RELAY_ON);
	VIN.Set(FV, 0.0, FPVI10_10V, FPVI10_100MA, RELAY_ON);
	delay_ms(3);
	VIN.Set(FV, 5.5, FPVI10_10V, FPVI10_100MA, RELAY_ON);
	delay_ms(3);

	EN.Set(FV, 5.5, FOVI_10V, FOVI_1MA, RELAY_ON);
	delay_ms(3);

	EN.MeasureVI(50, 50);
	delay_ms(1);

	adresult[0] = EN.GetMeasResult(0, MIRET);
	ilk_enh_post[0] = adresult[0]*1e6f;
	Ilk_enh_post->SetTestResult(0, 0, ilk_enh_post[0]);

	EN.Set(FV, 0.0, FOVI_10V, FOVI_100UA, RELAY_ON);
	delay_ms(3);

	EN.MeasureVI(50, 50);
	delay_ms(1);
	adresult[0] = EN.GetMeasResult(0, MIRET);
	ilk_enl_post[0] = adresult[0]*1e6f;
	Ilk_enl_post->SetTestResult(0, 0, ilk_enl_post[0]);

	VIN.Set(FV, 0.0, FPVI10_10V, FPVI10_100MA, RELAY_ON);
	delay_ms(3);
	VIN.Set(FV, 0.0, FPVI10_10V, FPVI10_100MA, RELAY_OFF);
	EN.Set(FV, 0.0, FOVI_10V, FOVI_100UA, RELAY_OFF);
	MODE.Set(FV, 0.0, FOVI_10V, FOVI_100UA, RELAY_OFF);
	delay_ms(3);

/////////////////////////
	cbit.SetOn(K2,/*K3,*/K4, K13, K8, K11, -1);//K3 is used for read//2024/08/21,add K11,VOUT_fovi
	delay_ms(3);
	dio.Connect();
	delay_ms(1);

	VOUT.Set(FV, 1.0, FOVI_5V, FOVI_100MA, RELAY_ON);	//2024/08/21,set VOUT = 1V can let ic stage more stable
	//I2CPUP.Set(FV, 3.6, FOVI_5V, FOVI_100MA, RELAY_ON);
	VIN.Set(FV, 3.6, FPVI10_10V, FPVI10_100MA, RELAY_ON);
	EN.Set(FV, 3.6, FOVI_5V, FOVI_100MA, RELAY_ON);
	delay_ms(3);

	DIOExpressWriteData(0x6a,0x5a);
	delay_ms(1);
	DIOExpressWriteData(0x6a,0xa5);
	delay_ms(3);

//	DIOExpressWriteData(0x23,0x90);
//	delay_ms(3);
//	EN.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_ON);
//	delay_ms(3);
//	EN.Set(FI, 0.0, FOVI_5V, FOVI_100UA, RELAY_ON);
//	delay_ms(3);
//	DIOExpressReadData(0x29);
//	delay_ms(1);

	DIOExpressWriteData(0x25,0x01);
	delay_ms(1);

	VIN.Set(FV, 5.5, FPVI10_10V, FPVI10_100MA, RELAY_ON);
	delay_ms(1);
	LX.Set(FV, 5.5, FPVI10_10V, FPVI10_100UA, RELAY_ON);
	delay_ms(3);

	LX.MeasureVI(50, 50);
	delay_ms(1);
	adresult[0] = LX.GetMeasResult(0, MIRET);
	ilk_lxh_post[0] = adresult[0]*1e6f;
	Ilk_lxh_post->SetTestResult(0, 0, ilk_lxh_post[0]);

	LX.Set(FV, 0.0, FPVI10_10V, FPVI10_100UA, RELAY_ON);
	delay_ms(3);

	LX.MeasureVI(50, 50);
	delay_ms(1);
	adresult[0] = LX.GetMeasResult(0, MIRET);
	ilk_lxl_post[0] = adresult[0]*1e6f;
	Ilk_lxl_post->SetTestResult(0, 0, ilk_lxl_post[0]);

	DIOExpressWriteData(0x6a,0x00);
	delay_ms(1);
	dio.Disconnect();
	delay_ms(1);

	VIN.Set(FV, 0.0, FPVI10_10V, FPVI10_100MA, RELAY_ON);
	EN.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_ON);
	//I2CPUP.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_ON);
	VOUT.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_ON);	//2024/08/21,set VOUT = 1V can let ic stage more stable
	delay_ms(3);
	VOUT.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_OFF);	//2024/08/21,set VOUT = 1V can let ic stage more stable
	VIN.Set(FV, 0.0, FPVI10_10V, FPVI10_100MA, RELAY_OFF);
	EN.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_OFF);
	//I2CPUP.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_OFF);
	delay_ms(3);
	cbit.SetOn(-1);
	delay_ms(3);

	Ilk_vin_delta->SetTestResult(0, 0, ilk_vin_post[0] - ilk_vin_pre[0]);
	Ilk_enh_delta->SetTestResult(0, 0, ilk_enh_post[0] - ilk_enh_pre[0]);
	Ilk_enl_delta->SetTestResult(0, 0, ilk_enl_post[0] - ilk_enl_pre[0]);
	Ilk_modeh_delta->SetTestResult(0, 0, ilk_modeh_post[0] - ilk_modeh_pre[0]);
	Ilk_model_delta->SetTestResult(0, 0, ilk_model_post[0] - ilk_model_pre[0]);
	Ilk_lxh_delta->SetTestResult(0, 0, ilk_lxh_post[0] - ilk_lxh_pre[0]);
	Ilk_lxl_delta->SetTestResult(0, 0, ilk_lxl_post[0] - ilk_lxl_pre[0]);
	Ilk_vouth_delta->SetTestResult(0, 0, ilk_vouth_post[0] - ilk_vouth_pre[0]);
	Ilk_voutl_delta->SetTestResult(0, 0, ilk_voutl_post[0] - ilk_voutl_pre[0]);

    return 0;
}


DUT_API int T52_CONTINUITY_Post(short funcindex, LPCTSTR funclabel)
{
    //{{AFX_STS_PARAM_PROTOTYPES
    CParam *OS2_VIN = StsGetParam(funcindex,"OS2_VIN");
    CParam *OS2_LX = StsGetParam(funcindex,"OS2_LX");
    CParam *OS2_VOUT = StsGetParam(funcindex,"OS2_VOUT");
    CParam *OS2_MODE = StsGetParam(funcindex,"OS2_MODE");
    CParam *OS2_EN = StsGetParam(funcindex,"OS2_EN");
    //}}AFX_STS_PARAM_PROTOTYPES

    // TODO: Add your function code here
	cbit.SetOn(K1,K4,K8,K11,-1);
	delay_ms(3);

	EN.Set(FV, 0.0, FOVI_5V, FOVI_10MA, RELAY_ON);
	VOUT.Set(FV, 0.0, FOVI_5V, FOVI_10MA, RELAY_ON);
	MODE.Set(FV, 0.0, FOVI_5V, FOVI_10MA, RELAY_ON);
	VIN.Set(FV, 0.0, FPVI10_5V, FPVI10_10MA, RELAY_ON);
	LX.Set(FV, 0.0, FPVI10_5V, FPVI10_10MA, RELAY_ON);
	delay_ms(3);

////////////////////
	VIN.Set(FI, -100e-6f, FPVI10_2V, FPVI10_10MA, RELAY_ON);
	delay_ms(3);

	VIN.MeasureVI(50, 50);
	delay_ms(1);
	adresult[0] = VIN.GetMeasResult(0, MVRET);
	OS2_VIN->SetTestResult(0, 0, adresult[0]);

	VIN.Set(FI, 0.0, FPVI10_2V, FPVI10_10MA, RELAY_ON);
	delay_ms(3);
	VIN.Set(FV, 0, FPVI10_2V, FPVI10_10MA, RELAY_ON);
	delay_ms(3);

	/////////////////////
	LX.Set(FI, -100e-6f, FPVI10_2V, FPVI10_10MA, RELAY_ON);
	delay_ms(3);

	LX.MeasureVI(50, 50);
	delay_ms(1);
	adresult[0] = LX.GetMeasResult(0, MVRET);
	OS2_LX->SetTestResult(0, 0, adresult[0]);

	LX.Set(FI, 0.0, FPVI10_2V, FPVI10_10MA, RELAY_ON);
	delay_ms(3);
	LX.Set(FV, 0, FPVI10_2V, FPVI10_10MA, RELAY_ON);
	delay_ms(3);

	/////////////////////////
	VOUT.Set(FI, -100e-6f, FOVI_2V, FOVI_10MA, RELAY_ON);
	delay_ms(3);

	VOUT.MeasureVI(50, 50);
	delay_ms(1);
	adresult[0] = VOUT.GetMeasResult(0, MVRET);
	OS2_VOUT->SetTestResult(0, 0, adresult[0]);

	VOUT.Set(FI, 0e-3f, FOVI_2V, FOVI_10MA, RELAY_ON);
	delay_ms(3);
	VOUT.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	delay_ms(3);


	/////////////////////////
	MODE.Set(FI, -100e-6f, FOVI_2V, FOVI_10MA, RELAY_ON);
	delay_ms(3);

	MODE.MeasureVI(50, 50);
	delay_ms(1);
	adresult[0] = MODE.GetMeasResult(0, MVRET);
	OS2_MODE->SetTestResult(0, 0, adresult[0]);

	MODE.Set(FI, 0e-3f, FOVI_2V, FOVI_10MA, RELAY_ON);
	delay_ms(3);
	MODE.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	delay_ms(3);

	/////////////////////////
	EN.Set(FI, -100e-6f, FOVI_2V, FOVI_10MA, RELAY_ON);
	delay_ms(3);

	EN.MeasureVI(50, 50);
	delay_ms(1);
	adresult[0] = EN.GetMeasResult(0, MVRET);
	OS2_EN->SetTestResult(0, 0, adresult[0]);

	EN.Set(FI, 0e-3f, FOVI_2V, FOVI_10MA, RELAY_ON);
	delay_ms(3);
	EN.Set(FV, 0, FOVI_2V, FOVI_10MA, RELAY_ON);
	delay_ms(3);

	EN.Set(FV, 0.0, FOVI_5V, FOVI_10MA, RELAY_OFF);
	VOUT.Set(FV, 0.0, FOVI_5V, FOVI_10MA, RELAY_OFF);
	MODE.Set(FV, 0.0, FOVI_5V, FOVI_10MA, RELAY_OFF);
	VIN.Set(FV, 0.0, FPVI10_5V, FPVI10_10MA, RELAY_OFF);
	LX.Set(FV, 0.0, FPVI10_5V, FPVI10_10MA, RELAY_OFF);
	delay_ms(3);
	cbit.SetOn(-1);
	delay_ms(3);
    return 0;
}






DUT_API int T29_ZCS_Post2(short funcindex, LPCTSTR funclabel)
{
    //{{AFX_STS_PARAM_PROTOTYPES
    CParam *ZCS_vin2p5_Reg27 = StsGetParam(funcindex,"ZCS_vin2p5_Reg27");
    CParam *ZCS_vin2p5_post = StsGetParam(funcindex,"ZCS_vin2p5_post");
    CParam *ZCS_vin3p6_Reg27 = StsGetParam(funcindex,"ZCS_vin3p6_Reg27");
    CParam *ZCS_vin3p6_post = StsGetParam(funcindex,"ZCS_vin3p6_post");
    CParam *ZCS_vin4p2_Reg27 = StsGetParam(funcindex,"ZCS_vin4p2_Reg27");
    CParam *ZCS_vin4p2_post = StsGetParam(funcindex,"ZCS_vin4p2_post");
    CParam *ZCS_vin5p5_Reg27 = StsGetParam(funcindex,"ZCS_vin5p5_Reg27");
    CParam *ZCS_vin5p5_post = StsGetParam(funcindex,"ZCS_vin5p5_post");
    //}}AFX_STS_PARAM_PROTOTYPES

    // TODO: Add your function code here
	// TODO: Add your function code here
	cbit.SetOn(K2,/*K3,*/K4, K8, K13,K11, -1);//K3 is used for read
	delay_ms(3);
	dio.Connect();
	delay_ms(1);

	VIN.Set(FV, 0.0, FPVI10_10V, FPVI10_1A, RELAY_ON);
	EN.Set(FV, 0.0, FOVI_10V, FOVI_10MA, RELAY_ON);
	VOUT.Set(FV, 0.0, FOVI_10V, FOVI_100MA, RELAY_ON);
	//I2CPUP.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_ON);
	LX.Set(FV, 0.0, FPVI10_10V, FPVI10_1A, RELAY_ON);
	delay_ms(3);

	LX.Set(FI, 0.0, FPVI10_10V, FPVI10_1A, RELAY_ON);
	VOUT.Set(FV, 2.5, FOVI_10V, FOVI_100MA, RELAY_ON);
	VIN.Set(FV, 2.5, FPVI10_10V, FPVI10_1A, RELAY_ON,3);
	delay_ms(10);
	EN.Set(FV, 3.6, FOVI_10V, FOVI_10MA, RELAY_ON,2);
	delay_ms(3);

	DIOExpressWriteData(0x6a, 0x5a);
	delay_ms(1);
	DIOExpressWriteData(0x6a, 0xa5);
	delay_ms(1);

if ( AllSimCOde == 1)
{
DIOExpressWriteData(0x47, vbg_code[0]);	delay_ms(1);
DIOExpressWriteData(0x40, vref_eaout_code[0]);	delay_ms(1);
DIOExpressWriteData(0x41, ibias_code[0] + fosc_code[0]);	delay_ms(1);
DIOExpressWriteData(0x48, rsns_code[0]);	delay_ms(1);
DIOExpressWriteData(0x42, hscl_code[0] + vcl_code[0]);	delay_ms(1);
DIOExpressWriteData(0x43, zcs_code[0] + ton_code[0]);		delay_ms(1);
}

	//	DIOExpressWriteData(0x23,0x90);
	//	delay_ms(3);
	//	DIOExpressReadData(0x29);
	//	delay_ms(1);

	EN.Set(FV, 0.0, FOVI_10V, FOVI_10MA, RELAY_ON);
	delay_ms(3);
	EN.Set(FI, 0.0, FOVI_10V, FOVI_100UA, RELAY_SENSE_ON);
	delay_ms(3);

cbit.SetCBITOn(K3);//EN_DIO
delay_ms(3);
DIOExpressWriteData(0x23,0x90);   delay_ms(1);
Rdata1[0] = DIOExpressReadData(0x27);
ZCS_vin2p5_Reg27->SetTestResult(0, 0, (Rdata1[0] & 0x0F));


if (AllSimCOde == 2)
{
	Rdata1[0] = DIOExpressReadData(0x43);
	Rdata1[1] = Rdata1[0] & 0xF0;
	DIOExpressWriteData(0x43, zcs_code[0] + Rdata1[1]);	delay_ms(1);
}



cbit.SetCBITOff(K3);//EN_DIO
	cbit.SetCBITOff(K4);//FOVI0_to_EN
	delay_ms(3);
	cbit.SetCBITOn(K5);//EN_to_op07_to_FOVI0
	delay_ms(3);


	DIOExpressWriteData(0x25, 0x50);
	delay_ms(1);
	//DIOExpressWriteData(0x26,0xE0);
	delay_ms(1);
	DIOExpressWriteData(0x23, 0x8C);
	delay_ms(1);




	double Trig = 1;//trigger level
	double Trig_Point[2] = { 0 };
	double result[2] = { 0 };
	int sam = 201; //awgSize
	int interval = 100; //awgInterval��unit=us
	double zcs_Data[210] = { 0.0 };
	int i = 0;
	int	m = 0;

	double zcs_post[2] = { 0 };
	double zcs_post_err[2] = { 0 };
	LX.Set(FI, -0.01, FPVI10_10V, FPVI10_1A, RELAY_ON);

	STSAWGCreateRampData(&zcs_Data[0], sam, 1, -0.01, -0.21);
	LX.AwgLoader("zcs_post", FI, FPVI10_10V, FPVI10_1A, zcs_Data, sam);
	LX.AwgSelect("zcs_post", 0, sam - 1, 0, interval);

	EN.SetMeasVTrig(Trig, TRIG_FALLING);
	EN.MeasureVI(sam, interval, MEAS_AWG);
	LX.MeasureVI(sam, interval, MEAS_AWG);

	/*
	STSEnableAWG(&LX);
	STSEnableMeas(&EN, &LX);
	STSAWGRunTriggerStop(&EN, &EN, &LX);
	//StsAWGRun();
	/*/
	VIN.MeasureVI(sam, interval, MEAS_AWG);
	STSEnableAWG(&LX);
	STSEnableMeas(&EN, &LX, &VIN);
	//STSAWGRunTriggerStop(&EN, &EN, &LX,&VIN);
	StsAWGRun();
	//*/

	Trig_Point[0] = EN.GetMeasResult(0, MVRET, TRIG_RESULT);
	m = Trig_Point[0] - 1;
	if (m<2)
	{
		zcs_post[0] = -777;
	}
	else if (m>sam - 3)
	{
		zcs_post[0] = -999;

	}
	else
	{
		zcs_post[0] = 1e3f*zcs_Data[m];//FPVIO+FPVI1

	}

	ZCS_vin2p5_post->SetTestResult(0, 0, -zcs_post[0]);

	LX.Set(FI, 0.0, FPVI10_10V, FPVI10_1A, RELAY_ON);
	delay_ms(3);

	DIOExpressWriteData(0x21, 0x00);
	delay_ms(1);
	dio.Disconnect();
	delay_ms(1);

	cbit.SetCBITOff(K5);//EN_to_op07_to_FOVI0
	delay_ms(3);
	cbit.SetCBITOn(K4);//FOVI0_to_EN
	delay_ms(3);
	
	VIN.Set(FV, 0.0, FPVI10_10V, FPVI10_1A, RELAY_ON);
	EN.Set(FV, 0.0, FOVI_10V, FOVI_10MA, RELAY_ON);
	VOUT.Set(FV, 0.0, FOVI_10V, FOVI_100MA, RELAY_ON);
	//I2CPUP.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_ON);
	LX.Set(FV, 0.0, FPVI10_10V, FPVI10_1A, RELAY_ON);
	delay_ms(3);

///ZCS_vin3p6_post
	LX.Set(FI, 0.0, FPVI10_10V, FPVI10_1A, RELAY_ON);
	VOUT.Set(FV, 3.6, FOVI_10V, FOVI_100MA, RELAY_ON);
	VIN.Set(FV, 3.6, FPVI10_10V, FPVI10_1A, RELAY_ON,3);
	delay_ms(10);
	EN.Set(FV, 3.6, FOVI_10V, FOVI_10MA, RELAY_ON,2);
	delay_ms(3);
	dio.Connect();
	delay_ms(3);

	DIOExpressWriteData(0x6a, 0x5a);
	delay_ms(1);
	DIOExpressWriteData(0x6a, 0xa5);
	delay_ms(1);

if (AllSimCOde == 1)
{
DIOExpressWriteData(0x47, vbg_code[0]);	delay_ms(1);
DIOExpressWriteData(0x40, vref_eaout_code[0]);	delay_ms(1);
DIOExpressWriteData(0x41, ibias_code[0] + fosc_code[0]);	delay_ms(1);
DIOExpressWriteData(0x48, rsns_code[0]);	delay_ms(1);
DIOExpressWriteData(0x42, hscl_code[0] + vcl_code[0]);	delay_ms(1);
DIOExpressWriteData(0x43, zcs_code[0] + ton_code[0]);		delay_ms(1);
}

	//	DIOExpressWriteData(0x23,0x90);
	//	delay_ms(3);
	//	DIOExpressReadData(0x29);
	//	delay_ms(1);

	EN.Set(FV, 0.0, FOVI_10V, FOVI_10MA, RELAY_ON);
	delay_ms(3);
	EN.Set(FI, 0.0, FOVI_10V, FOVI_100UA, RELAY_SENSE_ON);
	delay_ms(3);

cbit.SetCBITOn(K3);//EN_DIO
delay_ms(3);
DIOExpressWriteData(0x23, 0x90);   delay_ms(1);
Rdata1[0] = DIOExpressReadData(0x27);
ZCS_vin3p6_Reg27->SetTestResult(0, 0, (Rdata1[0] & 0x0F));


if (AllSimCOde == 2)
{
	Rdata1[0] = DIOExpressReadData(0x43);
	Rdata1[1] = Rdata1[0] & 0xF0;
	DIOExpressWriteData(0x43, zcs_code[0] + Rdata1[1]);	delay_ms(1);
}



cbit.SetCBITOff(K3);//EN_DIO

	cbit.SetCBITOff(K4);//FOVI0_to_EN
	delay_ms(3);
	cbit.SetCBITOn(K5);//EN_to_op07_to_FOVI0
	delay_ms(3);

	DIOExpressWriteData(0x25, 0x50);
	delay_ms(1);
	//DIOExpressWriteData(0x26,0xE0);
	delay_ms(1);
	DIOExpressWriteData(0x23, 0x8C);
	delay_ms(1);

	Trig_Point[0] = 0;
	Trig_Point[1] = 0;
	i = 0;
	m = 0;
	zcs_post[0] = 0;
	zcs_post[1] = 0;

	LX.Set(FI, -0.01, FPVI10_10V, FPVI10_1A, RELAY_ON);

	LX.AwgLoader("zcs_post", FI, FPVI10_10V, FPVI10_1A, zcs_Data, sam);
	LX.AwgSelect("zcs_post", 0, sam - 1, 0, interval);

	EN.SetMeasVTrig(Trig, TRIG_FALLING);
	EN.MeasureVI(sam, interval, MEAS_AWG);
	LX.MeasureVI(sam, interval, MEAS_AWG);

	/*
	STSEnableAWG(&LX);
	STSEnableMeas(&EN, &LX);
	STSAWGRunTriggerStop(&EN, &EN, &LX);
	//StsAWGRun();
	/*/
	VIN.MeasureVI(sam, interval, MEAS_AWG);
	STSEnableAWG(&LX);
	STSEnableMeas(&EN, &LX, &VIN);
	//STSAWGRunTriggerStop(&EN, &EN, &LX,&VIN);
	StsAWGRun();
	//*/

	Trig_Point[0] = EN.GetMeasResult(0, MVRET, TRIG_RESULT);
	m = Trig_Point[0] - 1;
	if (m<2)
	{
		zcs_post[0] = -777;
	}
	else if (m>sam - 3)
	{
		zcs_post[0] = -999;

	}
	else
	{
		zcs_post[0] = 1e3f*zcs_Data[m];//FPVIO+FPVI1

	}

	ZCS_vin3p6_post->SetTestResult(0, 0, -zcs_post[0]);

	LX.Set(FI, 0.0, FPVI10_10V, FPVI10_1A, RELAY_ON);
	delay_ms(3);

	DIOExpressWriteData(0x21, 0x00);
	delay_ms(1);
	dio.Disconnect();
	delay_ms(1);

	cbit.SetCBITOff(K5);//EN_to_op07_to_FOVI0
	delay_ms(3);
	cbit.SetCBITOn(K4);//FOVI0_to_EN
	delay_ms(3);

	VIN.Set(FV, 0.0, FPVI10_10V, FPVI10_1A, RELAY_ON);
	EN.Set(FV, 0.0, FOVI_10V, FOVI_10MA, RELAY_ON);
	VOUT.Set(FV, 0.0, FOVI_10V, FOVI_100MA, RELAY_ON);
	//I2CPUP.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_ON);
	LX.Set(FV, 0.0, FPVI10_10V, FPVI10_1A, RELAY_ON);
	delay_ms(3);

///ZCS_vin4p2_post
	LX.Set(FI, 0.0, FPVI10_10V, FPVI10_1A, RELAY_ON);
	VOUT.Set(FV, 4.2, FOVI_10V, FOVI_100MA, RELAY_ON);
	VIN.Set(FV, 4.2, FPVI10_10V, FPVI10_1A, RELAY_ON,3);
	delay_ms(10);
	EN.Set(FV, 3.6, FOVI_10V, FOVI_10MA, RELAY_ON,2);
	delay_ms(3);
	dio.Connect();
	delay_ms(3);

	DIOExpressWriteData(0x6a, 0x5a);
	delay_ms(1);
	DIOExpressWriteData(0x6a, 0xa5);
	delay_ms(1);

if (AllSimCOde == 1)
{
DIOExpressWriteData(0x47, vbg_code[0]);	delay_ms(1);
DIOExpressWriteData(0x40, vref_eaout_code[0]);	delay_ms(1);
DIOExpressWriteData(0x41, ibias_code[0] + fosc_code[0]);	delay_ms(1);
DIOExpressWriteData(0x48, rsns_code[0]);	delay_ms(1);
DIOExpressWriteData(0x42, hscl_code[0] + vcl_code[0]);	delay_ms(1);
DIOExpressWriteData(0x43, zcs_code[0] + ton_code[0]);		delay_ms(1);
}

	//	DIOExpressWriteData(0x23,0x90);
	//	delay_ms(3);
	//	DIOExpressReadData(0x29);
	//	delay_ms(1);

	EN.Set(FV, 0.0, FOVI_10V, FOVI_10MA, RELAY_ON);
	delay_ms(3);
	EN.Set(FI, 0.0, FOVI_10V, FOVI_100UA, RELAY_SENSE_ON);
	delay_ms(3);

cbit.SetCBITOn(K3);//EN_DIO
delay_ms(3);
DIOExpressWriteData(0x23, 0x90);   delay_ms(1);
Rdata1[0] = DIOExpressReadData(0x27);
ZCS_vin4p2_Reg27->SetTestResult(0, 0, (Rdata1[0] & 0x0F));


if (AllSimCOde == 2)
{
	Rdata1[0] = DIOExpressReadData(0x43);
	Rdata1[1] = Rdata1[0] & 0xF0;
	DIOExpressWriteData(0x43, zcs_code[0] + Rdata1[1]);	delay_ms(1);
}



cbit.SetCBITOff(K3);//EN_DIO

	cbit.SetCBITOff(K4);//FOVI0_to_EN
	delay_ms(3);
	cbit.SetCBITOn(K5);//EN_to_op07_to_FOVI0
	delay_ms(3);

	DIOExpressWriteData(0x25, 0x50);
	delay_ms(1);
	//DIOExpressWriteData(0x26,0xE0);
	delay_ms(1);
	DIOExpressWriteData(0x23, 0x8C);
	delay_ms(1);

	Trig_Point[0] = 0;
	Trig_Point[1] = 0;
	i = 0;
	m = 0;
	zcs_post[0] = 0;
	zcs_post[1] = 0;

	LX.Set(FI, -0.01, FPVI10_10V, FPVI10_1A, RELAY_ON);

	LX.AwgLoader("zcs_post", FI, FPVI10_10V, FPVI10_1A, zcs_Data, sam);
	LX.AwgSelect("zcs_post", 0, sam - 1, 0, interval);

	EN.SetMeasVTrig(Trig, TRIG_FALLING);
	EN.MeasureVI(sam, interval, MEAS_AWG);
	LX.MeasureVI(sam, interval, MEAS_AWG);

	/*
	STSEnableAWG(&LX);
	STSEnableMeas(&EN, &LX);
	STSAWGRunTriggerStop(&EN, &EN, &LX);
	//StsAWGRun();
	/*/
	VIN.MeasureVI(sam, interval, MEAS_AWG);
	STSEnableAWG(&LX);
	STSEnableMeas(&EN, &LX, &VIN);
	//STSAWGRunTriggerStop(&EN, &EN, &LX,&VIN);
	StsAWGRun();
	//*/

	Trig_Point[0] = EN.GetMeasResult(0, MVRET, TRIG_RESULT);
	m = Trig_Point[0] - 1;
	if (m<2)
	{
		zcs_post[0] = -777;
	}
	else if (m>sam - 3)
	{
		zcs_post[0] = -999;

	}
	else
	{
		zcs_post[0] = 1e3f*zcs_Data[m];//FPVIO+FPVI1

	}

	ZCS_vin4p2_post->SetTestResult(0, 0, -zcs_post[0]);

	LX.Set(FI, 0.0, FPVI10_10V, FPVI10_1A, RELAY_ON);
	delay_ms(3);

	DIOExpressWriteData(0x21, 0x00);
	delay_ms(1);
	dio.Disconnect();
	delay_ms(1);

	cbit.SetCBITOff(K5);//EN_to_op07_to_FOVI0
	delay_ms(3);
	cbit.SetCBITOn(K4);//FOVI0_to_EN
	delay_ms(3);

	VIN.Set(FV, 0.0, FPVI10_10V, FPVI10_1A, RELAY_ON);
	EN.Set(FV, 0.0, FOVI_10V, FOVI_10MA, RELAY_ON);
	VOUT.Set(FV, 0.0, FOVI_10V, FOVI_100MA, RELAY_ON);
	//I2CPUP.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_ON);
	LX.Set(FV, 0.0, FPVI10_10V, FPVI10_1A, RELAY_ON);
	delay_ms(3);

///ZCS_vin5p5_post
	LX.Set(FI, 0.0, FPVI10_10V, FPVI10_1A, RELAY_ON);
	VOUT.Set(FV, 3.6, FOVI_10V, FOVI_100MA, RELAY_ON);
	VIN.Set(FV, 5.5, FPVI10_10V, FPVI10_1A, RELAY_ON,3);
	delay_ms(10);
	EN.Set(FV, 3.6, FOVI_10V, FOVI_10MA, RELAY_ON,2);
	delay_ms(3);
	dio.Connect();
	delay_ms(3);

	DIOExpressWriteData(0x6a, 0x5a);
	delay_ms(1);
	DIOExpressWriteData(0x6a, 0xa5);
	delay_ms(1);

if (AllSimCOde == 1)
{
DIOExpressWriteData(0x47, vbg_code[0]);	delay_ms(1);
DIOExpressWriteData(0x40, vref_eaout_code[0]);	delay_ms(1);
DIOExpressWriteData(0x41, ibias_code[0] + fosc_code[0]);	delay_ms(1);
DIOExpressWriteData(0x48, rsns_code[0]);	delay_ms(1);
DIOExpressWriteData(0x42, hscl_code[0] + vcl_code[0]);	delay_ms(1);
DIOExpressWriteData(0x43, zcs_code[0] + ton_code[0]);		delay_ms(1);
}

	//	DIOExpressWriteData(0x23,0x90);
	//	delay_ms(3);
	//	DIOExpressReadData(0x29);
	//	delay_ms(1);

	EN.Set(FV, 0.0, FOVI_10V, FOVI_10MA, RELAY_ON);
	delay_ms(3);
	EN.Set(FI, 0.0, FOVI_10V, FOVI_100UA, RELAY_SENSE_ON);
	delay_ms(3);

cbit.SetCBITOn(K3);//EN_DIO
delay_ms(3);
DIOExpressWriteData(0x23, 0x90);   delay_ms(1);
Rdata1[0] = DIOExpressReadData(0x27);
ZCS_vin5p5_Reg27->SetTestResult(0, 0, (Rdata1[0] & 0x0F));


if (AllSimCOde == 2)
{
	Rdata1[0] = DIOExpressReadData(0x43);
	Rdata1[1] = Rdata1[0] & 0xF0;
	DIOExpressWriteData(0x43, zcs_code[0] + Rdata1[1]);	delay_ms(1);
}



cbit.SetCBITOff(K3);//EN_DIO

	cbit.SetCBITOff(K4);//FOVI0_to_EN
	delay_ms(3);
	cbit.SetCBITOn(K5);//EN_to_op07_to_FOVI0
	delay_ms(3);

	DIOExpressWriteData(0x25, 0x50);
	delay_ms(1);
	//DIOExpressWriteData(0x26,0xE0);
	delay_ms(1);
	DIOExpressWriteData(0x23, 0x8C);
	delay_ms(1);

	Trig_Point[0] = 0;
	Trig_Point[1] = 0;
	i = 0;
	m = 0;
	zcs_post[0] = 0;
	zcs_post[1] = 0;

	LX.Set(FI, -0.01, FPVI10_10V, FPVI10_1A, RELAY_ON);

	LX.AwgLoader("zcs_post", FI, FPVI10_10V, FPVI10_1A, zcs_Data, sam);
	LX.AwgSelect("zcs_post", 0, sam - 1, 0, interval);

	EN.SetMeasVTrig(Trig, TRIG_FALLING);
	EN.MeasureVI(sam, interval, MEAS_AWG);
	LX.MeasureVI(sam, interval, MEAS_AWG);

	/*
	STSEnableAWG(&LX);
	STSEnableMeas(&EN, &LX);
	STSAWGRunTriggerStop(&EN, &EN, &LX);
	//StsAWGRun();
	/*/
	VIN.MeasureVI(sam, interval, MEAS_AWG);
	STSEnableAWG(&LX);
	STSEnableMeas(&EN, &LX, &VIN);
	//STSAWGRunTriggerStop(&EN, &EN, &LX,&VIN);
	StsAWGRun();
	//*/

	Trig_Point[0] = EN.GetMeasResult(0, MVRET, TRIG_RESULT);
	m = Trig_Point[0] - 1;
	if (m<2)
	{
		zcs_post[0] = -777;
	}
	else if (m>sam - 3)
	{
		zcs_post[0] = -999;

	}
	else
	{
		zcs_post[0] = 1e3f*zcs_Data[m];//FPVIO+FPVI1

	}

	ZCS_vin5p5_post->SetTestResult(0, 0, -zcs_post[0]);

	LX.Set(FI, 0.0, FPVI10_10V, FPVI10_1A, RELAY_ON);
	delay_ms(3);

	DIOExpressWriteData(0x21, 0x00);
	delay_ms(1);
	dio.Disconnect();
	delay_ms(1);

	cbit.SetCBITOff(K5);//EN_to_op07_to_FOVI0
	delay_ms(3);
	cbit.SetCBITOn(K4);//FOVI0_to_EN
	delay_ms(3);

	VIN.Set(FV, 0.0, FPVI10_10V, FPVI10_1A, RELAY_ON);
	EN.Set(FV, 0.0, FOVI_10V, FOVI_10MA, RELAY_ON);
	VOUT.Set(FV, 0.0, FOVI_10V, FOVI_100MA, RELAY_ON);
	//I2CPUP.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_ON);
	LX.Set(FV, 0.0, FPVI10_10V, FPVI10_1A, RELAY_ON);
	delay_ms(3);

	VOUT.Set(FV, 0.0, FOVI_10V, FOVI_100MA, RELAY_OFF);
	LX.Set(FV, 0.0, FPVI10_10V, FPVI10_1A, RELAY_OFF);
	VIN.Set(FV, 0.0, FPVI10_10V, FPVI10_1A, RELAY_OFF);
	EN.Set(FV, 0.0, FOVI_10V, FOVI_10MA, RELAY_OFF);
	//I2CPUP.Set(FV, 0.0, FOVI_5V, FOVI_100MA, RELAY_OFF);
	delay_ms(3);
	cbit.SetOn(-1);
	delay_ms(3);

    return 0;
}


DUT_API int T27A_ZCS_Trim(short funcindex, LPCTSTR funclabel)
{
    //{{AFX_STS_PARAM_PROTOTYPES
    CParam *REG27_1 = StsGetParam(funcindex,"REG27_1");
    CParam *ZCS_pre = StsGetParam(funcindex,"ZCS_pre");
    CParam *ZCS_pre_err = StsGetParam(funcindex,"ZCS_pre_err");
    CParam *ZCS_code = StsGetParam(funcindex,"ZCS_code");
    CParam *REG27_2 = StsGetParam(funcindex,"REG27_2");
    CParam *ZCS_sim = StsGetParam(funcindex,"ZCS_sim");
    CParam *ZCS_sim_err = StsGetParam(funcindex,"ZCS_sim_err");
    //}}AFX_STS_PARAM_PROTOTYPES
if (adresult4[1] == 1)
{
	STSSetAlwaysRunFunction("T27B_ZCS_Trim");
	STSSetAlwaysRunFunction("T27C_ZCS_Trim");
	STSSetAlwaysRunFunction("T27D_ZCS_Trim");
	STSSetAlwaysRunFunction("T29_ZCS_Post2");
	STSSetAlwaysRunFunction("T52_CONTINUITY_Post");
}



    // TODO: Add your function code here
Rdata1[0]=0;
double VVINset =2.5;
	cbit.SetOn(K2/*,K3*/,K4,K8,K13,K11,/*K1,*/-1);//K3 is used for read
	delay_ms(3);
	dio.Connect();
	delay_ms(1);
VOUT.Set(FV, 0.0, FOVI_10V, FOVI_100MA, RELAY_ON);
VIN.Set(FV, 0.0, FPVI10_10V, FPVI10_1A, RELAY_ON);
EN.Set(FV, 0.0, FOVI_10V, FOVI_10MA, RELAY_ON);
delay_ms(3);
	//I2CPUP.Set(FV, 3.6, FOVI_10V, FOVI_100MA, RELAY_ON);
VOUT.Set(FV, VVINset, FOVI_10V, FOVI_100MA, RELAY_ON);
//MODE.Set(FV, 3.6, FOVI_10V, FOVI_10MA, RELAY_ON);
VIN.Set(FV, VVINset, FPVI10_10V, FPVI10_1A, RELAY_ON,3);
delay_ms(10);
	EN.Set(FV, 3.6, FOVI_10V, FOVI_10MA, RELAY_ON, 2);
	delay_ms(3);

	DIOExpressWriteData(0x6a,0x5a);
	delay_ms(1);
	DIOExpressWriteData(0x6a,0xa5);
	delay_ms(3);

	if (AllSimCOde == 1)
	{
		DIOExpressWriteData(0x47, vbg_code[0]);	delay_ms(1);
		DIOExpressWriteData(0x40, vref_eaout_code[0]);	delay_ms(1);
		DIOExpressWriteData(0x41, ibias_code[0] + fosc_code[0]);	delay_ms(1);
		DIOExpressWriteData(0x48, rsns_code[0]);	delay_ms(1);
		DIOExpressWriteData(0x42, hscl_code[0] + vcl_code[0]);	delay_ms(1);
		//DIOExpressWriteData(0x43,ton_code[0]);	delay_ms(1);
	}

//	DIOExpressWriteData(0x23,0x90);
//	delay_ms(3);
//	DIOExpressReadData(0x29);
//	delay_ms(1);

	EN.Set(FV, 0.0, FOVI_10V, FOVI_10MA, RELAY_ON);
	delay_ms(3);
	EN.Set(FI, 0.0, FOVI_10V, FOVI_100UA, RELAY_SENSE_ON);
	delay_ms(3);
cbit.SetCBITOn(K3);//EN_DIO
delay_ms(3);

DIOExpressWriteData(0x23,0x90);   delay_ms(1);
Rdata1[0] = DIOExpressReadData(0x27);
REG27_1->SetTestResult(0, 0, (Rdata1[0] & 0x0F));

cbit.SetCBITOff(K3);//EN_DIO
	cbit.SetCBITOff(K4);//FOVI0_to_EN
	delay_ms(3);
	cbit.SetCBITOn(K5);//EN_to_op07_to_FOVI0
	delay_ms(3);

	DIOExpressWriteData(0x25, 0x50);
	delay_ms(1);
	//DIOExpressWriteData(0x26,0xE0);
	//delay_ms(1);
	DIOExpressWriteData(0x23,0x8C);
	delay_ms(1);


	double Trig = 1;//trigger level
	double Trig_Point[2] = { 0 };
	double result[2] = { 0 };
	int sam = 101; //awgSize
	int interval = 200; //awgInterval��unit=us
	double zcs_Data[110] = { 0.0 };
	int i = 0;
	int	m = 0;

	double zcs_pre[2] = { 0 };
	double zcs_pre_err[2] = { 0 };

	LX.Set(FI, -0.01, FPVI10_10V, FPVI10_1A, RELAY_ON);

	STSAWGCreateRampData(&zcs_Data[0], sam, 1, -0.01, -0.21);
	LX.AwgLoader("zcs", FI, FPVI10_10V, FPVI10_1A, zcs_Data, sam);
	LX.AwgSelect("zcs", 0, sam - 1, 0, interval);


	EN.SetMeasVTrig(Trig, TRIG_FALLING);
	EN.MeasureVI(sam, interval, MEAS_AWG);
	LX.MeasureVI(sam, interval, MEAS_AWG);

	STSEnableAWG(&LX);
	STSEnableMeas(&EN, &LX);
	STSAWGRunTriggerStop(&EN, &EN, &LX);

	//	StsAWGRun();


		Trig_Point[0] = EN.GetMeasResult(0, MVRET, TRIG_RESULT);
		m = Trig_Point[0] - 1;
		if (m<2)
		{
			zcs_pre[0] = -777;
		}
		else if (m>sam - 3)
		{
			zcs_pre[0] = -999;

		}
		else
		{
			zcs_pre[0] = 1e3f*zcs_Data[m] ;//FPVIO+FPVI1

		}

		zcs_pre_err[0] = (zcs_pre[0] + zcs_target) / (-zcs_pre[0] + 1e-20f) * 100;

		ZCS_pre->SetTestResult(0, 0, -zcs_pre[0]);
		ZCS_pre_err->SetTestResult(0, 0, zcs_pre_err[0]);

	LX.Set(FI, 0.0, FPVI10_10V, FPVI10_1A, RELAY_ON);
	delay_ms(3);
	DIOExpressWriteData(0x21,0x00);
	delay_ms(1);
	dio.Disconnect();
	delay_ms(1);

	cbit.SetCBITOff(K5);//EN_to_op07_to_FOVI0
	delay_ms(3);
	cbit.SetCBITOn(K4);//FOVI0_to_EN
	delay_ms(3);

	VIN.Set(FV, 0.0, FPVI10_10V, FPVI10_1A, RELAY_ON);
	EN.Set(FV, 0.0, FOVI_10V, FOVI_100MA, RELAY_ON);
	//I2CPUP.Set(FV, 0.0, FOVI_10V, FOVI_100MA, RELAY_ON);
	//LX.Set(FV, 0.0, FPVI10_10V, FPVI10_1A, RELAY_ON);
	//MODE.Set(FV, 0.0, FOVI_10V, FOVI_10MA, RELAY_ON);
	delay_ms(3);
	cbit.SetOn(-1);
	delay_ms(3);

	if (zcs_pre_err[0] >= -70.0 && zcs_pre_err[0]<70.0)
		{
			if (zcs_pre_err[0] >= -4.55 && zcs_pre_err[0]< -1.14)		{ zcs_code[0] = 15; }//
			if (zcs_pre_err[0] >= -7.95 && zcs_pre_err[0]< -4.55)		{ zcs_code[0] = 14; }//
			if (zcs_pre_err[0] >= -11.36 && zcs_pre_err[0]< -7.95)		{ zcs_code[0] = 13; }//
			if (zcs_pre_err[0] >= -15.91 && zcs_pre_err[0]< -11.36)		{ zcs_code[0] = 12; }//
			if (zcs_pre_err[0] >= -19.32 && zcs_pre_err[0]< -15.91)		{ zcs_code[0] = 11; }//
			if (zcs_pre_err[0] >= -22.73 && zcs_pre_err[0]< -19.32)		{ zcs_code[0] = 10; }//
			if (zcs_pre_err[0] >= -26.14 && zcs_pre_err[0]< -22.73)		{ zcs_code[0] = 9; }//
			if (zcs_pre_err[0] >= -70.0 && zcs_pre_err[0]< -26.14)		{ zcs_code[0] = 8; }//

			if (zcs_pre_err[0] >= 25.0 && zcs_pre_err[0]< 70.0)			{ zcs_code[0] = 7; }//
			if (zcs_pre_err[0] >= 20.45 && zcs_pre_err[0]< 25.0)		{ zcs_code[0] = 6; }//
			if (zcs_pre_err[0] >= 17.05 && zcs_pre_err[0]< 20.45)		{ zcs_code[0] = 5; }//
			if (zcs_pre_err[0] >= 13.64 && zcs_pre_err[0]< 17.05)		{ zcs_code[0] = 4; }//
			if (zcs_pre_err[0] >= 9.09 && zcs_pre_err[0]< 13.64)		{ zcs_code[0] = 3; }//
			if (zcs_pre_err[0] >= 5.68 && zcs_pre_err[0]< 9.09)			{ zcs_code[0] = 2; }//
			if (zcs_pre_err[0] >= 2.27 && zcs_pre_err[0]< 5.68)			{ zcs_code[0] = 1; }//
			if (zcs_pre_err[0] >= -1.14 && zcs_pre_err[0]< 2.27)		{ zcs_code[0] = 0; }//
		}
		else
			zcs_code[0] = 0; //


		/******************* already trimmed dies -> set to reading of OTP ******************/
		if ((EN_OTP43_03_VD[0] == 0))
		{
			zcs_code[0] = OTP43_07_VD[0];
		}


	ZCS_code->SetTestResult(0, 0, zcs_code[0]);


	cbit.SetOn(K2,/*K3,*/K4,K8,K13,K11/*,K1*/,-1);//K3 is used for read
	delay_ms(3);
	dio.Connect();
	delay_ms(1);

VOUT.Set(FV, VVINset, FOVI_10V, FOVI_100MA, RELAY_ON);
//MODE.Set(FV, 3.6, FOVI_10V, FOVI_10MA, RELAY_ON);
	//I2CPUP.Set(FV, 3.6, FOVI_10V, FOVI_100MA, RELAY_ON);
VIN.Set(FV, VVINset, FPVI10_10V, FPVI10_1A, RELAY_ON, 3);
delay_ms(10);
	EN.Set(FV, 3.6, FOVI_10V, FOVI_10MA, RELAY_ON, 2);
	delay_ms(3);


	DIOExpressWriteData(0x6a,0x5a);
	delay_ms(1);
	DIOExpressWriteData(0x6a,0xa5);
	delay_ms(3);

	if (AllSimCOde == 1)
	{
		DIOExpressWriteData(0x47, vbg_code[0]);	delay_ms(1);
		DIOExpressWriteData(0x40, vref_eaout_code[0]);	delay_ms(1);
		DIOExpressWriteData(0x41, ibias_code[0] + fosc_code[0]);	delay_ms(1);
		DIOExpressWriteData(0x48, rsns_code[0]);	delay_ms(1);
		DIOExpressWriteData(0x42, hscl_code[0] + vcl_code[0]);	delay_ms(1);
		//DIOExpressWriteData(0x43,ton_code[0]);	delay_ms(1);
	}

//	DIOExpressWriteData(0x23,0x90);
//	delay_ms(3);
//	DIOExpressReadData(0x29);
//	delay_ms(1);

	EN.Set(FV, 0.0, FOVI_10V, FOVI_10MA, RELAY_ON);
	delay_ms(3);
	EN.Set(FI, 0.0, FOVI_10V, FOVI_100UA, RELAY_SENSE_ON);
	delay_ms(3);
cbit.SetCBITOn(K3);//EN_DIO
delay_ms(3);
DIOExpressWriteData(0x23,0x90);   delay_ms(1);
Rdata1[0] = DIOExpressReadData(0x27);
REG27_2->SetTestResult(0, 0, (Rdata1[0] & 0x0F));

cbit.SetCBITOff(K3);//EN_DIO
	cbit.SetCBITOff(K4);//FOVI0_to_EN
	delay_ms(3);
	cbit.SetCBITOn(K5);//EN_to_op07_to_FOVI0
	delay_ms(3);

	DIOExpressWriteData(0x25,0x50);
	delay_ms(1);
	//DIOExpressWriteData(0x26,0xE0);
	delay_ms(1);
	DIOExpressWriteData(0x23,0x8C);
	delay_ms(1);



	Trig = 1;//trigger level

	for(i=0;i<2;i++)
	{
	Trig_Point[i]=0;
	result[i]=0;
	}

	sam = 101; //awgSize
	interval = 200; //awgInterval��unit=us
	double zcs_sim_Data[110] = { 0.0 };
	i = 0;
	m = 0;

	double zcs_sim[2] = { 0 };
	double zcs_sim_err[2] = { 0 };

#if 1

	DIOExpressWriteData(0x43,zcs_code[0]);
	delay_ms(1);

	LX.Set(FI, -0.01, FPVI10_10V, FPVI10_1A, RELAY_ON);

	STSAWGCreateRampData(&zcs_sim_Data[0], sam, 1, -0.01, -0.21);
	LX.AwgLoader("zcs", FI, FPVI10_10V, FPVI10_1A, zcs_sim_Data, sam);
	LX.AwgSelect("zcs", 0, sam - 1, 0, interval);


	EN.SetMeasVTrig(Trig, TRIG_FALLING);
	EN.MeasureVI(sam, interval, MEAS_AWG);
	LX.MeasureVI(sam, interval, MEAS_AWG);

	STSEnableAWG(&LX);
	STSEnableMeas(&EN, &LX);
	STSAWGRunTriggerStop(&EN, &EN, &LX);

	//	StsAWGRun();


		Trig_Point[0] = EN.GetMeasResult(0, MVRET, TRIG_RESULT);
		m = Trig_Point[0] - 1;
		if (m<2)
		{
			zcs_sim[0] = -777;
		}
		else if (m>sam - 3)
		{
			zcs_sim[0] = -999;

		}
		else
		{
			zcs_sim[0] = 1e3f*zcs_sim_Data[m] ;//FPVIO+FPVI1

		}
#endif

#if 0
	int code[16]={0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15};
		
	double tempp[64]={0.0};

	for(i=0;i<2;i++)
	{
	Trig_Point[i]=0;
	result[i]=0;
	}
	dio.Connect();
	delay_ms(1);

	STSAWGCreateRampData(&zcs_sim_Data[0], sam, 1, -0.01, -0.21);
	LX.AwgLoader("zcs", FI, FPVI10_10V, FPVI10_1A, zcs_sim_Data, sam);
	LX.AwgSelect("zcs", 0, sam - 1, 0, interval);

	for(i=0;i<16;i++)
	{

	DIOExpressWriteData(0x43,code[i]);
	delay_ms(1);

	LX.Set(FI, -0.01, FPVI10_10V, FPVI10_1A, RELAY_ON);

	EN.SetMeasVTrig(Trig, TRIG_FALLING);
	EN.MeasureVI(sam, interval, MEAS_AWG);
	LX.MeasureVI(sam, interval, MEAS_AWG);

	STSEnableAWG(&LX);
	STSEnableMeas(&EN, &LX);
	STSAWGRunTriggerStop(&EN, &EN, &LX);

		Trig_Point[0] = EN.GetMeasResult(0, MVRET, TRIG_RESULT);
		m = Trig_Point[0] - 1;
		if (m<2)
		{
			zcs_sim[0] = -777;
		}
		else if (m>sam - 3)
		{
			zcs_sim[0] = -999;

		}
		else
		{
			tempp[i] = 1e3f*zcs_sim_Data[m] ;//FPVIO+FPVI1

		}

	LX.Set(FI, -0.0, FPVI10_10V, FPVI10_1A, RELAY_ON);
	delay_ms(3);
	}
#endif


	LX.Set(FI, 0.0, FPVI10_10V, FPVI10_1A, RELAY_ON);
	delay_ms(3);
	DIOExpressWriteData(0x21,0x00);
	delay_ms(1);
	dio.Disconnect();
	delay_ms(1);

	cbit.SetCBITOff(K5);//EN_to_op07_to_FOVI0
	delay_ms(3);
	cbit.SetCBITOn(K4);//FOVI0_to_EN
	delay_ms(3);

	VIN.Set(FV, 0.0, FPVI10_10V, FPVI10_1A, RELAY_ON);
	EN.Set(FV, 0.0, FOVI_10V, FOVI_100MA, RELAY_ON);
	//I2CPUP.Set(FV, 0.0, FOVI_10V, FOVI_100MA, RELAY_ON);
	LX.Set(FV, 0.0, FPVI10_10V, FPVI10_1A, RELAY_ON);
	//MODE.Set(FV, 0.0, FOVI_10V, FOVI_10MA, RELAY_ON);
	VOUT.Set(FV, 0.0, FOVI_10V, FOVI_100MA, RELAY_ON);
	delay_ms(3);
	//MODE.Set(FV, 0.0, FOVI_10V, FOVI_10MA, RELAY_OFF);
	VOUT.Set(FV, 0.0, FOVI_10V, FOVI_100MA, RELAY_OFF);
	VIN.Set(FV, 0.0, FPVI10_10V, FPVI10_1A, RELAY_OFF);
	EN.Set(FV, 0.0, FOVI_10V, FOVI_100MA, RELAY_OFF);
	//I2CPUP.Set(FV, 0.0, FOVI_10V, FOVI_100MA, RELAY_OFF);
	LX.Set(FV, 0.0, FPVI10_10V, FPVI10_1A, RELAY_OFF);
	delay_ms(3);

	zcs_sim_err[0] = (zcs_sim[0] + zcs_target) / (-zcs_sim[0] + 1e-20f) * 100;
	ZCS_sim->SetTestResult(0, 0, -zcs_sim[0]);
	ZCS_sim_err->SetTestResult(0, 0, zcs_sim_err[0]);

	cbit.SetOn(-1);
	delay_ms(3);
	
	
    return 0;
}


DUT_API int T27B_ZCS_Trim(short funcindex, LPCTSTR funclabel)
{
    //{{AFX_STS_PARAM_PROTOTYPES
    CParam *REG27_1 = StsGetParam(funcindex,"REG27_1");
    CParam *ZCS_pre = StsGetParam(funcindex,"ZCS_pre");
    CParam *ZCS_pre_err = StsGetParam(funcindex,"ZCS_pre_err");
    CParam *ZCS_code = StsGetParam(funcindex,"ZCS_code");
    CParam *REG27_2 = StsGetParam(funcindex,"REG27_2");
    CParam *ZCS_sim = StsGetParam(funcindex,"ZCS_sim");
    CParam *ZCS_sim_err = StsGetParam(funcindex,"ZCS_sim_err");
    //}}AFX_STS_PARAM_PROTOTYPES

    // TODO: Add your function code here
Rdata1[0]=0;
double VVINset =3.6;
cbit.SetOn(K2/*,K3*/, K4, K8, K13, K11,/*K1,*/-1);//K3 is used for read
delay_ms(3);
dio.Connect();
delay_ms(1);
VOUT.Set(FV, 0.0, FOVI_10V, FOVI_100MA, RELAY_ON);
VIN.Set(FV, 0.0, FPVI10_10V, FPVI10_1A, RELAY_ON);
EN.Set(FV, 0.0, FOVI_10V, FOVI_10MA, RELAY_ON);
delay_ms(3);
//I2CPUP.Set(FV, 3.6, FOVI_10V, FOVI_100MA, RELAY_ON);
VOUT.Set(FV, VVINset, FOVI_10V, FOVI_100MA, RELAY_ON);
//MODE.Set(FV, 3.6, FOVI_10V, FOVI_10MA, RELAY_ON);
VIN.Set(FV, VVINset, FPVI10_10V, FPVI10_1A, RELAY_ON, 3);
delay_ms(10);
EN.Set(FV, 3.6, FOVI_10V, FOVI_10MA, RELAY_ON, 2);
delay_ms(3);

DIOExpressWriteData(0x6a, 0x5a);
delay_ms(1);
DIOExpressWriteData(0x6a, 0xa5);
delay_ms(3);

if (AllSimCOde == 1)
{
	DIOExpressWriteData(0x47, vbg_code[0]);	delay_ms(1);
	DIOExpressWriteData(0x40, vref_eaout_code[0]);	delay_ms(1);
	DIOExpressWriteData(0x41, ibias_code[0] + fosc_code[0]);	delay_ms(1);
	DIOExpressWriteData(0x48, rsns_code[0]);	delay_ms(1);
	DIOExpressWriteData(0x42, hscl_code[0] + vcl_code[0]);	delay_ms(1);
	//DIOExpressWriteData(0x43,ton_code[0]);	delay_ms(1);
}

//	DIOExpressWriteData(0x23,0x90);
//	delay_ms(3);
//	DIOExpressReadData(0x29);
//	delay_ms(1);

EN.Set(FV, 0.0, FOVI_10V, FOVI_10MA, RELAY_ON);
delay_ms(3);
EN.Set(FI, 0.0, FOVI_10V, FOVI_100UA, RELAY_SENSE_ON);
delay_ms(3);
cbit.SetCBITOn(K3);//EN_DIO
delay_ms(3);

DIOExpressWriteData(0x23, 0x90);   delay_ms(1);
Rdata1[0] = DIOExpressReadData(0x27);
REG27_1->SetTestResult(0, 0, (Rdata1[0] & 0x0F));

cbit.SetCBITOff(K3);//EN_DIO
cbit.SetCBITOff(K4);//FOVI0_to_EN
delay_ms(3);
cbit.SetCBITOn(K5);//EN_to_op07_to_FOVI0
delay_ms(3);

DIOExpressWriteData(0x25, 0x50);
delay_ms(1);
//DIOExpressWriteData(0x26,0xE0);
//delay_ms(1);
DIOExpressWriteData(0x23, 0x8C);
delay_ms(1);


double Trig = 1;//trigger level
double Trig_Point[2] = { 0 };
double result[2] = { 0 };
int sam = 101; //awgSize
int interval = 200; //awgInterval��unit=us
double zcs_Data[110] = { 0.0 };
int i = 0;
int	m = 0;

double zcs_pre[2] = { 0 };
double zcs_pre_err[2] = { 0 };

LX.Set(FI, -0.01, FPVI10_10V, FPVI10_1A, RELAY_ON);

STSAWGCreateRampData(&zcs_Data[0], sam, 1, -0.01, -0.21);
LX.AwgLoader("zcs", FI, FPVI10_10V, FPVI10_1A, zcs_Data, sam);
LX.AwgSelect("zcs", 0, sam - 1, 0, interval);


EN.SetMeasVTrig(Trig, TRIG_FALLING);
EN.MeasureVI(sam, interval, MEAS_AWG);
LX.MeasureVI(sam, interval, MEAS_AWG);

STSEnableAWG(&LX);
STSEnableMeas(&EN, &LX);
STSAWGRunTriggerStop(&EN, &EN, &LX);

//	StsAWGRun();


Trig_Point[0] = EN.GetMeasResult(0, MVRET, TRIG_RESULT);
m = Trig_Point[0] - 1;
if (m<2)
{
	zcs_pre[0] = -777;
}
else if (m>sam - 3)
{
	zcs_pre[0] = -999;

}
else
{
	zcs_pre[0] = 1e3f*zcs_Data[m];//FPVIO+FPVI1

}

zcs_pre_err[0] = (zcs_pre[0] + zcs_target) / (-zcs_pre[0] + 1e-20f) * 100;

ZCS_pre->SetTestResult(0, 0, -zcs_pre[0]);
ZCS_pre_err->SetTestResult(0, 0, zcs_pre_err[0]);

LX.Set(FI, 0.0, FPVI10_10V, FPVI10_1A, RELAY_ON);
delay_ms(3);
DIOExpressWriteData(0x21, 0x00);
delay_ms(1);
dio.Disconnect();
delay_ms(1);

cbit.SetCBITOff(K5);//EN_to_op07_to_FOVI0
delay_ms(3);
cbit.SetCBITOn(K4);//FOVI0_to_EN
delay_ms(3);

VIN.Set(FV, 0.0, FPVI10_10V, FPVI10_1A, RELAY_ON);
EN.Set(FV, 0.0, FOVI_10V, FOVI_100MA, RELAY_ON);
//I2CPUP.Set(FV, 0.0, FOVI_10V, FOVI_100MA, RELAY_ON);
//LX.Set(FV, 0.0, FPVI10_10V, FPVI10_1A, RELAY_ON);
//MODE.Set(FV, 0.0, FOVI_10V, FOVI_10MA, RELAY_ON);
delay_ms(3);
cbit.SetOn(-1);
delay_ms(3);

if (zcs_pre_err[0] >= -70.0 && zcs_pre_err[0]<70.0)
{
	if (zcs_pre_err[0] >= -4.55 && zcs_pre_err[0]< -1.14)		{ zcs_code[0] = 15; }//
	if (zcs_pre_err[0] >= -7.95 && zcs_pre_err[0]< -4.55)		{ zcs_code[0] = 14; }//
	if (zcs_pre_err[0] >= -11.36 && zcs_pre_err[0]< -7.95)		{ zcs_code[0] = 13; }//
	if (zcs_pre_err[0] >= -15.91 && zcs_pre_err[0]< -11.36)		{ zcs_code[0] = 12; }//
	if (zcs_pre_err[0] >= -19.32 && zcs_pre_err[0]< -15.91)		{ zcs_code[0] = 11; }//
	if (zcs_pre_err[0] >= -22.73 && zcs_pre_err[0]< -19.32)		{ zcs_code[0] = 10; }//
	if (zcs_pre_err[0] >= -26.14 && zcs_pre_err[0]< -22.73)		{ zcs_code[0] = 9; }//
	if (zcs_pre_err[0] >= -70.0 && zcs_pre_err[0]< -26.14)		{ zcs_code[0] = 8; }//

	if (zcs_pre_err[0] >= 25.0 && zcs_pre_err[0]< 70.0)			{ zcs_code[0] = 7; }//
	if (zcs_pre_err[0] >= 20.45 && zcs_pre_err[0]< 25.0)		{ zcs_code[0] = 6; }//
	if (zcs_pre_err[0] >= 17.05 && zcs_pre_err[0]< 20.45)		{ zcs_code[0] = 5; }//
	if (zcs_pre_err[0] >= 13.64 && zcs_pre_err[0]< 17.05)		{ zcs_code[0] = 4; }//
	if (zcs_pre_err[0] >= 9.09 && zcs_pre_err[0]< 13.64)		{ zcs_code[0] = 3; }//
	if (zcs_pre_err[0] >= 5.68 && zcs_pre_err[0]< 9.09)			{ zcs_code[0] = 2; }//
	if (zcs_pre_err[0] >= 2.27 && zcs_pre_err[0]< 5.68)			{ zcs_code[0] = 1; }//
	if (zcs_pre_err[0] >= -1.14 && zcs_pre_err[0]< 2.27)		{ zcs_code[0] = 0; }//
}
else
zcs_code[0] = 0; //


/******************* already trimmed dies -> set to reading of OTP ******************/
if ((EN_OTP43_03_VD[0] == 0))
{
	zcs_code[0] = OTP43_07_VD[0];
}


ZCS_code->SetTestResult(0, 0, zcs_code[0]);


cbit.SetOn(K2,/*K3,*/K4, K8, K13, K11/*,K1*/, -1);//K3 is used for read
delay_ms(3);
dio.Connect();
delay_ms(1);

VOUT.Set(FV, VVINset, FOVI_10V, FOVI_100MA, RELAY_ON);
//MODE.Set(FV, 3.6, FOVI_10V, FOVI_10MA, RELAY_ON);
//I2CPUP.Set(FV, 3.6, FOVI_10V, FOVI_100MA, RELAY_ON);
VIN.Set(FV, VVINset, FPVI10_10V, FPVI10_1A, RELAY_ON, 3);
delay_ms(10);
EN.Set(FV, 3.6, FOVI_10V, FOVI_10MA, RELAY_ON, 2);
delay_ms(3);


DIOExpressWriteData(0x6a, 0x5a);
delay_ms(1);
DIOExpressWriteData(0x6a, 0xa5);
delay_ms(3);

if (AllSimCOde == 1)
{
	DIOExpressWriteData(0x47, vbg_code[0]);	delay_ms(1);
	DIOExpressWriteData(0x40, vref_eaout_code[0]);	delay_ms(1);
	DIOExpressWriteData(0x41, ibias_code[0] + fosc_code[0]);	delay_ms(1);
	DIOExpressWriteData(0x48, rsns_code[0]);	delay_ms(1);
	DIOExpressWriteData(0x42, hscl_code[0] + vcl_code[0]);	delay_ms(1);
	//DIOExpressWriteData(0x43,ton_code[0]);	delay_ms(1);
}

//	DIOExpressWriteData(0x23,0x90);
//	delay_ms(3);
//	DIOExpressReadData(0x29);
//	delay_ms(1);

EN.Set(FV, 0.0, FOVI_10V, FOVI_10MA, RELAY_ON);
delay_ms(3);
EN.Set(FI, 0.0, FOVI_10V, FOVI_100UA, RELAY_SENSE_ON);
delay_ms(3);
cbit.SetCBITOn(K3);//EN_DIO
delay_ms(3);
DIOExpressWriteData(0x23, 0x90);   delay_ms(1);
Rdata1[0] = DIOExpressReadData(0x27);
REG27_2->SetTestResult(0, 0, (Rdata1[0] & 0x0F));

cbit.SetCBITOff(K3);//EN_DIO
cbit.SetCBITOff(K4);//FOVI0_to_EN
delay_ms(3);
cbit.SetCBITOn(K5);//EN_to_op07_to_FOVI0
delay_ms(3);

DIOExpressWriteData(0x25, 0x50);
delay_ms(1);
//DIOExpressWriteData(0x26,0xE0);
delay_ms(1);
DIOExpressWriteData(0x23, 0x8C);
delay_ms(1);



Trig = 1;//trigger level

for (i = 0; i<2; i++)
{
	Trig_Point[i] = 0;
	result[i] = 0;
}

sam = 101; //awgSize
interval = 200; //awgInterval��unit=us
double zcs_sim_Data[110] = { 0.0 };
i = 0;
m = 0;

double zcs_sim[2] = { 0 };
double zcs_sim_err[2] = { 0 };

#if 1

DIOExpressWriteData(0x43, zcs_code[0]);
delay_ms(1);

LX.Set(FI, -0.01, FPVI10_10V, FPVI10_1A, RELAY_ON);

STSAWGCreateRampData(&zcs_sim_Data[0], sam, 1, -0.01, -0.21);
LX.AwgLoader("zcs", FI, FPVI10_10V, FPVI10_1A, zcs_sim_Data, sam);
LX.AwgSelect("zcs", 0, sam - 1, 0, interval);


EN.SetMeasVTrig(Trig, TRIG_FALLING);
EN.MeasureVI(sam, interval, MEAS_AWG);
LX.MeasureVI(sam, interval, MEAS_AWG);

STSEnableAWG(&LX);
STSEnableMeas(&EN, &LX);
STSAWGRunTriggerStop(&EN, &EN, &LX);

//	StsAWGRun();


Trig_Point[0] = EN.GetMeasResult(0, MVRET, TRIG_RESULT);
m = Trig_Point[0] - 1;
if (m<2)
{
	zcs_sim[0] = -777;
}
else if (m>sam - 3)
{
	zcs_sim[0] = -999;

}
else
{
	zcs_sim[0] = 1e3f*zcs_sim_Data[m] ;//FPVIO+FPVI1

}
#endif

#if 0
int code[16]={0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15};

double tempp[64]={0.0};

for(i=0;i<2;i++)
{
	Trig_Point[i]=0;
	result[i]=0;
}
dio.Connect();
delay_ms(1);

STSAWGCreateRampData(&zcs_sim_Data[0], sam, 1, -0.01, -0.21);
LX.AwgLoader("zcs", FI, FPVI10_10V, FPVI10_1A, zcs_sim_Data, sam);
LX.AwgSelect("zcs", 0, sam - 1, 0, interval);

for(i=0;i<16;i++)
{

	DIOExpressWriteData(0x43,code[i]);
	delay_ms(1);

	LX.Set(FI, -0.01, FPVI10_10V, FPVI10_1A, RELAY_ON);

	EN.SetMeasVTrig(Trig, TRIG_FALLING);
	EN.MeasureVI(sam, interval, MEAS_AWG);
	LX.MeasureVI(sam, interval, MEAS_AWG);

	STSEnableAWG(&LX);
	STSEnableMeas(&EN, &LX);
	STSAWGRunTriggerStop(&EN, &EN, &LX);

	Trig_Point[0] = EN.GetMeasResult(0, MVRET, TRIG_RESULT);
	m = Trig_Point[0] - 1;
	if (m<2)
	{
		zcs_sim[0] = -777;
	}
	else if (m>sam - 3)
	{
		zcs_sim[0] = -999;

	}
	else
	{
		tempp[i] = 1e3f*zcs_sim_Data[m] ;//FPVIO+FPVI1

}

	LX.Set(FI, -0.0, FPVI10_10V, FPVI10_1A, RELAY_ON);
	delay_ms(3);
	}
#endif


LX.Set(FI, 0.0, FPVI10_10V, FPVI10_1A, RELAY_ON);
delay_ms(3);
DIOExpressWriteData(0x21, 0x00);
delay_ms(1);
dio.Disconnect();
delay_ms(1);

cbit.SetCBITOff(K5);//EN_to_op07_to_FOVI0
delay_ms(3);
cbit.SetCBITOn(K4);//FOVI0_to_EN
delay_ms(3);

VIN.Set(FV, 0.0, FPVI10_10V, FPVI10_1A, RELAY_ON);
EN.Set(FV, 0.0, FOVI_10V, FOVI_100MA, RELAY_ON);
//I2CPUP.Set(FV, 0.0, FOVI_10V, FOVI_100MA, RELAY_ON);
LX.Set(FV, 0.0, FPVI10_10V, FPVI10_1A, RELAY_ON);
//MODE.Set(FV, 0.0, FOVI_10V, FOVI_10MA, RELAY_ON);
VOUT.Set(FV, 0.0, FOVI_10V, FOVI_100MA, RELAY_ON);
delay_ms(3);
//MODE.Set(FV, 0.0, FOVI_10V, FOVI_10MA, RELAY_OFF);
VOUT.Set(FV, 0.0, FOVI_10V, FOVI_100MA, RELAY_OFF);
VIN.Set(FV, 0.0, FPVI10_10V, FPVI10_1A, RELAY_OFF);
EN.Set(FV, 0.0, FOVI_10V, FOVI_100MA, RELAY_OFF);
//I2CPUP.Set(FV, 0.0, FOVI_10V, FOVI_100MA, RELAY_OFF);
LX.Set(FV, 0.0, FPVI10_10V, FPVI10_1A, RELAY_OFF);
delay_ms(3);

zcs_sim_err[0] = (zcs_sim[0] + zcs_target) / (-zcs_sim[0] + 1e-20f) * 100;
ZCS_sim->SetTestResult(0, 0, -zcs_sim[0]);
ZCS_sim_err->SetTestResult(0, 0, zcs_sim_err[0]);

cbit.SetOn(-1);
delay_ms(3);


    return 0;
}


DUT_API int T27C_ZCS_Trim(short funcindex, LPCTSTR funclabel)
{
    //{{AFX_STS_PARAM_PROTOTYPES
    CParam *REG27_1 = StsGetParam(funcindex,"REG27_1");
    CParam *ZCS_pre = StsGetParam(funcindex,"ZCS_pre");
    CParam *ZCS_pre_err = StsGetParam(funcindex,"ZCS_pre_err");
    CParam *ZCS_code = StsGetParam(funcindex,"ZCS_code");
    CParam *REG27_2 = StsGetParam(funcindex,"REG27_2");
    CParam *ZCS_sim = StsGetParam(funcindex,"ZCS_sim");
    CParam *ZCS_sim_err = StsGetParam(funcindex,"ZCS_sim_err");
    //}}AFX_STS_PARAM_PROTOTYPES

    // TODO: Add your function code here
Rdata1[0]=0;
double VVINset =4.2;
cbit.SetOn(K2/*,K3*/, K4, K8, K13, K11,/*K1,*/-1);//K3 is used for read
delay_ms(3);
dio.Connect();
delay_ms(1);
VOUT.Set(FV, 0.0, FOVI_10V, FOVI_100MA, RELAY_ON);
VIN.Set(FV, 0.0, FPVI10_10V, FPVI10_1A, RELAY_ON);
EN.Set(FV, 0.0, FOVI_10V, FOVI_10MA, RELAY_ON);
delay_ms(3);
//I2CPUP.Set(FV, 3.6, FOVI_10V, FOVI_100MA, RELAY_ON);
VOUT.Set(FV, VVINset, FOVI_10V, FOVI_100MA, RELAY_ON);
//MODE.Set(FV, 3.6, FOVI_10V, FOVI_10MA, RELAY_ON);
VIN.Set(FV, VVINset, FPVI10_10V, FPVI10_1A, RELAY_ON, 3);
delay_ms(10);
EN.Set(FV, 3.6, FOVI_10V, FOVI_10MA, RELAY_ON, 2);
delay_ms(3);

DIOExpressWriteData(0x6a, 0x5a);
delay_ms(1);
DIOExpressWriteData(0x6a, 0xa5);
delay_ms(3);

if (AllSimCOde == 1)
{
	DIOExpressWriteData(0x47, vbg_code[0]);	delay_ms(1);
	DIOExpressWriteData(0x40, vref_eaout_code[0]);	delay_ms(1);
	DIOExpressWriteData(0x41, ibias_code[0] + fosc_code[0]);	delay_ms(1);
	DIOExpressWriteData(0x48, rsns_code[0]);	delay_ms(1);
	DIOExpressWriteData(0x42, hscl_code[0] + vcl_code[0]);	delay_ms(1);
	//DIOExpressWriteData(0x43,ton_code[0]);	delay_ms(1);
}

//	DIOExpressWriteData(0x23,0x90);
//	delay_ms(3);
//	DIOExpressReadData(0x29);
//	delay_ms(1);

EN.Set(FV, 0.0, FOVI_10V, FOVI_10MA, RELAY_ON);
delay_ms(3);
EN.Set(FI, 0.0, FOVI_10V, FOVI_100UA, RELAY_SENSE_ON);
delay_ms(3);
cbit.SetCBITOn(K3);//EN_DIO
delay_ms(3);

DIOExpressWriteData(0x23, 0x90);   delay_ms(1);
Rdata1[0] = DIOExpressReadData(0x27);
REG27_1->SetTestResult(0, 0, (Rdata1[0] & 0x0F));

cbit.SetCBITOff(K3);//EN_DIO
cbit.SetCBITOff(K4);//FOVI0_to_EN
delay_ms(3);
cbit.SetCBITOn(K5);//EN_to_op07_to_FOVI0
delay_ms(3);

DIOExpressWriteData(0x25, 0x50);
delay_ms(1);
//DIOExpressWriteData(0x26,0xE0);
//delay_ms(1);
DIOExpressWriteData(0x23, 0x8C);
delay_ms(1);


double Trig = 1;//trigger level
double Trig_Point[2] = { 0 };
double result[2] = { 0 };
int sam = 101; //awgSize
int interval = 200; //awgInterval��unit=us
double zcs_Data[110] = { 0.0 };
int i = 0;
int	m = 0;

double zcs_pre[2] = { 0 };
double zcs_pre_err[2] = { 0 };

LX.Set(FI, -0.01, FPVI10_10V, FPVI10_1A, RELAY_ON);

STSAWGCreateRampData(&zcs_Data[0], sam, 1, -0.01, -0.21);
LX.AwgLoader("zcs", FI, FPVI10_10V, FPVI10_1A, zcs_Data, sam);
LX.AwgSelect("zcs", 0, sam - 1, 0, interval);


EN.SetMeasVTrig(Trig, TRIG_FALLING);
EN.MeasureVI(sam, interval, MEAS_AWG);
LX.MeasureVI(sam, interval, MEAS_AWG);

STSEnableAWG(&LX);
STSEnableMeas(&EN, &LX);
STSAWGRunTriggerStop(&EN, &EN, &LX);

//	StsAWGRun();


Trig_Point[0] = EN.GetMeasResult(0, MVRET, TRIG_RESULT);
m = Trig_Point[0] - 1;
if (m<2)
{
	zcs_pre[0] = -777;
}
else if (m>sam - 3)
{
	zcs_pre[0] = -999;

}
else
{
	zcs_pre[0] = 1e3f*zcs_Data[m];//FPVIO+FPVI1

}

zcs_pre_err[0] = (zcs_pre[0] + zcs_target) / (-zcs_pre[0] + 1e-20f) * 100;

ZCS_pre->SetTestResult(0, 0, -zcs_pre[0]);
ZCS_pre_err->SetTestResult(0, 0, zcs_pre_err[0]);

LX.Set(FI, 0.0, FPVI10_10V, FPVI10_1A, RELAY_ON);
delay_ms(3);
DIOExpressWriteData(0x21, 0x00);
delay_ms(1);
dio.Disconnect();
delay_ms(1);

cbit.SetCBITOff(K5);//EN_to_op07_to_FOVI0
delay_ms(3);
cbit.SetCBITOn(K4);//FOVI0_to_EN
delay_ms(3);

VIN.Set(FV, 0.0, FPVI10_10V, FPVI10_1A, RELAY_ON);
EN.Set(FV, 0.0, FOVI_10V, FOVI_100MA, RELAY_ON);
//I2CPUP.Set(FV, 0.0, FOVI_10V, FOVI_100MA, RELAY_ON);
//LX.Set(FV, 0.0, FPVI10_10V, FPVI10_1A, RELAY_ON);
//MODE.Set(FV, 0.0, FOVI_10V, FOVI_10MA, RELAY_ON);
delay_ms(3);
cbit.SetOn(-1);
delay_ms(3);

if (zcs_pre_err[0] >= -70.0 && zcs_pre_err[0]<70.0)
{
	if (zcs_pre_err[0] >= -4.55 && zcs_pre_err[0]< -1.14)		{ zcs_code[0] = 15; }//
	if (zcs_pre_err[0] >= -7.95 && zcs_pre_err[0]< -4.55)		{ zcs_code[0] = 14; }//
	if (zcs_pre_err[0] >= -11.36 && zcs_pre_err[0]< -7.95)		{ zcs_code[0] = 13; }//
	if (zcs_pre_err[0] >= -15.91 && zcs_pre_err[0]< -11.36)		{ zcs_code[0] = 12; }//
	if (zcs_pre_err[0] >= -19.32 && zcs_pre_err[0]< -15.91)		{ zcs_code[0] = 11; }//
	if (zcs_pre_err[0] >= -22.73 && zcs_pre_err[0]< -19.32)		{ zcs_code[0] = 10; }//
	if (zcs_pre_err[0] >= -26.14 && zcs_pre_err[0]< -22.73)		{ zcs_code[0] = 9; }//
	if (zcs_pre_err[0] >= -70.0 && zcs_pre_err[0]< -26.14)		{ zcs_code[0] = 8; }//

	if (zcs_pre_err[0] >= 25.0 && zcs_pre_err[0]< 70.0)			{ zcs_code[0] = 7; }//
	if (zcs_pre_err[0] >= 20.45 && zcs_pre_err[0]< 25.0)		{ zcs_code[0] = 6; }//
	if (zcs_pre_err[0] >= 17.05 && zcs_pre_err[0]< 20.45)		{ zcs_code[0] = 5; }//
	if (zcs_pre_err[0] >= 13.64 && zcs_pre_err[0]< 17.05)		{ zcs_code[0] = 4; }//
	if (zcs_pre_err[0] >= 9.09 && zcs_pre_err[0]< 13.64)		{ zcs_code[0] = 3; }//
	if (zcs_pre_err[0] >= 5.68 && zcs_pre_err[0]< 9.09)			{ zcs_code[0] = 2; }//
	if (zcs_pre_err[0] >= 2.27 && zcs_pre_err[0]< 5.68)			{ zcs_code[0] = 1; }//
	if (zcs_pre_err[0] >= -1.14 && zcs_pre_err[0]< 2.27)		{ zcs_code[0] = 0; }//
}
else
zcs_code[0] = 0; //


/******************* already trimmed dies -> set to reading of OTP ******************/
if ((EN_OTP43_03_VD[0] == 0))
{
	zcs_code[0] = OTP43_07_VD[0];
}


ZCS_code->SetTestResult(0, 0, zcs_code[0]);


cbit.SetOn(K2,/*K3,*/K4, K8, K13, K11/*,K1*/, -1);//K3 is used for read
delay_ms(3);
dio.Connect();
delay_ms(1);

VOUT.Set(FV, VVINset, FOVI_10V, FOVI_100MA, RELAY_ON);
//MODE.Set(FV, 3.6, FOVI_10V, FOVI_10MA, RELAY_ON);
//I2CPUP.Set(FV, 3.6, FOVI_10V, FOVI_100MA, RELAY_ON);
VIN.Set(FV, VVINset, FPVI10_10V, FPVI10_1A, RELAY_ON, 3);
delay_ms(10);
EN.Set(FV, 3.6, FOVI_10V, FOVI_10MA, RELAY_ON, 2);
delay_ms(3);


DIOExpressWriteData(0x6a, 0x5a);
delay_ms(1);
DIOExpressWriteData(0x6a, 0xa5);
delay_ms(3);

if (AllSimCOde == 1)
{
	DIOExpressWriteData(0x47, vbg_code[0]);	delay_ms(1);
	DIOExpressWriteData(0x40, vref_eaout_code[0]);	delay_ms(1);
	DIOExpressWriteData(0x41, ibias_code[0] + fosc_code[0]);	delay_ms(1);
	DIOExpressWriteData(0x48, rsns_code[0]);	delay_ms(1);
	DIOExpressWriteData(0x42, hscl_code[0] + vcl_code[0]);	delay_ms(1);
	//DIOExpressWriteData(0x43,ton_code[0]);	delay_ms(1);
}

//	DIOExpressWriteData(0x23,0x90);
//	delay_ms(3);
//	DIOExpressReadData(0x29);
//	delay_ms(1);

EN.Set(FV, 0.0, FOVI_10V, FOVI_10MA, RELAY_ON);
delay_ms(3);
EN.Set(FI, 0.0, FOVI_10V, FOVI_100UA, RELAY_SENSE_ON);
delay_ms(3);
cbit.SetCBITOn(K3);//EN_DIO
delay_ms(3);
DIOExpressWriteData(0x23, 0x90);   delay_ms(1);
Rdata1[0] = DIOExpressReadData(0x27);
REG27_2->SetTestResult(0, 0, (Rdata1[0] & 0x0F));

cbit.SetCBITOff(K3);//EN_DIO
cbit.SetCBITOff(K4);//FOVI0_to_EN
delay_ms(3);
cbit.SetCBITOn(K5);//EN_to_op07_to_FOVI0
delay_ms(3);

DIOExpressWriteData(0x25, 0x50);
delay_ms(1);
//DIOExpressWriteData(0x26,0xE0);
delay_ms(1);
DIOExpressWriteData(0x23, 0x8C);
delay_ms(1);



Trig = 1;//trigger level

for (i = 0; i<2; i++)
{
	Trig_Point[i] = 0;
	result[i] = 0;
}

sam = 101; //awgSize
interval = 200; //awgInterval��unit=us
double zcs_sim_Data[110] = { 0.0 };
i = 0;
m = 0;

double zcs_sim[2] = { 0 };
double zcs_sim_err[2] = { 0 };

#if 1

DIOExpressWriteData(0x43, zcs_code[0]);
delay_ms(1);

LX.Set(FI, -0.01, FPVI10_10V, FPVI10_1A, RELAY_ON);

STSAWGCreateRampData(&zcs_sim_Data[0], sam, 1, -0.01, -0.21);
LX.AwgLoader("zcs", FI, FPVI10_10V, FPVI10_1A, zcs_sim_Data, sam);
LX.AwgSelect("zcs", 0, sam - 1, 0, interval);


EN.SetMeasVTrig(Trig, TRIG_FALLING);
EN.MeasureVI(sam, interval, MEAS_AWG);
LX.MeasureVI(sam, interval, MEAS_AWG);

STSEnableAWG(&LX);
STSEnableMeas(&EN, &LX);
STSAWGRunTriggerStop(&EN, &EN, &LX);

//	StsAWGRun();


Trig_Point[0] = EN.GetMeasResult(0, MVRET, TRIG_RESULT);
m = Trig_Point[0] - 1;
if (m<2)
{
	zcs_sim[0] = -777;
}
else if (m>sam - 3)
{
	zcs_sim[0] = -999;

}
else
{
	zcs_sim[0] = 1e3f*zcs_sim_Data[m] ;//FPVIO+FPVI1

}
#endif

#if 0
int code[16]={0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15};

double tempp[64]={0.0};

for(i=0;i<2;i++)
{
	Trig_Point[i]=0;
	result[i]=0;
}
dio.Connect();
delay_ms(1);

STSAWGCreateRampData(&zcs_sim_Data[0], sam, 1, -0.01, -0.21);
LX.AwgLoader("zcs", FI, FPVI10_10V, FPVI10_1A, zcs_sim_Data, sam);
LX.AwgSelect("zcs", 0, sam - 1, 0, interval);

for(i=0;i<16;i++)
{

	DIOExpressWriteData(0x43,code[i]);
	delay_ms(1);

	LX.Set(FI, -0.01, FPVI10_10V, FPVI10_1A, RELAY_ON);

	EN.SetMeasVTrig(Trig, TRIG_FALLING);
	EN.MeasureVI(sam, interval, MEAS_AWG);
	LX.MeasureVI(sam, interval, MEAS_AWG);

	STSEnableAWG(&LX);
	STSEnableMeas(&EN, &LX);
	STSAWGRunTriggerStop(&EN, &EN, &LX);

	Trig_Point[0] = EN.GetMeasResult(0, MVRET, TRIG_RESULT);
	m = Trig_Point[0] - 1;
	if (m<2)
	{
		zcs_sim[0] = -777;
	}
	else if (m>sam - 3)
	{
		zcs_sim[0] = -999;

	}
	else
	{
		tempp[i] = 1e3f*zcs_sim_Data[m] ;//FPVIO+FPVI1

}

	LX.Set(FI, -0.0, FPVI10_10V, FPVI10_1A, RELAY_ON);
	delay_ms(3);
	}
#endif


LX.Set(FI, 0.0, FPVI10_10V, FPVI10_1A, RELAY_ON);
delay_ms(3);
DIOExpressWriteData(0x21, 0x00);
delay_ms(1);
dio.Disconnect();
delay_ms(1);

cbit.SetCBITOff(K5);//EN_to_op07_to_FOVI0
delay_ms(3);
cbit.SetCBITOn(K4);//FOVI0_to_EN
delay_ms(3);

VIN.Set(FV, 0.0, FPVI10_10V, FPVI10_1A, RELAY_ON);
EN.Set(FV, 0.0, FOVI_10V, FOVI_100MA, RELAY_ON);
//I2CPUP.Set(FV, 0.0, FOVI_10V, FOVI_100MA, RELAY_ON);
LX.Set(FV, 0.0, FPVI10_10V, FPVI10_1A, RELAY_ON);
//MODE.Set(FV, 0.0, FOVI_10V, FOVI_10MA, RELAY_ON);
VOUT.Set(FV, 0.0, FOVI_10V, FOVI_100MA, RELAY_ON);
delay_ms(3);
//MODE.Set(FV, 0.0, FOVI_10V, FOVI_10MA, RELAY_OFF);
VOUT.Set(FV, 0.0, FOVI_10V, FOVI_100MA, RELAY_OFF);
VIN.Set(FV, 0.0, FPVI10_10V, FPVI10_1A, RELAY_OFF);
EN.Set(FV, 0.0, FOVI_10V, FOVI_100MA, RELAY_OFF);
//I2CPUP.Set(FV, 0.0, FOVI_10V, FOVI_100MA, RELAY_OFF);
LX.Set(FV, 0.0, FPVI10_10V, FPVI10_1A, RELAY_OFF);
delay_ms(3);

zcs_sim_err[0] = (zcs_sim[0] + zcs_target) / (-zcs_sim[0] + 1e-20f) * 100;
ZCS_sim->SetTestResult(0, 0, -zcs_sim[0]);
ZCS_sim_err->SetTestResult(0, 0, zcs_sim_err[0]);

cbit.SetOn(-1);
delay_ms(3);


    return 0;
}


DUT_API int T27D_ZCS_Trim(short funcindex, LPCTSTR funclabel)
{
    //{{AFX_STS_PARAM_PROTOTYPES
    CParam *REG27_1 = StsGetParam(funcindex,"REG27_1");
    CParam *ZCS_pre = StsGetParam(funcindex,"ZCS_pre");
    CParam *ZCS_pre_err = StsGetParam(funcindex,"ZCS_pre_err");
    CParam *ZCS_code = StsGetParam(funcindex,"ZCS_code");
    CParam *REG27_2 = StsGetParam(funcindex,"REG27_2");
    CParam *ZCS_sim = StsGetParam(funcindex,"ZCS_sim");
    CParam *ZCS_sim_err = StsGetParam(funcindex,"ZCS_sim_err");
    //}}AFX_STS_PARAM_PROTOTYPES

    // TODO: Add your function code here
Rdata1[0]=0;
double VVINset =5.5;
cbit.SetOn(K2/*,K3*/, K4, K8, K13, K11,/*K1,*/-1);//K3 is used for read
delay_ms(3);
dio.Connect();
delay_ms(1);
//LX.Set(FI, 0.0, FPVI10_10V, FPVI10_1A, RELAY_ON);
VOUT.Set(FV, 0.0, FOVI_10V, FOVI_100MA, RELAY_ON);
VIN.Set(FV, 0.0, FPVI10_10V, FPVI10_1A, RELAY_ON);
EN.Set(FV, 0.0, FOVI_10V, FOVI_10MA, RELAY_ON);
delay_ms(3);
//I2CPUP.Set(FV, 3.6, FOVI_10V, FOVI_100MA, RELAY_ON);
VOUT.Set(FV, VVINset, FOVI_10V, FOVI_100MA, RELAY_ON);
//MODE.Set(FV, 3.6, FOVI_10V, FOVI_10MA, RELAY_ON);
VIN.Set(FV, VVINset, FPVI10_10V, FPVI10_1A, RELAY_ON, 3);
delay_ms(10);
EN.Set(FV, 3.6, FOVI_10V, FOVI_10MA, RELAY_ON, 2);
delay_ms(3);

DIOExpressWriteData(0x6a, 0x5a);
delay_ms(1);
DIOExpressWriteData(0x6a, 0xa5);
delay_ms(3);

if (AllSimCOde == 1)
{
	DIOExpressWriteData(0x47, vbg_code[0]);	delay_ms(1);
	DIOExpressWriteData(0x40, vref_eaout_code[0]);	delay_ms(1);
	DIOExpressWriteData(0x41, ibias_code[0] + fosc_code[0]);	delay_ms(1);
	DIOExpressWriteData(0x48, rsns_code[0]);	delay_ms(1);
	DIOExpressWriteData(0x42, hscl_code[0] + vcl_code[0]);	delay_ms(1);
	//DIOExpressWriteData(0x43,ton_code[0]);	delay_ms(1);
}

//	DIOExpressWriteData(0x23,0x90);
//	delay_ms(3);
//	DIOExpressReadData(0x29);
//	delay_ms(1);

EN.Set(FV, 0.0, FOVI_10V, FOVI_10MA, RELAY_ON);
delay_ms(3);
EN.Set(FI, 0.0, FOVI_10V, FOVI_100UA, RELAY_SENSE_ON);
delay_ms(3);
cbit.SetCBITOn(K3);//EN_DIO
delay_ms(3);

DIOExpressWriteData(0x23, 0x90);   delay_ms(1);
Rdata1[0] = DIOExpressReadData(0x27);
REG27_1->SetTestResult(0, 0, (Rdata1[0] & 0x0F));

cbit.SetCBITOff(K3);//EN_DIO
cbit.SetCBITOff(K4);//FOVI0_to_EN
delay_ms(3);
cbit.SetCBITOn(K5);//EN_to_op07_to_FOVI0
delay_ms(3);

DIOExpressWriteData(0x25, 0x50);
delay_ms(1);
//DIOExpressWriteData(0x26,0xE0);
//delay_ms(1);
DIOExpressWriteData(0x23, 0x8C);
delay_ms(1);


double Trig = 1;//trigger level
double Trig_Point[2] = { 0 };
double result[2] = { 0 };
int sam = 101; //awgSize
int interval = 200; //awgInterval��unit=us
double zcs_Data[110] = { 0.0 };
int i = 0;
int	m = 0;

double zcs_pre[2] = { 0 };
double zcs_pre_err[2] = { 0 };

LX.Set(FI, -0.01, FPVI10_10V, FPVI10_1A, RELAY_ON);

STSAWGCreateRampData(&zcs_Data[0], sam, 1, -0.01, -0.21);
LX.AwgLoader("zcs", FI, FPVI10_10V, FPVI10_1A, zcs_Data, sam);
LX.AwgSelect("zcs", 0, sam - 1, 0, interval);


EN.SetMeasVTrig(Trig, TRIG_FALLING);
EN.MeasureVI(sam, interval, MEAS_AWG);
LX.MeasureVI(sam, interval, MEAS_AWG);

STSEnableAWG(&LX);
STSEnableMeas(&EN, &LX);
STSAWGRunTriggerStop(&EN, &EN, &LX);

//	StsAWGRun();


Trig_Point[0] = EN.GetMeasResult(0, MVRET, TRIG_RESULT);
m = Trig_Point[0] - 1;
if (m<2)
{
	zcs_pre[0] = -777;
}
else if (m>sam - 3)
{
	zcs_pre[0] = -999;

}
else
{
	zcs_pre[0] = 1e3f*zcs_Data[m];//FPVIO+FPVI1

}

zcs_pre_err[0] = (zcs_pre[0] + zcs_target) / (-zcs_pre[0] + 1e-20f) * 100;

ZCS_pre->SetTestResult(0, 0, -zcs_pre[0]);
ZCS_pre_err->SetTestResult(0, 0, zcs_pre_err[0]);

LX.Set(FI, 0.0, FPVI10_10V, FPVI10_1A, RELAY_ON);
delay_ms(3);
DIOExpressWriteData(0x21, 0x00);
delay_ms(1);
dio.Disconnect();
delay_ms(1);

cbit.SetCBITOff(K5);//EN_to_op07_to_FOVI0
delay_ms(3);
cbit.SetCBITOn(K4);//FOVI0_to_EN
delay_ms(3);

VIN.Set(FV, 0.0, FPVI10_10V, FPVI10_1A, RELAY_ON);
EN.Set(FV, 0.0, FOVI_10V, FOVI_100MA, RELAY_ON);
//I2CPUP.Set(FV, 0.0, FOVI_10V, FOVI_100MA, RELAY_ON);
//LX.Set(FV, 0.0, FPVI10_10V, FPVI10_1A, RELAY_ON);
//MODE.Set(FV, 0.0, FOVI_10V, FOVI_10MA, RELAY_ON);
delay_ms(3);
cbit.SetOn(-1);
delay_ms(3);

if (zcs_pre_err[0] >= -70.0 && zcs_pre_err[0]<70.0)
{
	if (zcs_pre_err[0] >= -4.55 && zcs_pre_err[0]< -1.14)		{ zcs_code[0] = 15; }//
	if (zcs_pre_err[0] >= -7.95 && zcs_pre_err[0]< -4.55)		{ zcs_code[0] = 14; }//
	if (zcs_pre_err[0] >= -11.36 && zcs_pre_err[0]< -7.95)		{ zcs_code[0] = 13; }//
	if (zcs_pre_err[0] >= -15.91 && zcs_pre_err[0]< -11.36)		{ zcs_code[0] = 12; }//
	if (zcs_pre_err[0] >= -19.32 && zcs_pre_err[0]< -15.91)		{ zcs_code[0] = 11; }//
	if (zcs_pre_err[0] >= -22.73 && zcs_pre_err[0]< -19.32)		{ zcs_code[0] = 10; }//
	if (zcs_pre_err[0] >= -26.14 && zcs_pre_err[0]< -22.73)		{ zcs_code[0] = 9; }//
	if (zcs_pre_err[0] >= -70.0 && zcs_pre_err[0]< -26.14)		{ zcs_code[0] = 8; }//

	if (zcs_pre_err[0] >= 25.0 && zcs_pre_err[0]< 70.0)			{ zcs_code[0] = 7; }//
	if (zcs_pre_err[0] >= 20.45 && zcs_pre_err[0]< 25.0)		{ zcs_code[0] = 6; }//
	if (zcs_pre_err[0] >= 17.05 && zcs_pre_err[0]< 20.45)		{ zcs_code[0] = 5; }//
	if (zcs_pre_err[0] >= 13.64 && zcs_pre_err[0]< 17.05)		{ zcs_code[0] = 4; }//
	if (zcs_pre_err[0] >= 9.09 && zcs_pre_err[0]< 13.64)		{ zcs_code[0] = 3; }//
	if (zcs_pre_err[0] >= 5.68 && zcs_pre_err[0]< 9.09)			{ zcs_code[0] = 2; }//
	if (zcs_pre_err[0] >= 2.27 && zcs_pre_err[0]< 5.68)			{ zcs_code[0] = 1; }//
	if (zcs_pre_err[0] >= -1.14 && zcs_pre_err[0]< 2.27)		{ zcs_code[0] = 0; }//
}
else
zcs_code[0] = 0; //


/******************* already trimmed dies -> set to reading of OTP ******************/
if ((EN_OTP43_03_VD[0] == 0))
{
	zcs_code[0] = OTP43_07_VD[0];
}


ZCS_code->SetTestResult(0, 0, zcs_code[0]);


cbit.SetOn(K2,/*K3,*/K4, K8, K13, K11/*,K1*/, -1);//K3 is used for read
delay_ms(3);
dio.Connect();
delay_ms(1);

VOUT.Set(FV, VVINset, FOVI_10V, FOVI_100MA, RELAY_ON);
//MODE.Set(FV, 3.6, FOVI_10V, FOVI_10MA, RELAY_ON);
//I2CPUP.Set(FV, 3.6, FOVI_10V, FOVI_100MA, RELAY_ON);
VIN.Set(FV, VVINset, FPVI10_10V, FPVI10_1A, RELAY_ON, 3);
delay_ms(10);
EN.Set(FV, 3.6, FOVI_10V, FOVI_10MA, RELAY_ON, 2);
delay_ms(3);


DIOExpressWriteData(0x6a, 0x5a);
delay_ms(1);
DIOExpressWriteData(0x6a, 0xa5);
delay_ms(3);

if (AllSimCOde == 1)
{
	DIOExpressWriteData(0x47, vbg_code[0]);	delay_ms(1);
	DIOExpressWriteData(0x40, vref_eaout_code[0]);	delay_ms(1);
	DIOExpressWriteData(0x41, ibias_code[0] + fosc_code[0]);	delay_ms(1);
	DIOExpressWriteData(0x48, rsns_code[0]);	delay_ms(1);
	DIOExpressWriteData(0x42, hscl_code[0] + vcl_code[0]);	delay_ms(1);
	//DIOExpressWriteData(0x43,ton_code[0]);	delay_ms(1);
}

//	DIOExpressWriteData(0x23,0x90);
//	delay_ms(3);
//	DIOExpressReadData(0x29);
//	delay_ms(1);

EN.Set(FV, 0.0, FOVI_10V, FOVI_10MA, RELAY_ON);
delay_ms(3);
EN.Set(FI, 0.0, FOVI_10V, FOVI_100UA, RELAY_SENSE_ON);
delay_ms(3);
cbit.SetCBITOn(K3);//EN_DIO
delay_ms(3);
DIOExpressWriteData(0x23, 0x90);   delay_ms(1);
Rdata1[0] = DIOExpressReadData(0x27);
REG27_2->SetTestResult(0, 0, (Rdata1[0] & 0x0F));

cbit.SetCBITOff(K3);//EN_DIO
cbit.SetCBITOff(K4);//FOVI0_to_EN
delay_ms(3);
cbit.SetCBITOn(K5);//EN_to_op07_to_FOVI0
delay_ms(3);

DIOExpressWriteData(0x25, 0x50);
delay_ms(1);
//DIOExpressWriteData(0x26,0xE0);
delay_ms(1);
DIOExpressWriteData(0x23, 0x8C);
delay_ms(1);



Trig = 1;//trigger level

for (i = 0; i<2; i++)
{
	Trig_Point[i] = 0;
	result[i] = 0;
}

sam = 101; //awgSize
interval = 200; //awgInterval��unit=us
double zcs_sim_Data[110] = { 0.0 };
i = 0;
m = 0;

double zcs_sim[2] = { 0 };
double zcs_sim_err[2] = { 0 };

#if 1

DIOExpressWriteData(0x43, zcs_code[0]);
delay_ms(1);

LX.Set(FI, -0.01, FPVI10_10V, FPVI10_1A, RELAY_ON);

STSAWGCreateRampData(&zcs_sim_Data[0], sam, 1, -0.01, -0.21);
LX.AwgLoader("zcs", FI, FPVI10_10V, FPVI10_1A, zcs_sim_Data, sam);
LX.AwgSelect("zcs", 0, sam - 1, 0, interval);


EN.SetMeasVTrig(Trig, TRIG_FALLING);
EN.MeasureVI(sam, interval, MEAS_AWG);
LX.MeasureVI(sam, interval, MEAS_AWG);

STSEnableAWG(&LX);
STSEnableMeas(&EN, &LX);
STSAWGRunTriggerStop(&EN, &EN, &LX);

//	StsAWGRun();


Trig_Point[0] = EN.GetMeasResult(0, MVRET, TRIG_RESULT);
m = Trig_Point[0] - 1;
if (m<2)
{
	zcs_sim[0] = -777;
}
else if (m>sam - 3)
{
	zcs_sim[0] = -999;

}
else
{
	zcs_sim[0] = 1e3f*zcs_sim_Data[m];//FPVIO+FPVI1

}
#endif

#if 0
int code[16]={0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15};

double tempp[64]={0.0};

for(i=0;i<2;i++)
{
	Trig_Point[i]=0;
	result[i]=0;
}
dio.Connect();
delay_ms(1);

STSAWGCreateRampData(&zcs_sim_Data[0], sam, 1, -0.01, -0.21);
LX.AwgLoader("zcs", FI, FPVI10_10V, FPVI10_1A, zcs_sim_Data, sam);
LX.AwgSelect("zcs", 0, sam - 1, 0, interval);

for(i=0;i<16;i++)
{

	DIOExpressWriteData(0x43,code[i]);
	delay_ms(1);

	LX.Set(FI, -0.01, FPVI10_10V, FPVI10_1A, RELAY_ON);

	EN.SetMeasVTrig(Trig, TRIG_FALLING);
	EN.MeasureVI(sam, interval, MEAS_AWG);
	LX.MeasureVI(sam, interval, MEAS_AWG);

	STSEnableAWG(&LX);
	STSEnableMeas(&EN, &LX);
	STSAWGRunTriggerStop(&EN, &EN, &LX);

	Trig_Point[0] = EN.GetMeasResult(0, MVRET, TRIG_RESULT);
	m = Trig_Point[0] - 1;
	if (m<2)
	{
		zcs_sim[0] = -777;
	}
	else if (m>sam - 3)
	{
		zcs_sim[0] = -999;

	}
	else
	{
		tempp[i] = 1e3f*zcs_sim_Data[m] ;//FPVIO+FPVI1

	}

	LX.Set(FI, -0.0, FPVI10_10V, FPVI10_1A, RELAY_ON);
	delay_ms(3);
}
#endif


LX.Set(FI, 0.0, FPVI10_10V, FPVI10_1A, RELAY_ON);
delay_ms(3);
DIOExpressWriteData(0x21, 0x00);
delay_ms(1);
dio.Disconnect();
delay_ms(1);

cbit.SetCBITOff(K5);//EN_to_op07_to_FOVI0
delay_ms(3);
cbit.SetCBITOn(K4);//FOVI0_to_EN
delay_ms(3);

VIN.Set(FV, 0.0, FPVI10_10V, FPVI10_1A, RELAY_ON);
EN.Set(FV, 0.0, FOVI_10V, FOVI_100MA, RELAY_ON);
//I2CPUP.Set(FV, 0.0, FOVI_10V, FOVI_100MA, RELAY_ON);
LX.Set(FV, 0.0, FPVI10_10V, FPVI10_1A, RELAY_ON);
//MODE.Set(FV, 0.0, FOVI_10V, FOVI_10MA, RELAY_ON);
VOUT.Set(FV, 0.0, FOVI_10V, FOVI_100MA, RELAY_ON);
delay_ms(3);
//MODE.Set(FV, 0.0, FOVI_10V, FOVI_10MA, RELAY_OFF);
VOUT.Set(FV, 0.0, FOVI_10V, FOVI_100MA, RELAY_OFF);
VIN.Set(FV, 0.0, FPVI10_10V, FPVI10_1A, RELAY_OFF);
EN.Set(FV, 0.0, FOVI_10V, FOVI_100MA, RELAY_OFF);
//I2CPUP.Set(FV, 0.0, FOVI_10V, FOVI_100MA, RELAY_OFF);
LX.Set(FV, 0.0, FPVI10_10V, FPVI10_1A, RELAY_OFF);
delay_ms(3);

zcs_sim_err[0] = (zcs_sim[0] + zcs_target) / (-zcs_sim[0] + 1e-20f) * 100;
ZCS_sim->SetTestResult(0, 0, -zcs_sim[0]);
ZCS_sim_err->SetTestResult(0, 0, zcs_sim_err[0]);

cbit.SetOn(-1);
delay_ms(3);

return 0;
}
