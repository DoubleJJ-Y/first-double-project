// Setup
    rdk::CW("K2;K15;K13;K12").on().APPLY(); // MODE_MDM, EN_MMXH, VIN_CAP, VOUT_CAP 
	rdk::Timer::WAIT(1e-3);

	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").connect().power(ON).APPLY();
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").connect().power(ON).APPLY();
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("3.6V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").connect().power(ON).APPLY();
	DPIN_PMU_Set("MODE_mdm",VSIM_,"3.6V",R6V,M32mA,"32.0mA","-32.0mA",CLOSE_,ON_);
	DPIN_Levelset("MODE_mdm","3.6V", "0.0V", "1.8V", "1.8V",CLOSE_,ON_);
	rdk::Timer::WAIT(1e-3); 
	
	
// Test Mode In	
	I2C_Write(0x6A,0x5A); rdk::Timer::WAIT(1e-3); // enter test mode 
	I2C_Write(0x6A,0xA5); rdk::Timer::WAIT(3e-3); // enter test mode   

	//EN FLOAT 1
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").connect().power(ON).APPLY(); //EN Float-1
	rdk::MMXH::PMU("EN_mmxh_pmu").disconnect().power(OFF).APPLY(); // EN float-2
	rdk::Timer::WAIT(6e-3);
	
	//EN FLOAT 2
	rdk::MMXH::PMU("EN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").connect().power(ON).APPLY(); //EN Float-1
	rdk::MMXH::PMU("EN_mmxh_pmu").isvm("0.0mA",rdkenum::R300uA,rdkenum::R7V,"7.0V","-7V").connect().power(ON).APPLY(); //EN Float-2
	rdk::Timer::WAIT(3e-3);

	rdk::CW("K16").off().APPLY(); // EN_MMXH
	rdk::CW("K5").on().APPLY(); // OP7
	rdk::Timer::WAIT(3e-3);
	
	
	//I2C_Write(0x25,0x0D); rdk::Timer::WAIT(1e-3); // (T_DIS_LPWR=1, T_EA_OFFS=1, T_DISABLE_DRVR=1)
	//I2C_Write(0x23,0xC9); rdk::Timer::WAIT(1e-3); // (MUXSEL=2'b11,AD_MUXO_EN=1,ENMUX=3'b001)
	
	I2C_Write(0x40,VREF1V_OTP55_4to7_code); rdk::Timer::WAIT(1.0e-3); // OTP data write reg.


// Test Mode Out	
	I2C_Write(0x6A,0x00); rdk::Timer::WAIT(1e-3); // EXIT test mode


// clean up
	DPIN_Levelset("MODE_mdm",OPEN_,OFF_);
	
	rdk::MMXH::PMU("EN_mmxh_pmu").mvm(rdkenum::MMXH::PMU::VMRANGE::R2V).connect().power(OFF).APPLY();	
	//DPIN_PMU_Set("MODE_mdm",VSIM_,"0.0V",R6V,M32mA,"32.0mA","-32.0mA",CLOSE_,ON_);
	//rdk::MMXH::PMU("EN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R300uA,"100.0uA","-100.0uA").connect().power(ON).APPLY();
	rdk::MMXH::PMU("VIN_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").connect().power(ON).APPLY();
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim("0.0V",rdkenum::R7V,rdkenum::R240mA,"100.0mA","-100.0mA").connect().power(ON).APPLY();
	rdk::Timer::WAIT(3e-3);
	rdk::MMXH::PMU("EN_mmxh_pmu").disconnect().power(OFF).APPLY();	
	rdk::MMXH::PMU("VIN_mmxh_pmu").disconnect().power(OFF).APPLY();	
	rdk::MMXH::PMU("VOUT_mmxh_pmu").disconnect().power(OFF).APPLY();	
	rdk::Timer::WAIT(3e-3);	
	rdk::CW("K_ALL").off().APPLY();
	rdk::Timer::WAIT(3e-3);

//Judge
	result |= Judge(1001,"Ron_5V_VVIN", "RDSON_LS.Ron_5V_VVIN", meas_HS_VIN_V[0],"SoftBins.BIN15"); if(RscDUTs(DUT_ACTIVE).isEmpty())return result; 


// Pre measure
	rdk::MMXH::PMU("EN_mmxh_pmu").mvm(rdkenum::MMXH::PMU::VMRANGE::R2V).connect().power(ON).APPLY();	
	rdk::Timer::WAIT(5e-3);
	BGR_pre = rdk::MMXH::PMU("EN_mmxh_pmu").MEAS_V(100);	
	
	
//Ramp up VOUT
/************************************************************************************/ 
	ValDUT FORCE("7.0V");
	ValDUT FORCE_V = FORCE * EN_OTP56_57_VD;  // fresh die(EN_OTP7_VD=1), trimmed die(EN_OTP1_VD=0)

	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim(FORCE_V*0.71,rdkenum::R7V,rdkenum::R240mA,"200.0mA","-200.0mA").connect().power(ON).APPLY();rdk::Timer::WAIT(1e-3);
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim(FORCE_V*0.79,rdkenum::R7V,rdkenum::R240mA,"200.0mA","-200.0mA").connect().power(ON).APPLY();rdk::Timer::WAIT(1e-3);
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim(FORCE_V*0.86,rdkenum::R7V,rdkenum::R240mA,"200.0mA","-200.0mA").connect().power(ON).APPLY();rdk::Timer::WAIT(1e-3);
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim(FORCE_V*0.93,rdkenum::R7V,rdkenum::R240mA,"200.0mA","-200.0mA").connect().power(ON).APPLY();rdk::Timer::WAIT(1e-3);
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim(FORCE_V*1.0,rdkenum::R7V,rdkenum::R240mA,"200.0mA","-200.0mA").connect().power(ON).APPLY();rdk::Timer::WAIT(1e-3);//6. Ramp up Vout from 5V to 7V in 0.5ms.

/************************************************************************************/ 

	I2C_Write(0x21,0x0B); rdk::Timer::WAIT(2e-3); //7. Write 0x21 = 0x0B to program the OTP(BURN_EN=1). 8. Wait 1ms.
	I2C_Write(0x21,0x09); rdk::Timer::WAIT(2e-3); //9. Write 0x21 = 0x09 to stop OTP programming.

//Ramp down VOUT //10. Ramp down Vout from 7V to 5V in 0.5ms.
/************************************************************************************/ 
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim(FORCE_V*1.0,rdkenum::R7V,rdkenum::R240mA,"200.0mA","-200.0mA").connect().power(ON).APPLY();rdk::Timer::WAIT(1e-3);
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim(FORCE_V*0.93,rdkenum::R7V,rdkenum::R240mA,"200.0mA","-200.0mA").connect().power(ON).APPLY();rdk::Timer::WAIT(1e-3);
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim(FORCE_V*0.86,rdkenum::R7V,rdkenum::R240mA,"200.0mA","-200.0mA").connect().power(ON).APPLY();rdk::Timer::WAIT(1e-3);
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim(FORCE_V*0.79,rdkenum::R7V,rdkenum::R240mA,"200.0mA","-200.0mA").connect().power(ON).APPLY();rdk::Timer::WAIT(1e-3);
	rdk::MMXH::PMU("VOUT_mmxh_pmu").vsim(FORCE_V*0.71,rdkenum::R7V,rdkenum::R240mA,"200.0mA","-200.0mA").connect().power(ON).APPLY();rdk::Timer::WAIT(1e-3);// 7*0.71 = 5V 
/************************************************************************************/
I2C_Write(0x6A,0x00); rdk::Timer::WAIT(1e-3); // EXIT test mode	
	
if(RscDUT("1").isActive()||RscDUT("2").isActive()||RscDUT("5").isActive()||RscDUT("6").isActive()||RscDUT("9").isActive()||RscDUT("10").isActive())
{
 mask_if_active("3,4,7,8,11,12");
 
 unmask_if_masked("3,4,7,8,11,12");
 	unmask_if_masked("1,2,5,6,9,10");
}

if(RscDUT("3").isActive()||RscDUT("4").isActive()||RscDUT("7").isActive()||RscDUT("8").isActive()||RscDUT("11").isActive()||RscDUT("12").isActive())
{
    mask_if_active("1,2,5,6,9,10");

	unmask_if_masked("1,2,5,6,9,10");
}



//Digitizer.
	PinDUTDoubleArray DGT_OUT;
	
	
	DGT_Lvlset("OUT_mmxh_dgt",VM_,M4V,"10KHz",16000);
	DGT_Start("OUT_mmxh_dgt");
	//관찰할 구문
	DGT_Dataread("OUT_mmxh_dgt",DGT_OUT);
	unmask_if_masked("3,4,7,8,11,12");
	
	
//DLG OUT
dlgout <<"DUT"<<*itrDut<<" V_data_100uA : "<< V_data[0][*itrDut]<<" R_data_100uA :"<< R_data[0][*itrDut]<<"\n";	


///Sim Search
//for(int i=0; i<16; i++)
//{
//	int IN_Data = i *16;
//
//    I2C_Write(0x43,IN_Data); 
//	rdk::Timer::WAIT(10e-3); // ( DIS_LPWR=1);
//
//    //I2C_Write(0x43,ton_code); 
//	//rdk::Timer::WAIT(10e-3); // ( DIS_LPWR=1);
//
//	//DGT_Lvlset("LX_mfhp_dgt",VM_,"1.9MHz",16000); //Max 1MHz, 0~16000
//	//DGT_Start("LX_mfhp_dgt");
//	//rdk::Timer::WAIT(100e-3);
//	//DGT_Stop("LX_mfhp_dgt");
//
//// sim measure
//	rdk::Digital::Pin("BUF_mmxh_dcl").vohl("2.0V","1.0V").connect().power(ON).APPLY(); 
//	rdk::MMXH::TMU("BUF_mmxh_tmu").event(rdkenum::COMPVOL_HIRES_FALL).count(2).trigger(rdkenum::START,rdkenum::SOFT,"NONE",rdkenum::FALLING).APPLY();
//
//	RscTMUPin tmu_a("BUF_mmxh_tmu"); tmu_a.setCondition("TimeOut","100.0mS"); // setting time-out
//	
//	rdk::MMXH::TMU("BUF_mmxh_tmu").START().WAIT_ACQ("30mS");
//	rdk::MMXH::TMU("BUF_mmxh_tmu").STOP();
//	rdk::MMXH::TMU("BUF_mmxh_tmu").GET_RESULT_FREQ(TON_pre,rdkenum::COMPVOL_FALL);
//
//    for(ItrDUTs itrDut(DUT_ACTIVE); !itrDut.isDone(); itrDut++) 
//	{
//		TON_pre2[i][*itrDut] = TON_pre[*itrDut].getAsDouble();
//    	TON_pre_err2[i][*itrDut] = (TON_target - TON_pre[*itrDut].getAsDouble()) / (TON_pre[*itrDut].getAsDouble()) ; 
//    }
//	dlgout<<fixed;
//	dlgout.precision(2);
//	dlgout<<"Data = "<<IN_Data<<"   TON = "<<TON_pre<<endl;
//}
//
//	ValDUT ton_code2 = 0;
//	double min = 99999.0;
//    for(ItrDUTs itrDut(DUT_ACTIVE); !itrDut.isDone(); itrDut++) 
//	{
//
//		min = 999999999999.0;
//		for(int cnt=0; cnt<16; cnt++)
//		{
//			if(min > fabs(TON_pre2[cnt][*itrDut].getAsDouble() - TON_target))
//			{
//				min = fabs(TON_pre2[cnt][*itrDut].getAsDouble() - TON_target);
//				ton_code2[*itrDut] = cnt * 16;
//				TON_pre_err[*itrDut] = TON_pre_err2[cnt][*itrDut].getAsDouble();
//				dlgout<<"site"<<*itrDut<<"   Data = "<<cnt*16<<"   TON = "<<TON_pre2[cnt][*itrDut].getAsDouble()<<endl;
//			}		
//		}
//	}


/////////////////////Sort and Midian/////////////////////////////////////////////
int TPG::quicksort(double *a, int m, int n) 
 { 
     int index; 
     if(m>=n) 
         return 0; 
     { 
         index = partition(a,m,n); 
         quicksort(a, m, index-1); 
         quicksort(a, index+1, n); 
     } 

	 return 1;
 } 
 
 
 // pre measure
	rdk::Digital::Pin("BUF_mmxh_dcl").vohl("2.0V","1.0V").connect().power(ON).APPLY(); 
	rdk::MMXH::TMU("BUF_mmxh_tmu").event(rdkenum::COMPVOL_HYS_RISE).count(5).trigger(rdkenum::START,rdkenum::SOFT,"NONE",rdkenum::RISING).APPLY();
	RscTMUPin tmu_a("BUF_mmxh_tmu"); tmu_a.setCondition("TimeOut","10.0mS"); // setting time-out

	OFCArray<ValDUT> TON_pre2(99,0); 
	for(int i=0; i<5; i++)
	{
		rdk::MMXH::TMU("BUF_mmxh_tmu").START().WAIT_ACQ("1mS");
		rdk::MMXH::TMU("BUF_mmxh_tmu").STOP();
		rdk::MMXH::TMU("BUF_mmxh_tmu").GET_RESULT_FREQ(TON_pre2[i],rdkenum::COMPVOL_RISE);
	}
	for(ItrDUTs itrDut(DUT_ACTIVE); !itrDut.isDone(); itrDut++) 
	{
		double SortData[5];
		for(int mcnt = 0; mcnt < 5; mcnt++) SortData[mcnt] = TON_pre2[mcnt][*itrDut].getAsDouble();
		quicksort(SortData,0,5-1);
		TON_pre[*itrDut] = SortData[2];
	}
/////////////////////Time measure////////////

	 rdk::timer::start(); 
	 dlgout.precision(3);
	 dlgout<<time<<endl;
/////////////////////////////////////////////



//16진수 변환 ///////////////////////////////////////////
//HEX_code[i][*itrDut] = Dec_to_hex(IREF_code[i][*itrDut],"U");

/////////////////////////